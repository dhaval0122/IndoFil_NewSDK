import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/DatePicker.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchThirdScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

// ignore: must_be_immutable
class EditDOScreen extends StatefulWidget {
  String displayName;

  EditDOScreen({this.displayName});

  @override
  EditDOScreenState createState() => EditDOScreenState();
}

class EditDOScreenState extends State<EditDOScreen>
    implements WSInterface, PushNotificationListener {
  EditDOScreenState() {
    wsPresenter = WSPresenter(this);
  }

  //GlobalKey<ScaffoldState> _key = GlobalKey();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _loading = false,
      loadingFlag = false,
      isShowFilterView = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '', subTitle = 'Edit DO';
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  TextEditingController fromDateController, toDateController, doStoController;
  DateTime selectedFromDate, selectedToDate;
  DateTime currentDateTime = DateTime.now();
  final FocusNode _donoFocus = FocusNode();
  String dateFormatAPI = '';
  WSPresenter wsPresenter;
  List<EditDoModel> editDOList;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    print("in initState");

    _initLoading();

    editDOList = List();
    fromDateController = TextEditingController();
    toDateController = TextEditingController();
    doStoController = TextEditingController();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    setUpDate();

    insertLogDetails();

  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_EDO');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }


  void setUpDate() {
    //print("in setUpDate ");
    selectedToDate = DateTime.now();
    //print('===calendarToDate====${selectedToDate.toString()}');
    selectedFromDate = DateTime(selectedToDate.year, selectedToDate.month, 1);
    //print('===calendarFromDate====${selectedFromDate.toString()}');

    sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
      dateFormatAPI = dateFormat;
      final String fromDateValues =
          mUtils.convertDateFormat(selectedFromDate, dateFormat);
      final String toDateValues =
          mUtils.convertDateFormat(selectedToDate, dateFormat);
      if (mounted) {
        setState(() {
          fromDateController.text = fromDateValues;
          toDateController.text = toDateValues;
        });

        //print("in setUpDate END");
        loadEditDoRecord();
      }
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
              // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void _setDate(bool isFromDate) {
    final DateTime minDate = DateTime(1970, 1, 1);
    DatePicker.showDatePicker(context,
        showTitleActions: true,
        minTime: isFromDate ? minDate : selectedFromDate,
        // ignore: avoid_types_as_parameter_names
        maxTime: currentDateTime, onConfirm: (DateTime) {
      final String monthValues = DateTime.month.toString().length > 1
          ? DateTime.month.toString()
          : '0${DateTime.month}';

      final String dayValues = DateTime.day.toString().length > 1
          ? DateTime.day.toString()
          : '0${DateTime.day}';

      if (isFromDate) {
        final String dateValues =
            '$monthValues' + '/$dayValues' + '/${DateTime.year}';
        selectedFromDate = DateTime;
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          fromDateController.text =
              mUtils.convertDateTimeDisplay(dateValues, dateFormat);
        });

        selectedToDate = mUtils.getActualMaxDate(selectedFromDate);
        final String monthValues1 = selectedToDate.month.toString().length > 1
            ? selectedToDate.month.toString()
            : '0${selectedToDate.month}';
        final String dayValues1 = selectedToDate.day.toString().length > 1
            ? selectedToDate.day.toString()
            : '0${selectedToDate.day}';

        final String dateToValues =
            '$monthValues1' + '/$dayValues1' + '/${selectedToDate.year}';
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          toDateController.text =
              mUtils.convertDateTimeDisplay(dateToValues, dateFormat);
        });
      } else {
        final String dateValues =
            '$monthValues' + '/$dayValues' + '/${DateTime.year}';
        selectedToDate = DateTime;
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          toDateController.text =
              mUtils.convertDateTimeDisplay(dateValues, dateFormat);
        });
      }
    },
        currentTime: isFromDate ? selectedFromDate : selectedToDate,
        locale: LocaleType.en);
  }

  void _snackBar(String text) {
    _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void loadEditDoRecord() {
    FocusScope.of(mContext).requestFocus(FocusNode());
    /*if (fromDateController.text.length > 0 ||
        toDateController.text.length > 0 ||
        doStoController.text.trim().length > 0) {*/
    if (fromDateController.text.isNotEmpty ||
        toDateController.text.isNotEmpty ||
        doStoController.text.trim().isNotEmpty) {
      _battery.checkInternet().then((String isConnection) {
        if (isConnection.contains('true')) {
          //show Dialog
          setState(() {
            loadingFlag = true;
          });

          Future.delayed(const Duration(milliseconds: 700), () {
            sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
              sharedPrefs
                  .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                  .then((int fkMainCustomerGlCode) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  sharedPrefs
                      .getString(PREF_DATE_FORMAT)
                      .then((String dateformat) {
                    var param = Map();
                    param[PARAM_PERSON_ID] = fkMainCustomerGlCode.toString();
                    param['LoginBy'] = initGlCode;
                    param['DONo'] = doStoController.text != null
                        ? doStoController.text
                        : '';
                    param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                        ? SUB_MODULE_NAME_ANDROID
                        : SUB_MODULE_NAME_IOS;
                    param[PARAM_VERSION] = APP_VERSION;
                    param[PARAM_API_TOKEN] = apiToken;
                    //if (fromDateController.text.length > 0) {
                    if (fromDateController.text.isNotEmpty) {
                      param['FromDate'] = mUtils.convertDateTime(
                          fromDateController.text, dateformat);
                    } else {
                      param['FromDate'] = '';
                    }

                    //if (toDateController.text.length > 0) {
                    if (toDateController.text.isNotEmpty) {
                      param['ToDate'] = mUtils.convertDateTime(
                          toDateController.text, dateformat);
                    } else {
                      param['ToDate'] = '';
                    }
                    sharedPrefs
                        .getString(PREF_DEVICE_ID)
                        .then((String deviceid) {
                      param[PARAM_DEVICE_ID] = deviceid;
                      print(param);
                      wsPresenter.callAPI(POST_METHOD, EDIT_DO, param);
                    });
                  });
                });
              });
            });
          });
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content:
                    LocaleUtils.getString(mContext, 'no_internet_connection'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: 'Ok',
                onPressedNegative: () {},
                onPressedPositive: () {},
              );
            },
          );
          /*_showErrorAlert(
            APP_Name, 'No Internet Connection', FAIL, '', 'OK', false);*/
        }
      });
    } else {
      _snackBar(LocaleUtils.getString(mContext, 'PlzApplyAtLeast1Filter'));
    }
  }

  void clear() {
    fromDateController.text = '';
    toDateController.text = '';
    doStoController.text = '';
    if (mounted) {
      setState(() {
        editDOList.clear();
      });
    }
  }

  String getCustomerNameCode(int index) {
    final String code = editDOList[index].varCustomerName != null
        ? editDOList[index].varCustomerName
        : '';
//    final String name = editDOList[index].varFullName != null
//        ? editDOList[index].varFullName
//        : '';
//    if (code.isEmpty) {
//      return name;
//    } else {
    return code;
//    }
  }

//  String getDOSTOTitle(int index) {
//    final String code = editDOList[index].chrTransType != null
//        ? editDOList[index].chrTransType
//        : '';
//    if (code == 'S') {
//      return '${globals.STO_NO}: ';
//    } else {
//      return '${globals.DO_NO}: ';
//    }
//  }

  void listViewClickEvent(int index) {
    databaseHelper
        .checkCancelDOForEditDO(editDOList[index].fk_Customer_DispatchGlCode)
        .then((int id) {
      if (id > 0) {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: '${globals.DO} is already cancelled.',
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      } else {
        sharedPrefs
            .setString(PREF_SCREEN_STATE, widget.displayName)
            .then((bool isAdd) {
          sharedPrefs
              .setString(
                  PREF_CHAR_TRAN_TYPE_DISPATCH, editDOList[index].chrTransType)
              .then((bool isAdd) {
            sharedPrefs
                .setInt(PREF_FK_DISPATCH_GL_CODE,
                    editDOList[index].fk_Customer_DispatchGlCode)
                .then((bool isAdd) {
              sharedPrefs
                  .setInt(PREF_FK_LAST_DISPATCHED_TO,
                      editDOList[index].fk_Customer_To_GlCode)
                  .then((bool isAdd) {
                databaseHelper
                    .relaseStickerForEditDO(
                        editDOList[index].fk_Customer_DispatchGlCode)
                    .then((int id) {
                  sharedPrefs
                      .getString(PREF_INIT_GI_CODE)
                      .then((String initGlCode) {
                    databaseHelper
                        .updateCPMCustomerDispatchForCancelDOFirstPage(
                            editDOList[index].fk_Customer_DispatchGlCode,
                            int.parse(initGlCode))
                        .then((int id) {
                      dispatchThirdScreenRedirect();
                    });
                  });
                });
              });
            });
          });
        });
      }
    });
  }

  void dispatchThirdScreenRedirect() async {
    final Route route = CupertinoPageRoute(
        builder: (context) =>
            DispatchThirdScreen(
            isRedirectToEditScreen: true, subTitleTxt: widget.displayName));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            setUpDate();
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final searchBtn = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Search'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          loadEditDoRecord();
        },
      ),
    );

    final resetBtn = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Reset'),
        buttonColor: const Color(colorAccent),
        textColor: Colors.black,
        onTap: () {
          clear();
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _scaffoldKey,
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              if (mounted) {
                setState(() {
                  isShowFilterView = !isShowFilterView;
                });
              }
              if (!isShowFilterView) {
                setUpDate();
              }
            },
            backgroundColor:
            isShowFilterView ? Colors.white : const Color(colorPrimary),
            child: Icon(
              Icons.filter_list,
              color:
              isShowFilterView ? const Color(colorPrimary) : Colors.white,
            ),
          ),
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(userName, widget.displayName,
                          'assets/edit_do_icon.png', 0),
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.all(10),
                          child: Column(
                            children: <Widget>[
                              isShowFilterView
                                  ? Container(
                                height: 45,
                                width: screenSize.width,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius:
                                            const BorderRadius.all(
                                                Radius.circular(7)),
                                            border: Border.all(
                                                color: const Color(
                                                    colorPrimary),
                                                width: 2),
                                            color: Colors.white),
                                        child: InkWell(
                                          child: TextField(
                                            controller:
                                            fromDateController,
                                            //enableInteractiveSelection: false,
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintStyle: TextStyle(
                                                  color: const Color(
                                                      colorPrimary),
                                                  fontSize: 15.0,
                                                  fontWeight:
                                                  FontWeight.w400,
                                                  fontFamily:
                                                  'helvetica'),
                                              labelStyle: TextStyle(
                                                  color: const Color(
                                                      colorPrimary),
                                                  fontSize: 15.0,
                                                  fontWeight:
                                                  FontWeight.w400,
                                                  fontFamily:
                                                  'helvetica'),
                                              hintText:
                                              LocaleUtils.getString(
                                                  mContext, 'FromDt'),
                                              counterText: '',
                                              //labelText: defaultFromDate
                                            ),
                                            style: TextStyle(
                                                color: const Color(
                                                    colorPrimary),
                                                fontSize: 15.0,
                                                fontWeight:
                                                FontWeight.w400,
                                                fontFamily: 'helvetica'),
                                            onChanged: (value) {
                                              print(
                                                  '====FROM DATE=====$value');
                                            },
                                            autofocus: false,
                                            enabled: false,
                                            maxLines: 1,
                                            maxLength: EditTxtMaxLengths,
                                          ),
                                          onTap: () {
                                            print(
                                                '====FROM DATE===TAP==');
                                            _setDate(true);
                                          },
                                        ),
                                        margin: const EdgeInsets.only(
                                            right: 5),
                                        padding: const EdgeInsets.only(
                                            left: 7, right: 7),
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Container(
                                          margin: const EdgeInsets.only(
                                              left: 5),
                                          padding: const EdgeInsets.only(
                                              left: 7, right: 7),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                              const BorderRadius.all(
                                                  Radius.circular(7)),
                                              border: Border.all(
                                                  color: const Color(
                                                      colorPrimary),
                                                  width: 2),
                                              color: Colors.white),
                                          child: InkWell(
                                            child: TextField(
                                              controller:
                                              toDateController,
                                              //enableInteractiveSelection: false,
                                              decoration: InputDecoration(
                                                border: InputBorder.none,
                                                hintStyle: TextStyle(
                                                    color: const Color(
                                                        colorPrimary),
                                                    fontSize: 15.0,
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontFamily:
                                                    'helvetica'),
                                                labelStyle: TextStyle(
                                                    color: const Color(
                                                        colorPrimary),
                                                    fontSize: 15.0,
                                                    fontWeight:
                                                    FontWeight.w400,
                                                    fontFamily:
                                                    'helvetica'),
                                                hintText:
                                                LocaleUtils.getString(
                                                    mContext, 'ToDt'),
                                                counterText: '',
                                              ),
                                              style: TextStyle(
                                                  color: const Color(
                                                      colorPrimary),
                                                  fontSize: 15.0,
                                                  fontWeight:
                                                  FontWeight.w400,
                                                  fontFamily:
                                                  'helvetica'),
                                              onChanged: (value) {
                                                print(
                                                    '====TO DATE=====$value');
                                                _setDate(false);
                                              },
                                              autofocus: false,
                                              enabled: false,
                                              maxLines: 1,
                                              maxLength:
                                              EditTxtMaxLengths,
                                            ),
                                            onTap: () {
                                              print(
                                                  '====TO DATE==TAP===');
                                              _setDate(false);
                                            },
                                          )),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              )
                                  : Container(),
                              isShowFilterView
                                  ? Container(
                                height: 45,
                                margin: const EdgeInsets.only(top: 7),
                                width: screenSize.width,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Container(
                                        decoration: BoxDecoration(
                                            borderRadius:
                                            const BorderRadius.all(
                                                Radius.circular(7)),
                                            border: Border.all(
                                                color: const Color(
                                                    colorPrimary),
                                                width: 2),
                                            color: Colors.white),
                                        child: TextFormField(
                                          controller: doStoController,
                                          //enableInteractiveSelection: false,
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            hintStyle: TextStyle(
                                                color: const Color(
                                                    colorPrimary),
                                                fontSize: 15.0,
                                                fontWeight:
                                                FontWeight.w400,
                                                fontFamily: 'helvetica'),
                                            labelStyle: TextStyle(
                                                color: const Color(
                                                    colorPrimary),
                                                fontSize: 15.0,
                                                fontWeight:
                                                FontWeight.w400,
                                                fontFamily: 'helvetica'),
                                            hintText:
                                            '${globals.DO_OR_STO}',
                                            counterText: '',
                                          ),
                                          style: TextStyle(
                                              color: const Color(
                                                  colorPrimary),
                                              fontSize: 15.0,
                                              fontWeight: FontWeight.w400,
                                              fontFamily: 'helvetica'),
                                          textInputAction:
                                          TextInputAction.done,
                                          focusNode: _donoFocus,
                                          onFieldSubmitted: (value) {
                                            _donoFocus.unfocus();
                                          },
                                          maxLines: 1,
                                          maxLength: EditTxtMaxLengths,
                                        ),
                                        margin: const EdgeInsets.only(
                                            right: 5),
                                        padding: const EdgeInsets.only(
                                            left: 7, right: 7),
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 5),
                                        child: Row(
                                          children: <Widget>[
                                            Expanded(
                                              child: Container(
                                                margin:
                                                const EdgeInsets.only(
                                                    right: 5),
                                                child: searchBtn,
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: resetBtn,
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              )
                                  : Container(),
                              Expanded(
                                child: !loadingFlag
                                //? editDOList.length > 0
                                    ? editDOList.isNotEmpty
                                    ? Container(
                                  child: ListView.builder(
                                    itemCount: editDOList.length,
                                    shrinkWrap: true,
                                    itemBuilder:
                                        (BuildContext context,
                                        int index) {
                                      return InkWell(
                                          onTap: () {
                                            print(
                                                '===========TAP=============$index');
                                            listViewClickEvent(index);
                                          },
                                          child: Card(
                                              margin: const EdgeInsets
                                                  .only(
                                                            left: 0,
                                                            top: 7,
                                                            bottom: 7,
                                                            right: 0),
                                              elevation: 3,
                                              child: Container(
                                                color: Colors.white,
                                                padding:
                                                const EdgeInsets
                                                    .all(10),
                                                child: Column(
                                                  crossAxisAlignment:
                                                  CrossAxisAlignment
                                                      .start,
                                                  mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .start,
                                                  children: <Widget>[
                                                    Row(
                                                      children: <
                                                          Widget>[
                                                        Wrap(
                                                          direction: Axis
                                                              .horizontal,
                                                          alignment:
                                                          WrapAlignment
                                                              .start,
                                                          crossAxisAlignment:
                                                          WrapCrossAlignment
                                                              .center,
                                                          children: <
                                                              Widget>[
                                                            Text(
                                                              LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'TranType'),
                                                              style:
                                                              prifixTxtStyle,
                                                            ),
                                                          ],
                                                        ),
                                                        Wrap(
                                                          direction: Axis
                                                              .horizontal,
                                                          alignment:
                                                          WrapAlignment
                                                              .start,
                                                          crossAxisAlignment:
                                                          WrapCrossAlignment
                                                              .center,
                                                          children: <
                                                              Widget>[
                                                            Text(
                                                              editDOList[index]
                                                                  .varTranType !=
                                                                  null
                                                                  ? editDOList[index]
                                                                  .varTranType
                                                                  : '',
                                                              style:
                                                              textStyle,
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          top: 5),
                                                      child: Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                        children: <
                                                            Widget>[
                                                          Wrap(
                                                            direction:
                                                            Axis.horizontal,
                                                            alignment:
                                                            WrapAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                              Text(
                                                                LocaleUtils
                                                                    .getString(
                                                                    mContext,
                                                                    'DispatchDtTime'),
                                                                style:
                                                                prifixTxtStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          Wrap(
                                                            direction:
                                                            Axis.horizontal,
                                                            alignment:
                                                            WrapAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                              Padding(
                                                                padding:
                                                                const EdgeInsets
                                                                    .only(
                                                                    top: 2),
                                                                child:
                                                                Text(
                                                                  editDOList[index]
                                                                      .dtDispatchDate !=
                                                                      null
                                                                      ? editDOList[index]
                                                                      .dtDispatchDate
                                                                      : '',
                                                                  style:
                                                                  textStyle,
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          top: 5),
                                                      child: Row(
                                                        mainAxisSize:
                                                        MainAxisSize
                                                            .max,
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                        children: <
                                                            Widget>[
                                                          Wrap(
                                                            direction:
                                                            Axis.horizontal,
                                                            alignment:
                                                            WrapAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                              Text(
                                                                LocaleUtils
                                                                    .getString(
                                                                    mContext,
                                                                    'Cust_'),
                                                                style:
                                                                prifixTxtStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          Expanded(
                                                            flex: 1,
                                                            child:
                                                            Wrap(
                                                              direction:
                                                              Axis.horizontal,
                                                              alignment:
                                                              WrapAlignment
                                                                  .start,
                                                              crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .center,
                                                              children: <
                                                                  Widget>[
                                                                Text(
                                                                  getCustomerNameCode(
                                                                      index),
                                                                  style:
                                                                  textStyle,
                                                                ),
                                                              ],
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          top: 5),
                                                      child: Row(
                                                        children: <
                                                            Widget>[
                                                          Wrap(
                                                            direction:
                                                            Axis.horizontal,
                                                            alignment:
                                                            WrapAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                              Text(
                                                                '${editDOList[index]
                                                                    .varEntityName}: ',
                                                                style:
                                                                prifixTxtStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          Wrap(
                                                            direction:
                                                            Axis.horizontal,
                                                            alignment:
                                                            WrapAlignment
                                                                .start,
                                                            crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                            children: <
                                                                Widget>[
                                                              Text(
                                                                editDOList[index]
                                                                    .varDONO !=
                                                                    null
                                                                    ? editDOList[index]
                                                                    .varDONO
                                                                    : '',
                                                                style:
                                                                textStyle,
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .only(
                                                          top: 5),
                                                      child: Row(
                                                        //crossAxisAlignment: CrossAxisAlignment.center,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceBetween,
                                                        mainAxisSize:
                                                        MainAxisSize
                                                            .max,
                                                        children: <
                                                            Widget>[
                                                          Expanded(
                                                            child:
                                                            Row(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              mainAxisSize:
                                                              MainAxisSize.max,
                                                              children: <
                                                                  Widget>[
                                                                Wrap(
                                                                  direction:
                                                                  Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                  WrapAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      LocaleUtils
                                                                          .getString(
                                                                          mContext,
                                                                          'TotArticle_'),
                                                                      style: prifixTxtStyle,
                                                                    ),
                                                                  ],
                                                                ),
                                                                Wrap(
                                                                  direction:
                                                                  Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                  WrapAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Padding(
                                                                        padding: const EdgeInsets
                                                                            .only(
                                                                            top: 2),
                                                                        child: Text(
                                                                          editDOList[index]
                                                                              .intTotalProduct
                                                                              .toString() !=
                                                                              null
                                                                              ? editDOList[index]
                                                                              .intTotalProduct
                                                                              .toString()
                                                                              : '',
                                                                          style: textStyle,
                                                                        ))
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                            flex: 2,
                                                          ),
                                                          Expanded(
                                                            child:
                                                            Row(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                              mainAxisSize:
                                                              MainAxisSize.max,
                                                              children: <
                                                                  Widget>[
                                                                Wrap(
                                                                  direction:
                                                                  Axis
                                                                      .horizontal,
                                                                  runAlignment:
                                                                  WrapAlignment
                                                                      .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      LocaleUtils
                                                                          .getString(
                                                                          mContext,
                                                                          'TotUnits_'),
                                                                      style: prifixTxtStyle,
                                                                    ),
                                                                  ],
                                                                ),
                                                                Expanded(
                                                                  child:
                                                                  Wrap(
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    runAlignment: WrapAlignment
                                                                        .start,
                                                                    children: <
                                                                        Widget>[
                                                                      Text(
                                                                        editDOList[index]
                                                                            .intTotalUnit !=
                                                                            null
                                                                            ? editDOList[index]
                                                                            .intTotalUnit
                                                                            : '',
                                                                        style: textStyle,
                                                                      ),
                                                                    ],
                                                                  ),
                                                                  flex:
                                                                  1,
                                                                )
                                                              ],
                                                            ),
                                                            flex: 3,
                                                          )
                                                        ],
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              )));
                                    },
                                  ),
                                )
                                    : Container(
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: <Widget>[
                                      Image.asset(
                                        'assets/nodata_icon.png',
                                        height: 100,
                                        width: 100,
                                      ),
                                      Padding(
                                        padding:
                                        const EdgeInsets.only(
                                            top: 10),
                                        child: Text(
                                          LocaleUtils.getString(
                                              mContext,
                                              'NoDataFound'),
                                          style: prifixTxtStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                                    : Center(
                                  child: const CircularProgressIndicator(
                                      valueColor:
                                      AlwaysStoppedAnimation<Color>(
                                          Color(colorPrimary))),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoginError(String errorTxt) {
    setState(() {
      loadingFlag = false;
    });

    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: errorTxt,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    print(response);

    setState(() {
      loadingFlag = false;
    });

    final dynamic jsonResponse = json.decode(response.toString().trim());
    final LoginResponseModel responseModel =
        LoginResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status == '1') {
      editDOList.clear();
      if (mounted) {
        setState(() {
          editDOList.addAll(responseModel?.Response?.editDO_Mst);
        });
      }
    } else if (responseModel.Status == '2') {
      //API Token
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title:
            PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    } else if (responseModel.Status == '0') {
      if (mounted) {
        setState(() {
          editDOList.clear();
        });
      }
    } else {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: responseModel.Message,
            title:
            PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
