import 'dart:async';
import 'dart:io';

import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/damage/DamageStockDetailsScreen.dart';
import 'package:flutter_basf_hk_app/database/DatabaseQuery.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchThirdScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/InvoiceDispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/HomeFragment.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/MyStockInfoModel.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveFirstScreen.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveSecondScreen.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveThirdScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/*
/Users/admin/Library/Developer/CoreSimulator/Devices/77ABF367-690F-423D-B83F-6B782B1AD92A/data/Containers/Data/Application/32055CFE-E355-4B5B-9FC8-C34D23DD8570/Documents
* */

class DatabaseHelper {
  static final DATABASE_NAME = "BASF-HK-Database.db";
  static DatabaseHelper _bookDatabase = new DatabaseHelper._internal();
  Database db;
  static bool didInit = false;

  static DatabaseHelper get() {
    _bookDatabase = new DatabaseHelper._internal();
    return _bookDatabase;
  }

  DatabaseHelper._internal();

  /// Use this method to access the database, because initialization of the database (it has to go through the method channel)
  Future<Database> getDB() async {
    if (!didInit) {
      await _init();
    } else {
      /* Below line add for refresh database after database sync */
      Directory documentsDirectory = await getApplicationDocumentsDirectory();
      String path = join(documentsDirectory.path, DATABASE_NAME);
      db = await openDatabase(path);
    }
    return db;
  }

  Future<String> getDBPath() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, DATABASE_NAME);
    return path;
  }

  Future<bool> removeLogs() async {
    var db = await getDB();
    await db.rawQuery("PRAGMA wal_checkpoint", []);
    await db.rawQuery("PRAGMA journal_mode=DELETE", []);
    return true;
  }

  Future init() async {
    return await _init();
  }

  close() async {
    /*var dbClient = await db;
    return dbClient.close();*/
    if (db != null) await db.close();
  }

  Future<int> clearData(SharedPrefs sharedPref) async {
    var dbClient = await getDB();
    bool isFlag = await sharedPref.getBool(IS_INTRO_SCREEN);
    await sharedPref.clearPrefs();
    await sharedPref.setBool(IS_INTRO_SCREEN, isFlag);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_DISPATCH);
    await dbClient.rawDelete(
        DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_RECEIVE);
    await dbClient.rawDelete(
        DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CPM_STRICKER_Details);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_STATUS_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_PRODUCT_SKU_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_COUNTRY_MST);
    await dbClient.rawDelete(
        DatabaseQuery.DELETE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST);
    await dbClient.rawDelete(
        DatabaseQuery.DELETE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_POLITICAL_GEOGRAPHY_DETAILS);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_SYSTEM_CONFIGURATION_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_EMPLOYEE_TYPE_MST);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_CUSTOMER_TYPE_REGIONAL_MST);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_CUSTOMER_TYPE_COUNTRY_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_PERSON_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_UOM_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_MENU_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_PSKU_BATCH_STOCK);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CUSTOMER_PARTNER_MST);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE);
    await dbClient.rawDelete(
        DatabaseQuery.DELETE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CPM_PALLET_MST);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_CONFIGURATION_DETAILS);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_INVOICE_DETAILS);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_LANGUAGE_MASTER);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_CPM_Customer_Sticker_Scrap);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_CPM_Customer_Sticker_Consume);
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_LOGIN_FORM_DETAILS);
    await dbClient
        .rawDelete(DatabaseQuery.DELETE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS);
    var result =
        await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_LOGIN_DETAILS);
    return result;
  }

  Future _init() async {
    // Get a location using path_provider
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, DATABASE_NAME);
    //db = await openDatabase(path)
    db = await openDatabase(path, version: 20,
        onCreate: (Database db, int version) async {
          // When creating the db, create the table
          await db.execute(DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_DISPATCH);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_RECEIVE);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_CPM_STRICKER_Details);
          await db.execute(DatabaseQuery.CREATE_TABLE_STATUS_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_PRODUCT_SKU_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_COUNTRY_MST);
          await db.execute(
              DatabaseQuery
                  .CREATE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_POLITICAL_GEOGRAPHY_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_SYSTEM_CONFIGURATION_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_EMPLOYEE_TYPE_MST);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CUSTOMER_TYPE_REGIONAL_MST);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CUSTOMER_TYPE_COUNTRY_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_PERSON_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_UOM_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_MENU_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_PSKU_BATCH_STOCK);
          await db.execute(DatabaseQuery.CREATE_TABLE_CUSTOMER_PARTNER_MST);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE);
          await db.execute(DatabaseQuery.CREATE_TABLE_LOGIN_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_CPM_PALLET_MST);
          await db.execute(DatabaseQuery.CREATE_TABLE_CONFIGURATION_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_INVOICE_DETAILS);
          await db.execute(DatabaseQuery.CREATE_TABLE_LANGUAGE_MASTER);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_Customer_Sticker_Scrap);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_Customer_Sticker_Consume);
          await db.execute(DatabaseQuery.CREATE_TABLE_LOGIN_FORM_DETAILS);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS);
          await db.execute(
              DatabaseQuery.CREATE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE);

          String INDEX_QUERY =
              "CREATE INDEX IF NOT EXISTS idx_btc_out_sticker ON cpm_sticker_details (varBTC_No_Out)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS Idx_CPM_Pallet_Mst_Pallet_no ON CPM_Pallet_Mst (varPalletNo)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS IDX_CPM_Pallet_mst_fk_CustomerGlCode ON CPM_Pallet_Mst(fk_CustomerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS IDX_CPM_Sticker_Details_fk_PalletGlcode ON CPM_Sticker_Details(fk_PalletGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS IDX_CPM_Dispatch_ProductDetail_fk_CustomerGlCode ON CPM_Customer_Dispatch_Product_Details(fk_PalletGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS IDX_CPM_Receive_ProductDetails_fk_PalletGlcode1 ON CPM_Customer_Receive_Product_Details(fk_PalletGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_qr_code_out_sticker ON cpm_sticker_details (varQR_Code_Out)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_varDONO ON CPM_Customer_Dispatch (varDONO)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_fk_Customer_From_GlCode ON CPM_Customer_Dispatch (fk_Customer_From_GlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_fk_Customer_To_GlCode ON CPM_Customer_Dispatch (fk_Customer_To_GlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_fk_Product_SKU_Glcode ON CPM_Customer_Dispatch_Product_Details (fk_Product_SKU_Glcode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_fk_Customer_DispatchGlCode ON CPM_Customer_Dispatch_Product_Details (fk_Customer_DispatchGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_fk_StickerGlCode ON CPM_Customer_Dispatch_Product_Details (fk_StickerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Dispatch_varSticker ON CPM_Customer_Dispatch_Product_Details (varSticker)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_Product_Details_varSticker ON CPM_Customer_Receive_Product_Details (varSticker)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Sticker_Damage_varSticker ON CPM_Customer_Sticker_Damage (varSticker)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_fk_DispatchGlCode ON CPM_Customer_Receive (fk_DispatchGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_fk_Customer_From_GlCode ON CPM_Customer_Receive (fk_Customer_From_GlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_fk_Customer_To_GlCode ON CPM_Customer_Receive (fk_Customer_To_GlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_Product_Details_fk_Product_SKU_Glcode ON CPM_Customer_Receive_Product_Details (fk_Product_SKU_Glcode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_Product_Details_fk_Customer_ReceiveGlCode ON CPM_Customer_Receive_Product_Details (fk_Customer_ReceiveGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Receive_Product_Details_fk_StickerGlCode ON CPM_Customer_Receive_Product_Details (fk_StickerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Sticker_Damage_fk_CustomerGlCode ON CPM_Customer_Sticker_Damage (fk_CustomerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Customer_Sticker_Damage_fk_StickerGlCode ON CPM_Customer_Sticker_Damage (fk_StickerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_fk_CustomerGlCode ON CPM_Sticker_Details (fk_CustomerGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_fk_Product_SKUGlCode ON CPM_Sticker_Details (fk_Product_SKUGlCode)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_varBatch_No ON CPM_Sticker_Details (varBatch_No)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_fk_Sticker_GeneratedBy ON CPM_Sticker_Details (fk_Sticker_GeneratedBy)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_fk_Last_DispatchedTo ON CPM_Sticker_Details (fk_Last_DispatchedTo)";
          await db.execute(INDEX_QUERY);

          INDEX_QUERY =
          "CREATE INDEX IF NOT EXISTS idx_CPM_Sticker_Details_fk_Last_DispatchedBy ON CPM_Sticker_Details (fk_Last_DispatchedBy)";
          await db.execute(INDEX_QUERY);

          String CREATE_TEMP =
              "CREATE TABLE IF NOT EXISTS CPM_TEMP_BULK(intGlCode INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,intRowNo INTEGER,stickerNo TEXT,stickerId TEXT,chrValid TEXT)";
          await db.execute(CREATE_TEMP);
        }, onUpgrade: (Database db, int versionOld, int versionNew) async {
          /* Migration Database Version 8 To 9 */
          if (versionOld < versionNew && versionOld < 9) {
            String sql1 = "";

            await db.execute(DatabaseQuery.CREATE_TABLE_CPM_PALLET_MST);
            await db.execute(DatabaseQuery.CREATE_TABLE_CONFIGURATION_DETAILS);
            await db.execute(DatabaseQuery.CREATE_TABLE_INVOICE_DETAILS);

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_STRICKER_Details +
                  " ADD COLUMN " +
                  DatabaseQuery.CHR_PALLET +
                  " TEXT DEFAULT 'N'";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_STRICKER_Details +
                  " ADD COLUMN " +
                  DatabaseQuery.FK_PALLET_GL_CODE +
                  " INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
                  " ADD COLUMN " +
                  DatabaseQuery.CHR_PALLET +
                  " TEXT DEFAULT 'N'";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
                  " ADD COLUMN " +
                  DatabaseQuery.FK_PALLET_GL_CODE +
                  " INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS +
                  " ADD COLUMN " +
                  DatabaseQuery.CHR_PALLET +
                  " TEXT DEFAULT 'N'";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS +
                  " ADD COLUMN " +
                  DatabaseQuery.FK_PALLET_GL_CODE +
                  " INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_VAR_ENTITY_NAME +
                  " TEXT DEFAULT 'N'";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            String INDEX_QUERY =
                "CREATE INDEX IF NOT EXISTS Idx_CPM_Pallet_Mst_Pallet_no ON CPM_Pallet_Mst (varPalletNo)";
            await db.execute(INDEX_QUERY);

            INDEX_QUERY =
            "CREATE INDEX IF NOT EXISTS IDX_CPM_Pallet_mst_fk_CustomerGlCode ON CPM_Pallet_Mst(fk_CustomerGlCode)";
            await db.execute(INDEX_QUERY);

            INDEX_QUERY =
            "CREATE INDEX IF NOT EXISTS IDX_CPM_Sticker_Details_fk_PalletGlcode ON CPM_Sticker_Details(fk_PalletGlCode)";
            await db.execute(INDEX_QUERY);
          }

          if (versionOld < versionNew && versionOld < 10) {
            String sql1 = "";
            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_CHR_CONFIRM +
                  " TEXT DEFAULT 'Y'";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_DT_CONFIRM_DATE +
                  " TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_REF_CONFIRM_BY +
                  " INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }
          }

          if (versionOld < versionNew && versionOld < 11) {
            await db.execute(DatabaseQuery.CREATE_TABLE_LANGUAGE_MASTER);

            String sql1 = "";
            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_VAR_CUSTOMER_SALES_RETURN +
                  " TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_PERSON_MST +
                  " ADD COLUMN " +
                  DatabaseQuery.FK_LANGUAGE_GL_CODE +
                  " INTEGER DEFAULT 1";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }
          }

          //if (versionOld < versionNew && versionOld < 12) {
          if (versionOld < 16) {
            String sql1 = "";
            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_VAR_REMARKS +
                  " TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE " +
                  DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
                  " ADD COLUMN " +
                  DatabaseQuery.COLUMN_FK_RETURN_STATUS_GL_CODE +
                  " INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }
          }

          /*
      * Database Version 17 below points change.
      *
      *   -Added Column ( Customer_Type_Country_Mst -> varCustomer_FOC).
      *   -Added Column (CPM_Customer_Dispatch -> varAuthorizedBy).
      *   -Added Column (CPM_Customer_Receive -> varSAPDocNo).
      *   -Added Column (CPM_Sticker_Details -> chrConsume,dtConsumeDateTime,fk_ConsumeBy,chrScrap,dtScrapDateTime,fk_ScrapBy).
      *   -Added Table (CPM_Customer_Sticker_Scrap).
      *   -Added Table (CPM_Customer_Sticker_Consume).
      *
      * */
          if (versionOld < 17) {
            String sql1 = "";
            try {
              sql1 =
              "ALTER TABLE Customer_Type_Country_Mst ADD COLUMN varCustomer_FOC TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Customer_Dispatch ADD COLUMN varAuthorizedBy TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Customer_Receive ADD COLUMN varSAPDocNo TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Sticker_Details ADD COLUMN chrConsume TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Sticker_Details ADD COLUMN dtConsumeDateTime TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Sticker_Details ADD COLUMN fk_ConsumeBy INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "ALTER TABLE CPM_Sticker_Details ADD COLUMN chrScrap TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Sticker_Details ADD COLUMN dtScrapDateTime TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 =
              "ALTER TABLE CPM_Sticker_Details ADD COLUMN fk_ScrapBy INTEGER DEFAULT 0";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            await db.execute(
                DatabaseQuery.CREATE_TABLE_CPM_Customer_Sticker_Scrap);
            await db
                .execute(
                DatabaseQuery.CREATE_TABLE_CPM_Customer_Sticker_Consume);
            await db.execute(DatabaseQuery.CREATE_TABLE_LOGIN_FORM_DETAILS);
            await db.execute(
                DatabaseQuery.CREATE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS);
          }

          /*
      * Database Version 18 below points change.
      *
      *   -Added Table (LoginFormDetails).
      *   -Added Table (LoginFailAttempt_Details).
      *
      * */
          if (versionOld < 18) {
            await db.execute(DatabaseQuery.CREATE_TABLE_LOGIN_FORM_DETAILS);
            await db.execute(
                DatabaseQuery.CREATE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS);
          }

          /*
      * Database Version 19 below points change.
      *
      *   -Change varBatch INTEGER TO TEXT in InvoiceDetails
      *
      * */
          if (versionOld < 19) {
            String sql1 = "";

            try {
              sql1 = "ALTER TABLE InvoiceDetails RENAME TO InvoiceDetails_TEMP";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "CREATE TABLE InvoiceDetails(" +
                  " intGlCode INTEGER PRIMARY KEY," +
                  " fk_FromCustomerGlCode INTEGER," +
                  " fk_Sold_To_Party_GlCode INTEGER," +
                  " fk_ToCustomerGlCode INTEGER," +
                  " varInvoiceNo TEXT," +
                  " fk_Product_SKUGlCode INTEGER," +
                  " varBatch TEXT," +
                  " intTotalQty INTEGER," +
                  " intTotalScannedQty INTEGER" +
                  " )";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "INSERT INTO InvoiceDetails(intGlCode," +
                  " fk_FromCustomerGlCode," +
                  " fk_Sold_To_Party_GlCode," +
                  " fk_ToCustomerGlCode," +
                  " varInvoiceNo," +
                  " fk_Product_SKUGlCode," +
                  " varBatch," +
                  " intTotalQty," +
                  " intTotalScannedQty) SELECT intGlCode," +
                  " fk_FromCustomerGlCode," +
                  " fk_Sold_To_Party_GlCode," +
                  " fk_ToCustomerGlCode," +
                  " varInvoiceNo," +
                  " fk_Product_SKUGlCode," +
                  " varBatch," +
                  " intTotalQty," +
                  " intTotalScannedQty from InvoiceDetails_TEMP";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }

            try {
              sql1 = "DROP TABLE IF EXISTS InvoiceDetails_TEMP";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }
          }

          /*
      * Database Version 20 below points change.
      *
      *   -Added Column ( LoginFailAttempt_Details -> varSubModuleName).
      *
      * */
          if (versionOld < 20) {
            String sql1 = "";
            try {
              sql1 =
              "ALTER TABLE LoginFailAttempt_Details ADD COLUMN varSubModuleName TEXT";
              await db.execute(sql1);
            } catch (e) {
              print(e);
            }
          }
        });

    didInit = true;
  }

  Future<bool> getCountLogin() async {
    var db = await getDB();
    List<Map> list = await db.rawQuery('Select * from LoginDetails', []);
    if (list != null) {
      return true;
    } else {
      return false;
    }
  }

  Future<int> deletePersonMaster(int initGlCode) async {
    var dbClient = await getDB();
    print('****deletePersonMaster******$initGlCode');
    return await dbClient
        .delete("Person_Mst", where: 'intGlCode = ?', whereArgs: [initGlCode]);
  }

  Future<String> getConfiguration(String purposeCode, String configCode,
      String configValue, String valuePOS) async {
    var dbClient = await getDB();

    String getPasswordQuery =
        "SELECT CD.varValue1,CD.varValue2,CD.varValue3,CD.varValue4" +
            " FROM Configuration_Details as CD" +
            " WHERE CD.varPurpose='$purposeCode'" +
            " AND CD.varCode='$configCode'" +
            " AND CD.chrActive='Y'";

    print('*******getConfiguration*******$getPasswordQuery');

    var result = await dbClient.rawQuery(getPasswordQuery);

    if (result.isNotEmpty) {
      if (valuePOS.isNotEmpty) {
        if (valuePOS.toLowerCase() == 'value1') {
          return result[0]['varValue1'];
        } else if (valuePOS.toLowerCase() == 'value2') {
          return result[0]['varValue2'];
        } else if (valuePOS.toLowerCase() == 'value3') {
          return result[0]['varValue3'];
        } else if (valuePOS.toLowerCase() == 'value4') {
          return result[0]['varValue4'];
        }
      } else {
        return configValue;
      }
    } else {
      return configValue;
    }
    return configValue;
  }

  Future<int> insertPersonMaster(PersonModel personModel) async {
    var dbClient = await getDB();

    String insertPersonMasterQuery = "INSERT INTO Person_Mst ("
        "intGlCode,"
        "chrUserType, "
        "fk_CountryGlCode, "
        "varUserID,"
        "varPassword,"
        "varSAPCode,"
        "varFirstName,"
        "varMiddleName,"
        "varLastName,"
        "varAddress,"
        "varEmail,"
        "chrUserLock,"
        "varPhoneNo,"
        "varMobileNo,"
        "varFullName,"
        "varOrganisationName,"
        "fk_Customer_Type_CountryGlCode,"
        "fk_Employee_TypeGlCode,"
        "fk_Employee_Designation_CountryGlCode,"
        "fk_Political_GeoGlCode,"
        "refParentGlCode,"
        "chrGender,"
        "dtDOB,"
        "varPincode,"
        "varLatitude,"
        "varLongitude,"
        "chrActive,"
        "dtEntryDate,"
        "ref_Entry_By,"
        "dtModifiedDate,"
        "ref_Modified_By,"
        "dtValidFrom,"
        "dtValidTo,"
        "varPrintingCode,"
        "chrDeviceLogin,"
        "dtLastSyncDate,"
        "chrSync,"
        "varSync_Code,"
        "dtSyncDate,"
        "chrAgree,"
        "dtAgree,"
        "fk_LanguageGlCode"
        ")"
        " VALUES ("
        "'${personModel.intGlCode}',"
        "'${personModel.chrUserType}',"
        "'${personModel.fk_CountryGlCode}',"
        "'${personModel.varUserID}',"
        "'${personModel.varPassword}',"
        "'${personModel.varSAPCode}',"
        "'${personModel.varFirstName}',"
        "'${personModel.varMiddleName}',"
        "'${personModel.varLastName}',"
        "'${personModel.varAddress}',"
        "'${personModel.varEmail}',"
        "'${personModel.chrUserLock}',"
        "'${personModel.varPhoneNo}',"
        "'${personModel.varMobileNo}',"
        "'${personModel.varFullName}',"
        "'${personModel.varOrganisationName}',"
        "'${personModel.fk_Customer_Type_CountryGlCode}',"
        "'${personModel.fk_Employee_TypeGlCode}',"
        "'${personModel.fk_Employee_Designation_CountryGlCode}',"
        "'${personModel.fk_Political_GeoGlCode}',"
        "'${personModel.refParentGlCode}',"
        "'${personModel.chrGender}',"
        "'${personModel.dtDOB}',"
        "'${personModel.varPincode}',"
        "'${personModel.varlatitude}',"
        "'${personModel.varlongitude}',"
        "'${personModel.chrActive}',"
        "'${personModel.dtEntryString}',"
        "'${personModel.ref_Entry_By}',"
        "'${personModel.dtModifiedString}',"
        "'${personModel.ref_Modified_By}',"
        "'${personModel.dtValidFrom}',"
        "'${personModel.dtValidTo}',"
        "'${personModel.varPrintingCode}',"
        "'Y'," //chrDeviceLogin
        "'${personModel.dtLastSyncDate}',"
        "''," //chrSync
        "'${personModel.varSync_Code}',"
        "'${personModel.dtSyncDate}',"
        "'${personModel.chrAgree}',"
        "'${personModel.dtAgree}',"
        "'${personModel.fk_LanguageGlCode}'"
        ")";
    print('******insertPersonMaster********$insertPersonMasterQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertPersonMasterQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertLoginDetails(String deviceID, String androidVersion,
      int fk_PersonGLCode, String SyncCode, int fk_SubModuleGlCode) async {
    var dbClient = await getDB();

    String insertLoginDetailsQuery = "INSERT INTO LoginDetails ("
        "dtLogIn,"
        "varSystemIP, "
        "varSystemName, "
        "varversion,"
        "fk_PersonGLCode,"
        "fk_SubModuleGlCode,"
        "chrLoginSuccess,"
        "dtEntryUpdateDate,"
        "chrSync,"
        "varSyncCode,"
        "dtSyncDate"
        ")"
        " VALUES ("
        "DATETIME('NOW'),"
        "'',"
        "'$deviceID',"
        "'$androidVersion',"
        "'$fk_PersonGLCode',"
        "'$fk_SubModuleGlCode',"
        "'Y',"
        "DATETIME('NOW'),"
        "'N',"
        "'$SyncCode',"
        "DATETIME('NOW')"
        ")";
    print('*******insertLoginDetails*******$insertLoginDetailsQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertLoginDetailsQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> updateLogFormDetails(int intGlCode) async {
    var dbClient = await getDB();

    String updateLogFormDetails = "UPDATE LoginFormDetails\n" +
        "SET dtPageOut=DATETIME('NOW') \n" +
        "WHERE intGlCode='$intGlCode'";
    print('*******updateLogFormDetails*******$updateLogFormDetails');

    var result = await dbClient.rawUpdate(updateLogFormDetails);
    return result;
  }

  Future<int> insertLogDetails(String deviceID,
      String androidVersion,
      int fk_PersonGLCode,
      String SyncCode,
      String loginSyncCode,
      int fk_SubModuleGlCode,
      int fkMenuGlCode,
      String menuName) async {
    var dbClient = await getDB();

    String insertLogDetailsQuery = "INSERT INTO LoginFormDetails ("
        "fk_MenuGlCode,"
        "dtPageIn,"
        "dtPageOut,"
        "fk_PersonGlCode,"
        "fk_SubModuleGlCode,"
        "chrLogInSuccess,"
        "varSystemIP,"
        "varSystemName,"
        "varVersion,"
        "fk_LDGLCode,"
        "varLDGLSyncCode,"
        "varFormName,"
        "chrFromSwtichUser,"
        "chrSync,"
        "varSyncCode,"
        "dtSyncDate,"
        "dtEntryDate"
        ")"
        " VALUES ("
        "'$fkMenuGlCode',"
        "DATETIME('NOW'),"
        "'',"
        "'$fk_PersonGLCode',"
        "'$fk_SubModuleGlCode',"
        "'Y',"
        "'',"
        "'$deviceID',"
        "'$androidVersion',"
        "0,"
        "'$loginSyncCode',"
        "'$menuName',"
        "'',"
        "'N',"
        "'$SyncCode',"
        "DATETIME('NOW'),"
        "DATETIME('NOW')"
        ")";
    print('*******insertLogDetailsQuery*******$insertLogDetailsQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertLogDetailsQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertLoginFailAttempDetails(String deviceID,
      String androidVersion,
      String EnteredUserName,
      String SyncCode,
      String EnteredPassword,
      int fk_SubModuleGlCode,
      String varReason,
      String varSubModuleName) async {
    var dbClient = await getDB();

    String insertLoginFailAttemptQuery =
        "INSERT INTO LoginFailAttempt_Details ("
        "varSystemName,"
        "varSystemIP,"
        "varVersion,"
        "fk_SubModuleGlCode,"
        "varEnteredUserName,"
        "varEnteredPassword,"
        "varReason,"
        "dtEntryDateTime,"
        "chrSync,"
        "varSyncCode,"
        "dtSyncDate,"
        "varSubModuleName"
        ")"
        " VALUES ("
        "'$deviceID',"
        "'',"
        "'$androidVersion',"
        "'$fk_SubModuleGlCode',"
        "'$EnteredUserName',"
        "'$EnteredPassword',"
        "'$varReason',"
        "DATETIME('NOW'),"
        "'N',"
        "'$SyncCode',"
        "DATETIME('NOW'),"
        "'$varSubModuleName'"
        ")";
    print(
        '*******insertLoginFailAttemptDetailsQuery*******$insertLoginFailAttemptQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertLoginFailAttemptQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertLanguageMst() async {
    var dbClient = await getDB();

    String insertLoginDetailsQuery =
        "INSERT INTO Language_Master(intGlCode,varLanguageCode,varLanguageName,varDescription,chrActive,ref_Entry_By,dtEntryDate,chrSync,varSync_Code,dtSyncDate)" +
            " VALUES(1,'en-US','English','English Language','Y',1,DATETIME('now'),'N','DB4C1DC5-4E21-4D6F-91CF-E590F21C44AD',DATETIME('now'))" +
            " ,(2,'hi-IN','हिंदी','हिंदी भाषा','Y',1,DATETIME('now'),'N','94B07D64-369E-4338-935E-728B58364E08',DATETIME('now'))" +
            " ,(3,'zh-HK','中文','中文','N',1,DATETIME('now'),'N','D1A949A2-9D39-4331-849B-3554B6FCC9B1',DATETIME('now'))" +
            " ,(5,'ja-JP','日本人','日本語','Y',1,DATETIME('now'),'N','731C5ACA-C621-413E-89ED-C62A635C58B1',DATETIME('now'));";
    print('*******insertLanguageMst*******$insertLoginDetailsQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertLoginDetailsQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertSystemConfiguration(
      SystemConfigModel systemConfigModel) async {
    var dbClient = await getDB();

    String insertSystemConfigurationQuery =
        "INSERT INTO SystemConfiguration_Mst ("
        "intGlCode,"
        "fk_SubModuleGlCode, "
        "varVersion, "
        "varFilePath,"
        "dtEntryUpdateDate,"
        "varProjectName,"
        "varErrorCaption,"
        "varXMLSettings"
        ")"
        " VALUES ("
        "'${systemConfigModel.intGlCode}',"
        "'${systemConfigModel.fk_SubModuleGlCode}',"
        "'${systemConfigModel.varVersion}',"
        "'',"
        "'${systemConfigModel.dtEntryUpdateDate}',"
        "'${systemConfigModel.varProjectName}',"
        "'${systemConfigModel.varErrorCaption}',"
        "'${systemConfigModel.varXMLSettings}'"
        ")";
    print(
        '*******insertSystemConfiguration*******$insertSystemConfigurationQuery');
    var result;
    try {
      result = await dbClient.rawInsert(insertSystemConfigurationQuery);
    } catch (e) {
      print(e.toString());
      return null;
    }

    return result;
  }

  Future<int> insertMenuMaster(MenuMasterModel menuMasterModel) async {
    var dbClient = await getDB();

    String insertMenuMasterQuery = "INSERT INTO Menu_Mst ("
        "intGlCode,"
        "varMenuName, "
        "varDisplayName, "
        "varURL,"
        "intMenu_Level,"
        "chrElement_Type,"
        "intDisplay_Order,"
        "varIconPath,"
        "chrDisplay,"
        "chrHeadType,"
        "chrMenuType,"
        "chrDBType,"
        "refParentMenuGLCode,"
        "varTransactionCode,"
        "refSubModuleGlCode,"
        "dtEntryDate,"
        "dtUpdateDate,"
        "fk_EntryPersonGlCode,"
        "fk_UpdatePersonGlCode,"
        "chrActive,"
        "chrSync,"
        "varSync_Code,"
        "dtSyncDate"
        ")"
        " VALUES ("
        "'${menuMasterModel.intGlCode}',"
        "'${menuMasterModel.varMenuName}',"
        "'${menuMasterModel.varDisplayName}',"
        "'${menuMasterModel.varURL}',"
        "'${menuMasterModel.intMenuLevel}',"
        "'${menuMasterModel.chrElementType}',"
        "'${menuMasterModel.intDisplayOrder}',"
        "'${menuMasterModel.varIconPath}',"
        "'${menuMasterModel.chrDisplay}',"
        "'${menuMasterModel.chrHeadType}',"
        "'${menuMasterModel.chrMenuType}',"
        "'${menuMasterModel.chrDBType}',"
        "'${menuMasterModel.refParentMenuGLCode}',"
        "'${menuMasterModel.varTransactionCode}',"
        "'${menuMasterModel.refSubModuleGlCode}',"
        "'${menuMasterModel.dtEntryDate}',"
        "'${menuMasterModel.dtUpdateDate}',"
        "'${menuMasterModel.fkEntryPersonGlCode}',"
        "'${menuMasterModel.fkUpdatePersonGlCode}',"
        "'${menuMasterModel.chrActive}',"
        "'${menuMasterModel.chrSync}',"
        "'${menuMasterModel.varSync_Code}',"
        "'${menuMasterModel.dtSyncDate}'"
        ")";
    print('*******insertMenuMaster*******$insertMenuMasterQuery');

    var result;
    try {
      result = await dbClient.rawInsert(insertMenuMasterQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertLanguageMaster(LanguageDetails languageDetails) async {
    var dbClient = await getDB();

    String insertMenuMasterQuery = "INSERT INTO Language_Master ("
        "intGlCode," +
        "varLanguageCode," +
        "varLanguageName," +
        "varDescription," +
        "chrActive," +
        "dtEntryDate," +
        "ref_Entry_By," +
        "dtModifiedDate," +
        "ref_Modified_By," +
        "chrSync," +
        "varSync_Code," +
        "dtSyncDate" +
        ")"
            " VALUES ("
            "'${languageDetails.intGlCode}',"
            "'${languageDetails.varLanguageCode}',"
            "'${languageDetails.varLanguageName}',"
            "'${languageDetails.varDescription}',"
            "'${languageDetails.chrActive}',"
            "'${languageDetails.dtEntryDate}',"
            "'${languageDetails.ref_Entry_By}',"
            "'${languageDetails.dtModifiedDate}',"
            "'${languageDetails.ref_Modified_By}',"
            "'${languageDetails.chrSync}',"
            "'${languageDetails.varSync_Code}',"
            "'${languageDetails.dtSyncDate}'"
            ")";
    print('*******insertLanguageMaster*******$insertMenuMasterQuery');

    var result;
    try {
      result = await dbClient.rawInsert(insertMenuMasterQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<int> insertConfiguration(ConfigurationModel configurationModel) async {
    var dbClient = await getDB();

    String insertMenuMasterQuery = "INSERT INTO Configuration_Details ("
        "intGlCode,"
        "fk_ConfigurationGlCode,"
        "chrConfigType,"
        "chrUserType,"
        "fk_CustTypeRegionalCode,"
        "fk_EmpDesignGlCode,"
        "fk_CountryGlCode,"
        "fk_PersonGlCode,"
        "varPurpose,"
        "varCode,"
        "varValue1,"
        "varValue2,"
        "varValue3,"
        "varValue4,"
        "chrActive,"
        "chrSync,"
        "varSyncCode,"
        "dtSyncDate"
        ")"
        " VALUES ("
        "'${configurationModel.intGlCode}',"
        "'${configurationModel.fk_ConfigurationGlCode}',"
        "'${configurationModel.chrConfigType}',"
        "'${configurationModel.chrUserType}',"
        "'${configurationModel.fk_CustTypeRegionalCode}',"
        "'${configurationModel.fk_EmpDesignGlCode}',"
        "'${configurationModel.fk_CountryGlCode}',"
        "'${configurationModel.fk_PersonGlCode}',"
        "'${configurationModel.varPurpose}',"
        "'${configurationModel.varCode}',"
        "'${configurationModel.varValue1}',"
        "'${configurationModel.varValue2}',"
        "'${configurationModel.varValue3}',"
        "'${configurationModel.varValue4}',"
        "'${configurationModel.chrActive}',"
        "'${configurationModel.chrSync}',"
        "'${configurationModel.varSyncCode}',"
        "'${configurationModel.dtSyncDate}'"
        ")";
    print('*******insertConfiguration*******$insertMenuMasterQuery');

    var result;
    try {
      result = await dbClient.rawInsert(insertMenuMasterQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<List> getPersonMasterAllRecords() async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery('SELECT * FROM Person_Mst');
    return result.toList();
  }

  Future<PersonModel> getPersonMasterRecords(String username) async {
    try {
      var dbClient = await getDB();

      String selectQuery = "SELECT * FROM " +
          DatabaseQuery.TABLE_PERSON_MST +
          " WHERE " +
          DatabaseQuery.COLUMN_VAR_USER_ID +
          "='$username'";

      var result = await dbClient.rawQuery(selectQuery);
      //if (result.isNotEmpty) {
      if (result.isNotEmpty) {
        return new PersonModel.fromMap(result.first);
      }
    } catch (e) {
      print(e.toString());
    }
    return null;
  }

  Future<PersonModel> verifyLoginForLockUser(String username) async {
    var dbClient = await getDB();
    String verifyLoginForLockUserQuery =
        "SELECT * FROM Person_Mst WHERE (lower(varUserID)=? OR lower(varEmail)=? OR lower(varMobileNo)=?) AND ifnull(chrUserLock,'N')='Y' AND chrDeviceLogin=?";
    print('*******verifyLoginForLockUser*******$verifyLoginForLockUserQuery');

    var result = await dbClient.rawQuery(verifyLoginForLockUserQuery, [
      username.toLowerCase(),
      username.toLowerCase(),
      username.toLowerCase(),
      'Y'
    ]);

    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new PersonModel.fromMap(result.first);
    }

    return null;
  }

  Future<PersonModel> verifyLogin(String username, String password) async {
    print('----username-----$username');
    print('----password-----$password');
    var dbClient = await getDB();
    String verifyLoginQuery =
        "SELECT * FROM Person_Mst WHERE (lower(varUserID)=? OR lower(varEmail)=? OR lower(varMobileNo)=?) AND varPassword=? AND chrDeviceLogin=?";

    print('*******verifyLogin*******$verifyLoginQuery');

    var result = await dbClient.rawQuery(verifyLoginQuery, [
      username.toLowerCase(),
      username.toLowerCase(),
      username.toLowerCase(),
      password,
      'Y'
    ]);
    print('----result---length--${result.length}');
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new PersonModel.fromMap(result.first);
    }
    return null;
  }

  Future<int> updatePasswordPersonMaster(String password, String email) async {
    var dbClient = await getDB();
    String updatePasswordPersonMasterQuery =
        "UPDATE Person_Mst SET varPassword='$password' WHERE varUserID='$email' OR varEmail='$email' OR varSAPCode='$email' OR varMobileNo='$email'";
    print(
        '*******updatePasswordPersonMaster*******$updatePasswordPersonMasterQuery');
    var result = await dbClient.rawUpdate(updatePasswordPersonMasterQuery);
    return result;
  }

  Future<String> getPassword(String iniGlCode) async {
    var dbClient = await getDB();
    String getPasswordQuery =
        "SELECT varPassword FROM Person_Mst WHERE intGlCode=?";
    print('*******getPassword*******$getPasswordQuery');
    print('*******iniGlCode*******$iniGlCode');
    var result = await dbClient.rawQuery(getPasswordQuery, [iniGlCode]);
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new PersonModel.fromMap(result.first).varPassword;
    }
    return null;
  }

  Future<int> updateUserLockPersonMaster(String intGlCode) async {
    var dbClient = await getDB();
    String updateUserLockPersonMasterQuery =
        "UPDATE Person_Mst SET chrUserLock='Y' WHERE intGlCode='$intGlCode'";
    print(
        '*******updatePasswordPersonMaster*******$updateUserLockPersonMasterQuery');
    var result = await dbClient.rawUpdate(updateUserLockPersonMasterQuery);
    return result;
  }

  Future<List<MenuMasterModel>> getMenuMasterAllRecords() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery('SELECT * FROM Menu_Mst ORDER BY varDisplayName ASC');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getHomeMenuTag();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode == tags[j].toString()) {
            list.add(masterModel);
          }
        }
      }
    }

    return list;
  }

  Future<MenuMasterModel> getSelectedMenuDetails(
      String varTransactionCode) async {
    var dbClient = await getDB();
    String getPasswordQuery =
        "SELECT * FROM Menu_Mst WHERE varTransactionCode='$varTransactionCode'";
    var result = await dbClient.rawQuery(getPasswordQuery);
    if (result.isNotEmpty) {
      return MenuMasterModel.fromMap(result.first);
    }
    return null;
  }

  Future<String> getLanguageCode(int fkLanguageGlCode) async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery(
        'SELECT varLanguageCode FROM Language_Master WHERE intGlCode = $fkLanguageGlCode');

    if (result.isNotEmpty) {
      return result[0]['varLanguageCode'];
    }
    return 'en-US';
  }

  Future<String> getSyncCodeFromLoginDetails(int fk_PersonGLCode) async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery(
        "SELECT varSyncCode FROM LoginDetails WHERE fk_PersonGLCode='$fk_PersonGLCode'");

    if (result.isNotEmpty) {
      return result[0]['varSyncCode'];
    }
    return '';
  }

  Future<String> getLanguageName(int fkLanguageGlCode) async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery(
        'SELECT varLanguageName FROM Language_Master WHERE intGlCode = $fkLanguageGlCode');

    if (result.isNotEmpty) {
      return result[0]['varLanguageName'];
    }
    return 'en-US';
  }

  Future<List<LanguageDetails>> getLanguageMasterAllRecords() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery("SELECT * FROM Language_Master WHERE chrActive = 'Y'");

    List<LanguageDetails> list = new List();
    if (result.isNotEmpty) {
      int resultLengths = result.length;
      for (int i = 0; i < resultLengths; i++) {
        LanguageDetails masterModel = LanguageDetails.fromMap(result[i]);
        list.add(masterModel);
      }
    }

    return list;
  }

  bool equalsIgnoreCase(String a, String b) =>
      (a == null && b == null) ||
      (a != null && b != null && a.toLowerCase() == b.toLowerCase());

  Future<List<MenuMasterModel>> getMenuMasterForSalesEmployee() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery('SELECT * FROM Menu_Mst ORDER BY varDisplayName ASC');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getMenuTagForSalesEmp();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode.contains('DEV_REP') &&
              !equalsIgnoreCase(masterModel.varTransactionCode, 'DEV_REP')) {
            if (tags[j].contains(masterModel.varTransactionCode)) {
              list.add(masterModel);
            }
          }
        }
      }
    }

    return list;
  }

  Future<List<MenuMasterModel>> getMenuMasterForPlaceOrder() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery('SELECT * FROM Menu_Mst ORDER BY varDisplayName ASC');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getMenuTagForPlaceOrder();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode.contains('DEV_PLO') &&
              !equalsIgnoreCase(masterModel.varTransactionCode, 'DEV_PLO')) {
            if (tags[j].contains(masterModel.varTransactionCode)) {
              list.add(masterModel);
            }
          }
        }
      }
    }

    return list;
  }

  Future<List<MenuMasterModel>> getMenuMasterForTrackNTrace() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery('SELECT * FROM Menu_Mst ORDER BY varDisplayName ASC');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getMenuTagForTrackNTrace();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode.contains('DEV_TNT') &&
              !equalsIgnoreCase(masterModel.varTransactionCode, 'DEV_TNT')) {
            if (tags[j].contains(masterModel.varTransactionCode)) {
              list.add(masterModel);
            }
          }
        }
      }
    }

    return list;
  }

  Future<List<MenuMasterModel>> getMenuMasterForUtility() async {
    var dbClient = await getDB();
    var result = await dbClient
        .rawQuery('SELECT * FROM Menu_Mst ORDER BY varDisplayName ASC');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getMenuTagForUtility();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode.contains('DEV_UTL') &&
              !equalsIgnoreCase(masterModel.varTransactionCode, 'DEV_UTL')) {
            if (tags[j].contains(masterModel.varTransactionCode)) {
              list.add(masterModel);
            }
          }
        }
      }
    }

    return list;
  }

  List<String> getMenuTagForSalesEmp() {
    List<String> tag = new List();
    tag.add('DEV_REP_SALES');
    tag.add('DEV_REP_ATP');
    return tag;
  }

  List<String> getMenuTagForPlaceOrder() {
    List<String> tag = new List();
    tag.add('DEV_PLO_PNO');
    tag.add('DEV_PLO_ORH');
    return tag;
  }

  List<String> getMenuTagForUtility() {
    List<String> tag = new List();
    tag.add('DEV_UTL_CSM');
    tag.add('DEV_UTL_SCP');
    tag.add('DEV_UTL_DMG');
    return tag;
  }

  List<String> getMenuTagForTrackNTrace() {
    List<String> tag = new List();
    tag.add('DEV_TNT_KYB');
    tag.add('DEV_TNT_PIV');
    return tag;
  }

  /*
  * This method use for home menu sequence.
  * */
  List<String> getHomeMenuTag() {
    List<String> tag = new List();
    tag.add('DEV_REC');
    tag.add('DEV_DIS');
    tag.add('DEV_MSI');
    tag.add('DEV_STF');
    tag.add('DEV_STV');
    tag.add('DEV_PLO');
    tag.add('DEV_REP');
    return tag;
  }

  List<String> getDrawerMenuTag() {
    List<String> tag = new List();
//    tag.add('DEV_KYB');
    tag.add('DEV_EDO');
    tag.add('DEV_FOC');
    tag.add('DEV_PADJ');
    tag.add('DEV_SIR');
    tag.add('DEV_SSR');
    tag.add('DEV_TNT');
    tag.add('DEV_UTL');
    tag.add('DEV_SET');
    return tag;
  }

  Future<List<MenuMasterModel>> getDrawerMenuMasterAllRecords() async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery('SELECT * FROM Menu_Mst');

    List<MenuMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      List<String> tags = getDrawerMenuTag();
      for (int j = 0; j < tags.length; j++) {
        for (int i = 0; i < result.length; i++) {
          MenuMasterModel masterModel = MenuMasterModel.fromMap(result[i]);
          if (masterModel.varTransactionCode == tags[j].toString()) {
            list.add(masterModel);
          }
        }
      }
    }

    return list;
  }

  Future<String> checkHalfTransactionInAllModule() async {
    String moduleName = '';

    var dbClient = await getDB();

    String QUERY = '';
    var result;

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Dispatch AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrTransType = 'D' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Dispatch';
      } else {
        moduleName = 'Dispatch';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Dispatch AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrTransType = 'S' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Stock Transfer';
      } else {
        moduleName = 'Stock Transfer';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Dispatch AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrTransType = 'R' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Sales Return';
      } else {
        moduleName = 'Sales Return';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Dispatch AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrTransType = 'F' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',FOC';
      } else {
        moduleName = 'FOC';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Receive AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Receive';
      } else {
        moduleName = 'Receive';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Consume AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Consume';
      } else {
        moduleName = 'Consume';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Scrap AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Scrap';
      } else {
        moduleName = 'Scrap';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Damage AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Damage';
      } else {
        moduleName = 'Damage';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Damage_Remove AS CCD" +
        " WHERE CCD.chrActive = 'Y' AND" +
        " CCD.chrValidSave = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Damage Remove';
      } else {
        moduleName = 'Damage Remove';
      }
    }

    return moduleName;
  }

  Future<String> checkSyncAllTransaction() async {
    String moduleName = '';

    var dbClient = await getDB();

    String QUERY = '';
    var result;

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Dispatch AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Dispatch';
      } else {
        moduleName = 'Dispatch';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Receive AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Receive';
      } else {
        moduleName = 'Receive';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Consume AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Consume';
      } else {
        moduleName = 'Consume';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Scrap AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Scrap';
      } else {
        moduleName = 'Scrap';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Damage AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Damage';
      } else {
        moduleName = 'Damage';
      }
    }

    QUERY = "SELECT CCD.intGlCode AS fk_DispatchGlCode" +
        " FROM CPM_Customer_Sticker_Damage_Remove AS CCD" +
        " WHERE CCD.chrSync = 'N'" +
        " ORDER BY CCD.intGlCode DESC" +
        " LIMIT 1";

    print('***checkHalfTransactionInAllModule****QUERY*******$QUERY');

    result = await dbClient.rawQuery(QUERY);

    if (result.isNotEmpty) {
      if (moduleName.isNotEmpty) {
        moduleName = moduleName + ',Damage Remove';
      } else {
        moduleName = 'Damage Remove';
      }
    }

    return moduleName;
  }

  Future<DispatchHalfTransactionModel> checkDispatchHalfTransaction(
      int fk_Customer_From_GlCode, String chrTransType) async {
    var dbClient = await getDB();
    String checkDispatchHalfTransactionQuery =
        "SELECT  CCD.intGlCode as fk_DispatchGlCode, CCD.fk_Customer_To_GlCode as fk_Customer_To_GlCode, CCD.chrTransType as chrTransType FROM CPM_Customer_Dispatch as CCD WHERE CCD.fk_Customer_From_GlCode=? AND CCD.chrActive='Y' AND CCD.chrTransType=? AND CCD.chrValidSave='N' ORDER BY CCD.intGlCode DESC limit 1";

    print(
        '*******checkDispatchHalfTransaction*******$checkDispatchHalfTransactionQuery');

    print('*******fk_Customer_From_GlCode*******$fk_Customer_From_GlCode');
    var result = await dbClient.rawQuery(checkDispatchHalfTransactionQuery,
        [fk_Customer_From_GlCode.toString(), chrTransType]);
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new DispatchHalfTransactionModel.fromMap(result.first);
    }
    return null;
  }

  Future<DispatchHalfReceiveTransactionModel>
      checkDispatchHalfTransactionReceive(int fkMainCustomerGlCode) async {
    var dbClient = await getDB();
    String CHECK_HALF_TRANSACTION =
        "SELECT  CCR.intGlCode as fk_ReceiveGlCode,\n" +
            "       CCR.fk_DispatchGlCode as fk_DispatchGlCode\n" +
            "FROM CPM_Customer_Receive as CCR\n" +
            "WHERE CCR.fk_Customer_To_GlCode='$fkMainCustomerGlCode'"
                "      AND CCR.chrActive='Y'\n" +
            "      AND CCR.varTransType='RECEIVE'\n" +
            "      AND CCR.chrValidSave='N' ORDER BY CCR.intGlCode DESC limit 1";
    print(
        '*****checkDispatchHalfTransactionReceive*****$CHECK_HALF_TRANSACTION');

    var result = await dbClient.rawQuery(CHECK_HALF_TRANSACTION);
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new DispatchHalfReceiveTransactionModel.fromMap(result.first);
    }
    return null;
  }

  Future<List<CountryMasterModel>> getCountryAllRecords() async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery(
        'SELECT * FROM Countries_Mst WHERE intGlCode IN(SELECT DISTINCT fk_CountryGlCode FROM Person_Mst) ORDER BY varName ASC');
    List<CountryMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        CountryMasterModel masterModel = CountryMasterModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<StatusMasterModel>> getReturnStatus() async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery(
        "SELECT SM.intGlCode,SM.varStatus FROM Status_Mst AS SM WHERE SM.varPurpose='CPM_RT'");
    List<StatusMasterModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        StatusMasterModel masterModel = StatusMasterModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<InvoiceModel>> getInvoiceAllRecords(int customerGlCode) async {
    var dbClient = await getDB();
    var result = await dbClient.rawQuery("SELECT DISTINCT id.fk_FromCustomerGlCode," +
        " pm_from.fk_Customer_Type_CountryGlCode as fk_From_Customer_Type_CountryGlCode," +
        " pm_from.varOrganisationName as var_From_OrganizationName," +
        " id.fk_Sold_To_Party_GlCode," +
        " pm_sold.fk_Customer_Type_CountryGlCode as fk_SoldTo_Customer_Type_CountryGlCode," +
        " pm_sold.varOrganisationName  as var_SoldTo_OrganizationName," +
        " id.fk_ToCustomerGlCode as fk_Shipt_To_Party_GlCode," +
        " pm_ship.fk_Customer_Type_CountryGlCode as fk_ShipTo_Customer_Type_CountryGlCode," +
        " pm_ship.varOrganisationName as var_ShipTo_OrganizationName," +
        " id.varInvoiceNo" +
        " FROM InvoiceDetails as id" +
        " INNER JOIN Person_Mst as pm_from ON id.fk_FromCustomerGlCode=pm_from.intGlCode" +
        " INNER JOIN Person_Mst as pm_sold ON id.fk_Sold_To_Party_GlCode=pm_sold.intGlCode" +
        " INNER JOIN Person_Mst as pm_ship ON id.fk_ToCustomerGlCode=pm_ship.intGlCode" +
        " where id.fk_FromCustomerGlCode='$customerGlCode'");

    List<InvoiceModel> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        InvoiceModel masterModel = InvoiceModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<String> getReturnRemarks(int initGlCode) async {
    var dbClient = await getDB();

    String getCustomerLevelForDispatchQuery =
        "SELECT varRemarks FROM CPM_Customer_Dispatch AS CCD where CCD.intGlCode='$initGlCode'";
    print('*******getReturnRemarks*******$getCustomerLevelForDispatchQuery');
    var result = await dbClient.rawQuery(getCustomerLevelForDispatchQuery);

    if (result.isNotEmpty) {
      return result[0]['varRemarks'];
    }

    return "";
  }

  Future<List<String>> getCustomerLevelForDispatch(int initGlCode) async {
    var dbClient = await getDB();

    String getCustomerLevelForDispatchQuery =
        'SELECT CTCM.varCustomer_Dispatch FROM Person_Mst as PM INNER JOIN Customer_Type_Country_Mst as CTCM ON PM.fk_Customer_Type_CountryGlCode=CTCM.intGlCode AND PM.fk_CountryGlCode=CTCM.fk_CountryGlCode WHERE PM.intGlCode=?';
    print(
        '*******getCustomerLevelForDispatch*******$getCustomerLevelForDispatchQuery');
    var result = await dbClient
        .rawQuery(getCustomerLevelForDispatchQuery, [initGlCode.toString()]);

    List<String> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['varCustomer_Dispatch'].toString());
      }
    }

    print('===getCustomerLevelForDispatch=========list=====${list.toString()}');

    return list;
  }

  Future<List<String>> getCustomerLevelForStockTransfer(int initGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CTCM." +
        DatabaseQuery.COLUMN_VAR_CUSTOMER_STOCK_TRANSFER +
        " FROM " +
        DatabaseQuery.TABLE_PERSON_MST +
        " as PM INNER JOIN " +
        DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST +
        " as CTCM ON PM." +
        DatabaseQuery.COLUMN_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE +
        "=CTCM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " AND PM." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        "=CTCM." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        " WHERE PM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        "=?";

    print('*******getCustomerLevelForStockTransfer*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery, [initGlCode.toString()]);

    List<String> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['varCustomer_StockTransfer'].toString());
      }
    }

    print(
        '===getCustomerLevelForStockTransfer=========list=====${list.toString()}');

    return list;
  }

  Future<List<String>> getCustomerLevelForSalesReturn(int initGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CTCM." +
        DatabaseQuery.COLUMN_VAR_CUSTOMER_SALES_RETURN +
        " FROM " +
        DatabaseQuery.TABLE_PERSON_MST +
        " as PM INNER JOIN " +
        DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST +
        " as CTCM ON PM." +
        DatabaseQuery.COLUMN_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE +
        "=CTCM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " AND PM." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        "=CTCM." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        " WHERE PM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        "=?";

    print('*******getCustomerLevelForSalesReturn*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery, [initGlCode.toString()]);

    List<String> list = new List();
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['varCustomer_SalesReturn'].toString());
      }
    }

    return list;
  }

  Future<List<AdvanceSearchModel>> getAllCountryCustomerForAdvanceSearch(
      int customerGlCode, String values, List<String> customerLevelList) async {
    String custString = "";

    // if (customerLevelList.length > 0) {
    if (customerLevelList.isNotEmpty) {
      var spitString = customerLevelList[0].split(',');

      for (var i = 0; i < spitString.length; i++) {
        print('=======customerLevelList========${spitString[i]}');
        //if (custString.length > 0) {
        if (custString.isNotEmpty) {
          custString = custString + ",'" + spitString[i] + "'";
        } else {
          custString = custString + "'" + spitString[i] + "'";
        }
      }
    }

    var dbClient = await getDB();

    String getSoldToPartyRecordQuery = "SELECT DISTINCT PM.intGlCode as fk_CustomeGlCode," +
        " PM.varOrganisationName as varCustomerName," +
        " PM.fk_Customer_Type_CountryGlCode," +
        " PM.varSAPCode," +
        " CTCM.varCustomer_Type_Name AS varCustomer_Type_Name," +
        " PM.fk_CountryGlCode AS  fk_CountryGlCode," +
        " CM.varName AS varName" +
        " FROM Person_Mst as PM INNER JOIN Customer_Partner_Mst as CPM ON PM.intGlCode=CPM.fk_To_CustomerGlCode" +
        " INNER JOIN Countries_Mst AS CM" +
        " ON PM.fk_CountryGlCode = CM.intGlCode" +
        " INNER JOIN Customer_Type_Country_Mst AS CTCM ON (CTCM.intGlCode=PM.fk_Customer_Type_CountryGlCode)" +
        " WHERE  PM.chrUserType='C'" +
        " AND PM.intGlCode Not IN('$customerGlCode')" +
        " AND CPM.varType IN('SOLDTO')" +
        " AND ifnull(PM.refParentGlCode,0)=0" +
        " AND (CTCM.varCustomer_Level='' OR CTCM.varCustomer_Level IN ($custString))" +
        " AND  (PM.varSAPCOde LIKE '%'||'$values'||'%' OR PM.varOrganisationName LIKE '%'||'$values'||'%')" +
        " ORDER BY PM.varOrganisationName ASC";

    print(
        '---getAllCountryCustomerForAdvanceSearch----$getSoldToPartyRecordQuery');

    var result = await dbClient.rawQuery(getSoldToPartyRecordQuery);

    List<AdvanceSearchModel> list = new List();

    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        AdvanceSearchModel masterModel = AdvanceSearchModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<CustomerTypeModel>> getSoldToPartyRecord(
      int fk_CountryGlCode,
      int customerGlCode,
      String varType,
      List<String> customerLevelList) async {
    String custString = "";

    // if (customerLevelList.length > 0) {
    if (customerLevelList.isNotEmpty) {
      var spitString = customerLevelList[0].split(',');

      for (var i = 0; i < spitString.length; i++) {
        // print('=======customerLevelList========${spitString[i]}');
        //if (custString.length > 0) {
        if (custString.isNotEmpty) {
          custString = custString + ",'" + spitString[i] + "'";
        } else {
          custString = custString + "'" + spitString[i] + "'";
        }
      }
    }

    var dbClient = await getDB();

    String getSoldToPartyRecordQuery =
        "SELECT DISTINCT PM.intGlCode as fk_CustomeGlCode, PM.varOrganisationName as varCustomerName, PM.fk_Customer_Type_CountryGlCode,PM.varSAPCode, CTCM.varCustomer_Type_Name AS varCustomer_Type_Name "
        "FROM Person_Mst as PM "
        "INNER JOIN Customer_Partner_Mst as CPM ON PM.intGlCode=CPM.fk_To_CustomerGlCode "
        "INNER JOIN Customer_Type_Country_Mst AS CTCM ON (CTCM.intGlCode=PM.fk_Customer_Type_CountryGlCode) "
        "WHERE PM.fk_CountryGlCode=$fk_CountryGlCode AND PM.chrUserType='C' AND PM.intGlCode Not IN($customerGlCode) AND CPM.varType IN('$varType')"
        "AND ifnull(PM.refParentGlCode,0)=0 AND (CTCM.varCustomer_Level='' OR CTCM.varCustomer_Level IN ($custString)) ORDER BY PM.varOrganisationName ASC";

    print('------getSoldToPartyRecordQuery--------$getSoldToPartyRecordQuery');

    var result = await dbClient.rawQuery(getSoldToPartyRecordQuery);

    List<CustomerTypeModel> list = new List();

    if (result.isNotEmpty) {
      CustomerTypeModel masterModelTemp;
      for (int i = 0; i < result.length; i++) {
        CustomerTypeModel masterModel = CustomerTypeModel.fromMap(result[i]);
        if (masterModel.varCustomer_Type_Name.contains('Other')) {
          masterModelTemp = CustomerTypeModel.fromMap(result[i]);
        } else {
          list.add(masterModel);
        }
      }
      if (masterModelTemp != null) {
        list.add(masterModelTemp);
      }
    }
    //print('===list====${list.length}');
    return list;
  }

  Future<CustomerChangeDetailsModel> getCustomerDetailsForChange(
      int initGlCode) async {
    var dbClient = await getDB();

    String getCustomerDetailsForChangeQuery = "SELECT CCD.intGLCode AS fk_Custome_Dispatch_GlCode,\n" +
        "       CCD.fk_Customer_To_GlCode AS fk_Customer_To_GlCode,\n" +
        "       PM.varOrganisationName AS VarCustomer_Ship_To_Name,\n" +
        "       CCD.fk_Customer_To_Type_CountryGlCode AS fk_Customer_ShipTo_Type_CountryGlCode,\n" +
        "       CCD.fk_Sold_To_Party_GlCode AS fk_Sold_To_Party_GlCode,\n" +
        "       PSM.varOrganisationName AS VarCustomer_Sold_To_Name,\n" +
        "       CCD.fk_Sold_To_Party_Type_CountryGlCode AS fk_Sold_To_Party_Type_CountryGlCode,\n" +
        "       PM.fk_CountryGlCode AS fk_CountryGLCode,\n" +
        "       CM.varName AS varCountryName,\n" +
        "       CCD.varDONO AS varDONo,\n" +
        "       CCD.varCustomer_Name AS varCustomer_Name,\n" +
        "       CCD.varSONO AS varSONO,\n" +
        "       CCD.varAuthorizedBy AS varAuthorizedBy,\n" +
        "       CTCM_ShipTo.varCustomer_Type_Name AS varCustomer_Type_Name_ShipTo,\n" +
        "       PM.varSAPCode AS VarCustomer_Ship_To_SAPCode,\n" +
        "       PSM.varSAPCode AS VarCustomer_Sold_To_SAPCode,\n" +
        "       CTCM_SoldTo.varCustomer_Type_Name AS varCustomer_Type_Name_SoldTo,\n" +
        "       SM.intGlCode AS fk_ReturnStatusGlCode,\n" +
        "       CCD.varRemarks AS varRemarks\n" +
        "FROM CPM_Customer_Dispatch CCD\n" +
        "INNER JOIN Person_Mst PM ON(PM.intGlCode=CCD.fk_Customer_To_GlCode)\n" +
        "INNER JOIN Countries_Mst CM ON (CM.intGlCode=PM.fk_CountryGlCode)\n" +
        "INNER JOIN Person_Mst PSM ON(PSM.intGlCode=CCD.fk_Sold_To_Party_GlCode)\n" +
        "INNER JOIN Customer_Type_Country_Mst CTCM_ShipTo ON ( CTCM_ShipTo.intGlCode = CCD.fk_Customer_To_Type_CountryGlCode)\n" +
        "INNER JOIN Customer_Type_Country_Mst CTCM_SoldTo ON(CTCM_SoldTo.intGlCode=CCD.fk_Sold_To_Party_Type_CountryGlCode)\n" +
        "LEFT JOIN Status_Mst SM ON(SM.intGlCode=ifnull(CCD.fk_ReturnStatusGlCode,0))\n" +
        "WHERE CCD.intGlCode=?" +
        "\n" +
        "AND ifnull(CCD.chrActive,'N')='Y'";

    //String getCustomerLevelForDispatchQuery = 'SELECT CTCM.varCustomer_Dispatch FROM Person_Mst as PM INNER JOIN Customer_Type_Country_Mst as CTCM ON PM.fk_Customer_Type_CountryGlCode=CTCM.intGlCode AND PM.fk_CountryGlCode=CTCM.fk_CountryGlCode WHERE PM.intGlCode=?';
    print(
        '*******getCustomerDetailsForChangeQuery*******$getCustomerDetailsForChangeQuery');

    var result = await dbClient
        .rawQuery(getCustomerDetailsForChangeQuery, [initGlCode.toString()]);

    print('=========result=========${result.toString()}');
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new CustomerChangeDetailsModel.fromMap(result.first);
    }
    return null;
  }

  Future<int> insertCustomerDispatch(
      int fk_Customer_From_GlCode,
      int fk_Customer_From_Type_CountryGlCode,
      int fk_Customer_To_GlCode,
      int fk_Customer_To_Type_CountryGlCode,
      int fk_sold_to_party_GlCode,
      int fk_sold_to_party_type_countryGlCode,
      String varDONO,
      String syncCode,
      int ref_Entry_By,
      String chrTransType,
      int fk_ReturnStatusGlCode,
      String remarks,
      String authorizedBy,
      String varCustomer_Name) async {
    var dbClient = await getDB();

    String varEntityName = chrTransType == 'D'
        ? '${globals.DO_NO}'
        : chrTransType == 'R'
        ? '${globals.RETURN_NO}'
        : chrTransType == 'F' ? '${globals.FOC_NO}' : '${globals.STO_NO}';

    String insertCustomerDispatchQuery =
        "INSERT INTO CPM_Customer_Dispatch (\n" +
            "    fk_Customer_From_GlCode,\n" +
            "    fk_Customer_From_Type_CountryGlCode,\n" +
            "    fk_Customer_To_GlCode ,\n" +
            "    fk_Customer_To_Type_CountryGlCode ,\n" +
            "    fk_Sold_To_Party_GlCode ,\n" +
            "    fk_Sold_To_Party_Type_CountryGlCode ,\n" +
            "    chrTransType,\n" +
            "    chrExternal_Customer,\n" +
            "    varCustomer_Name,\n" +
            "    varEmail,\n" +
            "    varMobile,\n" +
            "    varPhone_No,\n" +
            "    dtDispatchDate ,\n" +
            "    varSONO,\n" +
            "    varDONO,\n" +
            "    varAuthorizedBy,\n" +
            "    chrValidSave,\n" +
            "    chrEditDO,\n" +
            "    fk_EditDOBy,\n" +
            "    dtEditDODate,\n" +
            "    chrCancelDO,\n" +
            "    fk_CancelDOBy,\n" +
            "    dtCancelDODate,\n" +
            "    fk_ReturnStatusGlCode,\n" +
            "    varRemarks,\n" +
            "    chrActive,\n" +
            "    chrSync,\n" +
            "    varSync_Code,\n" +
            "    dtSyncDate,\n" +
            "    dtEntryDate,\n" +
            "    ref_Entry_By,\n" +
            "    dtModifiedDate,\n" +
            "    ref_Modified_By,varEntityName )\n" +
            "  VALUES\n" +
            "(\n" +
            "     '$fk_Customer_From_GlCode', \n" +
            "     '$fk_Customer_From_Type_CountryGlCode', \n" +
            "      '$fk_Customer_To_GlCode', \n" +
            "     '$fk_Customer_To_Type_CountryGlCode',\n" +
            "     '$fk_sold_to_party_GlCode',\n" +
            "     '$fk_sold_to_party_type_countryGlCode',\n" +
            "    '$chrTransType',\n" +
            "    '' ,\n" +
            "    '$varCustomer_Name' ,\n" +
            "    '' ,\n" +
            "    '',\n" +
            "    '' ,\n" +
            "    datetime('now') ,\n" +
            "    '' ,\n" +
            "    '$varDONO',\n" +
            "    '$authorizedBy',\n" +
            "    'N',\n" +
            "    '' ,\n" +
            "    NULL ,\n" +
            "    NULL ,\n" +
            "    NULL ,\n" +
            "    NULL ,\n" +
            "    NULL ,\n" +
            "    '$fk_ReturnStatusGlCode',\n"
                "    '$remarks',\n" +
            "    'Y' ,\n" +
            "    'N' ,\n" +
            "    '$syncCode',\n" +
            "    datetime('now'),\n" +
            "    datetime('now') ,\n" +
            "    '$ref_Entry_By',\n" +
            "    NULL,\n" +
            "    NULL,'$varEntityName'    \n" +
            ")";

    print('***insertCustomerDispatchQuery***$insertCustomerDispatchQuery');

    var result = 0;
    try {
      result = await dbClient.rawInsert(insertCustomerDispatchQuery);
    } catch (e) {
      print(e.toString());
    }
    return result;
  }

  Future<CustomerDetailsModel> getCustomerDetails(String initGlCode) async {
    var dbClient = await getDB();

    String getCustomerDetailsQuery = "SELECT  CCD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " as fk_DispatchGlCode," +
        "CCD." +
        DatabaseQuery.COLUMN_VAR_SONO +
        "," +
        "CCD." +
        DatabaseQuery.COLUMN_VAR_DONO +
        "," +
        "PM." +
        DatabaseQuery.COLUMN_VAR_ORGANIZATION_NAME +
        " as varOrgName," +
        "PM." +
        DatabaseQuery.COLUMN_VAR_FULL_NAME +
        " as varCustomerName," +
        "PM." +
        DatabaseQuery.COLUMN_VAR_SAP_CODE +
        " as varCustomerSAPCode," +
        "CTC." +
        DatabaseQuery.COLUMN_VAR_CUSTOMER_TYPE_NAME +
        " as varCustType," +
        "CM." +
        DatabaseQuery.COLUMN_VAR_NAME +
        " as varCountryName,CCD.varCustomer_Name AS varCustomer_Name" +
        " FROM " +
        DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH +
        " as CCD" +
        " INNER JOIN " +
        DatabaseQuery.TABLE_PERSON_MST +
        " as PM ON CCD." +
        DatabaseQuery.COLUMN_FK_CUSTOMER_TO_GI_CODE +
        "=PM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " INNER JOIN " +
        DatabaseQuery.TABLE_COUNTRY_MST +
        " as CM ON PM." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        "=CM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " INNER JOIN " +
        DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST +
        " as CTC ON CM." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        "=CTC." +
        DatabaseQuery.COLUMN_FK_COUNTRY_GI_CODE +
        " AND PM." +
        DatabaseQuery.COLUMN_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE +
        "=CTC." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " WHERE CCD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        "=?" +
        " AND CCD." +
        DatabaseQuery.COLUMN_CHAR_ACTIVE +
        "='Y';";

    print('*******getCustomerDetails*******$getCustomerDetailsQuery');

    var result = await dbClient
        .rawQuery(getCustomerDetailsQuery, [initGlCode.toString()]);

    print('=========reslt======${result.toString()}');

    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      return new CustomerDetailsModel.fromMap(result.first);
    }
    return null;
  }

  Future<int> updateChangeDetails(
      int intGlCode,
      int fk_Customer_To_GlCode,
      int fk_Customer_To_Type_CountryGlCode,
      int fk_sold_to_party_GlCode,
      int fk_sold_to_party_type_countryGlCode,
      String varDONO,
      int fk_ReturnStatusGlCode,
      String remarks,
      String authorizedBy,
      String varCustomer_Name) async {
    var dbClient = await getDB();

    String updateChangeDetailsQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    fk_Customer_To_GlCode='$fk_Customer_To_GlCode',\n" +
        "    fk_Customer_To_Type_CountryGlCode='$fk_Customer_To_Type_CountryGlCode', \n" +
        "    fk_Sold_To_Party_GlCode='$fk_sold_to_party_GlCode',\n" +
        "    fk_Sold_To_Party_Type_CountryGlCode='$fk_sold_to_party_type_countryGlCode', \n" +
        "    varDONO='$varDONO',\n" +
        "    varAuthorizedBy='$authorizedBy',\n" +
        "    fk_ReturnStatusGlCode='$fk_ReturnStatusGlCode',\n" +
        "    varRemarks='$remarks',\n" +
        "    varCustomer_Name='$varCustomer_Name',\n" +
        "    varSONO=''\n" +
        "WHERE intGlCode='$intGlCode'";
    print('*******updateChangeDetailsQuery*******$updateChangeDetailsQuery');

    var result = await dbClient.rawUpdate(updateChangeDetailsQuery);
    return result;
  }

  Future<List<ScanRecordModel>> getScannedRecord(int intGlCode) async {
    var dbClient = await getDB();

    /*String getScannedRecordQuery = "SELECT  PSM.intGlCode," +
        "PSM.varProduct_SKU_Name," +
        "COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit," +
        "round(COUNT(DISTINCT CCDPD.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                            WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG," +
        " PM.varOrganisationName  AS varLastDispatchBy," +
        " CSD.dtLast_DispatchedDate AS dtLastDispatchDate" +
        " FROM CPM_Customer_Dispatch as CCD" +
        " INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode" +
        " INNER JOIN Product_SKU_Mst as PSM  ON PSM.intGlCode=CCDPD.fk_Product_SKU_Glcode" +
        " INNER JOIN CPM_Sticker_Details AS CSD ON(CSD.intglCode=CCDPD.fk_StickerGlCode)" +
        " INNER JOIN Person_Mst PM ON(PM.intGlCode=CSD.fk_Last_DispatchedBy)" +
        " WHERE CCD.intGlCode='$intGlCode'" +
        " AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')" +
        " AND ifnull(CCD.chrActive,'N')='Y'" +
        " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')" +
        " AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')" +
        " AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " GROUP BY PSM.intGlCode," +
        " PSM.varProduct_SKU_Name," +
        " PM.varOrganisationName," +
        " CSD.dtLast_DispatchedDate;";*/
    String getScannedRecordQuery = "SELECT  PSM.intGlCode," +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        "COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit," +
        "round(COUNT(DISTINCT CCDPD.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                            WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG" +
        " FROM CPM_Customer_Dispatch as CCD" +
        " INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode" +
        " INNER JOIN Product_SKU_Mst as PSM  ON PSM.intGlCode=CCDPD.fk_Product_SKU_Glcode" +
        " WHERE CCD.intGlCode='$intGlCode'" +
        " AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')" +
        " AND ifnull(CCD.chrActive,'N')='Y'" +
        " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')" +
        " AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')" +
        " AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " GROUP BY PSM.intGlCode," +
        " PSM.varProduct_SKU_Name,PSM.varProduct_SKU_Code;";

    print('=======getScannedRecordQuery========$getScannedRecordQuery');

    var result = await dbClient.rawQuery(getScannedRecordQuery);

    print('====getScannedRecord==========result======${result.toString()}');

    List<ScanRecordModel> list = new List();

    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanRecordModel masterModel = ScanRecordModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<int> cancelDispatch(int initGICode, int ref_Modified_By) async {
    var dbClient = await getDB();

    String cancelDispatchQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$ref_Modified_By',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$initGICode'";
    print('*******updateChangeDetailsQuery*******$cancelDispatchQuery');

    var result = await dbClient.rawUpdate(cancelDispatchQuery);
    return result;
  }

  Future<int> updateCPMStickerDetailsForCancelDO(
      int fk_PrintedStatusGlCode,
      int fk_ReceivedStatusGlCode,
      int fk_Customer_DispatchGlCode,
      int ref_Modified_By,
      String varPrintedLastStage,
      String varReceivedLastStage,
      int mainCustomerGLCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " \n" +
        "SET fk_Last_DispatchedBy=fk_Last_PreviousDispatchBy,\n" +
        "   fk_StatusGlCode=(case when ifnull(fk_sticker_GeneratedBy,0)<>$mainCustomerGLCode THEN '$fk_ReceivedStatusGlCode' ELSE '$fk_PrintedStatusGlCode' END)" +
        ", \n" +
        "   fk_Last_DispatchedTo='$mainCustomerGLCode'" +
        ", \n" +
        "  chrSync='N',\n" +
        "   dtSyncDate=DATETIME('now'),\n" +
        "   varLastStage=(case when ifnull(fk_sticker_GeneratedBy,0)<>$mainCustomerGLCode THEN '$varReceivedLastStage' ELSE '$varPrintedLastStage' END),\n" +
        "   ref_Modified_By='$ref_Modified_By'" +
        ",\n" +
        "   dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode IN  ( SELECT CCDPD.fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details CCDPD\n" +
        "                       WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'\n" +
        "                       AND ifnull(CCDPD.chrActive,'N') in('Y','E')\n" +
        "                       AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "                      ) ;";

    print('*******updateCPMStickerDetailsForCancelDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMProductDetailsForEditDO(
      int fk_Customer_DispatchGlCode, int ref_Modified_By) async {
    var dbClient = await getDB();

    String selectQuery =
        "UPDATE CPM_Customer_Dispatch_Product_Details SET chrActive=(case when chrActive='E' then 'N' when chrActive='I' then 'Y' else chrActive end),dtModifiedDate=DATETIME('now'),ref_Modified_By='$ref_Modified_By', \n" +
            "  chrSync='N',\n" +
            "   dtSyncDate=DATETIME('now')\n" +
            " WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'";

    print('*******updateCPMProductDetailsForEditDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMCustomerDispatchForEditDO(int initGICode,
      int fk_Customer_DispatchGlCode, int mainCustomerGLCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrValidSave='Y',chrEditDO='Y',dtEditDODate=DATETIME('now'),fk_EditDOBy='$mainCustomerGLCode',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    dtDispatchDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGICode'" +
        ",\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$fk_Customer_DispatchGlCode'";

    print('*******updateCPMProductDetailsForEditDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMStickerDetailsForEditDO(
      int fk_StatusGlCode,
      int fk_Customer_DispatchGlCode,
      int ref_Modified_By,
      String varLastStage,
      int mainCustomerGLCode) async {
    var dbClient = await getDB();

    String selectQuery = "";

    if (fk_StatusGlCode == globals.intPrinted) {
      selectQuery = "UPDATE " +
          DatabaseQuery.TABLE_CPM_STRICKER_Details +
          " \n" +
          "SET fk_Last_DispatchedBy=fk_Last_PreviousDispatchBy,\n" +
          "   fk_StatusGlCode='$fk_StatusGlCode'" +
          ", \n" +
          "   fk_Last_DispatchedTo=null,fk_Last_DispatchedBy=null,fk_Last_PreviousDispatchBy=null,dtLast_DispatchedDate=null, \n" +
          "   chrActive=(case when chrActive='E' then 'N' else chrActive end),\n" +
          "  chrSync='N',\n" +
          "   dtSyncDate=DATETIME('now'),\n" +
          "   varLastStage='$varLastStage',\n" +
          "   ref_Modified_By='$ref_Modified_By'" +
          ",\n" +
          "   dtModifiedDate=DATETIME('now')\n" +
          "WHERE intGlCode IN  ( SELECT CCDPD.fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details CCDPD\n" +
          "                       WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'\n" +
          "                       AND ifnull(CCDPD.chrActive,'N')='E'\n" +
          "                       AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
          "                      ) ;";
    } else if (fk_StatusGlCode == globals.intReceived) {
      selectQuery = "UPDATE " +
          DatabaseQuery.TABLE_CPM_STRICKER_Details +
          " \n" +
          "SET fk_Last_DispatchedBy=fk_Last_PreviousDispatchBy,\n" +
          "   fk_StatusGlCode='$fk_StatusGlCode'" +
          ", \n" +
          "   fk_Last_DispatchedTo='$mainCustomerGLCode'" +
          ", \n" +
          "   chrActive=(case when chrActive='E' then 'N' else chrActive end),\n" +
          "  chrSync='N',\n" +
          "   dtSyncDate=DATETIME('now'),\n" +
          "   varLastStage='$varLastStage',\n" +
          "   ref_Modified_By='$ref_Modified_By'" +
          ",\n" +
          "   dtModifiedDate=DATETIME('now')\n" +
          "WHERE intGlCode IN  ( SELECT CCDPD.fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details CCDPD\n" +
          "                       WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'\n" +
          "                       AND ifnull(CCDPD.chrActive,'N')='E'\n" +
          "                       AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
          "                      ) ;";
    }

    print('*******updateCPMStickerDetailsForEditDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMCustomerDispatchProductDetailsForCancelDO(
      int ref_Modified_By,
      int fk_Customer_DispatchGlCode,
      int fkMainCustomerGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch_Product_Details \n" +
        "SET chrActive='N',fk_DispatchBy='$fkMainCustomerGlCode',chrDispatch='N',dtDispatchDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$ref_Modified_By'" +
        ", \n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'" +
        "\n" +
        "     AND ifnull(chrActive,'N') in('Y','E','I')";

    print(
        '*******updateCPMCustomerDispatchProductDetailsForCancelDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMCustomerDispatchForCancelDO(
      int fk_CancelDOBy, int ref_Modified_By, int intGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrActive='N',chrCancelDO='Y',\n" +
        "    fk_CancelDOBy='$fk_CancelDOBy'" +
        ",\n" +
        "    dtCancelDODate=DATETIME('now'),\n" +
        "    chrSync='N',chrValidSave='Y',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$ref_Modified_By'" +
        ",\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$intGlCode'" +
        "\n" +
        "      AND ifnull(chrActive,'N') in('Y','E')";

    print('*******updateCPMCustomerDispatchForCancelDO*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> customerTypeContryMstForCancelDO(int initGICode) async {
    var dbClient = await getDB();

    String selectQuery = "\n" +
        "SELECT CTCM.intGlCode AS intGlCode\n" +
        "FROM Person_Mst as PM\n" +
        "INNER JOIN Customer_Type_Country_Mst as CTCM ON PM.fk_Customer_Type_CountryGlCode=CTCM.intGlCode\n" +
        "WHERE PM.intGlCode='$initGICode'" +
        "\n" +
        "      AND ifnull(PM.chrActive,'N')='Y'\n" +
        "      AND ifnull(CTCM.chrActive,'N')='Y'\n" +
        "      AND CTCM.varCustomer_Level IN ('L5','L6')";

    print('*******customerTypeContryMstForCancelDO*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['intGlCode'];
      }
    }

    return -1;
  }

  Future<List<String>> checkSticker(String query) async {
    var dbClient = await getDB();
    print('*******checkSticker*******$query');
    var result = await dbClient.rawQuery(query);

    List<String> list = List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['varSticker'].toString());
      }
    }

    return list;
  }

  Future<ValidStickerModel> validStickerDispatch(
      int dispatchGLCode, int intMainCustomerGLCode, String serialNo) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CSD.intGlCode as fk_StickerGlCode,\n" +
        "       CSD.fk_Product_SKUGlCode,\n" +
        "       '${serialNo.toUpperCase()}' as varScanCode\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.chrValidSave IN('E','N') \n" +
        " AND CCD.chrActive='Y'\n" +
        " AND CCDPD.chrActive IN('I','Y')\n" +
        " AND CCDPD.chrValid='Y'\n" +
        " AND CCD.intGlCode='$dispatchGLCode'\n" +
        " AND CCD.fk_Customer_From_GlCode='$intMainCustomerGLCode'\n" +
        " AND ((CSD.fk_StatusGlCode in(${globals.intPrinted}) and CSD.fk_Sticker_GeneratedBy='$intMainCustomerGLCode')\n" +
        "       OR\n" +
        "      (CSD.fk_StatusGlCode in(${globals.intReceived}) and CSD.fk_Last_DispatchedTo='$intMainCustomerGLCode'))\n" +
        " AND CSD.chrActive='Y' \n" +
        " AND (UPPER(CSD.varBTC_No_Out)='${serialNo.toUpperCase()}' OR UPPER(CSD.varQR_Code_Out)='${serialNo.toUpperCase()}') AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validStickerDispatch*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      return ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<ValidStickerModel> validStickerDispatchForEditDO(int dispatchGLCode,
      int intMainCustomerGLCode, String serialNo) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CSD.intGlCode as fk_StickerGlCode,\n" +
        "       CSD.fk_Product_SKUGlCode,\n" +
        "       '${serialNo.toUpperCase()}' as varScanCode\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.chrValidSave IN('E','N') \n" +
        " AND CCD.chrActive='Y'\n" +
        " AND CCDPD.chrActive IN('I','Y')\n" +
        " AND CCDPD.chrValid='Y'\n" +
        " AND CCD.intGlCode='$dispatchGLCode'\n" +
        " AND CCD.fk_Customer_From_GlCode='$intMainCustomerGLCode'\n" +
        " AND ((CSD.fk_StatusGlCode in(${globals
            .intPrinted}) and CSD.fk_Sticker_GeneratedBy='$intMainCustomerGLCode')\n" +
        "       OR\n" +
        "      (CSD.fk_StatusGlCode in(${globals
            .intReceived}) and CSD.fk_Last_DispatchedTo='$intMainCustomerGLCode')" +
        " OR (CSD.fk_StatusGlCode IN(${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn})" +
        " AND CSD.fk_Last_DispatchedBy='$intMainCustomerGLCode'" +
        " AND CSD.intGLCode IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details WHERE fk_Customer_DispatchGlCode='$dispatchGLCode' AND ifnull(chrSync,'N')='N' AND ifnull(chrActive,'N') IN ('E','I') AND ifnull(chrValid,'N')='Y' ))" +
        " )\n" +
        " AND CSD.chrActive='Y' \n" +
        " AND (UPPER(CSD.varBTC_No_Out)='${serialNo
            .toUpperCase()}' OR UPPER(CSD.varQR_Code_Out)='${serialNo
            .toUpperCase()}') AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print(
        '*******validStickerDispatchForEditDO*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      print('===validStickerDispatchForEditDO=====GETTING VALUES======');
      return ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<int> validStickerDispatchForPalletForEditDO(int dispatchGLCode,
      int intMainCustomerGLCode, int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT count(DISTINCT CSD.intGlCode) as intNoOfSticker " +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.chrValidSave IN('E','N') \n" +
        " AND CCD.chrActive='Y'\n" +
        " AND ifnull(CCDPD.chrActive,'N') IN ('I','Y')\n" +
        " AND CCDPD.chrValid='Y'\n" +
        " AND CCD.intGlCode='$dispatchGLCode'\n" +
        " AND CCD.fk_Customer_From_GlCode='$intMainCustomerGLCode'\n" +
        " AND ((CSD.fk_StatusGlCode in(${globals
            .intPrinted}) and CSD.fk_Sticker_GeneratedBy='$intMainCustomerGLCode')\n" +
        "       OR\n" +
        "      (CSD.fk_StatusGlCode in(${globals
            .intReceived}) and CSD.fk_Last_DispatchedTo='$intMainCustomerGLCode')\n" +
        " OR (CSD.fk_StatusGlCode IN(${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn})" +
        " AND CSD.fk_Last_DispatchedBy='$intMainCustomerGLCode'" +
        " AND CSD.intGLCode IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details WHERE fk_Customer_DispatchGlCode='$dispatchGLCode' AND ifnull(chrSync,'N')='N' AND ifnull(chrActive,'N') IN ('E','I') AND ifnull(chrValid,'N')='Y' ))" +
        " )\n" +
        " AND CSD.chrActive='Y' \n" +
        " AND CSD.fk_PalletGlCode='$fk_PalletGlCode' AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validStickerDispatch*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    //if (result.isNotEmpty) {
    if (result?.length > 0) {
      print('===intNoOfSticker======${result[0]['intNoOfSticker']}');
      return result[0]['intNoOfSticker'];
    }
    //}

    return 0;
  }

  Future<int> validStickerDispatchForPallet(int dispatchGLCode,
      int intMainCustomerGLCode, int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT count(DISTINCT CSD.intGlCode) as intNoOfSticker " +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.chrValidSave IN('E','N') \n" +
        " AND CCD.chrActive='Y'\n" +
        " AND ifnull(CCDPD.chrActive,'N') IN ('I','Y')\n" +
        " AND CCDPD.chrValid='Y'\n" +
        " AND CCD.intGlCode='$dispatchGLCode'\n" +
        " AND CCD.fk_Customer_From_GlCode='$intMainCustomerGLCode'\n" +
        " AND ((CSD.fk_StatusGlCode in(${globals.intPrinted}) and CSD.fk_Sticker_GeneratedBy='$intMainCustomerGLCode')\n" +
        "       OR\n" +
        "      (CSD.fk_StatusGlCode in(${globals.intReceived}) and CSD.fk_Last_DispatchedTo='$intMainCustomerGLCode'))\n" +
        " AND CSD.chrActive='Y' \n" +
        " AND CSD.fk_PalletGlCode='$fk_PalletGlCode' AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validStickerDispatch*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    //if (result.isNotEmpty) {
    if (result.isNotEmpty) {
      print('===intNoOfSticker======${result[0]['intNoOfSticker']}');
      return result[0]['intNoOfSticker'];
    }
    //}

    return 0;
  }

  Future<bool> checkPalletValid(String palletNo) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery =
        "select CPM.intGlCode,ifnull(chrBreak,'N') as chrBreak" +
            " from CPM_Pallet_Mst as CPM" +
            " WHERE chrActive='Y'" +
            " AND ifnull(chrCompleted,'N')='Y'" +
            " AND varPalletNo='$palletNo'";
    print(
        '===checkPalletValid===validStickerDispatchQuery===$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    return result.isNotEmpty ? true : false;
  }

  Future<int> checkAutoDispatchDOConfirmValid(
      int fkDispatchGlCode,
      int fkFromCustomerGlCode,
      int fkSoldToPartyGlCode,
      int fkShipToPartyGlCode,
      int fkProductSkuGlCode,
      String doNo,
      String batchNo) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = " SELECT res.varInvoiceNo," +
        " res.varBatch," +
        " res.varProduct_SKU_Code," +
        " res.varProduct_SKU_Name," +
        " res.intTotalQty AS intTotalQty," +
        " res.intTotalScannedQty," +
        " res.intCurrentScannedQty AS intCurrentScannedQty," +
        " res.intDispatchScannedQty AS intDispatchScannedQty" +
        " FROM" +
        " (SELECT id.varInvoiceNo," +
        " id.varBatch," +
        " psm.varProduct_SKU_Code," +
        " psm.varProduct_SKU_Name," +
        " id.fk_Product_SKUGlCode," +
        " id.intTotalQty," +
        " id.intTotalScannedQty," +
        " (SELECT count(DISTINCT CCDPD.fk_StickerGlCode)" +
        " FROM CPM_Customer_Dispatch as CCD" +
        " INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode" +
        " INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode" +
        " WHERE CCD.chrValidSave <>'C'" +
        " AND CCD.chrActive='Y'" +
        " AND UPPER(CCD.varDONO)=UPPER(id.varInvoiceNo)" +
        " AND CCD.fk_Customer_From_GlCode=id.fk_FromCustomerGlCode" +
        " AND CCD.fk_Sold_To_Party_GlCode=id.fk_Sold_To_Party_GlCode" +
        " AND CCD.fk_Customer_To_GlCode=id.fk_ToCustomerGlCode" +
        " AND CSD.fk_Product_SKUGlCode=id.fk_Product_SKUGlCode" +
        " AND UPPER(CSD.varBatch_No)=UPPER(id.varBatch)" +
        " AND ifnull(CSD.chrActive,'N')='Y'" +
        " AND ifnull(CCDPD.chrActive,'N') IN ('I','Y')" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " ) as intDispatchScannedQty," +
        " 1 as intCurrentScannedQty" +
        " FROM InvoiceDetails as id" +
        " INNER JOIN Product_SKU_Mst as psm ON id.fk_Product_SKUGlCode=psm.intGlCode" +
        " where id.fk_FromCustomerGlCode='$fkFromCustomerGlCode'" +
        " and id.fk_ToCustomerGlCode='$fkShipToPartyGlCode'" +
        " AND id.fk_Sold_To_Party_GlCode='$fkSoldToPartyGlCode'" +
        " AND UPPER(id.varInvoiceNo)=UPPER('$doNo')" +
        " AND UPPER(id.varBatch)=UPPER('$batchNo')" +
        " AND id.fk_Product_SKUGlCode='$fkProductSkuGlCode') as res";

    print('==fkFromCustomerGlCode==$fkFromCustomerGlCode');
    print('==fkShipToPartyGlCode==$fkShipToPartyGlCode');
    print('==fkSoldToPartyGlCode==$fkSoldToPartyGlCode');
    print('==doNo==$doNo');
    print('==batchNo==$batchNo');
    print('==fkProductSkuGlCode==$fkProductSkuGlCode');

//        " WHERE ifnull(res.intTotalQty,0) >= (ifnull(res.intDispatchScannedQty,0)+ifnull(res.intCurrentScannedQty,0))";
    print('===checkAutoDispatchDOConfirmValid===$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    if (result.isNotEmpty) {
      int intTotalQty =
          result[0]['intTotalQty'] != null ? result[0]['intTotalQty'] : 0;
      int intDispatchScannedQty = result[0]['intDispatchScannedQty'] != null
          ? result[0]['intDispatchScannedQty']
          : 0;
      int intCurrentScannedQty = result[0]['intCurrentScannedQty'] != null
          ? result[0]['intCurrentScannedQty']
          : 0;
      if (intTotalQty >= (intDispatchScannedQty + intCurrentScannedQty)) {
        return 0;
      } else {
        return 1;
      }
    } else {
      return 2;
    }
  }

  Future<HalfTransactionModule> checkHalfTransactionFromOtherModule(
      String moduleName, int fkMainCustomerGlCode, String stickerNo) async {
    var dbClient = await getDB();

    HalfTransactionModule halfTransactionModule;
    if (moduleName == TAG_DISPATCH ||
        moduleName == TAG_STOCK_TRANSFER ||
        moduleName == TAG_SALES_RETURN ||
        moduleName == TAG_EDIT_DO ||
        moduleName == TAG_FOC ||
        moduleName == TAG_SCRAP_STOCK ||
        moduleName == TAG_CONSUME_STOCK ||
        moduleName == TAG_ADD_DAMAGE_STOCK) {
      String transType = "'D','S','R','F'";
      if (moduleName == TAG_DISPATCH) {
        transType = "'S','R','F'";
      } else if (moduleName == TAG_STOCK_TRANSFER) {
        transType = "'D','R','F'";
      } else if (moduleName == TAG_SALES_RETURN) {
        transType = "'D','S','F'";
      } else if (moduleName == TAG_EDIT_DO) {
        transType = "'D','S','R','F'";
      } else if (moduleName == TAG_FOC) {
        transType = "'D','S','R'";
      } else {
        transType = "'D','S','R','F'";
      }

      String validStickerDispatchQuery =
          "SELECT DISTINCT CCD.intGlCode,(CASE WHEN CCD.chrTransType='D' THEN 'Dispatch'" +
              " WHEN CCD.chrTransType='S' THEN 'Stock Transfer'" +
              " WHEN CCD.chrTransType='R' THEN 'Sales Return'" +
              " WHEN CCD.chrTransType='F' THEN 'FOC'" +
              " ELSE '' END) as varType" +
              " FROM CPM_Customer_Dispatch AS CCD" +
              " INNER JOIN CPM_Customer_Dispatch_Product_Details AS CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode" +
              " INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode" +
              " LEFT JOIN CPM_Pallet_Mst AS CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
              " WHERE   CCD.fk_Customer_From_GlCode='$fkMainCustomerGlCode'" +
              " AND (CSD.varBTC_No_Out='$stickerNo' OR CPM.varPalletNo='$stickerNo')" +
              " AND CCD.chrTransType IN($transType)" +
              " AND CCD.chrValidSave='N'" +
              " AND ifnull(CCDPD.chrValid,'N')='Y'" +
              " AND ifnull(CCD.chrActive,'N')='Y'" +
              " AND ifnull(CCDPD.chrActive,'N')='Y'";

      var result = await dbClient.rawQuery(validStickerDispatchQuery);

      if (result.length > 0) {
        halfTransactionModule =
        new HalfTransactionModule(false, result[0]['varType']);
        //tranModuleName = result[0]['varType'];
        return halfTransactionModule;
      }
    }

    if (moduleName == TAG_DISPATCH ||
        moduleName == TAG_STOCK_TRANSFER ||
        moduleName == TAG_SALES_RETURN ||
        moduleName == TAG_FOC ||
        moduleName == TAG_SCRAP_STOCK ||
        moduleName == TAG_CONSUME_STOCK ||
        moduleName == TAG_EDIT_DO) {
      String validStickerDispatchQuery1 =
          "SELECT DISTINCT CCSD.intGlCode,'Add Damage' AS varType" +
              " FROM CPM_Customer_Sticker_Damage CCSD" +
              " INNER JOIN CPM_Sticker_Details AS CSD ON CCSD.fk_StickerGlCode=CSD.intGlCode" +
              " LEFT JOIN CPM_Pallet_Mst AS CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
              " WHERE ifnull(CCSD.chrValidSave,'N')='N'" +
              " AND ifnull(CCSD.chrActive,'N')='Y'" +
              " AND ifnull(CCSD.chrValid,'N')='Y'" +
              " AND CCSD.fk_CustomerGlCode='$fkMainCustomerGlCode'" +
              " AND (CSD.varBTC_No_Out='$stickerNo'  OR  CPM.varPalletNo='$stickerNo' )";
      var result1 = await dbClient.rawQuery(validStickerDispatchQuery1);

      if (result1.isNotEmpty) {
        halfTransactionModule =
            HalfTransactionModule(false, result1[0]['varType']);
        //tranModuleName = result[0]['varType'];
        return halfTransactionModule;
      }
    }

    if (moduleName == TAG_DISPATCH ||
        moduleName == TAG_STOCK_TRANSFER ||
        moduleName == TAG_SALES_RETURN ||
        moduleName == TAG_FOC ||
        moduleName == TAG_ADD_DAMAGE_STOCK ||
        moduleName == TAG_CONSUME_STOCK ||
        moduleName == TAG_EDIT_DO) {
      String validStickerDispatchQuery1 =
          "SELECT DISTINCT CCSS.intGlCode,'Scrap' AS varType" +
              " FROM CPM_Customer_Sticker_Scrap CCSS" +
              " INNER JOIN CPM_Sticker_Details AS CSD ON CCSS.fk_StickerGlCode=CSD.intGlCode" +
              " LEFT JOIN CPM_Pallet_Mst AS CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
              " WHERE ifnull(CCSS.chrValidSave,'N')='N'" +
              " AND ifnull(CCSS.chrActive,'N')='Y'" +
              " AND ifnull(CCSS.chrValid,'N')='Y'" +
              " AND CCSS.fk_CustomerGlCode='$fkMainCustomerGlCode'" +
              " AND (CSD.varBTC_No_Out='$stickerNo'  OR  CPM.varPalletNo='$stickerNo' )";
      var result1 = await dbClient.rawQuery(validStickerDispatchQuery1);

      if (result1.isNotEmpty) {
        halfTransactionModule =
            HalfTransactionModule(false, result1[0]['varType']);
        //tranModuleName = result[0]['varType'];
        return halfTransactionModule;
      }
    }

    if (moduleName == TAG_DISPATCH ||
        moduleName == TAG_STOCK_TRANSFER ||
        moduleName == TAG_SALES_RETURN ||
        moduleName == TAG_FOC ||
        moduleName == TAG_ADD_DAMAGE_STOCK ||
        moduleName == TAG_SCRAP_STOCK ||
        moduleName == TAG_EDIT_DO) {
      String validStickerDispatchQuery1 =
          "SELECT DISTINCT CCSC.intGlCode,'Consume' AS varType" +
              " FROM CPM_Customer_Sticker_Consume CCSC" +
              " INNER JOIN CPM_Sticker_Details AS CSD ON CCSC.fk_StickerGlCode=CSD.intGlCode" +
              " LEFT JOIN CPM_Pallet_Mst AS CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
              " WHERE ifnull(CCSC.chrValidSave,'N')='N'" +
              " AND ifnull(CCSC.chrActive,'N')='Y'" +
              " AND ifnull(CCSC.chrValid,'N')='Y'" +
              " AND CCSC.fk_CustomerGlCode='$fkMainCustomerGlCode'" +
              " AND (CSD.varBTC_No_Out='$stickerNo'  OR  CPM.varPalletNo='$stickerNo')";
      var result1 = await dbClient.rawQuery(validStickerDispatchQuery1);

      if (result1.isNotEmpty) {
        halfTransactionModule =
            HalfTransactionModule(false, result1[0]['varType']);
        //tranModuleName = result[0]['varType'];
        return halfTransactionModule;
      }
    }

    halfTransactionModule = HalfTransactionModule(true, '');
    return halfTransactionModule;
  }

  Future<int> checkStickerPalletBreak(
      String palletNo, int fkDispatchGlCode, String breakPalletGlCodes) async {
    var dbClient = await getDB();
    print('--------------$breakPalletGlCodes');

    String validStickerDispatchQuery =
        "SELECT DISTINCT CPM.intGlCode FROM CPM_Sticker_Details AS CSD" +
            " INNER JOIN CPM_Pallet_Mst as CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
            " WHERE CSD.chrActive='Y'" +
            " AND CPM.chrActive='Y'" +
            " AND ifnull(CPM.chrCompleted,'N')='Y'" +
            " AND ifnull(CPM.chrBreak,'N')='N'" +
            " AND  CSD.varBTC_No_Out='$palletNo'" +
            " AND CSD.fk_PalletGlCode NOT IN(SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD" +
            " INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode" +
            " WHERE  CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'" +
            " AND CCDPD.chrActive IN('Y','I')" +
            " AND CCDPD.chrValid='Y'" +
            " AND ifnull(CCDPD.chrPallet,'N')='N'" +
            " AND ifnull(CSD.chrPallet,'N')='Y') AND CSD.fk_PalletGlCode NOT IN('$breakPalletGlCodes')";

    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      return result[0]['intGlCode'];
    }
    return 0;
    //return result?.length > 0 ? true : false;
  }

  Future<int> checkStickerPalletBreakForDamage(String palletNo,
      String breakPalletGlCodes) async {
    var dbClient = await getDB();
    print('--------------$breakPalletGlCodes');

    String validStickerDispatchQuery =
        "SELECT DISTINCT CPM.intGlCode FROM CPM_Sticker_Details AS CSD" +
            " INNER JOIN CPM_Pallet_Mst as CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
            " WHERE CSD.chrActive='Y'" +
            " AND CPM.chrActive='Y'" +
            " AND ifnull(CPM.chrCompleted,'N')='Y'" +
            " AND ifnull(CPM.chrBreak,'N')='N'" +
            " AND  CSD.varBTC_No_Out='$palletNo'" +
            " AND CSD.fk_PalletGlCode NOT IN(SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Sticker_Damage AS CCSD" +
            " INNER JOIN CPM_Sticker_Details AS CSD ON CCSD.fk_StickerGlCode=CSD.intGlCode" +
            " WHERE  CCSD.chrActive IN('Y')" +
            " AND CCSD.chrValid='Y'" +
            " AND ifnull(CSD.chrPallet,'N')='Y') AND CSD.fk_PalletGlCode NOT IN('$breakPalletGlCodes')";

    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      return result[0]['intGlCode'];
    }
    return 0;
    //return result?.length > 0 ? true : false;
  }

  Future<int> checkStickerPalletBreakForConsume(String palletNo,
      String breakPalletGlCodes) async {
    var dbClient = await getDB();
    print('--------------$breakPalletGlCodes');

    String validStickerDispatchQuery =
        "SELECT DISTINCT CPM.intGlCode FROM CPM_Sticker_Details AS CSD" +
            " INNER JOIN CPM_Pallet_Mst as CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
            " WHERE CSD.chrActive='Y'" +
            " AND CPM.chrActive='Y'" +
            " AND ifnull(CPM.chrCompleted,'N')='Y'" +
            " AND ifnull(CPM.chrBreak,'N')='N'" +
            " AND  CSD.varBTC_No_Out='$palletNo'" +
            " AND CSD.fk_PalletGlCode NOT IN(SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Sticker_Consume AS CCSC" +
            " INNER JOIN CPM_Sticker_Details AS CSD ON CCSC.fk_StickerGlCode=CSD.intGlCode" +
            " WHERE  CCSC.chrActive IN('Y')" +
            " AND CCSC.chrValid='Y'" +
            " AND ifnull(CCSC.chrPallet,'N')='N'" +
            " AND ifnull(CSD.chrPallet,'N')='Y') AND CSD.fk_PalletGlCode NOT IN('$breakPalletGlCodes')";

    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      return result[0]['intGlCode'];
    }
    return 0;
    //return result?.length > 0 ? true : false;
  }

  Future<int> checkStickerPalletBreakForScrap(String palletNo,
      String breakPalletGlCodes) async {
    var dbClient = await getDB();
    print('--------------$breakPalletGlCodes');

    String validStickerDispatchQuery =
        "SELECT DISTINCT CPM.intGlCode FROM CPM_Sticker_Details AS CSD" +
            " INNER JOIN CPM_Pallet_Mst as CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
            " WHERE CSD.chrActive='Y'" +
            " AND CPM.chrActive='Y'" +
            " AND ifnull(CPM.chrCompleted,'N')='Y'" +
            " AND ifnull(CPM.chrBreak,'N')='N'" +
            " AND  CSD.varBTC_No_Out='$palletNo'" +
            " AND CSD.fk_PalletGlCode NOT IN(SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Sticker_Scrap AS CCSS" +
            " INNER JOIN CPM_Sticker_Details AS CSD ON CCSS.fk_StickerGlCode=CSD.intGlCode" +
            " WHERE  CCSS.chrActive IN('Y')" +
            " AND CCSS.chrValid='Y'" +
            " AND ifnull(CCSS.chrPallet,'N')='N'" +
            " AND ifnull(CSD.chrPallet,'N')='Y') AND CSD.fk_PalletGlCode NOT IN('$breakPalletGlCodes')";

    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    if (result.isNotEmpty) {
      return result[0]['intGlCode'];
    }
    return 0;
    //return result?.length > 0 ? true : false;
  }

  Future<String> getMaxStickerIDForEditDOPallet(int fk_StickerPalletGlCode,
      int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();
    String validStickerDispatchQuery = "";

    validStickerDispatchQuery = "SELECT res.intGlCode" +
        " FROM" +
        " (SELECT fk_StickerGlCode,min(intGlCode) as intGlCode" +
        " FROM CPM_Customer_Dispatch_Product_Details" +
        " WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'" +
        " AND chrActive='E'" +
        " AND chrSync='N'" +
        " AND fk_PalletGlCode='$fk_StickerPalletGlCode'" +
        " GROUP BY fk_StickerGlCode) as res";

    print('=====releaseDeletedStickerForEditDO====$validStickerDispatchQuery');
    String maxIntGlCode = "";
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        if (maxIntGlCode.isEmpty) {
          maxIntGlCode = "'" + result[i]['intGlCode'].toString() + "'";
        } else {
          maxIntGlCode =
              maxIntGlCode + ",'" + result[i]['intGlCode'].toString() + "'";
        }
      }
    }
    return maxIntGlCode;
  }

  Future<String> getMaxStickerIDForEditDO(int fk_StickerPalletGlCode,
      int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();
    String validStickerDispatchQuery = "";

    validStickerDispatchQuery = "SELECT min(intGLCode) as intGlCode" +
        " FROM CPM_Customer_Dispatch_Product_Details" +
        " WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'" +
        " AND chrActive='E'" +
        " AND chrSync='N'" +
        " AND fk_StickerGlCode='$fk_StickerPalletGlCode'";

    print('=====releaseDeletedStickerForEditDO====$validStickerDispatchQuery');

    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    if (result.length > 0) {
      return result[0]['intGlCode'].toString();
    }
    return "";
  }

  void releaseDeletedStickerForEditDO(int fk_StickerPalletGlCode,
      int fk_Customer_DispatchGlCode,
      String maxDeletedSticker,
      bool isPallet) async {
    var dbClient = await getDB();
    String validStickerDispatchQuery = "";

    if (isPallet) {
      validStickerDispatchQuery =
          "UPDATE CPM_Customer_Dispatch_Product_Details" +
              " SET chrActive='N'" +
              " WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'" +
              " AND chrActive='E'" +
              " AND chrSync='N'" +
              " AND fk_PalletGlCode='$fk_StickerPalletGlCode'" +
              " AND intGlCode not in(${maxDeletedSticker.isEmpty
                  ? ''
                  : maxDeletedSticker})";
    } else {
      validStickerDispatchQuery =
          "UPDATE CPM_Customer_Dispatch_Product_Details" +
              " SET chrActive='N'" +
              " WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'" +
              " AND chrActive='E'" +
              " AND chrSync='N'" +
              " AND fk_StickerGlCode='$fk_StickerPalletGlCode'" +
              " AND intGlCode not in('$maxDeletedSticker')";
    }

    print('=====releaseDeletedStickerForEditDO====$validStickerDispatchQuery');

    await dbClient.rawUpdate(validStickerDispatchQuery);
  }

  Future<bool> checkStickerValid_(String palletNo, int fkDispatchGlCode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CSD.fk_PalletGlCode" +
        " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD" +
        " INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode" +
        " WHERE  CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'" +
        " AND CCDPD.chrActive IN('Y','I')" +
        " AND CCDPD.chrValid='Y'" +
        " AND CCDPD.varSticker IN ('$palletNo')";
    print('*******validStickerDispatchQuery*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);

    /*if(result.length > 0){
      return result[0]['intGlCode'];
    }
    return 0;*/
    return result?.length > 0 ? false : true;
  }

  Future<int> checkStickerPalletBreak_(
      String palletNo, int fkReceiveGlCode, String breakPalletGlCodes) async {
    //int id = 0;
    var dbClient = await getDB();

    String validStickerDispatchQuery =
        "SELECT DISTINCT CPM.intGlCode FROM CPM_Sticker_Details AS CSD" +
            " INNER JOIN CPM_Pallet_Mst as CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
            " WHERE CSD.chrActive='Y'" +
            " AND CPM.chrActive='Y'" +
            " AND ifnull(CPM.chrCompleted,'N')='Y'" +
            " AND ifnull(CPM.chrBreak,'N')='N'" +
            " AND  CSD.varBTC_No_Out='$palletNo'" +
            " AND CSD.fk_PalletGlCode NOT IN(SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Receive_Product_Details AS CCRPD" +
            " INNER JOIN CPM_Sticker_Details AS CSD ON CCRPD.fk_StickerGlCode=CSD.intGlCode" +
            " WHERE  CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode'" +
            " AND CCRPD.chrActive IN('Y','I')" +
            " AND CCRPD.chrValid='Y'" +
            " AND ifnull(CCRPD.chrPallet,'N')='N'" +
            " AND ifnull(CSD.chrPallet,'N')='Y') AND CSD.fk_PalletGlCode NOT IN('$breakPalletGlCodes')";

    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    if (result.length > 0) {
      return result[0]['intGlCode'];
    }
    return 0;
  }

  Future<bool> validInvalidPallet(String palletNo, int fkDisptchGlcode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CCDPD.intGlCode" +
        " FROM CPM_Customer_Dispatch_Product_Details as CCDPD" +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDisptchGlcode'" +
        " AND ifnull(CCDPD.chrActive, 'N' ) IN ('I','Y')" +
        " AND CCDPD.chrValid='N'" +
        " AND CCDPD.varSticker='$palletNo'";

    print('*******validInvalidPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('*******validInvalidPallet***result****${result.toString()}');
    return result.isNotEmpty ? false : true;
  }

  Future<bool> validPallet(String palletNo, int fkDisptchGlcode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CCDPD.intGlCode " +
        " FROM CPM_Customer_Dispatch_Product_Details as CCDPD" +
        " INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode" +
        " INNER JOIN CPM_Pallet_MST CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDisptchGlcode'" +
        " AND CSD.chrActive='Y'" +
        " AND CPM.varPalletNo IN ('$palletNo')" +
        " AND ifnull( CCDPD.chrActive, 'N' ) IN ('I','Y')" +
        " AND CPM.chrActive='Y'" +
        " AND CPM.chrCompleted='Y'" +
        " AND CPM.chrBreak<>'Y'";

    print('*******validPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('*******validPallet***result****${result.toString()}');
    return result?.length > 0 ? false : true;
  }

  Future<bool> validInvalidPalletForReceive(String palletNo,
      int fkReceiveGlcode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CCRPD.intGlCode" +
        " FROM CPM_Customer_Receive_Product_Details as CCRPD" +
        " WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlcode'" +
        " AND ifnull(CCRPD.chrActive, 'N' ) IN ('Y')" +
        " AND CCRPD.chrValid='N'" +
        " AND CCRPD.varSticker='$palletNo'";

    print('*******validPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('*******validPallet***result****${result.toString()}');
    return result?.length > 0 ? false : true;
  }

  Future<bool> validPalletForReceive(
      String palletNo, int fkReceiveGlcode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CCRPD.intGlCode " +
        " FROM CPM_Customer_Receive_Product_Details as CCRPD " +
        " INNER JOIN CPM_Sticker_Details AS CSD ON CCRPD.fk_StickerGlCode=CSD.intGlCode" +
        " INNER JOIN CPM_Pallet_MST CPM ON CSD.fk_PalletGlCode=CPM.intGlCode" +
        " WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlcode'" +
        " AND CCRPD.chrActive='Y'" +
        " AND CSD.chrActive='Y'" +
        " AND CPM.varPalletNo IN ('$palletNo')" +
        " AND ifnull( CCRPD.chrActive, 'N' ) = 'Y'" +
        " AND CPM.chrActive='Y'" +
        " AND CPM.chrCompleted='Y'" +
        " AND CPM.chrBreak<>'Y'";

    print('*******validPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('*******validPallet***result****${result.toString()}');
    return result?.length > 0 ? false : true;
  }

  Future<bool> batchValidation(
      String batchNo, int fk_Customer_GlCode, int fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CPBS.intGlCode" +
        " FROM CPM_PSKU_Batch_Stock as CPBS" +
        " WHERE CPBS.fk_Customer_GlCode='$fk_Customer_GlCode'" +
        " AND CPBS.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'" +
        " AND upper(CPBS.varBatchNo)=upper('$batchNo')";

    print('*******batchValidation*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    return result?.length > 0 ? true : false;
  }

  Future<bool> batchValidationForPallet(int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CSD.intGlCode" +
        " FROM CPM_Sticker_Details as CSD" +
        " LEFT JOIN CPM_PSKU_Batch_Stock as CPBS ON CSD.fk_CustomerGlCode=CPBS.fk_Customer_GlCode" +
        " AND CSD.fk_Product_SKUGlCode=CPBS.fk_Product_SKU_Glcode" +
        " AND upper(CSD.varBatch_No)=upper(CPBS.varBatchNo)" +
        " WHERE CSD.fk_PalletGlCode='$fk_PalletGlCode'" +
        " AND CPBS.intGlCode IS NULL";

    print('*******batchValidationForPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    return result?.length > 0 ? false : true;
  }

  Future<PalletCheckBreakModel> checkPalletBreak(String palletNo) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery = "SELECT CPM.intGlCode,CPM.chrBreak " +
        " FROM CPM_Pallet_Mst CPM " +
        " WHERE CPM.varPalletNo='$palletNo'" +
        " AND chrActive='Y'" +
        " AND CPM.chrCompleted='Y'";

    print('*******checkPalletBreak*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('*******checkPalletBreak***result****${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        //list.add(result[i]['varSticker'].toString());
        PalletCheckBreakModel palletCheckBreakModel = new PalletCheckBreakModel(
            result[i]['intGlCode'], result[i]['chrBreak'].toString());
        return palletCheckBreakModel;
      }
    }

    return null;
  }

  Future<List<PalletModel>> getStickerFromPallet(int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String validStickerDispatchQuery =
        "SELECT CSD.varBTC_No_Out as varStickerNo,CPM.varPalletNo,CPM.intGlCode as fk_PalletGlCode,'Y' as chrPallet " +
            " FROM CPM_Sticker_Details CSD " +
            " INNER JOIN CPM_Pallet_MST CPM ON CSD.fk_PalletGlCode=CPM.intGlCode " +
            " WHERE CSD.fk_PalletGlCode='$fk_PalletGlCode'" +
            " AND CPM.chrActive='Y'" +
            " AND CPM.chrCompleted='Y'" +
            " AND CPM.chrBreak<>'Y'";

    print('*******checkPallet*******$validStickerDispatchQuery');
    var result = await dbClient.rawQuery(validStickerDispatchQuery);
    print('===checkPallet===result==${result.toString()}');
    List<PalletModel> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(new PalletModel.fromMap(result[i]));
        /*list.add(new PalletModel(result[i]['varStickerNo'].toString(),
            result[i]['varPalletNo'].toString(),
            result[i]['fk_PalletGlCode'],
            result[i]['chrPallet'].toString()));*/
      }
    }

    return list;
  }

  Future<ValidStickerModel> validStickerReceive(
      int initGICode, int userLoginId, String serialNo) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CSD.intGlCode as fk_StickerGlCode,\n" +
        "       CSD.fk_Product_SKUGlCode,\n" +
        "       '" +
        serialNo +
        "' as varScanCode\n" +
        "FROM CPM_Sticker_Details as CSD\n" +
        "WHERE (CSD.fk_StatusGlCode in(${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn},${globals
            .intFOC}) and CSD.fk_Last_DispatchedTo='$userLoginId')\n" +
        "      AND CSD.chrActive='Y' \n" +
        "      AND (UPPER(CSD.varBTC_No_Out)='${serialNo.toUpperCase()}' OR UPPER(CSD.varQR_Code_Out)='${serialNo.toUpperCase()}')\n" +
        "      AND CSD.intGlCode\n" +
        "      IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details as CCDPD \n" +
        "          WHERE CCDPD.fk_Customer_DispatchGlCode='$initGICode' AND CCDPD.chrActive='Y' ) AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validStickerReceive*******$selectQuery');

    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      return new ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<int> validStickerReceiveForPallet(
      int initGICode, int userLoginId, int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT count(DISTINCT CSD.intGlCode) as intNoOfStickers\n" +
        " FROM CPM_Sticker_Details as CSD\n" +
        "WHERE (CSD.fk_StatusGlCode in(${globals.intDispatched},${globals
            .intTransfered},${globals
            .intSalesReturn}) and CSD.fk_Last_DispatchedTo='$userLoginId')\n" +
        "      AND CSD.chrActive='Y' \n" +
        "      AND CSD.fk_PalletGlCode='$fk_PalletGlCode' \n" +
        "      AND CSD.intGlCode\n" +
        "      IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details as CCDPD \n" +
        "          WHERE CCDPD.fk_Customer_DispatchGlCode='$initGICode' AND CCDPD.chrActive='Y' ) AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validStickerReceive*******$selectQuery');

    var result = await dbClient.rawQuery(selectQuery);

    if (result?.length > 0) {
      return result[0]['intNoOfStickers'];
    }

    return 0;
  }

  Future<ValidStickerModel> validDamageStickerForRemove(
      int mainInitGICode, String serialNo) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CSD.intGlCode as fk_StickerGlCode,\n" +
        " CSD.fk_Product_SKUGlCode,\n" +
        " CCSD.intGlCode AS fk_Sticker_DamageGlCode,\n" +
        " '$serialNo' as varScanCode\n" +
        " FROM CPM_Sticker_Details as CSD " +
        " INNER JOIN CPM_Customer_Sticker_Damage CCSD ON(CCSD.fk_StickerGlCode=CSD.intGlCode) \n" +
        " WHERE((CSD.fk_StatusGlCode IN (${globals.intDamaged}) and CSD.fk_Sticker_GeneratedBy='$mainInitGICode')\n" +
        "        OR\n" +
        "       (CSD.fk_StatusGlCode in(${globals.intDamaged}) and CSD.fk_Last_DispatchedTo='$mainInitGICode'))\n" +
        "      AND CSD.chrActive='N' \n" +
        "      AND (UPPER(CSD.varBTC_No_Out)='${serialNo.toUpperCase()}' OR UPPER(CSD.varQR_Code_Out)='${serialNo.toUpperCase()}') " +
        " AND ifnull(CSD.chrSync,'N') NOT IN('N') " +
        " AND ifnull(CCSD.chrActive,'N')='Y' " +
        " AND ifnull(CCSD.chrRemove,'N')='N'";

    print('*******validDamageStickerForRemove*******$selectQuery');

    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      return new ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<ValidStickerModel> validDamageSticker(
      int mainInitGICode, String serialNo) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CSD.intGlCode as fk_StickerGlCode,\n" +
        "       CSD.fk_Product_SKUGlCode,\n" +
        "       CSD.fk_Last_DispatchedBy as fk_ReceivedFromGlCode,\n" +
        "       '$serialNo' as varScanCode\n" +
        "FROM CPM_Sticker_Details as CSD\n" +
        "WHERE((CSD.fk_StatusGlCode IN (${globals.intPrinted}) and CSD.fk_Sticker_GeneratedBy='$mainInitGICode')\n" +
        "        OR\n" +
        "       (CSD.fk_StatusGlCode in(${globals.intReceived}) and CSD.fk_Last_DispatchedTo='$mainInitGICode'))\n" +
        "      AND CSD.chrActive='Y' \n" +
        "      AND (UPPER(CSD.varBTC_No_Out)='${serialNo.toUpperCase()}' OR UPPER(CSD.varQR_Code_Out)='${serialNo.toUpperCase()}') \n" +
        "      AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validDamageSticker*******$selectQuery');

    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      return ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<ValidStickerModel> validSticker_Dispatch(
      int dispatchGLCode, int intMainCustomerGLCode, String serialNo) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CSD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " as fk_StickerGlCode," +
        " CSD." +
        DatabaseQuery.COLUMN_FK_PRODUCT_SKU_GI_CODE_ +
        "," +
        "'${serialNo.toUpperCase()}' as varScanCode,CSD.chrPallet,CSD.fk_PalletGlCode,CSD.varBatch_No " +
        " FROM " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " as CSD " +
        " WHERE ((CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intPrinted}) AND CSD." +
        DatabaseQuery.COLUMN_FK_STICKER_GENERATED_BY +
        "='$intMainCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intReceived}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_TO +
        "='$intMainCustomerGLCode')) " +
        " AND CSD." +
        DatabaseQuery.COLUMN_CHAR_ACTIVE +
        "='Y' " +
        " AND (UPPER(CSD." +
        DatabaseQuery.COLUMN_VAR_BTC_NO_OUT +
        ")='${serialNo.toUpperCase()}' OR UPPER(CSD." +
        DatabaseQuery.COLUMN_VAR_QR_CODE_OUT +
        ")='${serialNo.toUpperCase()}') " +
        " AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validSticker_Dispatch*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      return new ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<int> validSticker_DispatchForPallet(int dispatchGLCode,
      int intMainCustomerGLCode, int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT count(DISTINCT CSD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        ") as intNoOfSticker " +
        " FROM " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " as CSD " +
        " WHERE ((CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intPrinted}) AND CSD." +
        DatabaseQuery.COLUMN_FK_STICKER_GENERATED_BY +
        "='$intMainCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intReceived}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_TO +
        "='$intMainCustomerGLCode')) " +
        " AND CSD." +
        DatabaseQuery.COLUMN_CHAR_ACTIVE +
        "='Y' " +
        " AND CSD." +
        DatabaseQuery.FK_PALLET_GL_CODE +
        "='$fk_PalletGlCode'" +
        " AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validSticker_Dispatch*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result?.length > 0) {
      return result[0]['intNoOfSticker'];
    }

    return 0;
  }

  Future<ValidStickerModel> validSticker_EditDO(int fkFromCustomerGLCode,
      int fk_Customer_DispatchGlCode, String serialNo) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT CSD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " as fk_StickerGlCode," +
        " CSD." +
        DatabaseQuery.COLUMN_FK_PRODUCT_SKU_GI_CODE_ +
        "," +
        "'" +
        serialNo.toUpperCase() +
        "' as varScanCode,CSD.varBatch_No " +
        " FROM " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " as CSD " +
        " WHERE ((CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intPrinted}) AND CSD." +
        DatabaseQuery.COLUMN_FK_STICKER_GENERATED_BY +
        "='$fkFromCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intReceived}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_TO +
        "='$fkFromCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intDispatched},${globals.intTransfered},${globals
            .intSalesReturn}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_BY +
        "='$fkFromCustomerGLCode' AND CSD.intGLCode IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details WHERE fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode' AND ifnull(chrSync,'N')='N' AND ifnull(chrActive,'N') IN ('E','I') AND ifnull(chrValid,'N')='Y' ))) " +
        " AND CSD." +
        DatabaseQuery.COLUMN_CHAR_ACTIVE +
        "='Y' " +
        " AND (UPPER(CSD." +
        DatabaseQuery.COLUMN_VAR_BTC_NO_OUT +
        ")='" +
        serialNo.toUpperCase() +
        "' OR UPPER(CSD." +
        DatabaseQuery.COLUMN_VAR_QR_CODE_OUT +
        ")='" +
        serialNo.toUpperCase() +
        "') " +
        " AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validSticker_Dispatch*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      print('==validSticker_EditDO====INNN===');
      return new ValidStickerModel.fromMap(result.first);
    }

    return null;
  }

  Future<int> validSticker_EditDOForPallet(int fkFromCustomerGLCode,
      int fk_Customer_DispatchGlCode, int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "SELECT count(DISTINCT CSD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        ") as intNoOfSticker"
            " FROM " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " as CSD " +
        " WHERE ((CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intPrinted}) AND CSD." +
        DatabaseQuery.COLUMN_FK_STICKER_GENERATED_BY +
        "='$fkFromCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intReceived}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_TO +
        "='$fkFromCustomerGLCode') " +
        " OR (CSD." +
        DatabaseQuery.COLUMN_FK_STATUS_GI_CODE +
        " in(${globals.intDispatched},${globals.intTransfered},${globals
            .intSalesReturn}) AND CSD." +
        DatabaseQuery.COLUMN_FK_LAST_DISPATCH_BY +
        "='$fkFromCustomerGLCode' AND CSD.intGLCode IN (SELECT fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details WHERE fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode' AND ifnull(chrSync,'N')='N' AND ifnull(chrActive,'N') IN ('E','I') AND ifnull(chrValid,'N')='Y' ))) " +
        " AND CSD." +
        DatabaseQuery.COLUMN_CHAR_ACTIVE +
        "='Y' " +
        " AND CSD." +
        DatabaseQuery.FK_PALLET_GL_CODE +
        "='$fk_PalletGlCode'" +
        " AND ifnull(CSD.chrSync,'N') NOT IN('N')";

    print('*******validSticker_Dispatch*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result?.length > 0) {
      return result[0]['intNoOfSticker'];
    }

    return 0;
  }

  Future<int> getCountQueryDispatch(int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();
    String countQuery = "select count(*) AS intCnt from " +
        DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
        " AS b " +
        " WHERE b.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'";

    print('*******getCountrQueryDispatch*******$countQuery');
    var result = await dbClient.rawQuery(countQuery);

    //List<String> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['intCnt'];
      }
    }

    return 0;
  }

  Future<int> insertSticker(
      int fk_Customer_DispatchGlCode,
      int fk_Product_SKU_Glcode,
      String chrPallet,
      int fk_PalletGlCode,
      int fk_StickerGlCode,
      String varSticker,
      int initGICode,
      String chrValid,
      String chrActive,
      String syncCode,
      int mainCustomerGLcode,
      int count,
      String scanType) async {
    var dbClient = await getDB();

    String insertStickerQuery =
        "INSERT INTO CPM_Customer_Dispatch_Product_Details\n" +
            "(\n" +
            "    fk_Customer_DispatchGlCode ,\n" +
            "    intRowNo ,\n" +
            "    fk_Product_SKU_Glcode,      \n" +
            "    chrPallet,      \n" +
            "    fk_PalletGlCode,      \n" +
            "    fk_StickerGlCode ,          \n" +
            "    varSticker,                 \n" +
            "    chrDispatch,                \n" +
            "    dtDispatchDate,             \n" +
            "    fk_DispatchBy,              \n" +
            "    chrReceived ,               \n" +
            "    dtReceivedDate,             \n" +
            "    fk_ReceivedBy,              \n" +
            "    chrRejected,                \n" +
            "    dtRejectedDate,             \n" +
            "    fk_RejectedBy,              \n" +
            "    chrValid,                   \n" +
            "    chrActive,                  \n" +
            "    chrSync,                    \n" +
            "    varSync_Code,               \n" +
            "    dtSyncDate,                 \n" +
            "    dtEntryDate,                \n" +
            "    ref_Entry_By,               \n" +
            "    dtModifiedDate,             \n" +
            "    ref_Modified_By            \n" +
            " )\n" +
            " VALUES\n" +
            " (\n" +
            "    '$fk_Customer_DispatchGlCode'" +
            ", \n" +
            "    '$count'" +
            ", \n" +
            "    '$fk_Product_SKU_Glcode'" +
            ",\n" +
            "    '$chrPallet'" +
            ",\n" +
            "    '$fk_PalletGlCode'" +
            ",\n" +
            "    '$fk_StickerGlCode'" +
            ", \n" +
            "    '$varSticker'" +
            ",\n" +
            "    'Y' ,\n" +
            "     datetime('now'), \n" +
            "    '$mainCustomerGLcode'" +
            ", \n" +
            "     NULL,                 \n" +
            "     NULL ,            \n" +
            "     NULL,              \n" +
            "     NULL,               \n" +
            "     NULL,           \n" +
            "     NULL,  \n" +
            "     '$chrValid'" +
            ",\n" +
            "     '$chrActive',                \n" +
            "     'N' ,                 \n" +
            "     '$syncCode'" +
            " ,\n" +
            "      datetime('now') , \n" +
            "      datetime('now'),\n" +
            "      '$initGICode'" +
            " ,\n" +
            "      NULL,         \n" +
            "      NULL    \n" +
            "  )";

    print('*******insertSticker*******$insertStickerQuery');
    var result1;
    try {
      result1 = await dbClient.rawInsert(insertStickerQuery);
    } catch (e) {
      print(e.toString());
    }

    return result1;
  }

  Future<int> insertStickerForPallet(
      int fk_Customer_DispatchGlCode,
      int initGICode,
      String chrValid,
      String chrActive,
      String syncCode,
      int mainCustomerGLcode,
      int count,
      int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String insertStickerQuery = "INSERT INTO CPM_Customer_Dispatch_Product_Details" +
        "   (" +
        "     fk_Customer_DispatchGlCode ," +
        "     intRowNo ," +
        "     fk_Product_SKU_Glcode," +
        "     chrPallet," +
        "     fk_PalletGlCode," +
        "     fk_StickerGlCode ," +
        "     varSticker," +
        "     chrDispatch," +
        "     dtDispatchDate," +
        "     fk_DispatchBy," +
        "     chrReceived ," +
        "     dtReceivedDate," +
        "     fk_ReceivedBy," +
        "     chrRejected," +
        "     dtRejectedDate," +
        "     fk_RejectedBy," +
        "     chrValid," +
        "     chrActive," +
        "     chrSync," +
        "     varSync_Code," +
        "     dtSyncDate," +
        "     dtEntryDate," +
        "     ref_Entry_By," +
        "     dtModifiedDate," +
        "     ref_Modified_By )" +
        " SELECT DISTINCT $fk_Customer_DispatchGlCode AS  fk_Customer_DispatchGlCode ," +
        " $count AS intRowNo ," +
        " CSD.fk_Product_SKUGlCode," +
        " CSD.chrPallet," +
        " CSD.fk_PalletGlCode," +
        " CSD.intGlCode as fk_StickerGlCode ," +
        " CSD.varBTC_No_Out varSticker," +
        " 'Y' AS chrDispatch," +
        " datetime('now') as dtDispatchDate," +
        " $mainCustomerGLcode as  fk_DispatchBy," +
        " NULL AS chrReceived ," +
        " NULL AS dtReceivedDate," +
        " NULL AS fk_ReceivedBy," +
        " NULL AS chrRejected," +
        " NULL AS dtRejectedDate," +
        " NULL AS fk_RejectedBy," +
        " '$chrValid' AS chrValid," +
        " '$chrActive' AS chrActive," +
        " 'N' AS chrSync," +
        " '$syncCode'||replace(datetime('now'),' ','')||CSD.intGlCode AS varSync_Code," +
        " datetime('now') AS dtSyncDate," +
        " datetime('now') AS dtEntryDate," +
        " $initGICode AS  ref_Entry_By," +
        " NULL AS dtModifiedDate," +
        " NULL AS ref_Modified_By" +
        " FROM CPM_Sticker_Details as CSD" +
        " WHERE CSD.fk_PalletGlCode='$fk_PalletGlCode'" +
        " AND CSD.chrActive='Y'";

    print('*******insertSticker*******$insertStickerQuery');
    var result1;
    try {
      result1 = await dbClient.rawInsert(insertStickerQuery);
    } catch (e) {
      print(e.toString());
    }

    return result1;
  }

  Future<int> insertCustomerReceiveForReject(
    String reasonText,
      String varSAPDocNo,
    String syncCode,
    int initGlCode,
    int fkDispatchGlCode,
  ) async {
    var dbClient = await getDB();

    String insertStickerQuery = "INSERT INTO CPM_Customer_Receive(\n" +
        "fk_Customer_From_GlCode,\n" +
        "fk_Customer_From_Type_CountryGlCode,\n" +
        "fk_Customer_To_GlCode,\n" +
        "fk_Customer_To_Type_CountryGlCode,\n" +
        "fk_DispatchGlCode,\n" +
        "dtDate,\n" +
        "varTransType,\n" +
        "varRemarks,\n" +
        "varSAPDocNo,\n" +
        "chrActive,\n" +
        "chrSync,\n" +
        "varSync_Code,\n" +
        "dtSyncDate,\n" +
        "dtEntryDate,\n" +
        "ref_Entry_By)\n" +
        "\n" +
        "SELECT DISTINCT \n" +
        "CCD.fk_Customer_From_GlCode,\n" +
        "CCD.fk_Customer_From_Type_CountryGlCode,\n" +
        "CCD.fk_Customer_To_GlCode,\n" +
        "CCD.fk_Customer_To_Type_CountryGlCode,\n" +
        "CCD.intGlCode,\n" +
        "dateTIME('Now') as dtDate,\n" +
        "'REJECT' as varTransType,\n" +
        "'$reasonText' as varRemarks,\n" +
        "'$varSAPDocNo' as varSAPDocNo,\n" +
        "'Y' as chrActive,\n" +
        "'N' as chrSync,\n" +
        "'$syncCode' as varSync_Code,\n" +
        "DATETIME('Now') as dtSyncDate,\n" +
        "DATETIME('Now') as dtEntryDate,\n" +
        "'$initGlCode'" +
        " as ref_EntryBy\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.intGlCode='$fkDispatchGlCode'" +
        "      AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')\n" +
        "      AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "      AND CSD.fk_StatusGlCode IN (${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn})\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CSD.chrActive,'N')='Y'";

    print('*******insertCustomerReceiveForReject*******$insertStickerQuery');
    var result1;
    try {
      result1 = await dbClient.rawInsert(insertStickerQuery);
    } catch (e) {
      print(e.toString());
    }

    return result1;
  }

  Future<int> insertCPMCustomerReceive(String syncCode, int initGlCode,
      int fkDispatchGlCode, String varSAPDocNo) async {
    var dbClient = await getDB();

    String insertStickerQuery = "INSERT INTO CPM_Customer_Receive(\n" +
        "fk_Customer_From_GlCode,\n" +
        "fk_Customer_From_Type_CountryGlCode,\n" +
        "fk_Customer_To_GlCode,\n" +
        "fk_Customer_To_Type_CountryGlCode,\n" +
        "fk_DispatchGlCode,\n" +
        "dtDate,\n" +
        "varTransType,\n" +
        "varRemarks,\n" +
        "varSAPDocNo,\n" +
        "chrActive,\n" +
        "chrValidSave,\n" +
        "chrSync,\n" +
        "varSync_Code,\n" +
        "dtSyncDate,\n" +
        "dtEntryDate,\n" +
        "ref_Entry_By\n" +
        ")\n" +
        "SELECT DISTINCT \n" +
        "CCD.fk_Customer_From_GlCode,\n" +
        "CCD.fk_Customer_From_Type_CountryGlCode,\n" +
        "CCD.fk_Customer_To_GlCode,\n" +
        "CCD.fk_Customer_To_Type_CountryGlCode,\n" +
        "CCD.intGlCode,\n" +
        "DATETIME('Now') as dtDate,\n" +
        "'RECEIVE' as varTransType,\n" +
        "NULL as varRemarks,\n" +
        "'$varSAPDocNo' as varSAPDocNo,\n" +
        "'Y' as chrActive,\n" +
        "'N' as charValidSave,\n" +
        "'N' as chrSync,\n" +
        "'$syncCode' as varSync_Code,\n" +
        "DATETIME('Now') as dtSyncDate,\n" +
        "DATETIME('Now') as dtEntryDate,'$initGlCode' as ref_EntryBy\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.intGlCode='$fkDispatchGlCode'" +
        "      AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')\n" +
        "      AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "      AND CSD.fk_StatusGlCode IN (${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn})\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CSD.chrActive,'N')='Y'";

    print('*******insertCPMCustomerReceive*******$insertStickerQuery');
    var result1;
    try {
      result1 = await dbClient.rawInsert(insertStickerQuery);
    } catch (e) {
      print(e.toString());
    }

    return result1;
  }

  Future<int> insertCustomerReceiveProductDetailsForReject(
    int fkReceiveGLCode,
    String syncCode,
    int initGlCode,
    int fkDispatchGlCode,
  ) async {
    var dbClient = await getDB();

    String insertStickerQuery = "INSERT INTO CPM_Customer_Receive_Product_Details\n" +
        "(\n" +
        "fk_Customer_ReceiveGlCode,\n" +
        "fk_Product_SKU_Glcode,\n" +
        "fk_StickerGlCode,\n" +
        "varSticker,\n" +
        "chrValid,\n" +
        "chrActive,\n" +
        "chrSync,\n" +
        "varSync_Code,\n" +
        "dtSyncDate,\n" +
        "dtEntryDate,\n" +
        "ref_Entry_By\n" +
        ")\n" +
        "SELECT DISTINCT '$fkReceiveGLCode' as fk_Customer_ReceiveGlCode,\n" +
        "CCDPD.fk_Product_SKU_Glcode,\n" +
        "CCDPD.fk_StickerGlCode,\n" +
        "CSD.varBTC_No_Out as varSticker,\n" +
        "'Y' as chrValid,\n" +
        "'Y' as chrActive,\n" +
        "'N' as chrSync,\n" +
        "('$syncCode' OR CCDPD.fk_StickerGlCode) as varSync_Code,"
            "dateTIME('Now') as dtSyncDate,\n" +
        "dateTIME('Now') as dtEntryDate,\n" +
        "'$initGlCode'" +
        " as ref_EntryBy\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN CPM_Sticker_Details AS CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode\n" +
        "WHERE CCD.intGlCode='$fkDispatchGlCode'"
            "      AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')\n" +
        "      AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "      AND CSD.fk_StatusGlCode IN (${globals.intDispatched},${globals
            .intTransfered},${globals.intSalesReturn})\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CSD.chrActive,'N')='Y'";

    //print('*******insertCustomerReceiveProductDetailsForReject*******$insertStickerQuery');
    var result1;
    try {
      result1 = await dbClient.rawInsert(insertStickerQuery);
    } catch (e) {
      print(e.toString());
    }

    return result1;
  }

  Future<int> insertReceiveSticker(
      int fk_Customer_ReceiveGlCode,
      int fk_Product_SKU_Glcode,
      String chrPallet,
      int fk_PalletGlCode,
      int fk_StickerGlCode,
      String varSticker,
      int initGICode,
      String syncCode,
      String charValid) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt from CPM_Customer_Receive_Product_Details b  where b.fk_Customer_ReceiveGlCode='$fk_Customer_ReceiveGlCode'";

    print('*******insertReceiveSticker***countQuery****$countQuery');
    var result = await dbClient.rawQuery(countQuery);

    List<String> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "INSERT INTO CPM_Customer_Receive_Product_Details\n" +
        "(\n" +
        "   fk_Customer_ReceiveGlCode,\n" +
        "    intRowNo,\n" +
        "    fk_Product_SKU_Glcode,\n" +
        "    chrPallet,      \n" +
        "    fk_PalletGlCode,      \n" +
        "    fk_StickerGlCode,\n" +
        "    varSticker,\n" +
        "    chrValid,\n" +
        "    chrActive,\n" +
        "    chrSync,                   \n" +
        "    varSync_Code,              \n" +
        "    dtSyncDate,                \n" +
        "    dtEntryDate,              \n" +
        "    ref_Entry_By,             \n" +
        "    dtModifiedDate,            \n" +
        "    ref_Modified_By            \n" +
        ")\n" +
        "VALUES\n" +
        "(\n" +
        "'$fk_Customer_ReceiveGlCode'," +
        "'$count'," +
        "'$fk_Product_SKU_Glcode'," +
        "'$chrPallet'," +
        "'$fk_PalletGlCode'," +
        "'$fk_StickerGlCode'," +
        "'$varSticker'," +
        "'$charValid'," +
        "'Y',\n" +
        "'N',\n" +
        "'$syncCode'," +
        "datetime('now'),\n" +
        "datetime('now'),\n" +
        "'$initGICode'," +
        "NULL,\n" +
        "NULL\n" +
        ")";

    print('*******insertReceiveSticker****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }

    //});

    return result1;
  }

  Future<int> insertReceiveStickerForPallet(
      int fk_Customer_ReceiveGlCode,
      int initGICode,
      String syncCode,
      String charValid,
      int fk_PalletGlCode) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt from CPM_Customer_Receive_Product_Details b  where b.fk_Customer_ReceiveGlCode='$fk_Customer_ReceiveGlCode'";

    print('*******insertReceiveSticker***countQuery****$countQuery');
    var result = await dbClient.rawQuery(countQuery);

    List<String> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "INSERT INTO CPM_Customer_Receive_Product_Details" +
        "  (" +
        "    fk_Customer_ReceiveGlCode," +
        "    intRowNo," +
        "    fk_Product_SKU_Glcode," +
        "    chrPallet," +
        "    fk_PalletGlCode," +
        "    fk_StickerGlCode," +
        "    varSticker," +
        "    chrValid," +
        "    chrActive," +
        "    chrSync," +
        "    varSync_Code," +
        "    dtSyncDate," +
        "    dtEntryDate," +
        "    ref_Entry_By," +
        "    dtModifiedDate," +
        "    ref_Modified_By" +
        ")" +
        " SELECT DISTINCT $fk_Customer_ReceiveGlCode," +
        " $count," +
        " CSD.fk_Product_SKUGlCode," +
        " CSD.chrPallet," +
        " CSD.fk_PalletGlCode," +
        " CSD.intGlCode as fk_StickerGlCode," +
        " CSD.varBTC_No_Out as varSticker," +
        " '$charValid' AS chrValid," +
        " 'Y' AS chrActive," +
        " 'N' AS chrSync," +
        " '$syncCode'||replace(datetime('now'),' ','')||CSD.intGlCode AS varSync_Code," +
        " datetime('now') AS  dtSyncDate," +
        " datetime('now') AS dtEntryDate," +
        " $initGICode AS ref_Entry_By," +
        " NULL AS dtModifiedDate," +
        " NULL AS ref_Modified_By" +
        " FROM CPM_Sticker_Details as CSD" +
        " WHERE CSD.fk_PalletGlCode='$fk_PalletGlCode'" +
        " AND CSD.chrActive='Y'";

    print('*******insertReceiveSticker****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }

    //});

    return result1;
  }

  Future<int> insertDamageStickerForRemove(
      int loginUserGlCode,
      int mainUSerIntGICode,
      int fk_StickerGlCode,
      String varSticker,
      String syncCode,
      String charValid,
      String varTransactionCode,
      int fk_Sticker_DamageGlCode) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt FROM CPM_Customer_Sticker_Damage_Remove b  WHERE ifnull(b.chrValidSave,'N')='N'";

    print('*******insertDamageStickerForRemove***countQuery****$countQuery');
    var result = await dbClient.rawQuery(countQuery);

    List<String> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "\n" +
        "INSERT INTO CPM_Customer_Sticker_Damage_Remove \n" +
        "(\n" +
        "    fk_Sticker_DamageGlCode,\n" +
        "    fk_CustomerGlCode,\n" +
        "    intRowNo,\n" +
        "    varTransactionCode,\n" +
        "    fk_StickerGlCode,\n" +
        "    VarSticker,\n" +
        "    chrValid,\n" +
        "    chrActive ,\n" +
        "    chrValidSave ,\n" +
        "    chrSync,\n" +
        "    varSync_Code,\n" +
        "    dtSyncDate,\n" +
        "    ref_Entry_By,\n" +
        "    dtEntryDate,\n" +
        "    dtModifiedDate,\n" +
        "    ref_Modified_By\n" +
        ")\n" +
        "VALUES\n" +
        "(\n" +
        "'$fk_Sticker_DamageGlCode',\n" +
        "'$mainUSerIntGICode',\n" +
        "'$count',\n" +
        "'$varTransactionCode',\n" +
        "'$fk_StickerGlCode',\n" +
        "'$varSticker',\n" +
        "'$charValid',\n" +
        "'Y',\n" +
        "'N', \n" +
        "'N' ,\n" +
        "'$syncCode',\n" +
        "datetime('now'),\n" +
        "'$loginUserGlCode',\n" +
        "datetime('now'),\n" +
        "NULL,\n" +
        "NULL\n" +
        ")";

    print('*******insertDamageStickerForRemove****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }

    //});

    return result1;
  }

  Future<int> insertDamageSticker(
      int loginUserGlCode,
      int mainUSerIntGICode,
      int fk_StickerGlCode,
      String varSticker,
      String syncCode,
      String charValid,
      String varTransactionCode,
      int fk_ReceiveFromGlCode) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt FROM CPM_Customer_Sticker_Damage b  WHERE ifnull(b.chrValidSave,'N')='N' AND varTransactionCode='$varTransactionCode'";

    print('*******insertDamageSticker***countQuery****$countQuery');

    var result = await dbClient.rawQuery(countQuery);

    List<String> list = new List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "\n" +
        "INSERT INTO CPM_Customer_Sticker_Damage \n" +
        "(\n" +
        "    fk_CustomerGlCode,\n" +
        "    intRowNo,\n" +
        "    varTransactionCode,\n" +
        "    fk_ReceiveFromGlCode,\n" +
        "    fk_StickerGlCode,\n" +
        "    VarSticker,\n" +
        "    chrValid,\n" +
        "    chrActive ,\n" +
        "    chrValidSave ,\n" +
        "    chrSync,\n" +
        "    varSync_Code,\n" +
        "    dtSyncDate,\n" +
        "    ref_Entry_By,\n" +
        "    dtEntryDate,\n" +
        "    dtModifiedDate,\n" +
        "    ref_Modified_By,\n" +
        "    chrRemove,\n" +
        "    dtRemoveDamage,\n" +
        "    fk_RemoveBy\n" +
        ")\n" +
        "VALUES\n" +
        "(\n" +
        "'$mainUSerIntGICode',\n" +
        "'$count',\n" +
        "'$varTransactionCode',\n" +
        "'$fk_ReceiveFromGlCode',\n" +
        "'$fk_StickerGlCode',\n" +
        "'$varSticker',\n" +
        "'$charValid',\n" +
        "'Y',\n" +
        "'N', \n" +
        "'N' ,\n" +
        "'$syncCode',\n" +
        "datetime('now'),\n" +
        "'$loginUserGlCode',\n" +
        "datetime('now'),\n" +
        "NULL,\n" +
        "NULL,\n" +
        "'N',\n" +
        "NULL,\n" +
        "NULL\n" +
        ")";

    print('*******insertDamageSticker****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }

    //});

    return result1;
  }

  Future<int> insertScrapSticker(
      int loginUserGlCode,
      int mainUSerIntGICode,
      int fk_StickerGlCode,
      String varSticker,
      String syncCode,
      String charValid,
      String varTransactionCode,
      int fk_ReceiveFromGlCode) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt FROM CPM_Customer_Sticker_Scrap b WHERE ifnull(b.chrValidSave,'N')='N' AND varTransactionCode='$varTransactionCode'";

    print('*******insertScrapSticker***countQuery****$countQuery');

    var result = await dbClient.rawQuery(countQuery);

    List<String> list = List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "\n" +
        "INSERT INTO CPM_Customer_Sticker_Scrap \n" +
        "(\n" +
        "  fk_CustomerGlCode,\n" +
        "  fk_StickerGlCode,\n" +
        "  chrPallet,\n" +
        "  fk_PalletGlCode,\n" +
        "  varSticker,\n" +
        "  fk_ReceiveFromGlCode,\n" +
        "  varRemarks,\n" +
        "  chrValid,\n" +
        "  chrActive,\n" +
        "  chrValidSave,\n" +
        "  chrSync,\n" +
        "  varSync_Code,\n" +
        "  dtSyncDate,\n" +
        "  ref_Entry_By,\n" +
        "  dtEntryDate,\n" +
        "  dtModifiedDate,\n" +
        "  ref_Modified_By,\n" +
        "  intRowNo,\n" +
        "  varTransactionCode\n" +
        ")\n" +
        "VALUES\n" +
        "(\n" +
        "'$mainUSerIntGICode',\n" +
        "'$fk_StickerGlCode',\n" +
        "'N',\n" +
        "'0',\n" +
        "'$varSticker',\n" +
        "'$fk_ReceiveFromGlCode',\n" +
        "'',\n" +
        "'$charValid',\n" +
        "'Y',\n" +
        "'N',\n" +
        "'N',\n" +
        "'$syncCode',\n" +
        "datetime('now'),\n" +
        "'$loginUserGlCode',\n" +
        "datetime('now'),\n" +
        "NULL,\n" +
        "NULL,\n" +
        "'$count',\n" +
        "'$varTransactionCode'\n" +
        ")";

    print('*******insertScrapSticker****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }

    //});

    return result1;
  }

  Future<int> insertConsumeSticker(
      int loginUserGlCode,
      int mainUSerIntGICode,
      int fk_StickerGlCode,
      String varSticker,
      String syncCode,
      String charValid,
      String varTransactionCode,
      int fk_ReceiveFromGlCode) async {
    var dbClient = await getDB();

    String countQuery =
        "select count(*) AS intCnt FROM CPM_Customer_Sticker_Consume b WHERE ifnull(b.chrValidSave,'N')='N' AND varTransactionCode='$varTransactionCode'";

    print('*******insertConsumeSticker***countQuery****$countQuery');

    var result = await dbClient.rawQuery(countQuery);

    List<String> list = List();
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        list.add(result[i]['intCnt'].toString());
      }
    }

    int count = 0;
    //if (list.length > 0) {
    if (list.isNotEmpty) {
      int temp = int.parse(list[0]);
      count = temp + 1;
    }

    String QUERY = "\n" +
        "INSERT INTO CPM_Customer_Sticker_Consume \n" +
        "(\n" +
        "  fk_CustomerGlCode,\n" +
        "  fk_StickerGlCode,\n" +
        "  chrPallet,\n" +
        "  fk_PalletGlCode,\n" +
        "  varSticker,\n" +
        "  fk_ReceiveFromGlCode,\n" +
        "  varRemarks,\n" +
        "  decConsumeQty,\n" +
        "  chrValid,\n" +
        "  chrActive,\n" +
        "  chrValidSave,\n" +
        "  chrSync,\n" +
        "  varSync_Code,\n" +
        "  dtSyncDate,\n" +
        "  ref_Entry_By,\n" +
        "  dtEntryDate,\n" +
        "  dtModifiedDate,\n" +
        "  ref_Modified_By,\n" +
        "  intRowNo,\n" +
        "  varTransactionCode\n" +
        ")\n" +
        "VALUES\n" +
        "(\n" +
        "'$mainUSerIntGICode',\n" +
        "'$fk_StickerGlCode',\n" +
        "'N',\n" +
        "'0',\n" +
        "'$varSticker',\n" +
        "'$fk_ReceiveFromGlCode',\n" +
        "'',\n" +
        "'0.0',\n" +
        "'$charValid',\n" +
        "'Y',\n" +
        "'N',\n" +
        "'N',\n" +
        "'$syncCode',\n" +
        "datetime('now'),\n" +
        "'$loginUserGlCode',\n" +
        "datetime('now'),\n" +
        "NULL,\n" +
        "NULL,\n" +
        "'$count',\n" +
        "'$varTransactionCode'\n" +
        ")";

    print('*******insertConsumeSticker****QUERY***$QUERY');
    var result1;
    try {
      result1 = await dbClient.rawInsert(QUERY);
    } catch (e) {
      print(e.toString());
    }
    return result1;
  }

  Future<List<ScanDataModel>> getScanDataList(
      int fk_Customer_DispatchGlCode, String screenState) async {
    var dbClient = await getDB();
    String QUERY = "";

    if (screenState == TAG_DISPATCH ||
        screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
        screenState == TAG_STOCK_TRANSFER ||
        screenState == TAG_FOC ||
        screenState == TAG_SALES_RETURN) {
      /*QUERY = "SELECT CCDPD." +
          DatabaseQuery.COLUMN_INT_GI_CODE +
          " as fk_Customer_DispatchProduct_GLCode," +
          "ifNull(intRowNo,0) AS intRowNo," +
          " CCDPD.varSticker AS varSticker," +
          " CCDPD.chrValid AS chrValid" +
          " FROM " +
          DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
          " CCDPD" +
          " WHERE CCDPD." +
          DatabaseQuery.COLUMN_FK_CUSTOMER_DISPATCH_GI_CODE +
          "='$fk_Customer_DispatchGlCode'" +
          " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I') ORDER BY intRowNo DESC";*/

      QUERY = "SELECT res.fk_Customer_DispatchProduct_GLCode," +
          " res.intRowNo," +
          " res.fk_Customer_DispatchGlCode," +
          " res.varSticker," +
          " res.chrValid," +
          " res.chrPallet," +
          " (CASE WHEN ifnull( res.chrPallet, 'N' ) = 'Y'  THEN" +
          " (SELECT count(DISTINCT CCDPD1.intGlCode)" +
          " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD1" +
          " WHERE CCDPD1.fk_Customer_DispatchGlCode=res.fk_Customer_DispatchGlCode" +
          " AND CCDPD1.fk_PalletGlCode=res.fk_PalletGlCode" +
          " AND CCDPD1.chrPallet='Y'" +
          " AND ifnull( CCDPD1.chrActive, 'N' ) IN ( 'Y', 'I' ) AND CCDPD1.chrValid = 'Y')" +
          " ELSE 0 END) AS intNoOfSticker" +
          " FROM" +
          " (SELECT DISTINCT" +
          " (case when ifnull(CCDPD.chrPallet,'N')='Y' then CCDPD.fk_PalletGlCode else CCDPD.intGlCode end)  as fk_Customer_DispatchProduct_GLCode," +
          " (case when ifnull(CCDPD.chrPallet,'N')='Y' then 0 else ifNull(intRowNo,0)  end)  AS intRowNo," +
          " (case when ifnull(CCDPD.chrPallet,'N')='Y' then CPM.varPalletNo else CCDPD.varSticker end)  AS varSticker," +
          " (case when ifnull(CCDPD.chrPallet,'N')='Y' then 'Y' else CCDPD.chrValid end) as chrValid," +
          " CCDPD.chrPallet AS chrPallet," +
          " CCDPD.fk_Customer_DispatchGlCode as fk_Customer_DispatchGlCode," +
          " (case when ifnull(CCDPD.chrPallet,'N')='Y' then CCDPD.fk_PalletGlCode else 0 end) as fk_PalletGlCode" +
          " FROM CPM_Customer_Dispatch_Product_Details CCDPD" +
          " LEFT JOIN CPM_Pallet_MST CPM ON CCDPD.fk_PalletGlCode=CPM.intGlCode" +
          " WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'" +
          " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')" +
          " ORDER BY CCDPD.dtEntryDate DESC) as res";
    } else if (screenState == TAG_RECEIVE) {
      QUERY = "SELECT res.fk_Customer_DispatchProduct_GLCode," +
          "   res.intRowNo," +
          " res.varSticker," +
          " res.fk_Customer_ReceiveGlCode," +
          " res.chrValid," +
          " res.chrPallet," +
          " (CASE WHEN ifnull( res.chrPallet, 'N' ) = 'Y'  THEN" +
          " (SELECT count(DISTINCT CCRPD1.intGlCode)" +
          " FROM CPM_Customer_Receive_Product_Details AS CCRPD1" +
          " WHERE CCRPD1.fk_Customer_ReceiveGlCode=res.fk_Customer_ReceiveGlCode" +
          " AND CCRPD1.fk_PalletGlCode=res.fk_PalletGlCode" +
          " AND CCRPD1.chrPallet='Y'" +
          " AND ifnull( CCRPD1.chrActive, 'N' ) IN ( 'Y' )" +
          " AND CCRPD1.chrValid='Y' )" +
          " ELSE 0 END)  AS intNoOfSticker" +
          " FROM" +
          " (SELECT  DISTINCT (case when ifnull(CCRPD.chrPallet,'N')='Y' then CCRPD.fk_PalletGlCode else CCRPD.intGlCode end) as fk_Customer_DispatchProduct_GLCode," +
          " (case when ifnull(CCRPD.chrPallet,'N')='Y' then 0 else CCRPD.intRowNo end)  as intRowNo," +
          " (case when ifnull(CCRPD.chrPallet,'N')='Y' then CPM.varPalletNo else CCRPD.varSticker end) AS varSticker," +
          " (case when ifnull(CCRPD.chrPallet,'N')='Y' then 'Y' else CCRPD.chrValid end) AS chrValid," +
          " CCRPD.chrPallet," +
          " CCRPD.fk_Customer_ReceiveGlCode as fk_Customer_ReceiveGlCode," +
          " (case when ifnull(CCRPD.chrPallet,'N')='Y' then CCRPD.fk_PalletGlCode else 0 end) as fk_PalletGlCode" +
          " FROM CPM_Customer_Receive_Product_Details as CCRPD\n" +
          " LEFT JOIN CPM_Pallet_MST CPM ON CCRPD.fk_PalletGlCode=CPM.intGlCode " +
          " WHERE CCRPD.fk_Customer_ReceiveGlCode='$fk_Customer_DispatchGlCode' AND CCRPD.chrActive='Y' ORDER BY CCRPD.dtEntryDate DESC) as res";
    } else if (screenState == TAG_ADD_DAMAGE_STOCK) {
      QUERY = "SELECT CCSD.intGlCode as fk_Customer_DispatchProduct_GLCode,CCSD.chrValid AS chrValid,\n" +
          "       CCSD.varSticker AS varSticker,\n" +
          "       CCSD.intRowNo as intRowNo\n" +
          "       FROM CPM_Customer_Sticker_Damage CCSD \n" +
          "       WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
          "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
          "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
          "      AND CCSD.fk_CustomerGlCode='$fk_Customer_DispatchGlCode' ORDER BY intRowNo DESC";
    } else if (screenState == TAG_REMOVE_DAMAGE_STOCK) {
      QUERY = "SELECT CCSD.intGlCode as fk_Customer_DispatchProduct_GLCode,CCSD.chrValid AS chrValid,\n" +
          "       CCSD.varSticker AS varSticker,\n" +
          "       CCSD.intRowNo as intRowNo\n" +
          "       FROM CPM_Customer_Sticker_Damage_Remove CCSD \n" +
          "       WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
          "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
          "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
          "      AND CCSD.fk_CustomerGlCode='$fk_Customer_DispatchGlCode' ORDER BY intRowNo DESC";
    } else if (screenState == TAG_SCRAP_STOCK) {
      QUERY = "SELECT CCSS.intGlCode as fk_Customer_DispatchProduct_GLCode,CCSS.chrValid AS chrValid,\n" +
          "       CCSS.varSticker AS varSticker,\n" +
          "       CCSS.intRowNo as intRowNo\n" +
          "       FROM CPM_Customer_Sticker_Scrap CCSS \n" +
          "       WHERE ifnull(CCSS.chrActive,'N')='Y'\n" +
          "      AND ifnull(CCSS.chrSync,'N')='N'\n" +
          "      AND ifnull(CCSS.chrValidSave,'N')='N'\n" +
          "      AND CCSS.fk_CustomerGlCode='$fk_Customer_DispatchGlCode' ORDER BY intRowNo DESC";
    } else if (screenState == TAG_CONSUME_STOCK) {
      QUERY = "SELECT CCSC.intGlCode as fk_Customer_DispatchProduct_GLCode,"
          "       CCSC.chrValid AS chrValid,\n" +
          "       CCSC.varSticker AS varSticker,\n" +
          "       CCSC.intRowNo as intRowNo\n" +
          "       FROM CPM_Customer_Sticker_Consume CCSC \n" +
          "       WHERE ifnull(CCSC.chrActive,'N')='Y'\n" +
          "      AND ifnull(CCSC.chrSync,'N')='N'\n" +
          "      AND ifnull(CCSC.chrValidSave,'N')='N'\n" +
          "      AND CCSC.fk_CustomerGlCode='$fk_Customer_DispatchGlCode'"
              "      ORDER BY intRowNo DESC";
    }
    print('===getScanDataList======QUERY===$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=====result======${result.toString()}');
    List<ScanDataModel> list = List();

    if (result.isNotEmpty) {
      int introw = result.length;
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        masterModel.intRows = introw;
        masterModel.isDeleted = false;
        masterModel.isMultiDeleted = false;
        introw = introw - 1;
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ReceiveRecordModel>> getReceiveDataList(int fkMainCustomerGlCode,
      String doNo, String TranType) async {
    var dbClient = await getDB();

    print("=======TranType=========$TranType");

    String QUERY = "SELECT  res.intGlCode intGlCode,\n" +
        "          res.varSONO as varSONO,\n" +
        "          res.varDONO as varDONO,\n" +
        "          res.varEntityName as varEntityName,\n" +
        "          res.chrTransType as chrTransType,\n" +
        "          res.fk_ReturnStatusGlCode as fk_ReturnStatusGlCode," +
        "          res.varReturnStatus as varReturnStatus," +
        "          (case when res.chrTransType='D' THEN 'Dispatch' when res.chrTransType='R' THEN 'Sales Return' when res.chrTransType='F' THEN 'FOC' ELSE 'Stock Transfer' END) varTranType,\n" +
        "          res.dtDispatchDate as dtDispatchDate,\n" +
        "          res.varOrganisationName as varFullName,\n" +
        "          (res.intTotalUnit-res.intScanCount) as intTotalUnit,\n" +
        "          (res.intTotalProductPendingScan ) as intTotalProduct,\n" +
        "          (CASE WHEN res.intScanCount=0 THEN 'W' ELSE 'B' END) as chrColor\n" +
        "  FROM \n" +
        "    (SELECT CCD.intGlCode,\n" +
        "            CCD.varSONO,\n" +
        "            CCD.varDONO,\n" +
        "            CCD.varEntityName,\n" +
        "            CCD.dtDispatchDate,\n" +
        "            PM_DES.varOrganisationName,\n" +
        "            CCD.chrTransType,\n" +
        "            SM.intGlCode as fk_ReturnStatusGlCode," +
        "            SM.varStatus as varReturnStatus," +
        "            COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit,\n" +
        "            COUNT(DISTINCT CCDPD.fk_Product_SKU_Glcode) as intTotalProduct,\n" +
        "            (SELECT COUNT(DISTINCT fk_StickerGlCode) as intScanCount\n" +
        "             FROM CPM_Customer_Receive CCR\n" +
        "             INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "             WHERE CCR.chrActive='Y'\n" +
        "                   AND CCRPD.chrActive='Y'\n" +
        "                   AND CCR.fk_DispatchGlCode IN(CCD.intGlCode)\n" +
        "                   AND CCR.chrValidSave IN('Y')\n" +
        "                   AND CCRPD.chrValid='Y'\n" +
        "             ) as intScanCount,\n" +
        "             (SELECT count(DISTINCT \n" +
        "CCDPD_PRD.fk_Product_SKU_Glcode )\n" +
        "                  FROM CPM_Customer_Dispatch_Product_Details as \n" +
        "CCDPD_PRD \n" +
        "                  LEFT JOIN CPM_Customer_Receive CCR_PRD ON \n" +
        "CCDPD_PRD.fk_Customer_DispatchGlCode=CCR_PRD.fk_DispatchGlCode\n" +
        "                                                             AND \n" +
        "CCR_PRD.chrActive='Y'\n" +
        "                                                             AND \n" +
        "CCR_PRD.chrValidSave in ('Y','N')\n" +
        "                                                             AND \n" +
        "CCR_PRD.fk_DispatchGlCode IN (CCD.intGlCode)\n" +
        "                  LEFT JOIN CPM_Customer_Receive_Product_Details AS \n" +
        "CCRPD_PRD ON CCR_PRD.intGlCode=CCRPD_PRD.fk_Customer_ReceiveGlCode \n" +
        "                                                                      \n" +
        "           AND CCDPD_PRD.fk_StickerGlCode=CCRPD_PRD.fk_StickerGlCode \n" +
        "                                                                      \n" +
        "           AND CCRPD_PRD.chrActive='Y'\n" +
        "                                                                      \n" +
        "           AND CCRPD_PRD.chrValid='Y'\n" +
        "                  WHERE   CCDPD_PRD.chrActive='Y'\n" +
        "                          AND CCDPD_PRD.chrValid='Y'\n" +
        "                          AND CCDPD_PRD.fk_Customer_DispatchGlCode \n" +
        "IN(CCD.intGlCode)\n" +
        "                          AND CCDPD_PRD.fk_StickerGlCode AND \n" +
        "CCRPD_PRD.intGlCode IS NULL ) as intTotalProductPendingScan \n" +
        "    FROM CPM_Customer_Dispatch as CCD\n" +
        "    INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "    INNER JOIN Person_Mst as PM_DES ON CCD.fk_Customer_From_GlCode=PM_DES.intGlCode\n" +
        "    INNER JOIN Person_Mst as PM_REC ON CCD.fk_Customer_To_GlCode=PM_REC.intGlCode\n" +
        "    INNER JOIN Countries_Mst as CM ON PM_REC.fk_CountryGlCode=CM.intGlCode \n" +
        "    LEFT JOIN Status_Mst as SM ON CCD.fk_ReturnStatusGlCode=SM.intGlCode AND SM.varPurpose='CPM_RT'" +
        "    WHERE CCD.fk_Customer_To_GlCode='$fkMainCustomerGlCode'" +
        "         AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "         AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "         AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "         AND ifnull(CCD.chrValidSave,'N')='Y'\n" +
        "         AND ifnull(CCD.chrConfirm,'N')='Y'\n" +
        "         AND (ifnull(CCD.chrCompleted,'N')='N' OR CCD.chrCompleted='')" +
        "         AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "         AND (UPPER(CCD.varDONO) like '%'||UPPER('$doNo')||'%' OR UPPER('$doNo')='' )\n" +
        "         AND (CCD.chrTransType IN($TranType))\n" +
        "    GROUP BY CCD.intGlCode,\n" +
        "             CCD.varSONO,\n" +
        "             CCD.varDONO,\n" +
        "             CCD.varEntityName,\n" +
        "             CCD.chrTransType,\n" +
        "             SM.intGlCode," +
        "             SM.varStatus," +
        "             CCD.dtDispatchDate,\n" +
        "             PM_DES.varFullName) as res \n" +
        "WHERE (res.intTotalUnit-res.intScanCount)>0 ORDER BY res.dtDispatchDate DESC";

    print('***getReceiveDataList***QUERY******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    //print('=====result======${result.toString()}');
    List<ReceiveRecordModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ReceiveRecordModel masterModel = ReceiveRecordModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }

    return list;
  }

  Future<List<FilterModel>> getFilterCountForReceive(
      int fkMainCustomerGlCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT (CASE WHEN CCD.chrTransType='D' THEN 'Dispatch'" +
        " WHEN CCD.chrTransType='S' THEN 'Stock Transfer'" +
        " WHEN CCD.chrTransType='R' THEN 'Sales Return'" +
        " WHEN CCD.chrTransType='F' THEN 'FOC'" +
        " ELSE 'Dispatch'" +
        " END) as varTransactionType," +
        " CCD.chrTransType," +
        " count(DISTINCT CCD.intGlCode) as intCount" +
        " FROM CPM_Customer_Dispatch as CCD" +
        " INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode" +
        " INNER JOIN Person_Mst as PM_DES ON CCD.fk_Customer_From_GlCode=PM_DES.intGlCode" +
        " INNER JOIN Person_Mst as PM_REC ON CCD.fk_Customer_To_GlCode=PM_REC.intGlCode" +
        " WHERE CCD.fk_Customer_To_GlCode='$fkMainCustomerGlCode'" +
        " AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')" +
        " AND ifnull(CCD.chrActive,'N')='Y'" +
        " AND ifnull(CCD.chrValidSave,'N')='Y'" +
        " AND ifnull(CCD.chrConfirm,'N')='Y'" +
        " AND (ifnull(CCD.chrCompleted,'N')='N' OR CCD.chrCompleted='')" +
        " AND ifnull(CCDPD.chrActive,'N')='Y'" +
        " AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')" +
        " AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " GROUP BY  CCD.chrTransType";

    print('***getFilterCountForReceive***QUERY******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=====result======${result.toString()}');
    List<FilterModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        FilterModel masterModel = FilterModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }

    return list;
  }

  Future<List> getReceiveCount(int fkMainCustomerGlCode) async {
    var dbClient = await getDB();

    String chrDOConfiguration = "";
    String chrSTOConfiguration = "";
    String chrSRConfiguration = "";
    String chrFOCConfiguration = "";

    if (globals.DOConfiguration == 'Y') {
      chrDOConfiguration = "D";
    }
    if (globals.STOConfiguration == 'Y') {
      chrSTOConfiguration = "S";
    }
    if (globals.SRConfiguration == 'Y') {
      chrSRConfiguration = "R";
    }
    if (globals.FOCConfiguration == 'Y') {
      chrFOCConfiguration = "F";
    }

    String QUERY_TOTAL_RECEIVE_ITEM = "SELECT   CCD.intGlCode as _id,\n" +
        "         CCD.varSONO,\n" +
        "         CCD.varDONO,\n" +
        "         CCD.dtDispatchDate AS dtDispatchDate,\n" +
        "         PM_DES.varOrganisationName,\n" +
        "         COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit,\n" +
        "         COUNT(DISTINCT CCDPD.fk_Product_SKU_Glcode) as intTotalProduct\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN Person_Mst as PM_DES ON CCD.fk_Customer_From_GlCode=PM_DES.intGlCode\n" +
        "INNER JOIN Person_Mst as PM_REC ON CCD.fk_Customer_To_GlCode=PM_REC.intGlCode\n" +
        "INNER JOIN Countries_Mst as CM ON PM_REC.fk_CountryGlCode=CM.intGlCode \n" +
        "WHERE CCD.fk_Customer_To_GlCode='$fkMainCustomerGlCode'"
            "      AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCD.chrValidSave,'N')='Y'\n" +
        "      AND ifnull(CCD.chrConfirm,'N')='Y'\n" +
        "      AND (ifnull(CCD.chrCompleted,'N')='N' OR CCD.chrCompleted='')" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')\n" +
        "      AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "      AND (UPPER(CCD.varDONO) like '%'||''||'%' OR ''='' )\n" +
        "      AND CCD.chrTransType IN('$chrDOConfiguration','$chrSTOConfiguration','$chrSRConfiguration','$chrFOCConfiguration')\n" +
        "GROUP BY CCD.intGlCode,\n" +
        "\t\t CCD.varSONO,\n" +
        "         CCD.varDONO,\n" +
        "         CCD.dtDispatchDate,\n" +
        "         PM_DES.varOrganisationName";
    print('***getReceiveDataList***QUERY******$QUERY_TOTAL_RECEIVE_ITEM');
    var result = await dbClient.rawQuery(QUERY_TOTAL_RECEIVE_ITEM);
    print('-======result===${result.toString()}');
    return result;
  }

  Future<List<ReceiveRecordModel>> getReceiveSecondRecordList(
      int fkMainCustomerGlCode, int fkDispatchGlCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT res.intGlCode intGlCode,\n" +
        "          res.varSONO as varSONO,\n" +
        "          res.varDONO as varDONO,\n" +
        "          res.varEntityName as varEntityName,\n" +
        "          res.dtDispatchDate as dtDispatchDate,\n" +
        "          res.varOrganisationName as varFullName,\n" +
        "          (res.intTotalUnit-res.intScanCount) as intTotalUnit,\n" +
        "          (res.intTotalProductPendingScan ) as intTotalProduct,\n" +
        "          (CASE WHEN res.intScanCount=0 THEN 'W' ELSE 'B' END) as chrColor\n" +
        "  FROM \n" +
        "    (SELECT CCD.intGlCode,\n" +
        "            CCD.varSONO,\n" +
        "            CCD.varDONO,\n" +
        "            CCD.varEntityName,\n" +
        "            CCD.dtDispatchDate,\n" +
        "            PM_DES.varOrganisationName,\n" +
        "            COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit,\n" +
        "            COUNT(DISTINCT CCDPD.fk_Product_SKU_Glcode) as intTotalProduct,\n" +
        "            (SELECT COUNT(DISTINCT fk_StickerGlCode) as intScanCount\n" +
        "             FROM CPM_Customer_Receive CCR\n" +
        "             INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "             WHERE CCR.chrActive='Y'\n" +
        "                   AND CCRPD.chrActive='Y'\n" +
        "                   AND CCR.fk_DispatchGlCode IN(CCD.intGlCode)\n" +
        "                   AND CCR.chrValidSave IN('Y')\n" +
        "                   AND CCRPD.chrValid='Y'\n" +
        "             ) as intScanCount,\n" +
        "             (SELECT COUNT(DISTINCT CCDPD_PRD.fk_Product_SKU_Glcode) as intStickerCount\n" +
        "             FROM CPM_Customer_Dispatch AS CCD_PRD\n" +
        "             INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD_PRD ON CCD_PRD.intGlCode=CCDPD_PRD.fk_Customer_DispatchGlCode\n" +
        "             INNER JOIN CPM_Customer_Receive as CCR_PRD ON CCD_PRD.intGlCode=CCR_PRD.fk_DispatchGlCode\n" +
        "             LEFT JOIN CPM_Customer_Receive_Product_Details AS CCRPD_PRD ON CCR_PRD.intGlCode=CCRPD_PRD.fk_Customer_ReceiveGlCode \n" +
        "                                                                            AND CCDPD_PRD.fk_StickerGlCode=CCRPD_PRD.fk_StickerGlCode \n" +
        "                                                                            AND CCRPD_PRD.chrActive='Y'\n" +
        "                                                                            AND CCRPD_PRD.chrValid='Y'\n" +
        "             WHERE CCD_PRD.chrActive='Y'\n" +
        "                   AND CCD_PRD.chrValidSave='Y'\n" +
        "                   AND CCDPD_PRD.chrActive='Y'\n" +
        "                   AND CCDPD_PRD.chrValid='Y'\n" +
        "                   AND CCD_PRD.intGlCode IN(CCD.intGlCode)\n" +
        "                   AND CCR_PRD.chrActive='Y'\n" +
        "                   AND CCR_PRD.chrValidSave='Y'\n" +
        "                   AND CCRPD_PRD.intGlCode IS NULL\n" +
        "                     ) as intTotalProductPendingScan \n" +
        "    FROM CPM_Customer_Dispatch as CCD\n" +
        "    INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "    INNER JOIN Person_Mst as PM_DES ON CCD.fk_Customer_From_GlCode=PM_DES.intGlCode\n" +
        "    INNER JOIN Person_Mst as PM_REC ON CCD.fk_Customer_To_GlCode=PM_REC.intGlCode\n" +
        "    INNER JOIN Countries_Mst as CM ON PM_REC.fk_CountryGlCode=CM.intGlCode \n" +
        "    WHERE CCD.fk_Customer_To_GlCode='$fkMainCustomerGlCode'" +
        "         AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "         AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "         AND ifnull(CCD.chrValidSave,'N')='Y'\n" +
        "         AND (ifnull(CCD.chrCompleted,'N')='N' OR CCD.chrCompleted='')" +
        "         AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "         AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "         AND (UPPER(CCD.varDONO) like '%'||''||'%' OR ''='' )\n" +
        "      AND CCD.intGlCode='$fkDispatchGlCode'" +
        "    GROUP BY CCD.intGlCode,\n" +
        "    \t CCD.varSONO,\n" +
        "             CCD.varDONO,\n" +
        "             CCD.varEntityName,\n" +
        "             CCD.dtDispatchDate,\n" +
        "             PM_DES.varOrganisationName) as res \n" +
        "WHERE (res.intTotalUnit-res.intScanCount)>0";

    var result = await dbClient.rawQuery(QUERY);
    print('=====result======${result.toString()}');
    List<ReceiveRecordModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ReceiveRecordModel masterModel = ReceiveRecordModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }

    return list;
  }

  Future<List<ReceiveDataModel>> getReceiveSecondDataList(
      int fkMainCustomerGlCode, int fkDispatchGlCode) async {
    var dbClient = await getDB();

    print('');

    String QUERY = "SELECT 0 _id,res.intGlCode as fk_Product_SKUGlCode,\n" +
        " res.varProduct_SKU_Code||' - '||res.varProduct_SKU_Name as varProduct_SKU_NAME," +
        "       (res.intTotalUnit-res.intLastScanCount) as intTotalUnit,\n" +
        "       res.intScanCount as intScanCount,\n" +
        "       ((res.intTotalUnit-res.intLastScanCount)-res.intScanCount) as intPendingCount\n" +
        " FROM\n" +
        " (SELECT  PSM.intGlCode,\n" +
        "        PSM.varProduct_SKU_Name,\n" +
        "        PSM.varProduct_SKU_Code,\n" +
        "        COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit,\n" +
        "        (SELECT COUNT(DISTINCT fk_StickerGlCode) as intScanCount\n" +
        "            FROM CPM_Customer_Receive CCR\n" +
        "            INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "            WHERE CCR.chrActive='Y'\n" +
        "                  AND CCRPD.chrActive='Y'\n" +
        "                  AND CCR.fk_DispatchGlCode IN(CCD.intGlCode)\n" +
        "                  AND CCRPD.fk_Product_SKU_Glcode IN(CCDPD.fk_Product_SKU_Glcode)\n" +
        "                  AND CCRPD.chrValid='Y'\n" +
        "                  AND CCR.chrValidSave IN('Y')\n" +
        "                  ) as intLastScanCount,\n" +
        "(SELECT COUNT(DISTINCT fk_StickerGlCode) as intScanCount\n" +
        "            FROM CPM_Customer_Receive CCR\n" +
        "            INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "            WHERE CCR.chrActive='Y'\n" +
        "                  AND CCRPD.chrActive='Y'\n" +
        "                  AND CCR.fk_DispatchGlCode IN(CCD.intGlCode)\n" +
        "                  AND CCRPD.fk_Product_SKU_Glcode IN(CCDPD.fk_Product_SKU_Glcode)\n" +
        "                  AND CCRPD.chrValid='Y'\n" +
        "                  AND CCR.chrValidSave IN('N')\n" +
        "                  ) as intScanCount\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN Product_SKU_Mst as PSM  ON PSM.intGlCode=CCDPD.fk_Product_SKU_Glcode\n" +
        "WHERE CCD.fk_Customer_To_GlCode='$fkMainCustomerGlCode'" +
        "      AND CCD.intGlCode='$fkDispatchGlCode'" +
        "      AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCD.chrValidSave,'N')='Y'\n" +
        "      AND (ifnull(CCD.chrCompleted,'N')='N' OR CCD.chrCompleted='')" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "GROUP BY PSM.intGlCode,\n" +
        "         PSM.varProduct_SKU_Name,PSM.varProduct_SKU_Code) as res\n" +
        "where  (res.intTotalUnit-res.intLastScanCount)>0";

    var result = await dbClient.rawQuery(QUERY);
    print('=====result======${result.toString()}');
    List<ReceiveDataModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ReceiveDataModel masterModel = ReceiveDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }

    return list;
  }

  Future<int> updateStickerForDelete(int initGICode,
      int fkCustomerDispatchGlCode,
      String chrActiveType,
      String chrPallet) async {
    var dbClient = await getDB();

    String updateStickerForDeleteQuery = "";
    if (chrPallet == 'Y') {
      updateStickerForDeleteQuery =
      "UPDATE CPM_Customer_Dispatch_Product_Details SET chrActive='$chrActiveType',chrSync='N',dtSyncDate=DATETIME('now') WHERE fk_PalletGlCode='$initGICode' AND fk_Customer_DispatchGlCode='$fkCustomerDispatchGlCode'";
    } else {
      updateStickerForDeleteQuery =
      "UPDATE CPM_Customer_Dispatch_Product_Details SET chrActive='$chrActiveType',chrSync='N',dtSyncDate=DATETIME('now') WHERE intGlCode='$initGICode' AND fk_Customer_DispatchGlCode='$fkCustomerDispatchGlCode'";
    }
    print(
        '*********updateStickerForDelete*********$updateStickerForDeleteQuery');

    var result = await dbClient.rawUpdate(updateStickerForDeleteQuery);
    return result;
  }

  Future<int> updateStickerForDeleteForEditDO(int initGICode,
      int fkCustomerDispatchGlCode,
      String chrActiveType,
      String chrPallet) async {
    var dbClient = await getDB();

    String updateStickerForDeleteQuery = "";
    if (chrPallet == 'Y') {
      updateStickerForDeleteQuery =
      "UPDATE CPM_Customer_Dispatch_Product_Details SET chrActive='$chrActiveType',chrSync='N',dtSyncDate=DATETIME('now') WHERE fk_PalletGlCode='$initGICode' AND fk_Customer_DispatchGlCode='$fkCustomerDispatchGlCode'";
    } else {
      updateStickerForDeleteQuery =
      "UPDATE CPM_Customer_Dispatch_Product_Details SET chrActive='$chrActiveType',chrSync='N',dtSyncDate=DATETIME('now') WHERE intGlCode='$initGICode' AND fk_Customer_DispatchGlCode='$fkCustomerDispatchGlCode'";
    }
    print(
        '*********updateStickerForDelete*********$updateStickerForDeleteQuery');

    var result = await dbClient.rawUpdate(updateStickerForDeleteQuery);
    return result;
  }

  Future<int> updateStickerForDeleteReceive(int initGICode,
      int fk_Customer_ReceiveGlCode, String chrPallet) async {
    var dbClient = await getDB();
    String UPDATE_QUERY = "";
    if (chrPallet == 'Y') {
      UPDATE_QUERY = "UPDATE CPM_Customer_Receive_Product_Details " +
          "SET chrActive='N',chrSync='N',dtSyncDate=datetime('now') " +
          "WHERE fk_PalletGlCode='$initGICode' AND fk_Customer_ReceiveGlCode='$fk_Customer_ReceiveGlCode'";
    } else {
      UPDATE_QUERY = "UPDATE CPM_Customer_Receive_Product_Details " +
          "SET chrActive='N',chrSync='N',dtSyncDate=datetime('now') " +
          "WHERE intGlCode='$initGICode' AND fk_Customer_ReceiveGlCode='$fk_Customer_ReceiveGlCode'";
    }
    print('**updateStickerForDeleteReceive**$UPDATE_QUERY');

    var result = await dbClient.rawUpdate(UPDATE_QUERY);
    return result;
  }

  Future<int> updateCustomerDispatchProductDetailsForReject(
    int fkMainCustomerGlCode,
    int fkDispatchGlCode,
    int fkReceiveGlCode,
  ) async {
    var dbClient = await getDB();

    String UPDATE_CPM_CUSTOMER_PRODUCT =
        "UPDATE CPM_Customer_Dispatch_Product_Details SET chrRejected='Y',\n" +
            "                 dtRejectedDate=dateTIME('Now'),\n" +
            "                 fk_RejectedBy='$fkMainCustomerGlCode',\n" +
            "                 chrSync='N',\n" +
            "                 dtSyncDate=dateTIME('Now')\n" +
            "WHERE  fk_Customer_DispatchGlCode='$fkDispatchGlCode'" +
            "       AND fk_StickerGlCode IN\n" +
            "       (SELECT CCRPD.fk_StickerGlCode FROM CPM_Customer_Receive_Product_Details AS CCRPD WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode')";

    //print('**updateCustomerDispatchProductDetailsForReject**$UPDATE_CPM_CUSTOMER_PRODUCT');

    var result = await dbClient.rawUpdate(UPDATE_CPM_CUSTOMER_PRODUCT);
    return result;
  }

  Future<int> updateStickerDetailsForReject(
    int fkMainCustomerGlCode,
    int initGlCode,
    int fkReceiveGlCode,
  ) async {
    var dbClient = await getDB();

    String UPDATE_CPM_STICKER_DETAIL =
        "UPDATE CPM_Sticker_Details SET fk_Last_RejectedBy='$fkMainCustomerGlCode',\n" +
            "                               dtLast_RejectedDate=dateTIME('Now'), \n" +
            "                               chrSync='N',\n" +
            "                               dtSyncDate=dateTIME('Now'),\n" +
            "                               dtModifiedDate=dateTIME('Now'),\n" +
            "                               ref_Modified_By='$initGlCode',\n" +
            "                               fk_StatusGlCode=${globals.intRejected},varLastStage='REJECTED',chrActive='N'\n" +
            "WHERE intGlCode IN \n" +
            "       (SELECT CCRPD.fk_StickerGlCode FROM CPM_Customer_Receive_Product_Details AS CCRPD WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode')";

    //print('**updateStickerDetailsForReject**$UPDATE_CPM_STICKER_DETAIL');

    var result = await dbClient.rawUpdate(UPDATE_CPM_STICKER_DETAIL);
    return result;
  }

  Future<int> updateCustomerReceiveForReject(
    int fkReceiveGlCode,
  ) async {
    var dbClient = await getDB();

    String QUERY_CPM_CUSTOMER_RECEIVE =
        "UPDATE CPM_Customer_Receive SET chrValidSave='Y',chrSync='N',dtSyncDate=dateTIME('Now') WHERE intGlCode='$fkReceiveGlCode'";

    //print('**updateCustomerReceiveForReject**$QUERY_CPM_CUSTOMER_RECEIVE');

    var result = await dbClient.rawUpdate(QUERY_CPM_CUSTOMER_RECEIVE);
    return result;
  }

  Future<int> updateCPMDispatchForReceiveForReject(
    int initGlCode,
    int fkDispatchGlCode,
  ) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch SET chrSync='N',\n" +
        "                                 dtSyncDate=DATETIME('now'),\n" +
        "                                 ref_Modified_By='$initGlCode', \n" +
        "                                 dtModifiedDate=DATETIME('now')\n" +
        " WHERE intGlCode ='$fkDispatchGlCode'";

    //print('**updateCustomerReceiveForReject**$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamage(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE chrValidSave='N'\n" +
        " AND fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        " AND varTransactionCode='$addTransCode'";

    print('**updateCPMCustomerStickerDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerConsume(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Consume\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE chrValidSave='N'\n" +
        " AND fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        " AND varTransactionCode='$addTransCode'";

    print('**updateCPMCustomerStickerConsume**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerScrap(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Scrap\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE chrValidSave='N'\n" +
        " AND fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        " AND varTransactionCode='$addTransCode'";

    print('**updateCPMCustomerStickerScrap**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMStickerDetailsForDamage(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

// "    fk_StatusGlCode=${globals.intDamaged},\n" +

    String QUERY = "\n" +
        "UPDATE CPM_Sticker_Details\n" +
        " SET fk_DamageBy='$mainCustomerGlCode',\n" +
        "    dtDamageDateTime=DATETIME('now'),\n" +
        "    fk_StatusGlCode=${globals.intDamaged},\n" +
        "    chrSync='N',\n" +
        "    chrDamage='Y',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    varLastStage='DAMAGED',chrActive='N',\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        " WHERE intGlCode IN  (SELECT CCSD.fk_StickerGlCode FROM CPM_Customer_Sticker_Damage CCSD\n" +
        "                       WHERE ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "                       AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        "                       AND CCSD.varTransactionCode='$addTransCode'\n" +
        "                       AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "                       AND CCSD.fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        "                       AND ifnull(CCSD.chrActive,'N')='Y'\n" +
        "                       AND ifnull(CCSD.chrValid,'N')='Y'\n" +
        "                      )";

    print('**updateCPMStickerDetailsForDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMStickerDetailsForConsume(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "\n" +
        "UPDATE CPM_Sticker_Details\n" +
        " SET fk_ConsumeBy='$mainCustomerGlCode',\n" +
        "    chrConsume='Y',\n" +
        "    dtConsumeDateTime=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    chrActive='N',\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        " WHERE intGlCode IN  (SELECT CCSC.fk_StickerGlCode FROM CPM_Customer_Sticker_Consume CCSC\n" +
        "                       WHERE ifnull(CCSC.chrValidSave,'N')='N'\n" +
        "                       AND CCSC.varTransactionCode='$addTransCode'\n" +
        "                       AND ifnull(CCSC.chrSync,'N')='N'\n" +
        "                       AND CCSC.fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        "                       AND ifnull(CCSC.chrActive,'N')='Y'\n" +
        "                       AND ifnull(CCSC.chrValid,'N')='Y'\n" +
        "                      )";

    print('**updateCPMStickerDetailsForConsume**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMStickerDetailsForScrap(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "\n" +
        "UPDATE CPM_Sticker_Details" +
        " SET fk_ScrapBy='$mainCustomerGlCode'," +
        " chrScrap='Y'," +
        " dtScrapDateTime=DATETIME('now')," +
        " fk_StatusGlCode=${globals.intScrap}," +
        " chrSync='N'," +
        " dtSyncDate=DATETIME('now')," +
        " varLastStage='SCRAP'," +
        " chrActive='N'," +
        " ref_Modified_By='$initGlCode'," +
        " dtModifiedDate=DATETIME('now')" +
        " WHERE intGlCode IN  (SELECT CCSS.fk_StickerGlCode FROM CPM_Customer_Sticker_Scrap CCSS" +
        " WHERE ifnull(CCSS.chrValidSave,'N')='N'" +
        " AND CCSS.varTransactionCode='$addTransCode'" +
        " AND ifnull(CCSS.chrSync,'N')='N'" +
        " AND CCSS.fk_CustomerGlCode='$mainCustomerGlCode'" +
        " AND ifnull(CCSS.chrActive,'N')='Y'" +
        " AND ifnull(CCSS.chrValid,'N')='Y'" +
        " );";

    print('**updateCPMStickerDetailsForScrap**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMStickerDetailsForDamageRemove(int initGlCode,
      int mainCustomerGlCode,
      String addTransCode,
      String varPrintedLastStage,
      String varReceivedLastStage) async {
    var dbClient = await getDB();
    String UPDATE_CPM_STICKER_DETAILS = "";
// "    fk_StatusGlCode=${globals.intPrinted},\n" +
    //if (id > 0) {
    UPDATE_CPM_STICKER_DETAILS = "\n" +
        "UPDATE CPM_Sticker_Details\n" +
        " SET fk_DamageBy=NULL,\n" +
        "    dtDamageDateTime=NULL,\n" +
        "    chrDamage=NULL,\n" +
        "    fk_StatusGlCode=(case when ifnull(fk_sticker_GeneratedBy,0)<>$mainCustomerGlCode THEN '${globals
            .intReceived}' ELSE '${globals.intPrinted}' END)," +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    varLastStage=(case when ifnull(fk_sticker_GeneratedBy,0)<>$mainCustomerGlCode THEN '$varReceivedLastStage' ELSE '$varPrintedLastStage' END),\n" +
        "    chrActive='Y',\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        " WHERE intGlCode IN  (SELECT CCSD.fk_StickerGlCode FROM CPM_Customer_Sticker_Damage_Remove CCSD\n" +
        "                       WHERE ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "                       AND CCSD.varTransactionCode='$addTransCode'\n" +
        "                       AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "                       AND CCSD.fk_CustomerGlCode='$mainCustomerGlCode'\n" +
        "                       AND ifnull(CCSD.chrActive,'N')='Y'\n" +
        "                       AND ifnull(CCSD.chrValid,'N')='Y'\n" +
        "                      )";
//    } else {
//      UPDATE_CPM_STICKER_DETAILS = "\n" +
//          "UPDATE CPM_Sticker_Details\n" +
//          " SET fk_DamageBy=NULL,\n" +
//          "    dtDamageDateTime=NULL,\n" +
//          "    fk_StatusGlCode=${globals.intReceived},\n" +
//          "    chrSync='N',\n" +
//          "    dtSyncDate=DATETIME('now'),\n" +
//          "    varLastStage='RECEIVED',chrActive='Y',\n" +
//          "    ref_Modified_By='$initGlCode',\n" +
//          "    dtModifiedDate=DATETIME('now')\n" +
//          " WHERE intGlCode IN  (SELECT CCSD.fk_StickerGlCode FROM CPM_Customer_Sticker_Damage_Remove CCSD\n" +
//          "                       WHERE ifnull(CCSD.chrValidSave,'N')='N'\n" +
//          "                       AND CCSD.varTransactionCode='$addTransCode'\n" +
//          "                       AND ifnull(CCSD.chrSync,'N')='N'\n" +
//          "                       AND CCSD.fk_CustomerGlCode='$mainCustomerGlCode'\n" +
//          "                       AND ifnull(CCSD.chrActive,'N')='Y'\n" +
//          "                       AND ifnull(CCSD.chrValid,'N')='Y'\n" +
//          "                      )";
//    }

    print(
        '**updateCPMStickerDetailsForDamageRemove**$UPDATE_CPM_STICKER_DETAILS');

    var result = await dbClient.rawUpdate(UPDATE_CPM_STICKER_DETAILS);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageForDamage(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY1 =
        "UPDATE CPM_Pallet_Mst set chrBreak='Y',dtSyncDate=datetime('now'),chrSync='N',ref_Modified_By='$initGlCode',dtModifiedDate=DATETIME('now'),ref_Break_By='$initGlCode',dtBreakDate=DATETIME('now')" +
            " WHERE intGlCode IN(" +
            " SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Sticker_Damage AS CCSD" +
            " INNER JOIN CPM_Sticker_Details as CSD ON CCSD.fk_StickerGlCode=CSD.intGlCode AND CSD.chrPallet='Y'" +
            " WHERE CCSD.fk_CustomerGlCode='$mainCustomerGlCode'" +
            " AND CCSD.varTransactionCode='$addTransCode'" +
            " AND ifnull(CCSD.chrActive,'N') IN ('Y')" +
            " AND ifnull(CCSD.chrValid,'N')='Y') AND ifnull(chrBreak,'N')='N' \n";

    print('**QUERY1**$QUERY1');
    await dbClient.rawUpdate(QUERY1);

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage\n" +
        "SET chrValidSave='Y',\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('Now')\n" +
        "WHERE ifnull(chrValidSave,'N')='N'\n" +
        "                       AND ifnull(chrSync,'N')='N'\n" +
        "                       AND varTransactionCode='$addTransCode'\n" +
        "                       AND fk_CustomerGlCode='$mainCustomerGlCode'";

    print('**updateCPMCustomerStickerDetailsDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageForConsume(int initGlCode,
      int mainCustomerGlCode, String addTransCode, String remark) async {
    var dbClient = await getDB();

    String QUERY1 =
        "UPDATE CPM_Pallet_Mst set chrBreak='Y',dtSyncDate=datetime('now'),chrSync='N',ref_Modified_By='$initGlCode',dtModifiedDate=DATETIME('now'),ref_Break_By='$initGlCode',dtBreakDate=DATETIME('now')" +
            " WHERE intGlCode IN(" +
            " SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Sticker_Consume AS CCSC" +
            " INNER JOIN CPM_Sticker_Details as CSD ON CCSC.fk_StickerGlCode=CSD.intGlCode AND CSD.chrPallet='Y'" +
            " WHERE CCSC.fk_CustomerGlCode='$mainCustomerGlCode'" +
            " AND CCSC.varTransactionCode='$addTransCode'" +
            " AND ifnull(CCSC.chrActive,'N') IN ('Y')" +
            " AND ifnull(CCSC.chrValid,'N')='Y') AND ifnull(chrBreak,'N')='N' \n";

    print('**QUERY1**$QUERY1');
    await dbClient.rawUpdate(QUERY1);

    String QUERY = "UPDATE CPM_Customer_Sticker_Consume\n" +
        "SET chrValidSave='Y',\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    varRemarks = '$remark' ,\n " +
        "    dtSyncDate=DATETIME('Now')\n" +
        "WHERE ifnull(chrValidSave,'N')='N'\n" +
        "                       AND ifnull(chrSync,'N')='N'\n" +
        "                       AND varTransactionCode='$addTransCode'\n" +
        "                       AND fk_CustomerGlCode='$mainCustomerGlCode'";

    print('**updateCPMCustomerStickerDamageForConsume**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageForScrap(int initGlCode,
      int mainCustomerGlCode, String addTransCode, String remarks) async {
    var dbClient = await getDB();

    String QUERY1 = "UPDATE CPM_Pallet_Mst SET" +
        " chrBreak='Y'," +
        " dtSyncDate=datetime('now')," +
        " chrSync='N'," +
        " ref_Modified_By='$initGlCode'," +
        " dtModifiedDate=DATETIME('now')," +
        " ref_Break_By='$initGlCode'," +
        " dtBreakDate=DATETIME('now')" +
        " WHERE intGlCode IN(" +
        " SELECT CSD.fk_PalletGlCode" +
        " FROM CPM_Customer_Sticker_Scrap AS CCSS" +
        " INNER JOIN CPM_Sticker_Details as CSD ON CCSS.fk_StickerGlCode=CSD.intGlCode AND CSD.chrPallet='Y'" +
        " WHERE CCSS.fk_CustomerGlCode='$mainCustomerGlCode'" +
        " AND CCSS.varTransactionCode='$addTransCode'" +
        " AND ifnull(CCSS.chrActive,'N') IN ('Y')" +
        " AND ifnull(CCSS.chrValid,'N')='Y')" +
        " AND ifnull(chrBreak,'N')='N'";

    print('**QUERY1**$QUERY1');
    await dbClient.rawUpdate(QUERY1);

    String QUERY = "UPDATE CPM_Customer_Sticker_Scrap" +
        " SET chrValidSave='Y'," +
        " ref_Modified_By='$initGlCode'," +
        " dtModifiedDate=DATETIME('now')," +
        " chrSync='N'," +
        " varRemarks='$remarks'," +
        " dtSyncDate=DATETIME('Now')" +
        " WHERE ifnull(chrValidSave,'N')='N'" +
        " AND ifnull(chrSync,'N')='N'" +
        " AND varTransactionCode='$addTransCode'" +
        " AND fk_CustomerGlCode='$mainCustomerGlCode'";

    print('**updateCPMCustomerStickerDetailsScrap**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageForRemoveDamage(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage\n" +
        "   SET ref_Modified_By = '$initGlCode',\n" +
        "       dtModifiedDate = DATETIME('now'),\n" +
        "       chrSync = 'N',\n" +
        "       dtSyncDate = DATETIME('Now'),\n" +
        "       chrRemove = 'Y',\n" +
        "       dtRemoveDamage = DATETIME('Now'),\n" +
        "       fk_RemoveBy = '$initGlCode'\n" +
        " WHERE ifnull( chrActive, 'N' ) = 'Y' \n" +
        "       AND fk_CustomerGlCode = '$mainCustomerGlCode'\n" +
        "       AND intGlCode IN (SELECT fk_Sticker_DamageGlCode \n" +
        "                         FROM CPM_Customer_Sticker_Damage_Remove CSDR \n" +
        "                         WHERE ifnull(CSDR.chrActive,'N')='Y'\n" +
        "                         AND ifnull(CSDR.chrValidSave,'N')='N'\n" +
        "                         AND ifnull(CSDR.chrValid,'N')='Y'\n" +
        "                         AND CSDR.varTransactionCode='$addTransCode'\n" +
        "                         );\n";

    print('**updateCPMCustomerStickerDamageRemoveForRemoveDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageRemoveForRemoveDamage(
      int initGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage_Remove\n" +
        "   SET chrValidSave = 'Y',\n" +
        "       ref_Modified_By = '$initGlCode',\n" +
        "       dtModifiedDate = DATETIME( 'now' ),\n" +
        "       chrSync = 'N',\n" +
        "       dtSyncDate = datetime( 'now' )\n" +
        " WHERE ifnull(chrValidSave,'N')= 'N' " +
        " AND varTransactionCode = '$addTransCode'\n" +
        " AND ref_Entry_By = '$initGlCode'";

    print('**updateCPMCustomerStickerDamageRemoveForRemoveDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateCPMCustomerStickerDamageRemove(
      int initGlCode, int mainCustomerGlCode, String addTransCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage_Remove\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGlCode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE chrValidSave='N'\n" +
        " AND fk_CustomerGlCode='$mainCustomerGlCode'" +
        " AND varTransactionCode='$addTransCode'";

    print('**updateCPMCustomerStickerDamageRemove**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateStickerForDeleteAddDamage(
      int initGICode, int Fk_Customer_DispatchProduct_GLCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage\n" +
        " SET chrActive='N',\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=datetime('now')\n" +
        " WHERE intGlCode='$Fk_Customer_DispatchProduct_GLCode'";

    print('**updateStickerForDeleteAddDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateStickerForDeleteScrap(
      int initGICode, int Fk_Customer_DispatchProduct_GLCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Scrap\n" +
        " SET chrActive='N',\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=datetime('now')\n" +
        " WHERE intGlCode='$Fk_Customer_DispatchProduct_GLCode'";

    print('**updateStickerForDeleteScrap**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateStickerForDeleteRemoveDamage(
      int initGICode, int Fk_Customer_DispatchProduct_GLCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Damage_Remove\n" +
        " SET chrActive='N',\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=datetime('now')\n" +
        " WHERE intGlCode='$Fk_Customer_DispatchProduct_GLCode'";

    print('**updateStickerForDeleteAddDamage**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> updateStickerForDeleteForConsume(
      int initGICode, int Fk_Customer_DispatchProduct_GLCode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Sticker_Consume\n" +
        " SET chrActive='N',\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=datetime('now')\n" +
        " WHERE intGlCode='$Fk_Customer_DispatchProduct_GLCode'";

    print('**updateStickerForDeleteForConsume**$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    print('====Result=====$result');
    return result;
  }

  Future<List<ScanDataModel>> getInvalidSticker(
      int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT 0 _id,CCDPD." +
        DatabaseQuery.COLUMN_INT_GI_CODE +
        " as fk_Customer_DispatchProduct_GLCode," +
        "CCDPD.intRowNo as intRowNo," +
        " CCDPD.varSticker AS varSticker," +
        " CCDPD.chrValid AS chrValid" +
        " FROM " +
        DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
        " CCDPD" +
        " WHERE CCDPD." +
        DatabaseQuery.COLUMN_FK_CUSTOMER_DISPATCH_GI_CODE +
        "='$fk_Customer_DispatchGlCode'" +
        " AND ifnull(CCDPD.chrActive,'N')='Y' AND ifnull(CCDPD.chrValid,'N')='N' ORDER BY intRowNo DESC";

    var result = await dbClient.rawQuery(QUERY);
    print('=====getInvalidSticker======${result.toString()}');
    List<ScanDataModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ScanDataModel>> getInvalidStickerForReceive(
      int fkReceiveGlCode) async {
    var dbClient = await getDB();

    String QUERY =
        "SELECT  0 _id,CCRPD.intGlCode as fk_Customer_ReceiveProductGlCode,\n" +
            "        CCRPD.intRowNo as intRowNo,\n" +
            "        CCRPD.varSticker AS varSticker,\n" +
            "        CCRPD.chrValid AS chrValid" +
            " FROM CPM_Customer_Receive as CCR\n" +
            "INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
            "WHERE CCR.intGlCode='$fkReceiveGlCode' \n" +
            "      AND ifnull(CCR.chrActive,'N')='Y'\n" +
            "      AND ifnull(CCRPD.chrActive,'N')='Y'\n" +
            "      AND ifnull(CCRPD.chrValid,'N')='N'";

    var result = await dbClient.rawQuery(QUERY);
    print('=====getInvalidStickerForReceive======${result.toString()}');
    List<ScanDataModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ScanDataModel>> getInvalidStickerForDamage(
      String addDamageTransCode, int mainCustomerGlCode) async {
    var dbClient = await getDB();

    String INVALID_CODES =
        "SELECT 0 _id,CCSD.intGlCode AS fk_Customer_Sticker_DamageGlCode,\n" +
            "       CCSD.varSticker AS varSticker,\n" +
            "       CCSD.chrValidSave As chrValidSave,\n" +
            "       CCSD.chrValid As chrValid,\n" +
            "       (select count(*) from CPM_Customer_Sticker_Damage b  where CCSD.intGlCode >= b.intGlCode AND ifnull(b.chrValidSave,'N')='N') as intRowNo\n" +
            "FROM CPM_Customer_Sticker_Damage CCSD \n" +
            "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
            "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
            "      AND CCSD.varTransactionCode='$addDamageTransCode'\n" +
            "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
            "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
            "      AND ifnull(CCSD.chrValid,'N')='N'\n" +
            "      AND CCSD.fk_CustomerGlCode='$mainCustomerGlCode'";

    var result = await dbClient.rawQuery(INVALID_CODES);
    print('=====getInvalidStickerForReceive======${result.toString()}');
    List<ScanDataModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ScanDataModel>> getInvalidStickerForConsume(
      String addDamageTransCode, int mainCustomerGlCode) async {
    var dbClient = await getDB();

    String INVALID_CODES =
        "SELECT CCSC.intGlCode AS fk_Customer_Sticker_DamageGlCode,\n" +
            "       CCSC.varSticker AS varSticker,\n" +
            "       CCSC.chrValidSave As chrValidSave,\n" +
            "       CCSC.chrValid As chrValid,\n" +
            "       (select count(*) from CPM_Customer_Sticker_Consume b  where CCSC.intGlCode >= b.intGlCode AND ifnull(b.chrValidSave,'N')='N') as intRowNo\n" +
            "FROM CPM_Customer_Sticker_Consume CCSC \n" +
            "WHERE ifnull(CCSC.chrActive,'N')='Y'\n" +
            "      AND CCSC.varTransactionCode='$addDamageTransCode'\n" +
            "      AND ifnull(CCSC.chrSync,'N')='N'\n" +
            "      AND ifnull(CCSC.chrValidSave,'N')='N'\n" +
            "      AND ifnull(CCSC.chrValid,'N')='N'\n" +
            "      AND CCSC.fk_CustomerGlCode='$mainCustomerGlCode'";

    var result = await dbClient.rawQuery(INVALID_CODES);
    print('=====getInvalidStickerForConsume======${result.toString()}');
    List<ScanDataModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ScanDataModel>> getInvalidStickerForScrap(
      String addDamageTransCode, int mainCustomerGlCode) async {
    var dbClient = await getDB();

    String INVALID_CODES =
        "SELECT CCSS.intGlCode AS fk_Customer_Sticker_DamageGlCode," +
            " CCSS.varSticker AS varSticker," +
            " CCSS.chrValidSave As chrValidSave," +
            " CCSS.chrValid As chrValid," +
            " (select count(*) from CPM_Customer_Sticker_Scrap b  where CCSS.intGlCode >= b.intGlCode AND ifnull(b.chrValidSave,'N')='N') as intRowNo" +
            " FROM CPM_Customer_Sticker_Scrap CCSS" +
            " WHERE ifnull(CCSS.chrActive,'N')='Y'" +
            " AND CCSS.varTransactionCode='$addDamageTransCode'" +
            " AND ifnull(CCSS.chrSync,'N')='N'" +
            " AND ifnull(CCSS.chrValidSave,'N')='N'" +
            " AND ifnull(CCSS.chrValid,'N')='N'" +
            " AND CCSS.fk_CustomerGlCode='$mainCustomerGlCode'";

    var result = await dbClient.rawQuery(INVALID_CODES);
    print('=====getInvalidStickerForReceive======${result.toString()}');
    List<ScanDataModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ScanDataModel>> getInvalidStickerForDamageRemove(
      String addDamageTransCode, int mainCustomerGlCode) async {
    var dbClient = await getDB();

    String INVALID_CODES =
        "SELECT CCSD.intGlCode AS fk_Customer_Sticker_DamageGlCode,\n" +
            "       CCSD.varSticker AS varSticker,\n" +
            "       CCSD.chrValidSave As chrValidSave,\n" +
            "       CCSD.chrValid As chrValid,\n" +
            "       (select count(*) from CPM_Customer_Sticker_Damage_Remove b  where CCSD.intGlCode >= b.intGlCode AND ifnull(b.chrValidSave,'N')='N') as intRowNo\n" +
            "FROM CPM_Customer_Sticker_Damage_Remove CCSD \n" +
            "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
            "      AND CCSD.varTransactionCode='$addDamageTransCode'\n" +
            "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
            "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
            "      AND ifnull(CCSD.chrValid,'N')='N'\n" +
            "      AND CCSD.fk_CustomerGlCode='$mainCustomerGlCode'";

    var result = await dbClient.rawQuery(INVALID_CODES);
    print('=====getInvalidStickerForReceive======${result.toString()}');
    List<ScanDataModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<TotalProductUnitsModel> getTotalArticleUnitsForReceive(
      int fkReceiveGlCode, int fkDispatchGlCode) async {
    var dbClient = await getDB();

    String QUERY_PENDING_COUNT = "SELECT res.intScanCount as intTotalUnit,\n" +
        "       res.intProductCount as intProductCount,\n" +
        "       ((res.intTotalUnit-res.intLastScanCount)-res.intScanCount) as intPendingCount " +
        "FROM\n" +
        "(SELECT \n" +
        "        COUNT(DISTINCT CCDPD.fk_StickerGlCode) as intTotalUnit,\n" +
        "        (SELECT COUNT(DISTINCT CCRPD.fk_StickerGlCode) as intScanCount\n" +
        "            FROM CPM_Customer_Receive CCR\n" +
        "            INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "            WHERE CCR.chrActive='Y'\n" +
        "                  AND CCRPD.chrActive='Y'\n" +
        "                  AND CCR.fk_DispatchGlCode in (CCD.intGlCode)\n" +
        "                  AND CCR.intGlCode<>'$fkReceiveGlCode' " +
        "                  AND CCRPD.chrValid='Y'\n" +
        "                  AND CCR.chrValidSave IN('Y')\n" +
        "                  ) as intLastScanCount,\n" +
        "          (SELECT COUNT(DISTINCT CCRPD.fk_StickerGlCode) as intScanCount\n" +
        "            FROM CPM_Customer_Receive CCR\n" +
        "            INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "            WHERE CCR.chrActive='Y'\n" +
        "                  AND CCRPD.chrActive='Y'\n" +
        "                  AND CCR.intGlCode='$fkReceiveGlCode'" +
        "                  AND CCRPD.chrValid='Y'\n" +
        "                  ) as intScanCount,\n" +
        "          (SELECT COUNT(DISTINCT CCRPD.fk_Product_SKU_Glcode) as intProductCount\n" +
        "            FROM CPM_Customer_Receive CCR\n" +
        "            INNER JOIN CPM_Customer_Receive_Product_Details as CCRPD ON CCR.intGlCode=CCRPD.fk_Customer_ReceiveGlCode\n" +
        "            WHERE CCR.chrActive='Y'\n" +
        "                  AND CCRPD.chrActive='Y'\n" +
        "                  AND CCR.intGlCode='$fkReceiveGlCode'" +
        "                  AND CCRPD.chrValid='Y'\n" +
        "                  ) as intProductCount\n" +
        "FROM CPM_Customer_Dispatch as CCD\n" +
        "INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        "INNER JOIN Product_SKU_Mst as PSM  ON PSM.intGlCode=CCDPD.fk_Product_SKU_Glcode\n" +
        "WHERE CCD.intGlCode='$fkDispatchGlCode'" +
        "      AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrValid,'N')='Y' ) as res";

    var result = await dbClient.rawQuery(QUERY_PENDING_COUNT);
    print('=======getTotalArticleUnitsForReceive=======${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        TotalProductUnitsModel masterModel =
            TotalProductUnitsModel.fromMap(result[i]);
        return masterModel;
      }
    }
    return null;
  }

  Future<TotalProductUnitsModel> getTotalArticleUnitsForDamage(
      String addDamageTransCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSD.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Damage CCSD\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        "      AND CCSD.varTransactionCode='$addDamageTransCode'\n" +
        "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    var result = await dbClient.rawQuery(COUNT_QUERY);
    print('=======getTotalArticleUnitsForReceive=======${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        TotalProductUnitsModel masterModel =
            TotalProductUnitsModel.fromMap(result[i]);
        return masterModel;
      }
    }
    return null;
  }

  Future<TotalProductUnitsModel> getTotalArticleUnitsForConsume(
      String addDamageTransCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSC.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Consume CCSC\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSC.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSC.chrActive,'N')='Y'\n" +
        "      AND CCSC.varTransactionCode='$addDamageTransCode'\n" +
        "      AND ifnull(CCSC.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSC.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    var result = await dbClient.rawQuery(COUNT_QUERY);
    print('=======getTotalArticleUnitsForConsume=======${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        TotalProductUnitsModel masterModel =
            TotalProductUnitsModel.fromMap(result[i]);
        return masterModel;
      }
    }
    return null;
  }

  Future<TotalProductUnitsModel> getTotalArticleUnitsForDamageRemove(
      String addDamageTransCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSD.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Damage_Remove CCSD\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND CCSD.varTransactionCode='$addDamageTransCode'\n" +
        "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    var result = await dbClient.rawQuery(COUNT_QUERY);
    print('=======getTotalArticleUnitsForReceive=======${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        TotalProductUnitsModel masterModel =
            TotalProductUnitsModel.fromMap(result[i]);
        return masterModel;
      }
    }
    return null;
  }

  Future<int> updateStickerDetails(
      int initGICode,
      int fk_Customer_DispatchGlCode,
      int fk_Last_DispatchedTo,
      int mainCustomerGLCode,
      int fk_StatusGlCode) async {
    var dbClient = await getDB();

    String updateStickerDetailsQuery = "UPDATE " +
        DatabaseQuery.TABLE_CPM_STRICKER_Details +
        " \n" +
        "SET fk_Last_DispatchedBy='$mainCustomerGLCode',\n" +
        "    fk_Last_PreviousDispatchBy= fk_Last_DispatchedBy,\n" +
        "    dtLast_DispatchedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    fk_StatusGlCode='$fk_StatusGlCode',\n" +
        "    varLastStage='DISPATCHED',\n" +
        "    fk_Last_DispatchedTo='$fk_Last_DispatchedTo'" +
        ",\n" +
        "    ref_Modified_By='$initGICode'" +
        ",\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode IN  ( SELECT CCDPD.fk_StickerGlCode FROM CPM_Customer_Dispatch_Product_Details CCDPD\n" +
        "                       WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'" +
        "\n" +
        "                       AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')\n" +
        "                       AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        "                      )";

    String updatePalletQuery =
        "UPDATE CPM_Pallet_Mst SET chrSync='N',dtSyncDate=DATETIME('now'),ref_Modified_By='$initGICode',dtModifiedDate=DATETIME('now')" +
            " WHERE intGlCode IN(SELECT CCDPD.fk_PalletGlCode" +
            " FROM CPM_Customer_Dispatch_Product_Details CCDPD" +
            " WHERE CCDPD.fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'" +
            " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')" +
            " AND ifnull(CCDPD.chrValid,'N')='Y'" +
            " )";

    print('*******updateStickerDetails*******$updateStickerDetailsQuery');

    await dbClient.rawUpdate(updateStickerDetailsQuery);
    var result = await dbClient.rawUpdate(updatePalletQuery);
    return result;
  }

  Future<int> updateStickerDetailsForReceive(
      int initGICode, int fkReceiveGlCode, int mainCustomerGLCode) async {
    var dbClient = await getDB();

    String QUERY_UPDATE_CPM_STICK = "UPDATE CPM_Sticker_Details \n" +
        "SET chrSync='N',\n" +
        "    fk_Last_ReceivedBy='$mainCustomerGLCode',\n" +
        "    dtLast_ReceivedDate=DATETIME('now'),\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    fk_StatusGlCode=${globals.intReceived},\n" +
        "    varLastStage='RECEIVED',\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode IN  (SELECT CCRPD.fk_StickerGlCode FROM CPM_Customer_Receive_Product_Details CCRPD\n" +
        "                       WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode' \n" +
        "                       AND ifnull(CCRPD.chrActive,'N')='Y'\n" +
        "                       AND ifnull(CCRPD.chrValid,'N')='Y'\n" +
        "                      )";
    print(
        '*******updateStickerDetailsForReceive*******$QUERY_UPDATE_CPM_STICK');

    String QUERY_PALLET =
        "UPDATE CPM_Pallet_Mst SET chrSync='N',dtSyncDate=DATETIME('now'),ref_Modified_By='$initGICode',dtModifiedDate=DATETIME('now')" +
            " WHERE intGlCode IN(SELECT CCRPD.fk_PalletGlCode FROM CPM_Customer_Receive_Product_Details CCRPD" +
            " WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode'" +
            " AND ifnull(CCRPD.chrActive,'N')='Y'" +
            " AND ifnull(CCRPD.chrValid,'N')='Y'" +
            " )";

    print('*******QUERY_PALLET*******$QUERY_PALLET');

    await dbClient.rawUpdate(QUERY_UPDATE_CPM_STICK);
    var result = await dbClient.rawUpdate(QUERY_PALLET);
    return result;
  }

  Future<int> updateCPMCustomerReceive(int initGICode, int fkReceiveGlCode,
      String SAPDocNo) async {
    var dbClient = await getDB();

    String QUERY_UPDATE_CPM_STICK = "UPDATE CPM_Customer_Receive\n" +
        "SET chrValidSave='Y',\n" +
        "    chrSync='N',\n" +
        "    varSAPDocNo='$SAPDocNo',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    dtDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$fkReceiveGlCode'";

    print('*******updateCPMCustomerReceive*******$QUERY_UPDATE_CPM_STICK');

    var result = await dbClient.rawUpdate(QUERY_UPDATE_CPM_STICK);
    return result;
  }

  Future<int> updatePalletBreakForReceive(
      int initGICode, int fkReceiveGlCode) async {
    var dbClient = await getDB();

    String QUERY_UPDATE_CPM_STICK =
        "UPDATE CPM_Pallet_Mst set chrBreak='Y',dtSyncDate=datetime('now'),chrSync='N',ref_Modified_By='$initGICode',dtModifiedDate=DATETIME('now'),ref_Break_By='$initGICode',dtBreakDate=DATETIME('now') " +
            " WHERE intGlCode IN(" +
            " SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Receive_Product_Details CCRPD" +
            " INNER JOIN CPM_Sticker_Details as CSD ON CCRPD.fk_StickerGlCode=CSD.intGlCode AND CSD.chrPallet='Y'" +
            " WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode'" +
            " AND ifnull(CCRPD.chrActive,'N') IN ('Y','I')" +
            " AND ifnull(CCRPD.chrValid,'N')='Y'" +
            " AND ifnull(CCRPD.chrPallet,'N')='N'" +
            " AND ifnull(CSD.chrActive,'N')='Y'" +
            ")";

    print('*******updateCPMCustomerReceive*******$QUERY_UPDATE_CPM_STICK');

    var result = await dbClient.rawUpdate(QUERY_UPDATE_CPM_STICK);
    return result;
  }

  Future<int> updateCPMCustomerDispatchProduct(
      int initGICode,
      int fkReceiveGlCode,
      int fkDispatchGlCode,
      int fkMainCustomerGlCode) async {
    var dbClient = await getDB();

    String QUERY_UPDATE_CPM_STICK = "Update CPM_Customer_Dispatch_Product_Details\n" +
        "SET chrReceived='Y',\n" +
        "    fk_ReceivedBy='$fkMainCustomerGlCode',\n" +
        "    dtReceivedDate=DATETIME('now'),\n" +
        "    chrSync='N',\n" +
        "    dtModifiedDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtSyncDate=DATETIME('now')\n " +
        "WHERE fk_Customer_DispatchGlCode='$fkDispatchGlCode' \n" +
        "      AND fk_StickerGlCode IN (SELECT CCRPD.fk_StickerGlCode FROM CPM_Customer_Receive_Product_Details CCRPD\n" +
        "                       WHERE CCRPD.fk_Customer_ReceiveGlCode IN ('$fkReceiveGlCode')\n" +
        "                       AND ifnull(CCRPD.chrActive,'N')='Y'\n" +
        "                       AND ifnull(CCRPD.chrValid,'N')='Y'\n" +
        "                      )";

    print(
        '*******updateCPMCustomerDispatchProduct*******$QUERY_UPDATE_CPM_STICK');

    var result = await dbClient.rawUpdate(QUERY_UPDATE_CPM_STICK);
    return result;
  }

  Future<int> updateCPMDispatchForReceive(
      int initGICode, int fkDispatchGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch SET chrSync='N',\n" +
        "                                 dtSyncDate=DATETIME('now'),\n" +
        "                                 ref_Modified_By='$initGICode', \n" +
        "                                 dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode ='$fkDispatchGlCode'";

    print('*******updateCPMDispatchForReceive*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> cancelTransactionForReceive(
      int initGICode, int fkReceiveGlCode) async {
    var dbClient = await getDB();

    String CLOSE_TRANSACTION = "UPDATE CPM_Customer_Receive\n" +
        "SET chrValidSave='C',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGICode',\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$fkReceiveGlCode'";

    print('*******cancelTransactionForReceive*******$CLOSE_TRANSACTION');

    var result = await dbClient.rawUpdate(CLOSE_TRANSACTION);
    return result;
  }

  Future<int> updateCPMCustomerDispatch(
      int initGICode, int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();

    String updateCPMCustomerDispatchQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrValidSave='Y',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    dtDispatchDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$initGICode'" +
        ",\n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$fk_Customer_DispatchGlCode'";

    print(
        '*******updateCPMCustomerDispatch*******$updateCPMCustomerDispatchQuery');

    var result = await dbClient.rawUpdate(updateCPMCustomerDispatchQuery);
    return result;
  }

  Future<int> updatePalletForBreak(
      int initGICode, int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();

    String updateCPMCustomerDispatchQuery =
        "UPDATE CPM_Pallet_Mst set chrBreak='Y',dtSyncDate=datetime('now'),chrSync='N',ref_Modified_By='$initGICode',dtModifiedDate=DATETIME('now'),ref_Break_By='$initGICode',dtBreakDate=DATETIME('now') " +
            " WHERE intGlCode IN(" +
            " SELECT CSD.fk_PalletGlCode" +
            " FROM CPM_Customer_Dispatch_Product_Details CCDPD" +
            " INNER JOIN CPM_Sticker_Details as CSD ON CCDPD.fk_StickerGlCode=CSD.intGlCode AND CSD.chrPallet='Y'" +
            " WHERE CCDPD.fk_Customer_DispatchGlCode='${fk_Customer_DispatchGlCode}'" +
            " AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')" +
            " AND ifnull(CCDPD.chrValid,'N')='Y'" +
            " AND ifnull(CCDPD.chrPallet,'N')='N' " +
            " AND ifnull(CSD.chrActive,'N')='Y'" +
            ")";

    print(
        '*******updateCPMCustomerDispatch*******$updateCPMCustomerDispatchQuery');

    var result = await dbClient.rawUpdate(updateCPMCustomerDispatchQuery);
    return result;
  }

  /*Future<int> updatePalletForBreakForReceive(
      int initGICode, int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();

    String updateCPMCustomerDispatchQuery =
        "UPDATE CPM_Customer_Dispatch_Product_Details set chrBreak='Y'"+
        " WHERE fk_DispatchGlCode='$fk_Customer_DispatchGlCode'"+
        " AND fk_PalletGlCode in (SELECT fk_PalletGlCode FROM CPM_Sticker_Details where intGlCode='$initGICode')";

    print(
        '*******updatePalletForBreakForReceive*******$updateCPMCustomerDispatchQuery');

    var result = await dbClient.rawUpdate(updateCPMCustomerDispatchQuery);
    return result;
  }*/

  Future<int> deleteDispatchRecords(int initGlCode,
      int fk_Customer_DispatchGlCode, int fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String QUERY = "UPDATE CPM_Customer_Dispatch_Product_Details\n" +
        "    SET chrActive='N',\n" +
        "        chrSync='N',\n" +
        "        dtSyncDate=datetime('now'),\n" +
        "        dtModifiedDate=datetime('now'),\n" +
        "        ref_Modified_By='$initGlCode'\n" +
        "    WHERE fk_Customer_DispatchGlCode='$fk_Customer_DispatchGlCode'\n" +
        "    AND fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode';\n";

    print('*******deleteDispatchRecords*******$QUERY');

    var result = await dbClient.rawUpdate(QUERY);
    return result;
  }

  Future<int> deleteLoginDetails() async {
    var dbClient = await getDB();

    String selectQuery =
        "DELETE FROM LoginDetails WHERE intGLCode NOT IN(SELECT ifnull(max(intGLCode),0) as intGlCode from LoginDetails)";

    print('*******deleteLoginDetails*******$selectQuery');

    var result = await dbClient.rawDelete(selectQuery);
    return result;
  }

  Future<int> deleteLoginFormDetails() async {
    var dbClient = await getDB();

    String selectQuery = "DELETE FROM LoginFormDetails";

    print('*******deleteLoginFormDetails*******$selectQuery');

    var result = await dbClient.rawDelete(selectQuery);
    return result;
  }

  Future<int> deleteLoginFailAttempt_Details() async {
    var dbClient = await getDB();

    String selectQuery = "DELETE FROM LoginFailAttempt_Details";

    print('*******deleteLoginFailAttempt_Details*******$selectQuery');

    var result = await dbClient.rawDelete(selectQuery);
    return result;
  }

  Future<int> deleteMenuMaster() async {
    var dbClient = await getDB();
    var result = await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_MENU_MST);
    return result;
  }

  Future<int> deleteLanguageMaster() async {
    var dbClient = await getDB();
    var result =
    await dbClient.rawDelete(DatabaseQuery.DELETE_TABLE_LANGUAGE_MASTER);
    return result;
  }

  void getStatusMaster() async {
    var dbClient = await getDB();

    String intPrintedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('1') AND SM.varPurpose='CPM'";
    String intDispatchedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('2') AND SM.varPurpose='CPM'";
    String intTransferedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('3') AND SM.varPurpose='CPM'";
    String intReceivedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('4') AND SM.varPurpose='CPM'";
    String intRejectedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('5') AND SM.varPurpose='CPM'";
    String intDamagedQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('6') AND SM.varPurpose='CPM'";
    String intInitializePrintQuery =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('7') AND SM.varPurpose='CPM'";
    String intSalesReturn =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('8') AND SM.varPurpose='CPM'";
    String intFOC =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('9') AND SM.varPurpose='CPM'";
    String intScrap =
        "SELECT SM.intGlCode FROM Status_Mst AS SM WHERE SM.intCode IN ('10') AND SM.varPurpose='CPM'";

    var printedResult = await dbClient.rawQuery(intPrintedQuery);
    if (printedResult.isNotEmpty) {
      for (int i = 0; i < printedResult.length; i++) {
        globals.intPrinted = printedResult[i]['intGlCode'];
      }
    }

    var dispatchedResult = await dbClient.rawQuery(intDispatchedQuery);
    if (dispatchedResult.isNotEmpty) {
      for (int i = 0; i < dispatchedResult.length; i++) {
        globals.intDispatched = dispatchedResult[i]['intGlCode'];
      }
    }

    var transferedResult = await dbClient.rawQuery(intTransferedQuery);
    if (transferedResult.isNotEmpty) {
      for (int i = 0; i < transferedResult.length; i++) {
        globals.intTransfered = transferedResult[i]['intGlCode'];
      }
    }

    var receivedResult = await dbClient.rawQuery(intReceivedQuery);
    if (receivedResult.isNotEmpty) {
      for (int i = 0; i < receivedResult.length; i++) {
        globals.intReceived = receivedResult[i]['intGlCode'];
      }
    }

    var rejectedResult = await dbClient.rawQuery(intRejectedQuery);
    if (rejectedResult.isNotEmpty) {
      for (int i = 0; i < rejectedResult.length; i++) {
        globals.intRejected = rejectedResult[i]['intGlCode'];
      }
    }

    var damagedResult = await dbClient.rawQuery(intDamagedQuery);
    if (damagedResult.isNotEmpty) {
      for (int i = 0; i < damagedResult.length; i++) {
        globals.intDamaged = damagedResult[i]['intGlCode'];
      }
    }

    var initializePrintResult =
        await dbClient.rawQuery(intInitializePrintQuery);
    if (initializePrintResult.isNotEmpty) {
      for (int i = 0; i < initializePrintResult.length; i++) {
        globals.intInitializePrint = initializePrintResult[i]['intGlCode'];
      }
    }

    var salesReturnResult = await dbClient.rawQuery(intSalesReturn);
    if (salesReturnResult.isNotEmpty) {
      for (int i = 0; i < salesReturnResult.length; i++) {
        globals.intSalesReturn = salesReturnResult[i]['intGlCode'];
      }
    }

    var focResult = await dbClient.rawQuery(intFOC);
    if (focResult.isNotEmpty) {
      for (int i = 0; i < focResult.length; i++) {
        globals.intFOC = focResult[i]['intGlCode'];
      }
    }

    var scrapResult = await dbClient.rawQuery(intScrap);
    if (scrapResult.isNotEmpty) {
      for (int i = 0; i < scrapResult.length; i++) {
        globals.intScrap = scrapResult[i]['intGlCode'];
      }
    }
  }

  Future<int> updateLoginDetails() async {
    var dbClient = await getDB();

    String selectQuery =
        "UPDATE LoginDetails SET dtLogOut=DATETIME('NOW'),chrSync='N',dtSyncDate=DATETIME('NOW') WHERE intGLCode IN(SELECT ifnull(max(intGLCode),0) as intGlCode from LoginDetails)";

    print('*******deleteLoginDetails*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> updateCPMCustomerDispatchForCancelDOFirstPage(
      int fk_Customer_DispatchGlCode, int ref_Modified_By) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrValidSave='E',\n" +
        "    chrSync='N',\n" +
        "    dtSyncDate=DATETIME('now'),\n" +
        "    ref_Modified_By='$ref_Modified_By'" +
        ", \n" +
        "    dtModifiedDate=DATETIME('now')\n" +
        "WHERE intGlCode='$fk_Customer_DispatchGlCode'" +
        "";

    print('*******deleteLoginDetails*******$selectQuery');

    var result = await dbClient.rawUpdate(selectQuery);
    return result;
  }

  Future<int> relaseStickerForEditDO(int fk_Customer_DispatchGlCode) async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch_Product_Details\n" +
        "       SET chrActive='N'\n" +
        "WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'\n" +
        "      AND chrActive='I' AND chrSync='N'";

    String selectQuery1 = "UPDATE CPM_Customer_Dispatch_Product_Details\n" +
        "       SET chrActive='Y'\n" +
        "WHERE fk_Customer_DispatchGlCode ='$fk_Customer_DispatchGlCode'\n" +
        "      AND chrActive='E' AND chrSync='N'";

    print('*******relaseStickerForEditDO***selectQuery****$selectQuery');
    print('*******relaseStickerForEditDO***selectQuery1****$selectQuery1');

    await dbClient.rawUpdate(selectQuery);
    //var result = await dbClient.rawUpdate(selectQuery);
    var result1 = await dbClient.rawUpdate(selectQuery1);
    return result1;
  }

  Future<int> syncTimeRealseEditDO() async {
    var dbClient = await getDB();

    String selectQuery = "UPDATE CPM_Customer_Dispatch_Product_Details\n" +
        "SET chrActive='N'\n" +
        "WHERE chrActive='I' AND chrSync='N'";
    print('*******relaseStickerForEditDO***selectQuery****$selectQuery');
    await dbClient.rawUpdate(selectQuery);
    //var result = await dbClient.rawUpdate(selectQuery);

    String selectQuery1 = "UPDATE CPM_Customer_Dispatch_Product_Details\n" +
        "SET chrActive='Y'\n" +
        "WHERE chrActive='E' AND chrSync='N'";
    print('*******relaseStickerForEditDO***selectQuery1****$selectQuery1');
    await dbClient.rawUpdate(selectQuery1);
    //var result1 = await dbClient.rawUpdate(selectQuery1);

    String selectQuery2 = "UPDATE CPM_Customer_Dispatch\n" +
        "SET chrValidSave='Y'\n" +
        "WHERE chrValidSave='E' AND chrSync='N'";
    print('*******relaseStickerForEditDO***selectQuery2****$selectQuery2');
    var result2 = await dbClient.rawUpdate(selectQuery2);

    return result2;
  }

  Future<List<ScanDataModel>> showStickerDialogSearchTask(String values,
      int fk_Customer_DispatchGlCode, int fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT  DISTINCT" +
        " res.fk_Customer_DispatchProduct_GLCode," +
        " res.fk_Customer_DispatchGlCode," +
        " res.intRowNo," +
        " res.varSticker," +
        " res.chrValid," +
        " res.chrPallet," +
        " (CASE WHEN ifnull( res.chrPallet, 'N' ) = 'Y'  THEN" +
        " (SELECT count(DISTINCT CCDPD1.intGlCode)" +
        " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD1" +
        " WHERE CCDPD1.fk_Customer_DispatchGlCode=res.fk_Customer_DispatchGlCode" +
        " AND CCDPD1.fk_PalletGlCode=res.fk_PalletGlCode" +
        " AND CCDPD1.chrPallet='Y'" +
        " AND ifnull( CCDPD1.chrActive, 'N' ) IN ( 'Y', 'I' ) and CCDPD1.chrValid='Y')" +
        " ELSE 0 END) AS intNoOfSticker" +
        " FROM" +
        " (SELECT  DISTINCT (case when ifnull(CCDPD.chrPallet,'N')='Y' then CCDPD.fk_PalletGlCode else CCDPD.intGlCode end)  as fk_Customer_DispatchProduct_GLCode," +
        " (case when ifnull(CCDPD.chrPallet,'N')='Y' then 0 else ifNull(intRowNo,0)  end)  AS intRowNo," +
        " (case when ifnull(CCDPD.chrPallet,'N')='Y' then CPM.varPalletNo else CCDPD.varSticker end) AS varSticker," +
        " (case when ifnull(CCDPD.chrPallet,'N')='Y' then 'Y' else CCDPD.chrValid end) AS chrValid," +
        " CCDPD.chrPallet as chrPallet," +
        " CCD.intGlCode as fk_Customer_DispatchGlCode," +
        " (case when ifnull(CCDPD.chrPallet,'N')='Y' then CCDPD.fk_PalletGlCode else 0 end) as fk_PalletGlCode" +
        " FROM CPM_Customer_Dispatch as CCD\n" +
        " INNER JOIN CPM_Customer_Dispatch_Product_Details as CCDPD ON CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode\n" +
        " LEFT JOIN Product_SKU_Mst as PSM  ON PSM.intGlCode=CCDPD.fk_Product_SKU_Glcode\n" +
        " LEFT JOIN CPM_Pallet_MST CPM ON CCDPD.fk_PalletGlCode=CPM.intGlCode " +
        " WHERE CCD.intGlCode='$fk_Customer_DispatchGlCode'" +
        "      AND (ifnull(CCD.chrCancelDO,'N')='N' OR CCD.chrCancelDO='')\n" +
        "      AND CCDPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'" +
        "      AND ifnull(CCD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCDPD.chrActive,'N') IN ('Y','I')\n" +
        "      AND (ifnull(CCDPD.chrReceived,'N')='N' OR CCDPD.chrReceived='' OR CCDPD.chrReceived=' ')\n" +
        "      AND (ifnull(CCDPD.chrRejected,'N')='N' OR CCDPD.chrRejected='' OR CCDPD.chrRejected=' ')\n" +
        "      AND  CCDPD.chrValid IN ('N','Y') AND (CCDPD.varSticker LIKE '%'||'$values' ||'%' OR ''='$values') ORDER BY CCDPD.dtEntryDate DESC) as res";

    print('=======showStickerDialogSearchTask=====$QUERY');

    var result = await dbClient.rawQuery(QUERY);

    List<ScanDataModel> list = new List();

    if (result.isNotEmpty) {
      int introw = result.length;
      for (int i = 0; i < result.length; i++) {
        ScanDataModel masterModel = ScanDataModel.fromMap(result[i]);
        masterModel.intRows = introw;
        introw = introw - 1;
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<ReceiveScanRecordModel>> getReceiveStickerRecord(
      int fkReceiveGlCode,
      int fkDispatchGlCode,
      int fk_Product_SKU_Glcode,
      String values) async {
    var dbClient = await getDB();

    /*String QUERY = "SELECT DISTINCT 0 _id," +
        " res.varSticker," +
        " res.varColor," +
        " res.varBatch_No," +
        " ( CASE WHEN res.fk_DispatchPalletGlCode>0 AND res.chrDispatchBreak IS NULL THEN " +
        " (SELECT count(DISTINCT CCDPD1.intGlCode)" +
        " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD1" +
        " WHERE CCDPD1.fk_Customer_DispatchGlCode=res.fk_DispatchGlCode" +
        " AND CCDPD1.fk_PalletGlCode=res.fk_DispatchPalletGlCode" +
        " AND CCDPD1.chrPallet='Y'" +
        " AND ifnull( CCDPD1.chrActive, 'N' ) IN ( 'I','Y' )" +
        " AND CCDPD1.chrValid='Y' ) ELSE 0 END) AS intNoOfSticker" +
        " FROM" +
        " (SELECT DISTINCT" +
        " (CASE WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y' THEN res_detail.varReceivePalletNo" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL AND res_pallet_break.chrDispatchBreak IS NULL  THEN res_detail.varDispatchPalletNo" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_pallet_break.chrDispatchBreak='Y'  THEN res_detail.varDispatchSticker" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N'  THEN res_detail.varDispatchSticker" +
        " ELSE res_detail.varDispatchSticker END) as varSticker," +
        " (CASE WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y' THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL AND res_pallet_break.chrDispatchBreak IS NULL  THEN 'W'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NOT NULL AND res_pallet_break.chrDispatchBreak='Y'  THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS  NULL AND res_pallet_break.chrDispatchBreak='Y'  THEN 'W'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N' AND res_detail.varDispatchSticker= res_detail.varReceiveSticker THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N' AND ifnull(res_detail.varDispatchSticker,'')<> ifnull(res_detail.varReceiveSticker,'') THEN 'W'" +
        " ELSE 'G' END) as varColor," +
        " res_detail.fk_DispatchGlCode," +
        " (CASE WHEN (ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y')" +
        " OR ( ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL  AND res_pallet_break.chrDispatchBreak IS NULL )" +
        " THEN res_detail.fk_DispatchPalletGlCode" +
        " ELSE 0 END) as fk_DispatchPalletGlCode," +
        " res_detail.varBatch_No as varBatch_No," +
        " res_pallet_break.chrDispatchBreak" +
        " FROM" +
        " (" +
        " SELECT DISTINCT" +
        " CCD.intGlCode as fk_DispatchGlCode," +
        " CCDPD.intGlCode as fk_DispatchProductDetailGlCode," +
        " CCDPD.chrPallet as chrDispatchPallet," +
        " CCDPD.fk_PalletGlCode as fk_DispatchPalletGlCode," +
        " CCDPD.fk_StickerGlCode as fk_DispatchStickerGlCode," +
        " CCDPD.varSticker as varDispatchSticker," +
        " CPM_DISP.varPalletNo as varDispatchPalletNo," +
        " CCDPD.chrReceived as chrDispatchReceived," +
        " CCR.intGlCode as fk_ReceiveGlCode," +
        " CCRPD.intGlCode as fk_ReceiveProductDetailGlCode," +
        " CCRPD.chrPallet as chrReceivePallet," +
        " CCRPD.fk_PalletGlCode as fk_ReceivePalletGlCode," +
        " CCRPD.varSticker as varReceiveSticker," +
        " CPM_RECV.varPalletNo as varReceivePalletNo," +
        " CSD.varBatch_No" +
        " FROM CPM_Customer_Dispatch_Product_Details CCDPD \n" +
        " INNER JOIN CPM_Customer_Dispatch  CCD ON(CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode)                                               \n" +
        " INNER JOIN CPM_Sticker_Details CSD ON(CSD.intGlCode=CCDPD.fk_StickerGlCode)                                               \n" +
        " LEFT JOIN CPM_Customer_Receive CCR ON(CCR.fk_DispatchGlCode=CCD.intGlCode AND CCR.chrValidSave<>'C' AND CCR.chrActive='Y') \n" +
        " LEFT JOIN CPM_Customer_Receive_Product_Details CCRPD ON(CCRPD.fk_Customer_ReceiveGlCode=CCR.intGlCode\n" +
        "                                                        AND CCRPD.fk_Product_SKU_Glcode=CCDPD.fk_Product_SKU_Glcode\n" +
        "                                                        AND CCRPD.fk_StickerGlCode=CCDPD.fk_StickerGlCode                                                                                                                                                              \n" +
        "                                                        AND ifnull(CCRPD.chrValid,'N')='Y'\n" +
        "                                                        AND ifnull(CCRPD.chrActive,'N')='Y'\n" +
        "                                                       )\n" +
        " LEFT JOIN CPM_Pallet_MST CPM_DISP ON CCDPD.fk_PalletGlCode=CPM_DISP.intGlCode " +
        " LEFT JOIN CPM_Pallet_MST CPM_RECV ON CCRPD.fk_PalletGlCode=CPM_RECV.intGlCode " +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'\n" +
        " AND CCDPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'\n" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        " AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        " AND ifnull(CCDPD.chrReceived,'N')='N'\n" +
        " AND ifnull(CCDPD.chrRejected,'N')='N'\n" +
        " AND ifnull(CCD.chrValidSave,'N')='Y' AND (CCDPD.varSticker LIKE '%' ||'$values' ||'%' OR ''='$values') ORDER BY CCDPD.dtEntryDate DESC) as res_detail " +
        " LEFT JOIN" +
        " (SELECT CCDPD.fk_PalletGlCode,'Y' as chrDispatchBreak" +
        " FROM CPM_Customer_Dispatch_Product_Details CCDPD" +
        " INNER JOIN CPM_Customer_Dispatch  CCD ON(CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode)" +
        " INNER JOIN CPM_Customer_Receive CCR ON(CCR.fk_DispatchGlCode=CCD.intGlCode AND CCR.chrValidSave<>'C' AND CCR.chrActive='Y')" +
        " INNER JOIN CPM_Customer_Receive_Product_Details CCRPD ON(CCRPD.fk_Customer_ReceiveGlCode=CCR.intGlCode" +
        " AND CCRPD.fk_Product_SKU_Glcode=CCDPD.fk_Product_SKU_Glcode" +
        " AND CCRPD.fk_StickerGlCode=CCDPD.fk_StickerGlCode" +
        " AND ifnull(CCRPD.chrValid,'N')='Y'" +
        " AND ifnull(CCRPD.chrActive,'N')='Y'" +
        " )" +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'" +
        " AND CCDPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " AND ifnull(CCDPD.chrActive,'N')='Y'" +
        " AND ifnull(CCD.chrValidSave,'N')='Y'" +
        " AND CCDPD.chrPallet='Y'" +
        " AND CCRPD.chrPallet='N') as res_pallet_break" +
        " ON res_detail.fk_DispatchPalletGlCode=res_pallet_break.fk_PalletGlCode) AS res";*/

    String QUERY = "SELECT DISTINCT 0 _id," +
        " res.varSticker," +
        " res.varColor," +
        " res.varBatch_No," +
        " ( CASE WHEN res.fk_DispatchPalletGlCode>0 AND res.chrDispatchBreak IS NULL THEN " +
        " (SELECT count(DISTINCT CCDPD1.intGlCode)" +
        " FROM CPM_Customer_Dispatch_Product_Details AS CCDPD1" +
        " WHERE CCDPD1.fk_Customer_DispatchGlCode=res.fk_DispatchGlCode" +
        " AND CCDPD1.fk_PalletGlCode=res.fk_DispatchPalletGlCode" +
        " AND CCDPD1.chrPallet='Y'" +
        " AND ifnull( CCDPD1.chrActive, 'N' ) IN ( 'I','Y' )" +
        " AND CCDPD1.chrValid='Y' ) ELSE 0 END) AS intNoOfSticker" +
        " FROM" +
        " (SELECT DISTINCT" +
        " (CASE WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y' THEN res_detail.varReceivePalletNo" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL AND res_pallet_break.chrDispatchBreak IS NULL  THEN res_detail.varDispatchPalletNo" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_pallet_break.chrDispatchBreak='Y'  THEN res_detail.varDispatchSticker" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N'  THEN res_detail.varDispatchSticker" +
        " ELSE res_detail.varDispatchSticker END) as varSticker," +
        " (CASE WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y' THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL AND res_pallet_break.chrDispatchBreak IS NULL  THEN 'W'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NOT NULL AND res_pallet_break.chrDispatchBreak='Y'  THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS  NULL AND res_pallet_break.chrDispatchBreak='Y'  THEN 'W'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N' AND res_detail.varDispatchSticker= res_detail.varReceiveSticker THEN 'G'" +
        " WHEN ifnull(res_detail.chrDispatchPallet,'N')='N' AND ifnull(res_detail.varDispatchSticker,'')<> ifnull(res_detail.varReceiveSticker,'') THEN 'W'" +
        " ELSE 'G' END) as varColor," +
        " res_detail.fk_DispatchGlCode," +
        " (CASE WHEN (ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet='Y')" +
        " OR ( ifnull(res_detail.chrDispatchPallet,'N')='Y' AND res_detail.chrReceivePallet IS NULL  AND res_pallet_break.chrDispatchBreak IS NULL )" +
        " THEN res_detail.fk_DispatchPalletGlCode" +
        " ELSE 0 END) as fk_DispatchPalletGlCode," +
        " res_detail.varBatch_No as varBatch_No," +
        " res_pallet_break.chrDispatchBreak" +
        " FROM" +
        " (" +
        " SELECT DISTINCT" +
        " CCD.intGlCode as fk_DispatchGlCode," +
        " CCDPD.intGlCode as fk_DispatchProductDetailGlCode," +
        " CCDPD.chrPallet as chrDispatchPallet," +
        " CCDPD.fk_PalletGlCode as fk_DispatchPalletGlCode," +
        " CCDPD.fk_StickerGlCode as fk_DispatchStickerGlCode," +
        " CCDPD.varSticker as varDispatchSticker," +
        " CPM_DISP.varPalletNo as varDispatchPalletNo," +
        " CCDPD.chrReceived as chrDispatchReceived," +
        " recv.fk_ReceiveGlCode as fk_ReceiveGlCode," +
        " recv.fk_CustomerReceiveProductGlCode as fk_ReceiveProductDetailGlCode," +
        " recv.chrPallet as chrReceivePallet," +
        " recv.fk_PalletGlCode as fk_ReceivePalletGlCode," +
        " recv.varSticker as varReceiveSticker," +
        " CPM_RECV.varPalletNo as varReceivePalletNo," +
        " CSD.varBatch_No" +
        " FROM CPM_Customer_Dispatch_Product_Details CCDPD \n" +
        " INNER JOIN CPM_Customer_Dispatch  CCD ON(CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode) \n" +
        " INNER JOIN CPM_Sticker_Details CSD ON(CSD.intGlCode=CCDPD.fk_StickerGlCode) \n" +
        " LEFT JOIN (SELECT distinct CCR.intGlCode as fk_ReceiveGlCode," +
        " CCR.fk_DispatchGlCode," +
        " CCRPD.intGlCode as fk_CustomerReceiveProductGlCode," +
        " CCRPD.fk_Product_SKU_Glcode," +
        " CCRPD.chrPallet," +
        " CCRPD.fk_StickerGlCode," +
        " CCRPD.fk_PalletGlCode ," +
        " CCRPD.varSticker" +
        " FROM CPM_Customer_Receive CCR" +
        " LEFT JOIN CPM_Customer_Receive_Product_Details CCRPD ON(CCRPD.fk_Customer_ReceiveGlCode=CCR.intGlCode" +
        " AND ifnull(CCRPD.chrValid,'N')='Y'" +
        " AND ifnull(CCRPD.chrActive,'N')='Y')" +
        " WHERE  CCR.fk_DispatchGlCode='$fkDispatchGlCode' AND CCRPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode' AND CCR.chrValidSave<>'C' AND CCR.chrActive='Y'" +
        " ) as recv ON recv.fk_DispatchGlCode=CCD.intGlCode" +
        " AND recv.fk_Product_SKU_Glcode=CCDPD.fk_Product_SKU_Glcode" +
        " AND recv.fk_StickerGlCode=CCDPD.fk_StickerGlCode" +
        " LEFT JOIN CPM_Pallet_MST CPM_DISP ON CCDPD.fk_PalletGlCode=CPM_DISP.intGlCode" +
        " LEFT JOIN CPM_Pallet_MST CPM_RECV ON recv.fk_PalletGlCode=CPM_RECV.intGlCode" +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'\n" +
        " AND CCDPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'\n" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'\n" +
        " AND ifnull(CCDPD.chrActive,'N')='Y'\n" +
        " AND ifnull(CCDPD.chrReceived,'N')='N'\n" +
        " AND ifnull(CCDPD.chrRejected,'N')='N'\n" +
        " AND ifnull(CCD.chrValidSave,'N')='Y' AND (CCDPD.varSticker LIKE '%' ||'$values' ||'%' OR ''='$values') ORDER BY CCDPD.dtEntryDate DESC) as res_detail " +
        " LEFT JOIN" +
        " (SELECT CCDPD.fk_PalletGlCode,'Y' as chrDispatchBreak" +
        " FROM CPM_Customer_Dispatch_Product_Details CCDPD" +
        " INNER JOIN CPM_Customer_Dispatch  CCD ON(CCD.intGlCode=CCDPD.fk_Customer_DispatchGlCode)" +
        " INNER JOIN CPM_Customer_Receive CCR ON(CCR.fk_DispatchGlCode=CCD.intGlCode AND CCR.chrValidSave<>'C' AND CCR.chrActive='Y')" +
        " INNER JOIN CPM_Customer_Receive_Product_Details CCRPD ON(CCRPD.fk_Customer_ReceiveGlCode=CCR.intGlCode" +
        " AND CCRPD.fk_Product_SKU_Glcode=CCDPD.fk_Product_SKU_Glcode" +
        " AND CCRPD.fk_StickerGlCode=CCDPD.fk_StickerGlCode" +
        " AND ifnull(CCRPD.chrValid,'N')='Y'" +
        " AND ifnull(CCRPD.chrActive,'N')='Y'" +
        " )" +
        " WHERE CCDPD.fk_Customer_DispatchGlCode='$fkDispatchGlCode'" +
        " AND CCDPD.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'" +
        " AND ifnull(CCDPD.chrValid,'N')='Y'" +
        " AND ifnull(CCDPD.chrActive,'N')='Y'" +
        " AND ifnull(CCD.chrValidSave,'N')='Y'" +
        " AND CCDPD.chrPallet='Y'" +
        " AND CCRPD.chrPallet='N') as res_pallet_break" +
        " ON res_detail.fk_DispatchPalletGlCode=res_pallet_break.fk_PalletGlCode) AS res";

    print('=======showStickerDialogSearchTask=====$QUERY');

    var result = await dbClient.rawQuery(QUERY);

    List<ReceiveScanRecordModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        ReceiveScanRecordModel masterModel =
            ReceiveScanRecordModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<String> getDateForSyncTime() async {
    var dbClient = await getDB();

    String selectQuery = "select DATETIME('now') as dtDate";
    print('*******getDateForSyncTime*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['dtDate'].toString();
      }
    }

    return null;
  }

  Future<int> getMaxReceiveID() async {
    var dbClient = await getDB();

    String selectQuery =
        "SELECT MAX(intGlCode) AS fk_Customer_ReceiveGlCode\n" +
            "FROM CPM_Customer_Receive CCR";
    print('*******getMaxReceiveID*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['fk_Customer_ReceiveGlCode'];
      }
    }

    return 0;
  }

  Future<int> checkCancelDOForEditDO(int initGlCode) async {
    var dbClient = await getDB();

    String selectQuery =
        "SELECT count(intGlCode) as count FROM CPM_Customer_Dispatch WHERE intGlCode='$initGlCode' AND ifnull(chrCancelDO,'N')='Y'";

    print('*******checkCancelDOForEditDO*******$selectQuery');
    var result = await dbClient.rawQuery(selectQuery);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['count'];
      }
    }

    return -1;
  }

  Future<String> checkHalfTransactionForAddDamage() async {
    var dbClient = await getDB();

    String QUERY =
        "SELECT CCSD.intGlCode AS Fk_Customer_Sticker_DamageGlCode,CCSD.varTransactionCode as varAddTransactionCode \n" +
            " FROM CPM_Customer_Sticker_Damage CCSD\n" +
            " WHERE ifnull(chrValidSave,'N')='N'\n" +
            " AND ifnull(chrActive,'N')='Y'\n" +
            " ORDER BY CCSD.intGlCode DESC LIMIT 1";

    print('*******checkHalfTransactionForAddDamage*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('===result===${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['varAddTransactionCode'];
      }
    }

    return null;
  }

  Future<String> checkDispatchHalfTransactionForScrap() async {
    var dbClient = await getDB();

    String QUERY = "SELECT varTransactionCode as varTransactionCode" +
        " FROM CPM_Customer_Sticker_Scrap AS CCSS" +
        " WHERE ifnull(chrValidSave,'N')='N'" +
        " AND ifnull(chrActive,'N')='Y'" +
        " ORDER BY CCSS.intGlCode DESC LIMIT 1;";

    print('*******checkHalfTransactionForAddDamage*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('===result===${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['varTransactionCode'];
      }
    }

    return null;
  }

  Future<String> checkHalfTransactionForAddConsume() async {
    var dbClient = await getDB();

    String QUERY =
        "SELECT CCSC.intGlCode AS Fk_Customer_Sticker_DamageGlCode,CCSC.varTransactionCode as varAddTransactionCode \n" +
            " FROM CPM_Customer_Sticker_Consume CCSC\n" +
            " WHERE ifnull(chrValidSave,'N')='N'\n" +
            " AND ifnull(chrActive,'N')='Y'\n" +
            " ORDER BY CCSC.intGlCode DESC LIMIT 1";

    print('*******checkHalfTransactionForAddConsume*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('===result===${result.toString()}');
    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['varAddTransactionCode'];
      }
    }

    return null;
  }

  Future<String> checkHalfTransactionForRemoveDamage() async {
    var dbClient = await getDB();

    String DamageRemoveHalfTrans =
        "SELECT CCSDR.intGlCode AS Fk_Customer_Sticker_Damage_RemoveGlCode,CCSDR.varTransactionCode as varRemoveTransactionCode \n" +
            "FROM CPM_Customer_Sticker_Damage_Remove CCSDR\n" +
            "WHERE ifnull(CCSDR.chrValidSave,'N')='N'\n" +
            "AND ifnull(CCSDR.chrActive,'N')='Y'\n" +
            "ORDER BY CCSDR.intGlCode DESC LIMIT 1";

    print(
        '*******checkHalfTransactionForAddDamage*******$DamageRemoveHalfTrans');
    var result = await dbClient.rawQuery(DamageRemoveHalfTrans);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return result[i]['varRemoveTransactionCode'];
      }
    }

    return null;
  }

  Future<List<MyStockInfoModel>> getStockInfoList(
      int initGlCode, String searchText) async {
    var dbClient = await getDB();

    String getStockInfoListQuery =
        "SELECT  0 _id,CPBS.fk_Product_SKU_Glcode AS  fk_Product_SKU_Glcode,\n" +
            "        PSM.varProduct_SKU_Code AS varProduct_SKU_Code,\n" +
            "        PSM.varProduct_SKU_Name AS varProduct_SKU_Name,\n" +
            "        round(SUM(CPBS.decQty),2) AS decQty,\n" +
            "        round(SUM(CPBS.decQty / (CASE WHEN PSM.fk_UOMGlCode=3 THEN 1\n" +
            "            WHEN PSM.fk_UOMGlCode<>3 and ifnull(Conversion_Factor,0)>0 THEN ifnull(Conversion_Factor,1) \n" +
            "            ELSE 1 END)),2) AS qtyKG\n" +
            "FROM CPM_PSKU_Batch_Stock  CPBS \n" +
            "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CPBS.fk_Product_SKU_Glcode)\n" +
            "WHERE CPBS.fk_Customer_GlCode='$initGlCode' AND ifnull(CPBS.decQty,0)>0" +
            " \n" +
            "AND (PSM.varProduct_SKU_Name LIKE '%'||" +
            "'$searchText'" +
            "||'%' OR PSM.varProduct_SKU_Code LIKE '%'||" +
            "'$searchText'" +
            "||'%' OR " +
            "'$searchText'" +
            "='')\n" +
            "GROUP BY CPBS.fk_Product_SKU_Glcode,PSM.varProduct_SKU_Code,PSM.varProduct_SKU_Name ORDER BY PSM.varProduct_SKU_Name";

    print('*******getStockInfoListQuery*******$getStockInfoListQuery');
    var result = await dbClient.rawQuery(getStockInfoListQuery);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getDamageList(
      String initGlCode, String searchText) async {
    var dbClient = await getDB();

    String QUERY = "SELECT \n" +
        "       COUNT(CCSD.fk_StickerGlCode) AS totalUnit,\n" +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        "       CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode,\n" +
        "       round(COUNT(CCSD.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                            WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG \n" +
        "FROM CPM_Customer_Sticker_Damage CCSD \n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        " AND (PSM.varProduct_SKU_Name LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR PSM.varProduct_SKU_Code LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR " +
        "'$searchText'" +
        "='')\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='Y'\n" +
        "GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getDamageList*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getScrapList(
      String initGlCode, String searchText) async {
    var dbClient = await getDB();

    String QUERY = "SELECT  COUNT(CCSS.fk_StickerGlCode) AS totalUnit," +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        " CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode," +
        " round(COUNT(CCSS.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1" +
        " WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0" +
        " THEN ifnull(MIN(Conversion_Factor),1)" +
        " ELSE 1 END),2) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Scrap CCSS" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSS.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSS.chrActive,'N')='Y'" +
        " AND ifnull(PSM.chrActive,'N')='Y'" +
        " AND (PSM.varProduct_SKU_Name LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR PSM.varProduct_SKU_Code LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR " +
        "'$searchText'" +
        "='')\n" +
        " AND ifnull(CCSS.chrValidSave,'N')='Y'" +
        " GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getScrapList*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getLoadConsumeList(
      String initGlCode, String searchText) async {
    var dbClient = await getDB();

    String QUERY = "SELECT  COUNT(CCSC.fk_StickerGlCode) AS totalUnit," +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        " CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode," +
        " round(COUNT(CCSC.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1" +
        " WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0" +
        " THEN ifnull(MIN(Conversion_Factor),1)" +
        " ELSE 1 END),2) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Consume CCSC" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSC.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSC.chrActive,'N')='Y'" +
        " AND ifnull(PSM.chrActive,'N')='Y'" +
        " AND (PSM.varProduct_SKU_Name LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR PSM.varProduct_SKU_Code LIKE '%'||" +
        "'$searchText'" +
        "||'%' OR " +
        "'$searchText'" +
        "='')\n" +
        " AND ifnull(CCSC.chrValidSave,'N')='Y'" +
        " GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getLoadConsumeList*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getDamageListForAdd(
      String addDamageTransCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT \n" +
        "       COUNT(CCSD.fk_StickerGlCode) AS totalUnit,\n" +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        "       CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode,\n" +
        "       round(COUNT(CCSD.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                           WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG\n" +
        "FROM CPM_Customer_Sticker_Damage CCSD \n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        "      AND CCSD.varTransactionCode='$addDamageTransCode'\n" +
        "      AND ifnull(CSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getDamageListForAdd*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getConsumeListForAdd(
      String addDamageTransCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT \n" +
        "       COUNT(CCSC.fk_StickerGlCode) AS totalUnit,\n" +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        "       CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode,\n" +
        "       round(COUNT(CCSC.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                           WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG\n" +
        "FROM CPM_Customer_Sticker_Consume CCSC \n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSC.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSC.chrActive,'N')='Y'\n" +
        "      AND CCSC.varTransactionCode='$addDamageTransCode'\n" +
        "      AND ifnull(CSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSC.chrValidSave,'N')='N'\n" +
        "GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getConsumeListForAdd*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getScrapListForArticle(
      String addScrapTransCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT COUNT(CCSS.fk_StickerGlCode) AS totalUnit," +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        " CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode," +
        " round(COUNT(CCSS.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1" +
        " WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0" +
        " THEN ifnull(MIN(Conversion_Factor),1)" +
        " ELSE 1 END),2) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Scrap CCSS" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSS.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSS.chrActive,'N')='Y'" +
        " AND CCSS.varTransactionCode='$addScrapTransCode'" +
        " AND ifnull(CSD.chrActive,'N')='Y'" +
        " AND ifnull(PSM.chrActive,'N')='Y'" +
        " AND ifnull(CCSS.chrValidSave,'N')='N'" +
        " GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getScrapListForArticle*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoModel>> getDamageListForRemove(
      String removeDamageTransCode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT \n" +
        "       COUNT(CCSD.fk_StickerGlCode) AS totalUnit,\n" +
        " PSM.varProduct_SKU_Code||' - '||PSM.varProduct_SKU_Name as varProduct_SKU_Name," +
        "       CSD.fk_Product_SKUGlCode as fk_Product_SKUGlCode,\n" +
        "       round(COUNT(CCSD.fk_StickerGlCode) / (CASE WHEN MIN(PSM.fk_UOMGlCode)=3 THEN 1 \n" +
        "                           WHEN MIN(PSM.fk_UOMGlCode)<>3 and ifnull(MIN(Conversion_Factor),0)>0 THEN ifnull(MIN(Conversion_Factor),1)\n" +
        "                           ELSE 1 END),2) AS qtyKG\n" +
        "FROM CPM_Customer_Sticker_Damage_Remove CCSD \n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND CCSD.varTransactionCode='$removeDamageTransCode'\n" +
        "      AND ifnull(CSD.chrActive,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "GROUP BY PSM.varProduct_SKU_Name,CSD.fk_Product_SKUGlCode,PSM.varProduct_SKU_Code";

    print('*******getDamageListForRemove*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoModel masterModel = MyStockInfoModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<DamageUnitsProductModel> getDamageUnitProductCountForAdd(
      String addTransactionCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSD.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Damage CCSD\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        "      AND CCSD.varTransactionCode='$addTransactionCode'\n" +
        "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    print('*******getDamageUnitProductCount*******$COUNT_QUERY');
    var result = await dbClient.rawQuery(COUNT_QUERY);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return DamageUnitsProductModel.fromMap(result[i]);
      }
    }
    return null;
  }

  Future<DamageUnitsProductModel> getConsumeUnitProductCountForAdd(
      String addTransactionCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSC.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Consume CCSC\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSC.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSC.chrActive,'N')='Y'\n" +
        "      AND CCSC.varTransactionCode='$addTransactionCode'\n" +
        "      AND ifnull(CCSC.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSC.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    print('*******getConsumeUnitProductCount*******$COUNT_QUERY');
    var result = await dbClient.rawQuery(COUNT_QUERY);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return DamageUnitsProductModel.fromMap(result[i]);
      }
    }
    return null;
  }

  Future<DamageUnitsProductModel> getUnitProductCountForScrap(
      String addTransactionCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSS.intGlCode) AS TotalUnit," +
        " COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct" +
        " FROM CPM_Customer_Sticker_Scrap CCSS" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSS.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSS.chrActive,'N')='Y'" +
        " AND CCSS.varTransactionCode='$addTransactionCode'" +
        " AND ifnull(CCSS.chrSync,'N')='N'" +
        " AND ifnull(CCSS.chrValidSave,'N')='N'" +
        " AND ifnull(PSM.chrActive,'N')='Y'";

    print('*******getScrapUnitProductCount*******$COUNT_QUERY');
    var result = await dbClient.rawQuery(COUNT_QUERY);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return DamageUnitsProductModel.fromMap(result[i]);
      }
    }
    return null;
  }

  Future<DamageUnitsProductModel> getDamageUnitProductCountForRemove(
      String removeTransactionCode) async {
    var dbClient = await getDB();

    String COUNT_QUERY = "SELECT COUNT(CCSD.intGlCode) AS TotalUnit,\n" +
        "       COUNT(DISTINCT CSD.fk_Product_SKUGlCode) AS TotalProduct\n" +
        "FROM CPM_Customer_Sticker_Damage_Remove CCSD\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND CCSD.varTransactionCode='$removeTransactionCode'\n" +
        "      AND ifnull(CCSD.chrSync,'N')='N'\n" +
        "      AND ifnull(CCSD.chrValidSave,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'";

    print('*******getDamageUnitProductCount*******$COUNT_QUERY');
    var result = await dbClient.rawQuery(COUNT_QUERY);

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        return DamageUnitsProductModel.fromMap(result[i]);
      }
    }
    return null;
  }

  Future<List<MyStockInfoPopupModel>> getStockInfoPopupList(
      int fk_Customer_GlCode, String fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String getStockInfoPopupListQuery =
        "SELECT  CPBS.intGlCode AS fk_CPM_PSKU_Batch_StockGlCode, "
                "CPBS.fk_Product_SKU_Glcode AS  fk_Product_SKU_Glcode, "
                "PSM.varProduct_SKU_Name AS varProduct_SKU_Name,"
                "    CPBS.varBatchNo AS varBatchNo,"
                "    CPBS.dtExpiryDate AS dtExpiryDate,"
                "    round(CPBS.decQty, 2) AS decQty,"
                "    round(CPBS.decQty / (CASE WHEN PSM.fk_UOMGlCode=3 THEN 1"
                "    WHEN PSM.fk_UOMGlCode<>3 and ifnull(Conversion_Factor,0)>0 THEN ifnull(Conversion_Factor,1)"
                "    ELSE 1 END), 2) AS qtyKG"
                "    FROM CPM_PSKU_Batch_Stock  CPBS"
                "    INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CPBS.fk_Product_SKU_Glcode)"
                "    WHERE CPBS.fk_Customer_GlCode='$fk_Customer_GlCode'" +
            "    AND CPBS.fk_Product_SKU_Glcode='$fk_Product_SKU_Glcode'";

    print('*******getStockInfoListQuery*******$getStockInfoPopupListQuery');
    var result = await dbClient.rawQuery(getStockInfoPopupListQuery, []);
    print('=========result=========${result.toString()}');

    List<MyStockInfoPopupModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoPopupModel masterModel =
            MyStockInfoPopupModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoPopupModel>> getDamageStockPopupList(
      String fk_Customer_GlCode, String fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT \n" +
        "        CSD.fk_Product_SKUGlCode AS  fk_Product_SKU_Glcode,\n" +
        "        PSM.varProduct_SKU_Name AS varProduct_SKU_Name,\n" +
        "        CSD.varBatch_No AS varBatchNo,\n" +
        "        CSD.dtExpireDate AS dtExpiryDate, \n" +
        "        COUNT(DISTINCT CSD.intGlCode) AS decQty,\n" +
        "        COUNT(DISTINCT CSD.intGlCode)/(CASE WHEN PSM.fk_UOMGlCode=3 THEN 1\n" +
        "            WHEN PSM.fk_UOMGlCode<>3 and ifnull(Conversion_Factor,0)>0 THEN ifnull(Conversion_Factor,1) \n" +
        "            ELSE 1 END) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Damage CCSD\n" +
        "INNER JOIN CPM_Sticker_Details CSD ON (CCSD.fk_StickerGlCode=CSD.intGlCode)\n" +
        "INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)\n" +
        "WHERE ifnull(CCSD.chrActive,'N')='Y'\n" +
        "      AND ifnull(CCSD.chrRemove,'N')='N'\n" +
        "      AND ifnull(PSM.chrActive,'N')='Y'\n" +
        "      AND CSD.fk_Product_SKUGlCode='" +
        fk_Product_SKU_Glcode +
        "'\n" +
        "GROUP BY CSD.fk_Product_SKUGlCode,\n" +
        "         CSD.varBatch_No,\n" +
        "         PSM.varProduct_SKU_Name,\n" +
        "         CSD.dtExpireDate";

    print('*******getStockInfoListQuery*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoPopupModel> list = new List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoPopupModel masterModel =
            MyStockInfoPopupModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoPopupModel>> getScrapStockPopupList(
      String fk_Customer_GlCode, String fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT CSD.fk_Product_SKUGlCode AS fk_Product_SKU_Glcode," +
        " PSM.varProduct_SKU_Name AS varProduct_SKU_Name," +
        " CSD.varBatch_No AS varBatchNo," +
        " CSD.dtExpireDate AS dtExpiryDate," +
        " COUNT(DISTINCT CSD.intGlCode) AS decQty," +
        " COUNT(DISTINCT CSD.intGlCode)/(CASE WHEN PSM.fk_UOMGlCode=3 THEN 1" +
        " WHEN PSM.fk_UOMGlCode<>3 and ifnull(Conversion_Factor,0)>0" +
        " THEN ifnull(Conversion_Factor,1)" +
        " ELSE 1 END) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Scrap CCSS" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSS.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSS.chrActive,'N')='Y'" +
        " AND ifnull(PSM.chrActive,'N')='Y'" +
        " AND CSD.fk_Product_SKUGlCode='" +
        fk_Product_SKU_Glcode +
        "'" +
        " GROUP BY CSD.fk_Product_SKUGlCode," +
        " CSD.varBatch_No," +
        " PSM.varProduct_SKU_Name," +
        " CSD.dtExpireDate";

    print('*******getScrapInfoListQuery*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoPopupModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoPopupModel masterModel =
        MyStockInfoPopupModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }

  Future<List<MyStockInfoPopupModel>> getConsumeStockPopupList(
      String fk_Customer_GlCode, String fk_Product_SKU_Glcode) async {
    var dbClient = await getDB();

    String QUERY = "SELECT CSD.fk_Product_SKUGlCode AS fk_Product_SKU_Glcode," +
        " PSM.varProduct_SKU_Name AS varProduct_SKU_Name," +
        " CSD.varBatch_No AS varBatchNo," +
        " CSD.dtExpireDate AS dtExpiryDate," +
        " COUNT(DISTINCT CSD.intGlCode) AS decQty," +
        " COUNT(DISTINCT CSD.intGlCode)/(CASE WHEN PSM.fk_UOMGlCode=3 THEN 1" +
        " WHEN PSM.fk_UOMGlCode<>3 and ifnull(Conversion_Factor,0)>0" +
        " THEN ifnull(Conversion_Factor,1)" +
        " ELSE 1 END) AS qtyKG" +
        " FROM CPM_Customer_Sticker_Consume CCSC" +
        " INNER JOIN CPM_Sticker_Details CSD ON (CCSC.fk_StickerGlCode=CSD.intGlCode)" +
        " INNER JOIN Product_SKU_Mst PSM ON(PSM.intGlCode=CSD.fk_Product_SKUGlCode)" +
        " WHERE ifnull(CCSC.chrActive,'N')='Y'" +
        " AND ifnull(PSM.chrActive,'N')='Y'" +
        " AND CSD.fk_Product_SKUGlCode='" +
        fk_Product_SKU_Glcode +
        "'" +
        " GROUP BY CSD.fk_Product_SKUGlCode," +
        " CSD.varBatch_No," +
        " PSM.varProduct_SKU_Name," +
        " CSD.dtExpireDate";

    print('*******getConsumeStockPopupListQuery*******$QUERY');
    var result = await dbClient.rawQuery(QUERY);
    print('=========result=========${result.toString()}');

    List<MyStockInfoPopupModel> list = List();

    if (result.isNotEmpty) {
      for (int i = 0; i < result.length; i++) {
        MyStockInfoPopupModel masterModel =
        MyStockInfoPopupModel.fromMap(result[i]);
        list.add(masterModel);
      }
    }
    return list;
  }
}
