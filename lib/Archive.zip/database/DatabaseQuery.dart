class DatabaseQuery {
  static final String LOG = "DatabaseHelper";

  //8905531178

  // Database Version
  static final int DATABASE_VERSION = 5;

  // Database Name
  static final String DATABASE_NAME = "BASF-HK-Database.db";

  // Table Names
  static final String TABLE_CPM_CUSTOMER_DISPATCH = "CPM_Customer_Dispatch";
  static final String TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS =
      "CPM_Customer_Dispatch_Product_Details";
  static final String TABLE_CPM_CUSTOMER_RECEIVE = "CPM_Customer_Receive";
  static final String TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS =
      "CPM_Customer_Receive_Product_Details";
  static final String TABLE_CPM_STRICKER = "CPM_Sticker";
  static final String TABLE_CPM_STRICKER_Details = "CPM_Sticker_Details";
  static final String TABLE_CPM_CUSTOMER_RECEIVE_DAMAGE =
      "CPM_Customer_Receive_Damage";
  static final String TABLE_CPM_CUSTOMER_OPENING_STOCK =
      "CPM_Customer_Opening_Stock";
  static final String TABLE_CPM_CUSTOMER_PENDING_ORDER =
      "CPM_Customer_Pending_Order";
  static final String TABLE_CPM_CUSTOMER_PENDING_DISPATCH =
      "CPM_Customer_Pending_Dispatch";
  static final String TABLE_CPM_DI_DETAILS = "CPM_DI_Details";
  static final String TABLE_STATUS_MST = "Status_Mst";
  static final String TABLE_PRODUCT_MAIN_GROUP_MST = "Product_Main_Group_Mst";
  static final String TABLE_PRODUCT_BUSINESS_GROUP_MST =
      "Product_Business_Group_Mst";
  static final String TABLE_PRD_MST = "PRD_Mst";
  static final String TABLE_PRODUCT_SKU_MST = "Product_SKU_Mst";
  static final String TABLE_PRODUCT_SKU_CONVERSION = "Product_SKU_Conversion";
  static final String TABLE_COUNTRY_MST = "Countries_Mst";
  static final String TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST =
      "Political_Geography_Level_Regional_Mst";
  static final String TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST =
      "Political_Geography_Level_Country_Mst";
  static final String TABLE_POLITICAL_GEOGRAPHY_DETAILS =
      "Political_Geography_Details";
  static final String TABLE_SYSTEM_CONFIGURATION_MST =
      "SystemConfiguration_Mst";
  static final String TABLE_EMPLOYEE_TYPE_MST = "Employee_Type_Mst";
  static final String TABLE_CUSTOMER_TYPE_REGIONAL_MST =
      "Customer_Type_Regional_Mst";
  static final String TABLE_CUSTOMER_TYPE_COUNTRY_MST =
      "Customer_Type_Country_Mst";
  static final String TABLE_PERSON_MST = "Person_Mst";
  static final String TABLE_UOM_MST = "UOM_Mst";
  static final String TABLE_MENU_MST = "Menu_Mst";
  static final String TABLE_PSKU_BATCH_STOCK = "CPM_PSKU_Batch_Stock";
  static final String TABLE_CUSTOMER_PARTNER_MST = "Customer_Partner_Mst";
  static final String TABLE_CPM_CUSTOMER_STICKER_DAMAGE =
      "CPM_Customer_Sticker_Damage";
  static final String TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE =
      "CPM_Customer_Sticker_Damage_Remove";
  static final String TABLE_LOGIN_DETAILS = "LoginDetails";
  static final String TABLE_CPM_Customer_Sticker_Scrap =
      "CPM_Customer_Sticker_Scrap";
  static final String TABLE_CPM_Customer_Sticker_Consume =
      "CPM_Customer_Sticker_Consume";

  //CPM_Customer_Dispatch column names
  static final String COLUMN_INT_GI_CODE = "intGlCode";
  static final String COLUMN_FK_CUSTOMER_FROM_GI_CODE =
      "fk_Customer_From_GlCode";
  static final String COLUMN_FK_CUSTOMER_FROM_TYPE_COUNTRY_GI_CODE =
      "fk_Customer_From_Type_CountryGlCode";
  static final String COLUMN_FK_CUSTOMER_TO_GI_CODE = "fk_Customer_To_GlCode";
  static final String COLUMN_FK_CUSTOMER_TO_TYPE_COUNTRY_GI_CODE =
      "fk_Customer_To_Type_CountryGlCode";
  static final String COLUMN_FK_SOLD_TO_PARTY_GI_CODE_ =
      "fk_Sold_To_Party_GlCode";
  static final String COLUMN_FK_SOLD_TO_PARTY_TYPE_COUNTRY_GI_CODE =
      "fk_Sold_To_Party_Type_CountryGlCode";
  static final String COLUMN_CHAR_TRANS_TYPE = "chrTransType";
  static final String COLUMN_CHAR_EXTERNAL_CUSTOMER = "chrExternal_Customer";
  static final String COLUMN_VAR_CUSTOMER_NAME = "varCustomer_Name";
  static final String COLUMN_VAR_EMAIL = "varEmail";
  static final String COLUMN_VAR_MOBILE = "varMobile";
  static final String COLUMN_VAR_PHONE_NO = "varPhone_No";
  static final String COLUMN_DT_DISPATCH_DATE = "dtDispatchDate";
  static final String COLUMN_VAR_SONO = "varSONO";
  static final String COLUMN_VAR_DONO = "varDONO";
  static final String COLUMN_CHAR_VALID_SAVE = "chrValidSave";
  static final String COLUMN_CHAR_EDIT_DO = "chrEditDO";
  static final String COLUMN_FK_EDIT_DO_BY = "fk_EditDOBy";
  static final String COLUMN_DT_EDIT_DO_DATE = "dtEditDODate";
  static final String COLUMN_CHAR_CANCEL_DO = "chrCancelDO";
  static final String COLUMN_FK_CANCEL_DO_BY = "fk_CancelDOBy";
  static final String COLUMN_DT_CANCEL_DO_DATE = "dtCancelDODate";
  static final String COLUMN_FK_RETURN_STATUS_GL_CODE = "fk_ReturnStatusGlCode";
  static final String COLUMN_VAR_REMARKS = "varRemarks";
  static final String COLUMN_CHAR_ACTIVE = "chrActive";
  static final String COLUMN_CHAR_SYNC = "chrSync";
  static final String COLUMN_CHAR_SYNC_DATE = "varSync_Code";
  static final String COLUMN_DT_SYNC_DATE = "dtSyncDate";
  static final String COLUMN_DT_ENTRY_DATE = "dtEntryDate";
  static final String COLUMN_REF_ENTRY_BY = "ref_Entry_By";
  static final String COLUMN_DT_MODIFIED_DATE = "dtModifiedDate";
  static final String COLUMN_REF_MODIFIED_BY = "ref_Modified_By";
  static final String COLUMN_VAR_ENTITY_NAME = "varEntityName";

  /*static final String COLUMN_DT_CONFIRM_DATE = "dtConfirmDate";
  static final String COLUMN_REF_CONFIRM_BY = "ref_ConfirmBy";*/
  static final String COLUMN_FK_DISPATCH_GL_CODE = "fk_DispatchGlCode";
  static final String COLUMN_VAR_ORGANIZATION_NAME = "varOrganisationName";

  //CPM_Customer_Dispatch_Product_Details column names
  static final String COLUMN_FK_CUSTOMER_DISPATCH_GI_CODE =
      "fk_Customer_DispatchGlCode";
  static final String COLUMN_FK_PRODUCT_SKU_GI_CODE = "fk_Product_SKU_Glcode";
  static final String COLUMN_FK_STRICKER_GI_CODE = "fk_StickerGlCode";
  static final String COLUMN_VAR_STICKER = "varSticker";
  static final String COLUMN_CHAR_DISPATCH = "chrDispatch";
  static final String COLUMN_FK_DISPATCH_BY = "fk_DispatchBy";
  static final String COLUMN_CHAR_RECEIVED = "chrReceived";
  static final String COLUMN_DT_RECEIVED_DATE = "dtReceivedDate";
  static final String COLUMN_FK_RECEIVED_BY = "fk_ReceivedBy";
  static final String COLUMN_CHAR_REJECTED = "chrRejected";
  static final String COLUMN_DT_REJECTED_DATE = "dtRejectedDate";
  static final String COLUMN_FK_REJECTED_BY = "fk_RejectedBy";
  static final String COLUMN_CHAR_VALID = "chrValid";

  //CPM_Customer_Receive column names
  static final String COLUMN_DT_DATE = "dtDate";
  static final String COLUMN_VAR_TRANS_TYPE = "varTransType";

  //static final String COLUMN_VAR_REMARKS = "varRemarks";

  //CPM_Customer_Receive_Product_Details column names
  static final String COLUMN_FK_CUSTOMER_RECEIVE_GI_CODE =
      "fk_Customer_ReceiveGlCode";

  //CPM_Sticker_Details column names
  static final String COLUMN_FK_STICKER_GI_CODE = "fk_StickerGlCode";
  static final String COLUMN_VAR_REF_ID = "varRef_Id";
  static final String COLUMN_FK_PRODUCT_SKU_GI_CODE_ = "fk_Product_SKUGlCode";
  static final String COLUMN_VAR_SYSTEM_NAME = "varSystem_Name";
  static final String COLUMN_FK_CUSTOMER_GI_CODE = "fk_CustomerGlCode";
  static final String COLUMN_FK_COUNTRY_GI_CODE = "fk_CountryGlCode";
  static final String COLUMN_FK_PBG_GI_CODE = "fk_PBGGlCode";
  static final String COLUMN_FK_PRD_GI_CODE = "fk_PRDGlCode";
  static final String COLUMN_VAR_STICKER_TYPE = "varStickerType";
  static final String COLUMN_VAR_DI_NO = "varDINo";
  static final String COLUMN_VAR_BATCH_NO = "varBatch_No";
  static final String COLUMN_DT_MFG_DATE = "dtMFGDate";
  static final String COLUMN_DT_EXPIRE_DATE = "dtExpireDate";
  static final String COLUMN_INT_PRINT_QTY = "intPrintQty";
  static final String COLUMN_VAR_STICKER_FROM_RANGE = "varSticker_From_Range";
  static final String COLUMN_VAR_STICKER_TO_RANGE = "varSticker_To_Range";
  static final String COLUMN_VAR_BTC_NO_IN = "varBTC_No_In";
  static final String COLUMN_VAR_BTC_NO_OUT = "varBTC_No_Out";
  static final String COLUMN_VAR_QR_CODE_IN = "varQR_Code_In";
  static final String COLUMN_VAR_QR_CODE_OUT = "varQR_Code_Out";
  static final String COLUMN_VAR_STICKER_NO = "varSticker_No";
  static final String COLUMN_FK_STATUS_GI_CODE = "fk_StatusGlCode";
  static final String COLUMN_FK_STICKER_GENERATED_BY = "fk_Sticker_GeneratedBy";
  static final String COLUMN_DT_STICKER_GENERATED_DATE =
      "dtSticker_GeneratedDate";
  static final String COLUMN_FK_LAST_DISPATCH_TO = "fk_Last_DispatchedTo";
  static final String COLUMN_FK_LAST_DISPATCH_BY = "fk_Last_DispatchedBy";
  static final String COLUMN_FK_LAST_PREVIOUS_DISPATCH_BY =
      "fk_Last_PreviousDispatchBy";
  static final String COLUMN_DT_LAST_DISPATCH_DATE = "dtLast_DispatchedDate";
  static final String COLUMN_FK_LAST_RECEIVED_BY = "fk_Last_ReceivedBy";
  static final String COLUMN_DT_LAST_RECEIVED_DATE = "dtLast_ReceivedDate";
  static final String COLUMN_FK_LAST_REJECTED_BY = "fk_Last_RejectedBy";
  static final String COLUMN_DT_LAST_REJECTED_DATE = "dtLast_RejectedDate";
  static final String COLUMN_CHAR_DAMAGE = "chrDamage";
  static final String COLUMN_DT_DAMAGE_DATE_TIME = "dtDamageDateTime";
  static final String COLUMN_FK_DAMAGE_BY = "fk_DamageBy";
  static final String COLUMN_VAR_LAST_STAGE = "varLastStage";

  //CPM_Customer_Receive_Damage column names
  static final String COLUMN_FK_SYSTEM_GI_CODE = "fk_SystemGlCode";
  static final String COLUMN_FK_PERSON_GI_CODE = "fk_PersonGlCode";
  static final String COLUMN_CHAR_TYPE = "chrType";
  static final String COLUMN_INT_QUANTITY = "intQuantity";

  //CPM_Customer_Opening_Stock column names
  static final String COLUMN_DT_DATE_TIME = "dtDatetime";
  static final String COLUMN_DEC_QUANTITY = "decQuantitiy";
  static final String COLUMN_DEC_AMOUNT = "decAmount";
  static final String COLUMN_FK_UOM_GI_CODE = "fk_UOMGlCode";

  //CPM_DI_Details column names
  static final String COLUMN_FK_FROM_CUSTOMER_GI_CODE =
      "fk_From_CustomerGlcode";
  static final String COLUMN_FK_SOLD_TO_PARTY_GI_CODE = "fk_SoldToPartyGlCode";
  static final String COLUMN_FK_SHIP_TO_PARTY_GI_CODE = "fk_ShipToPartyGlCode";
  static final String COLUMN_VAR_DI_NUMBER = "varDI_Number";
  static final String COLUMN_DT_DI_DATE = "dtDI_Date";
  static final String COLUMN_FK_PRODUCTSKU_GI_CODE = "fk_ProductSKUGlCode";
  static final String COLUMN_DEC_QTY = "decQty";

  //Product_Main_Group_Mst column names
  static final String COLUMN_VAR_SKU = "varSBU";
  static final String COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE =
      "varProduct_Main_Group_Code";
  static final String COLUMN_VAR_RPDOCUT_MAIN_GROUP_NAME =
      "varProduct_Main_Group_Name";
  static final String COLUMN_VAR_DESCRIPTION = "varDescription";

  //Status_Mst column names
  static final String COLUMN_INT_CODE = "intCode";
  static final String COLUMN_VAR_STATUS = "varStatus";
  static final String COLUMN_VAR_PURPOSE = "varPurpose";

  //Product_Business_Group_Mst column names
  static final String COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE_ =
      "fk_Product_Main_GroupGlCode";
  static final String COLUMN_VAR_PBG_CODE_ = "varPBG_Code";
  static final String COLUMN_VAR_PBG_NAME_ = "varPBG_Name";

  //PRD_MST column names
  static final String COLUMN_VAR_PRODUCT_BUSINESS_GI_CODE =
      "fk_Product_BusinessGlCode";
  static final String COLUMN_VAR_PBG_CODE = "varPRD_Code";
  static final String COLUMN_VAR_PBG_NAME = "varPRD_Name";

  //Product_SKU_Mst column names
  static final String COLUMN_VAR_SBU = "varSBU";
  static final String COLUMN_VAR_PMG_DESCRIPTION = "varPMGDescription";
  static final String COLUMN_VAR_PBG_DESCRIPTION = "varPBGDescription";
  static final String COLUMN_VAR_PRD_CODE = "varPRD_Code";
  static final String COLUMN_VAR_PRD_NAME = "varPRD_Name";
  static final String COLUMN_VAR_PRD_DESCRIPTION = "varPRDDescription";
  static final String COLUMN_VAR_PRODUCT_SKU_CODE = "varProduct_SKU_Code";
  static final String COLUMN_VAR_PRODUCT_SKU_NAME = "varProduct_SKU_Name";
  static final String COLUMN_VAR_PRODUCT_SKU_SORT_NAME =
      "varProduct_SKU_Sort_Name";
  static final String COLUMN_VAR_PRODUCT_TECHNICAL_NAME =
      "varProduct_Technical_Name";
  static final String COLUMN_FK_UOMGICODE = "fk_UOMGlCode";
  static final String COLUMN_VAR_PRODUCT_SKU_SIZE = "varProdcut_SKU_Size";
  static final String COLUMN_INT_NO_OF_UNITS = "int_NO_Of_Units";
  static final String COLUMN_VAR_GTIN_CHECK_DIGIT = "varGTIN_Check_Digit";
  static final String COLUMN_VAR_GTIN = "varGTIN";
  static final String COLUMN_PACKING_CONVERSION_FACTOR =
      "Packing_Conversion_Factor";
  static final String COLUMN_BOX_CONVERSION_FACTOR = "Box_Conversion_Factor";
  static final String OLD_COLUMN_CONVERSION_FACTOR = "Drum_Conversion_Factor";
  static final String COLUMN_CONVERSION_FACTOR = "Conversion_Factor";

  //Countries_Mst column names
  static final String COLUMN_VAR_CODE = "varCode";
  static final String COLUMN_VAR_NAME = "varName";
  static final String COLUMN_VAR_TIME_ZONE = "varTime_Zone";
  static final String COLUMN_INT_UTC_MINUTE_DIFF = "intUTC_Minute_Diff";
  static final String COLUMN_VAR_LATITUDE = "varLatitude";
  static final String COLUMN_VAR_LONGITUDE = "varLongitude";
  static final String COLUMN_INT_FINANCIAL_MONTH = "intFinancial_Month";

  //Political_Geography_Level_Regional_Mst column names
  static final String COLUMN_VAR_LEVEL = "varLevel";
  static final String COLUMN_VAR_GEO_LEVEL_NAME = "varGeo_Level_Name";

  //Political_Geography_Level_Country_Mst column names
  static final String COLUMN_FK_POLITICAL_GEO_LEVEL_REGIONAL_GI_CODE =
      "fk_Political_Geo_Level_RegionalGlCode";

  //Political_Geography_Details column names
  static final String COLUMN_FK_POLITICAL_GEO_LEVEL_COUNTRY_GI_CODE_ =
      "fk_Political_Geo_Level_Country_GlCode";
  static final String COLUMN_REF_PARENT_GI_CODE = "ref_ParentGlCode";
  static final String COLUMN_VAR_POLITICAL_GEOGRAPHY_CODE =
      "varPolitical_Geography_Code";
  static final String COLUMN_VAR_POLITICAL_GEOGRAPHY_NAME =
      "varPolitical_Geography_Name";

  //SystemConfiguration_Mst column names
  static final String COLUMN_FK_SUB_MODULE_GI_CODE = "fk_SubModuleGlCode";
  static final String COLUMN_VAR_VERSION = "varVersion";
  static final String COLUMN_VAR_FILE_PATH = "varFilePath";
  static final String COLUMN_DT_ENTRY_UPDATE_DATE = "dtEntryUpdateDate";
  static final String COLUMN_VAR_PROJECT_NAME = "varProjectName";
  static final String COLUMN_VAR_ERROR_CAPTION = "varErrorCaption";
  static final String COLUMN_VAR_XML_SETTINGS = "varXMLSettings";

  //Employee_Type_Mst column names
  static final String COLUMN_VAR_EMPLOYEE_TYPE_CODE = "varEmployee_Type_Code";
  static final String COLUMN_VAR_EMPLOYEE_TYPE_NAME = "varEmployee_Type_Name";

  //Customer_Type_Regional_Mst column names
  static final String COLUMN_VAR_CUSTOMER_LEVEL = "varCustomer_Level";
  static final String COLUMN_VAR_CUSTOMER_TYPE_CODE = "varCustomer_Type_Code";
  static final String COLUMN_VAR_CUSTOMER_TYPE_NAME = "varCustomer_Type_Name";

  //Customer_Type_Country_Mst column names
  static final String COLUMN_FK_CUSTOMER_TYPE_REGIONAL_GI_CODE =
      "fk_Customer_Type_RegionalGlCode";
  static final String COLUMN_FK_POLITICAL_GEO_LEVEL_COUNTRY_GI_CODE =
      "FK_PoliticalGeo_Level_CountryGlCode";
  static final String COLUMN_VAR_CUSTOMER_DISPATCH = "varCustomer_Dispatch";
  static final String COLUMN_VAR_CUSTOMER_STOCK_TRANSFER =
      "varCustomer_StockTransfer";
  static final String COLUMN_VAR_CUSTOMER_SALES_RETURN =
      "varCustomer_SalesReturn";

  //Person_Mst column names
  static final String COLUMN_CHAR_USER_TYPE = "chrUserType";
  static final String COLUMN_VAR_USER_ID = "varUserID";
  static final String COLUMN_VAR_PASSWORD = "varPassword";
  static final String COLUMN_VAR_SAP_CODE = "varSAPCode";
  static final String COLUMN_VAR_FIRST_NAME = "varFirstName";
  static final String COLUMN_VAR_MIDDLE_NAME = "varMiddleName";
  static final String COLUMN_VAR_LAST_NAME = "varLastName";
  static final String COLUMN_VAR_ADDRESS = "varAddress";
  static final String COLUMN_CHAR_USER_LOCK = "chrUserLock";
  static final String COLUMN_VAR_PHONENO = "varPhoneNo";
  static final String COLUMN_VAR_MOBILE_NO = "varMobileNo";
  static final String COLUMN_VAR_FULL_NAME = "varFullName";
  static final String COLUMN_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE =
      "fk_Customer_Type_CountryGlCode";
  static final String COLUMN_FK_EMPLOYEE_TYPE_GI_CODE =
      "fk_Employee_TypeGlCode";
  static final String COLUMN_FK_EMPLOYEE_DESIGNATION_COUNTRY_GI_CODE =
      "fk_Employee_Designation_CountryGlCode";
  static final String COLUMN_FK_POLITICAL_GEO_GI_CODE =
      "fk_Political_GeoGlCode";
  static final String COLUMN_REF_PARENTGICODE = "refParentGlCode";
  static final String COLUMN_CHAR_GENDER = "chrGender";
  static final String COLUMN_DTDOB = "dtDOB";
  static final String COLUMN_VAR_PINCODE = "varPincode";
  static final String COLUMN_DT_VALID_FROM = "dtValidFrom";
  static final String COLUMN_DT_VALID_TO = "dtValidTo";
  static final String COLUMN_VAR_PRINTING_CODE = "varPrintingCode";
  static final String COLUMN_CHAR_DEVICE_LOGIN = "chrDeviceLogin";
  static final String COLUMN_DT_LAST_SYNC_DATE = "dtLastSyncDate";
  static final String COLUMN_CHR_AGREE = "chrAgree";
  static final String COLUMN_DT_AGREE = "dtAgree";
  static final String FK_LANGUAGE_GL_CODE = "fk_LanguageGlCode";

  //Menu_Mst column names
  static final String COLUMN_VAR_MENU_NAME = "varMenuName";
  static final String COLUMN_VAR_DISPLAY_NAME = "varDisplayName";
  static final String COLUMN_VAR_URL = "varURL";
  static final String COLUMN_INT_MENU_LEVEL = "intMenu_Level";
  static final String COLUMN_CHAR_ELEMENT_TYPE = "chrElement_Type";
  static final String COLUMN_INT_DISPLAY_ORDER = "intDisplay_Order";
  static final String COLUMN_VAR_ICON_PATH = "varIconPath";
  static final String COLUMN_CHAR_DISPLAY = "chrDisplay";
  static final String COLUMN_CHAR_HEAD_TYPE = "chrHeadType";
  static final String COLUMN_CHAR_MENU_TYPE = "chrMenuType";
  static final String COLUMN_CHAR_DB_TYPE = "chrDBType";
  static final String COLUMN_REF_PARENT_MENU_GI_CODE = "refParentMenuGLCode";
  static final String COLUMN_VAR_TRANSACTION_CODE = "varTransactionCode";
  static final String COLUMN_REF_SUB_MODULE_GI_CODE = "refSubModuleGlCode";
  static final String COLUMN_DT_UPDATE_DATE = "dtUpdateDate";
  static final String COLUMN_FK_ENTRY_PERSON_GI_CODE = "fk_EntryPersonGlCode";
  static final String COLUMN_FK_UPDATE_PERSON_GI_CODE = "fk_UpdatePersonGlCode";

  //PSKU_BATCH_STOCK
  static final String COLUMN_FK_CUSTOMER_GICODE = "fk_Customer_GlCode";
  static final String COLUMN_FK_UOM_GICODE = "fk_UOM_GlCode";
  static final String COLUMN_VAR_BATCHNO = "varBatchNo";
  static final String COLUMN_DT_EXPIRY_DATE = "dtExpiryDate";
  static final String COLUMN_INT_QTY = "decQty";

  //CUSTOMER_PARTNER_MST
  static final String COLUMN_VAR_TYPE = "varType";
  static final String COLUMN_FK_TO_CUSTOMERGICODE = "fk_To_CustomerGlCode";
  static final String COLUMN_INT_ROW_NO = "intRowNo";

  // static final String COLUMN_VAR_TRANSACTION_CODE = "varTransactionCode";
  static final String COLUMN_FK_RECEIVE_FROM_GL_CODE = "fk_ReceiveFromGlCode";
  static final String COLUMN_CHR_COMPLETED = "chrCompleted";
  static final String COLUMN_DT_COMPLETED_DATE = "dtCompletedDate";

  static final String COLUMN_CHR_CONFIRM = "chrConfirm";
  static final String COLUMN_DT_CONFIRM_DATE = "dtConfirmDate";
  static final String COLUMN_REF_CONFIRM_BY = "ref_ConfirmBy";

  static final String CHR_REMOVE = "chrRemove";
  static final String DT_REMOVE_DAMAGE = "dtRemoveDamage";
  static final String FK_REMOVEBY = "fk_RemoveBy";
  static final String FK_STICKER_DAMAGEGLCODE = "fk_Sticker_DamageGlCode";

  static final String CHR_PALLET = "chrPallet";

  //static final String CHR_BREAK = "chrBreak";
  static final String FK_PALLET_GL_CODE = "fk_PalletGlCode";

  static final String DELETE_TABLE_CPM_CUSTOMER_DISPATCH =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_DISPATCH;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_DISPATCH =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_DISPATCH +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_CUSTOMER_FROM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_FROM_TYPE_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_TO_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_TO_TYPE_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_SOLD_TO_PARTY_GI_CODE_ +
          " INTEGER," +
          COLUMN_FK_SOLD_TO_PARTY_TYPE_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_TRANS_TYPE +
          " TEXT," +
          COLUMN_CHAR_EXTERNAL_CUSTOMER +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_NAME +
          " TEXT," +
          COLUMN_VAR_EMAIL +
          " TEXT," +
          COLUMN_VAR_MOBILE +
          " TEXT," +
          COLUMN_VAR_PHONE_NO +
          " TEXT," +
          COLUMN_DT_DISPATCH_DATE +
          " TEXT," +
          COLUMN_VAR_SONO +
          " TEXT," +
          COLUMN_VAR_DONO +
          " TEXT," +
          "varAuthorizedBy TEXT," +
          COLUMN_CHAR_VALID_SAVE +
          " TEXT," +
          COLUMN_CHAR_EDIT_DO +
          " TEXT," +
          COLUMN_FK_EDIT_DO_BY +
          " INTEGER," +
          COLUMN_DT_EDIT_DO_DATE +
          " TEXT," +
          COLUMN_CHAR_CANCEL_DO +
          " TEXT," +
          COLUMN_FK_CANCEL_DO_BY +
          " INTEGER," +
          COLUMN_DT_CANCEL_DO_DATE +
          " TEXT," +
          COLUMN_FK_RETURN_STATUS_GL_CODE +
          " INTEGER," +
          COLUMN_VAR_REMARKS +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHR_COMPLETED +
          " TEXT," +
          COLUMN_DT_COMPLETED_DATE +
          " TEXT," +
          COLUMN_CHR_CONFIRM +
          " TEXT," +
          COLUMN_DT_CONFIRM_DATE +
          " TEXT," +
          COLUMN_REF_CONFIRM_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_VAR_ENTITY_NAME +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_LOGIN_DETAILS = "DELETE FROM LoginDetails";

  static final String CREATE_TABLE_LOGIN_DETAILS =
      "CREATE TABLE IF NOT EXISTS LoginDetails \n" +
          "(intGLCode INTEGER PRIMARY KEY,\n" +
          "dtLogIn TEXT,\n" +
          "dtLogOut TEXT,\n" +
          "varSystemIP TEXT,\n" +
          "varSystemName TEXT,\n" +
          "varversion TEXT,\n" +
          "fk_PersonGLCode INTEGER,\n" +
          "fk_SubModuleGlCode INTEGER,\n" +
          "chrLoginSuccess TEXT,\n" +
          "dtEntryUpdateDate TEXT,\n" +
          "chrSync  TEXT,\n" +
          "varSyncCode TEXT,\n" +
          "dtSyncDate TEXT,\n" +
          "intTimestamp INTEGER \n" +
          ")";

  static final String DELETE_TABLE_CPM_Customer_Sticker_Scrap =
      "DELETE FROM $TABLE_CPM_Customer_Sticker_Scrap";

  static final String CREATE_TABLE_CPM_Customer_Sticker_Scrap =
      "CREATE TABLE $TABLE_CPM_Customer_Sticker_Scrap" +
          "(" +
          "intGlCode INTEGER PRIMARY KEY," +
          "fk_CustomerGlCode INTEGER," +
          "fk_StickerGlCode INTEGER," +
          "chrPallet TEXT," +
          "fk_PalletGlCode INTEGER," +
          "varSticker TEXT," +
          "fk_ReceiveFromGlCode INTEGER," +
          "varRemarks TEXT," +
          "chrValid TEXT," +
          "chrActive TEXT," +
          "chrValidSave TEXT," +
          "chrSync TEXT," +
          "varSync_Code TEXT," +
          "dtSyncDate TEXT," +
          "ref_Entry_By INTEGER," +
          "dtEntryDate TEXT," +
          "dtModifiedDate TEXT," +
          "ref_Modified_By INTEGER," +
          "intRowNo INTEGER," +
          "varTransactionCode TEXT" +
          ")";

  static final String DELETE_TABLE_CPM_Customer_Sticker_Consume =
      "DELETE FROM $TABLE_CPM_Customer_Sticker_Consume";

  static final String CREATE_TABLE_CPM_Customer_Sticker_Consume =
      "CREATE TABLE $TABLE_CPM_Customer_Sticker_Consume" +
          "(" +
          "intGlCode INTEGER PRIMARY KEY," +
          "fk_CustomerGlCode INTEGER ," +
          "fk_StickerGlCode INTEGER," +
          "chrPallet TEXT," +
          "fk_PalletGlCode INTEGER," +
          "fk_ReceiveFromGlCode INTEGER," +
          "varRemarks TEXT," +
          "decConsumeQty REAL," +
          "varSticker TEXT," +
          "chrValid TEXT," +
          "chrActive TEXT," +
          "chrValidSave TEXT," +
          "chrSync TEXT," +
          "varSync_Code TEXT," +
          "dtSyncDate TEXT," +
          "ref_Entry_By INTEGER," +
          "dtEntryDate TEXT," +
          "dtModifiedDate TEXT," +
          "ref_Modified_By INTEGER," +
          "intRowNo INTEGER," +
          "varTransactionCode TEXT" +
          ")";

  static final String DELETE_TABLE_CPM_PALLET_MST =
      "DELETE FROM CPM_Pallet_Mst";

  static final String CREATE_TABLE_CPM_PALLET_MST =
      "CREATE TABLE IF NOT EXISTS CPM_Pallet_Mst \n" +
          "(intGlCode INTEGER PRIMARY KEY,\n" +
          "fk_CustomerGlCode INTEGER,\n" +
          "fk_CountryGlCode INTEGER,\n" +
          "varSystem_Name TEXT,\n" +
          "varPalletNo TEXT,\n" +
          "varPallet_QR_Code TEXT,\n" +
          "chrBreak TEXT,\n" +
          "ref_Break_By INTEGER,\n" +
          "dtBreakDate TEXT,\n" +
          "chrCompleted TEXT,\n" +
          "chrActive TEXT,\n" +
          "chrSync TEXT,\n" +
          "varSync_Code  TEXT,\n" +
          "dtSyncDate TEXT,\n" +
          "dtEntryDate TEXT,\n" +
          "ref_Entry_By INTEGER,\n" +
          "dtModifiedDate TEXT,\n" +
          "ref_Modified_By INTEGER \n" +
          ")";

  //Config Table
  static final String DELETE_TABLE_CONFIGURATION_DETAILS =
      "DELETE FROM Configuration_Details";

  static final String CREATE_TABLE_CONFIGURATION_DETAILS =
      "CREATE TABLE IF NOT EXISTS Configuration_Details \n" +
          "(intGlCode INTEGER PRIMARY KEY,\n" +
          "fk_ConfigurationGlCode INTEGER,\n" +
          "chrConfigType TEXT,\n" +
          "chrUserType TEXT,\n" +
          "fk_CustTypeRegionalCode INTEGER,\n" +
          "fk_EmpDesignGlCode INTEGER,\n" +
          "fk_CountryGlCode INTEGER,\n" +
          "fk_PersonGlCode INTEGER,\n" +
          "varPurpose TEXT,\n" +
          "varCode TEXT,\n" +
          "varValue1 TEXT,\n" +
          "varValue2 TEXT,\n" +
          "varValue3  TEXT,\n" +
          "varValue4 TEXT,\n" +
          "chrActive TEXT,\n" +
          "chrSync TEXT,\n" +
          "varSyncCode TEXT,\n" +
          "dtSyncDate TEXT \n" +
          ")";

  //Config Table
  static final String DELETE_TABLE_INVOICE_DETAILS =
      "DELETE FROM InvoiceDetails";

  static final String CREATE_TABLE_INVOICE_DETAILS =
      "CREATE TABLE InvoiceDetails(" +
          " intGlCode INTEGER PRIMARY KEY," +
          " fk_FromCustomerGlCode INTEGER," +
          " fk_Sold_To_Party_GlCode INTEGER," +
          " fk_ToCustomerGlCode INTEGER," +
          " varInvoiceNo TEXT," +
          " fk_Product_SKUGlCode INTEGER," +
          " varBatch TEXT," +
          " intTotalQty INTEGER," +
          " intTotalScannedQty INTEGER" +
          " )";

  static final String DELETE_TABLE_LOGIN_FORM_DETAILS =
      "DELETE FROM LoginFormDetails";

  static final String CREATE_TABLE_LOGIN_FORM_DETAILS =
      "CREATE TABLE IF NOT EXISTS LoginFormDetails (" +
          " intGlCode INTEGER PRIMARY KEY," +
          " fk_MenuGlCode INTEGER," +
          " dtPageIn TEXT," +
          " dtPageOut TEXT," +
          " fk_PersonGlCode INTEGER," +
          " fk_SubModuleGlCode INTEGER," +
          " chrLogInSuccess TEXT," +
          " varSystemIP TEXT," +
          " varSystemName TEXT," +
          " varVersion TEXT," +
          " fk_LDGLCode INTEGER," +
          " varLDGLSyncCode TEXT," +
          " varFormName TEXT," +
          " chrFromSwtichUser TEXT," +
          " chrSync TEXT," +
          " varSyncCode TEXT," +
          " dtSyncDate TEXT," +
          " dtEntryDate TEXT" +
          " );";

  static final String DELETE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS =
      "DELETE FROM LoginFailAttempt_Details";

  static final String CREATE_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS =
      "CREATE TABLE IF NOT EXISTS LoginFailAttempt_Details (" +
          " intGlCode INTEGER PRIMARY KEY," +
          " varSystemName TEXT," +
          " varSystemIP TEXT," +
          " varVersion TEXT," +
          " fk_SubModuleGlCode INTEGER," +
          " varSubModuleName TEXT," +
          " varEnteredUserName TEXT," +
          " varEnteredPassword TEXT," +
          " varReason TEXT," +
          " dtEntryDateTime TEXT," +
          " chrSync TEXT," +
          " varSyncCode TEXT," +
          " dtSyncDate TEXT" +
          " );";

  static final String DELETE_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_INT_ROW_NO +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_DISPATCH_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          CHR_PALLET +
          " TEXT," +
          FK_PALLET_GL_CODE +
          " INTEGER," +
          COLUMN_FK_STRICKER_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_STICKER +
          " TEXT," +
          COLUMN_CHAR_DISPATCH +
          " TEXT," +
          COLUMN_DT_DISPATCH_DATE +
          " TEXT," +
          COLUMN_FK_DISPATCH_BY +
          " INTEGER," +
          COLUMN_CHAR_RECEIVED +
          " TEXT," +
          COLUMN_DT_RECEIVED_DATE +
          " TEXT," +
          COLUMN_FK_RECEIVED_BY +
          " INTEGER," +
          COLUMN_CHAR_REJECTED +
          " TEXT," +
          COLUMN_DT_REJECTED_DATE +
          " TEXT," +
          COLUMN_FK_REJECTED_BY +
          " INTEGER," +
          COLUMN_CHAR_VALID +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_RECEIVE =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_RECEIVE;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_RECEIVE =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_RECEIVE +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_CUSTOMER_FROM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_FROM_TYPE_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_TO_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_TO_TYPE_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_DISPATCH_GL_CODE +
          " INTEGER," +
          COLUMN_DT_DATE +
          " TEXT," +
          COLUMN_VAR_TRANS_TYPE +
          " TEXT," +
          COLUMN_VAR_REMARKS +
          " TEXT," +
          "varSAPDocNo TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_VALID_SAVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_INT_ROW_NO +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_RECEIVE_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          CHR_PALLET +
          " TEXT," +
          FK_PALLET_GL_CODE +
          " INTEGER," +
          COLUMN_FK_STRICKER_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_STICKER +
          " TEXT," +
          COLUMN_CHAR_VALID +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_STRICKER =
      "DELETE FROM " + TABLE_CPM_STRICKER;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_STRICKER = "CREATE TABLE " +
      TABLE_CPM_STRICKER +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_CHAR_SYNC +
      " TEXT," +
      COLUMN_CHAR_SYNC_DATE +
      " TEXT," +
      COLUMN_DT_SYNC_DATE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_CPM_STRICKER_Details =
      "DELETE FROM " + TABLE_CPM_STRICKER_Details;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_STRICKER_Details =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_STRICKER_Details +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_STICKER_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_REF_ID +
          " TEXT," +
          COLUMN_VAR_SYSTEM_NAME +
          " TEXT," +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_FK_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PBG_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRD_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE_ +
          " INTEGER," +
          COLUMN_VAR_STICKER_TYPE +
          " TEXT," +
          COLUMN_VAR_DI_NO +
          " TEXT," +
          COLUMN_VAR_BATCH_NO +
          " TEXT," +
          COLUMN_DT_MFG_DATE +
          " TEXT," +
          COLUMN_DT_EXPIRE_DATE +
          " TEXT," +
          COLUMN_INT_PRINT_QTY +
          " INTEGER," +
          COLUMN_VAR_STICKER_FROM_RANGE +
          " TEXT," +
          COLUMN_VAR_STICKER_TO_RANGE +
          " TEXT," +
          COLUMN_VAR_BTC_NO_IN +
          " TEXT," +
          COLUMN_VAR_BTC_NO_OUT +
          " TEXT," +
          COLUMN_VAR_QR_CODE_IN +
          " TEXT," +
          COLUMN_VAR_QR_CODE_OUT +
          " TEXT," +
          COLUMN_VAR_STICKER_NO +
          " TEXT," +
          CHR_PALLET +
          " TEXT," +
          FK_PALLET_GL_CODE +
          " INTEGER," +
          COLUMN_FK_STATUS_GI_CODE +
          " INTEGER," +
          COLUMN_FK_STICKER_GENERATED_BY +
          " INTEGER," +
          COLUMN_DT_STICKER_GENERATED_DATE +
          " TEXT," +
          COLUMN_CHAR_EXTERNAL_CUSTOMER +
          " TEXT," +
          COLUMN_FK_LAST_DISPATCH_TO +
          " INTEGER," +
          COLUMN_FK_LAST_DISPATCH_BY +
          " INTEGER," +
          COLUMN_FK_LAST_PREVIOUS_DISPATCH_BY +
          " INTEGER," +
          COLUMN_DT_LAST_DISPATCH_DATE +
          " TEXT," +
          COLUMN_FK_LAST_RECEIVED_BY +
          " INTEGER," +
          COLUMN_DT_LAST_RECEIVED_DATE +
          " TEXT," +
          COLUMN_FK_LAST_REJECTED_BY +
          " INTEGER," +
          COLUMN_DT_LAST_REJECTED_DATE +
          " TEXT," +
          COLUMN_CHAR_DAMAGE +
          " TEXT," +
          COLUMN_DT_DAMAGE_DATE_TIME +
          " TEXT," +
          COLUMN_FK_DAMAGE_BY +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_VAR_LAST_STAGE +
          " TEXT," +
          "chrConsume TEXT," +
          "dtConsumeDateTime TEXT," +
          "fk_ConsumeBy INTEGER," +
          "chrScrap TEXT," +
          "dtScrapDateTime TEXT," +
          "fk_ScrapBy INTEGER" +
          ")";

  static final String DELETE_TABLE_LANGUAGE_MASTER =
      "DELETE FROM Language_Master";

  static final String CREATE_TABLE_LANGUAGE_MASTER =
      "CREATE TABLE Language_Master" +
          "(" +
          "intGlCode INTEGER PRIMARY KEY," +
          "varLanguageCode TEXT," +
          "varLanguageName TEXT," +
          "varDescription TEXT," +
          "chrActive TEXT," +
          "dtEntryDate TEXT," +
          "ref_Entry_By INTEGER," +
          "dtModifiedDate TEXT," +
          "ref_Modified_By INTEGER," +
          "chrSync TEXT," +
          "varSync_Code TEXT," +
          "dtSyncDate TEXT" +
          " )";

  static final String DELETE_TABLE_CPM_CUSTOMER_RECEIVE_DAMAGE =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_RECEIVE_DAMAGE;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_RECEIVE_DAMAGE =
      "CREATE TABLE " +
          TABLE_CPM_CUSTOMER_RECEIVE_DAMAGE +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_SYSTEM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PERSON_GI_CODE +
          " INTEGER," +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_TYPE +
          " TEXT," +
          COLUMN_DT_DATE +
          " TEXT," +
          COLUMN_INT_QUANTITY +
          " INTEGER," +
          COLUMN_VAR_REMARKS +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_OPENING_STOCK =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_OPENING_STOCK;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_OPENING_STOCK =
      "CREATE TABLE " +
          TABLE_CPM_CUSTOMER_OPENING_STOCK +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_SYSTEM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PERSON_GI_CODE +
          " INTEGER," +
          COLUMN_DT_DATE_TIME +
          " TEXT," +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_BATCH_NO +
          " TEXT," +
          COLUMN_DEC_QUANTITY +
          " REAL," +
          COLUMN_DEC_AMOUNT +
          " REAL," +
          COLUMN_FK_UOM_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_PENDING_ORDER =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_PENDING_ORDER;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_PENDING_ORDER =
      "CREATE TABLE " +
          TABLE_CPM_CUSTOMER_PENDING_ORDER +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_SYSTEM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PERSON_GI_CODE +
          " INTEGER," +
          COLUMN_DT_DATE_TIME +
          " TEXT," +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          COLUMN_DEC_QUANTITY +
          " REAL," +
          COLUMN_DEC_AMOUNT +
          " REAL," +
          COLUMN_FK_UOM_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_PENDING_DISPATCH =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_PENDING_DISPATCH;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_CUSTOMER_PENDING_DISPATCH =
      "CREATE TABLE " +
          TABLE_CPM_CUSTOMER_PENDING_DISPATCH +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_SYSTEM_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PERSON_GI_CODE +
          " INTEGER," +
          COLUMN_DT_DATE_TIME +
          " TEXT," +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          COLUMN_DEC_QUANTITY +
          " REAL," +
          COLUMN_DEC_AMOUNT +
          " REAL," +
          COLUMN_FK_UOM_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CPM_DI_DETAILS =
      "DELETE FROM " + TABLE_CPM_DI_DETAILS;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CPM_DI_DETAILS = "CREATE TABLE " +
      TABLE_CPM_DI_DETAILS +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_FK_SYSTEM_GI_CODE +
      " INTEGER," +
      COLUMN_FK_PERSON_GI_CODE +
      " INTEGER," +
      COLUMN_FK_FROM_CUSTOMER_GI_CODE +
      " INTEGER," +
      COLUMN_FK_SOLD_TO_PARTY_GI_CODE +
      " INTEGER," +
      COLUMN_FK_SHIP_TO_PARTY_GI_CODE +
      " INTEGER," +
      COLUMN_VAR_DI_NUMBER +
      " TEXT," +
      COLUMN_DT_DI_DATE +
      " TEXT," +
      COLUMN_VAR_BATCH_NO +
      " TEXT," +
      COLUMN_FK_PRODUCTSKU_GI_CODE +
      " INTEGER," +
      COLUMN_DEC_QTY +
      " REAL," +
      COLUMN_FK_UOM_GI_CODE +
      " INTEGER," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_CHAR_SYNC +
      " TEXT," +
      COLUMN_CHAR_SYNC_DATE +
      " TEXT," +
      COLUMN_DT_SYNC_DATE +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_STATUS_MST =
      "DELETE FROM " + TABLE_STATUS_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_STATUS_MST = "CREATE TABLE IF NOT EXISTS " +
      TABLE_STATUS_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_INT_CODE +
      " INTEGER," +
      COLUMN_VAR_STATUS +
      " TEXT," +
      COLUMN_VAR_PURPOSE +
      " TEXT" +
      ")";

  static final String DELETE_TABLE_PRODUCT_MAIN_GROUP_MST =
      "DELETE FROM " + TABLE_PRODUCT_MAIN_GROUP_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PRODUCT_MAIN_GROUP_MST = "CREATE TABLE " +
      TABLE_PRODUCT_MAIN_GROUP_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_VAR_SKU +
      " TEXT," +
      COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE +
      " TEXT," +
      COLUMN_VAR_RPDOCUT_MAIN_GROUP_NAME +
      " TEXT," +
      COLUMN_VAR_DESCRIPTION +
      " TEXT," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_PRODUCT_BUSINESS_GROUP_MST =
      "DELETE FROM " + TABLE_PRODUCT_BUSINESS_GROUP_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PRODUCT_BUSINESS_GROUP_MST =
      "CREATE TABLE " +
          TABLE_PRODUCT_BUSINESS_GROUP_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE_ +
          " INTEGER," +
          COLUMN_VAR_PBG_CODE_ +
          " TEXT," +
          COLUMN_VAR_PBG_NAME_ +
          " TEXT," +
          COLUMN_VAR_DESCRIPTION +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_PRD_MST = "DELETE FROM " + TABLE_PRD_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PRD_MST = "CREATE TABLE " +
      TABLE_PRD_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_VAR_PRODUCT_BUSINESS_GI_CODE +
      " TEXT," +
      COLUMN_VAR_PBG_CODE +
      " TEXT," +
      COLUMN_VAR_PBG_NAME +
      " TEXT," +
      COLUMN_VAR_DESCRIPTION +
      " TEXT," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_PRODUCT_SKU_MST =
      "DELETE FROM " + TABLE_PRODUCT_SKU_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PRODUCT_SKU_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_PRODUCT_SKU_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE_ +
          " INTEGER," +
          COLUMN_VAR_SBU +
          " TEXT," +
          COLUMN_VAR_PRODUCT_MAIN_GROUP_CODE +
          " TEXT," +
          COLUMN_VAR_RPDOCUT_MAIN_GROUP_NAME +
          " TEXT," +
          COLUMN_VAR_PMG_DESCRIPTION +
          " TEXT," +
          COLUMN_VAR_PRODUCT_BUSINESS_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_PBG_CODE_ +
          " TEXT," +
          COLUMN_VAR_PBG_NAME_ +
          " TEXT," +
          COLUMN_VAR_PBG_DESCRIPTION +
          " TEXT," +
          COLUMN_FK_PRD_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_PRD_CODE +
          " TEXT," +
          COLUMN_VAR_PRD_NAME +
          " TEXT," +
          COLUMN_VAR_PRD_DESCRIPTION +
          " TEXT," +
          COLUMN_VAR_PRODUCT_SKU_CODE +
          " TEXT," +
          COLUMN_VAR_PRODUCT_SKU_NAME +
          " TEXT," +
          COLUMN_VAR_PRODUCT_SKU_SORT_NAME +
          " TEXT," +
          COLUMN_VAR_PRODUCT_TECHNICAL_NAME +
          " TEXT," +
          COLUMN_FK_UOMGICODE +
          " INTEGER," +
          COLUMN_VAR_PRODUCT_SKU_SIZE +
          " TEXT," +
          COLUMN_INT_NO_OF_UNITS +
          " INTEGER," +
          COLUMN_VAR_GTIN_CHECK_DIGIT +
          " TEXT," +
          COLUMN_VAR_GTIN +
          " TEXT," +
          COLUMN_CONVERSION_FACTOR +
          " REAL," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_PRODUCT_SKU_CONVERSION =
      "DELETE FROM " + TABLE_PRODUCT_SKU_CONVERSION;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PRODUCT_SKU_CONVERSION = "CREATE TABLE " +
      TABLE_PRODUCT_SKU_CONVERSION +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_FK_PRODUCT_SKU_GI_CODE_ +
      " INTEGER," +
      COLUMN_PACKING_CONVERSION_FACTOR +
      " REAL," +
      COLUMN_BOX_CONVERSION_FACTOR +
      " REAL," +
      COLUMN_CONVERSION_FACTOR +
      " REAL," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_COUNTRY_MST =
      "DELETE FROM " + TABLE_COUNTRY_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_COUNTRY_MST = "CREATE TABLE IF NOT EXISTS " +
      TABLE_COUNTRY_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_VAR_CODE +
      " TEXT," +
      COLUMN_VAR_NAME +
      " TEXT," +
      COLUMN_VAR_TIME_ZONE +
      " TEXT," +
      COLUMN_INT_UTC_MINUTE_DIFF +
      " INTEGER," +
      COLUMN_VAR_LATITUDE +
      " TEXT," +
      COLUMN_VAR_LONGITUDE +
      " TEXT," +
      COLUMN_INT_FINANCIAL_MONTH +
      " INTEGER," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST =
      "DELETE FROM " + TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_POLITICAL_GEOGRAPHY_LEVEL_REGIONAL_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_LEVEL +
          " TEXT," +
          COLUMN_VAR_GEO_LEVEL_NAME +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST =
      "DELETE FROM " + TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_POLITICAL_GEO_LEVEL_REGIONAL_GI_CODE +
          " TEXT," +
          COLUMN_FK_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_LEVEL +
          " TEXT," +
          COLUMN_VAR_GEO_LEVEL_NAME +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_POLITICAL_GEOGRAPHY_DETAILS =
      "DELETE FROM " + TABLE_POLITICAL_GEOGRAPHY_DETAILS;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_POLITICAL_GEOGRAPHY_DETAILS =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_POLITICAL_GEOGRAPHY_DETAILS +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_POLITICAL_GEO_LEVEL_COUNTRY_GI_CODE_ +
          " INTEGER," +
          COLUMN_REF_PARENT_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_POLITICAL_GEOGRAPHY_CODE +
          " TEXT," +
          COLUMN_VAR_POLITICAL_GEOGRAPHY_NAME +
          " TEXT," +
          COLUMN_FK_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_SYSTEM_CONFIGURATION_MST =
      "DELETE FROM " + TABLE_SYSTEM_CONFIGURATION_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_SYSTEM_CONFIGURATION_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_SYSTEM_CONFIGURATION_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_SUB_MODULE_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_VERSION +
          " TEXT," +
          COLUMN_VAR_FILE_PATH +
          " TEXT," +
          COLUMN_DT_ENTRY_UPDATE_DATE +
          " TEXT," +
          COLUMN_VAR_PROJECT_NAME +
          " TEXT," +
          COLUMN_VAR_ERROR_CAPTION +
          " TEXT," +
          COLUMN_VAR_XML_SETTINGS +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_EMPLOYEE_TYPE_MST =
      "DELETE FROM " + TABLE_EMPLOYEE_TYPE_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_EMPLOYEE_TYPE_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_EMPLOYEE_TYPE_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_EMPLOYEE_TYPE_CODE +
          " TEXT," +
          COLUMN_VAR_EMPLOYEE_TYPE_NAME +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CUSTOMER_TYPE_REGIONAL_MST =
      "DELETE FROM " + TABLE_CUSTOMER_TYPE_REGIONAL_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CUSTOMER_TYPE_REGIONAL_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CUSTOMER_TYPE_REGIONAL_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_CUSTOMER_LEVEL +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_TYPE_CODE +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_TYPE_NAME +
          " TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER" +
          ")";

  static final String DELETE_TABLE_CUSTOMER_TYPE_COUNTRY_MST =
      "DELETE FROM " + TABLE_CUSTOMER_TYPE_COUNTRY_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CUSTOMER_TYPE_COUNTRY_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CUSTOMER_TYPE_COUNTRY_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_CUSTOMER_TYPE_REGIONAL_GI_CODE +
          " INTEGER," +
          COLUMN_FK_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_FK_POLITICAL_GEO_LEVEL_COUNTRY_GI_CODE +
          " INTEGER," +
          COLUMN_VAR_CUSTOMER_LEVEL +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_TYPE_CODE +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_TYPE_NAME +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_DISPATCH +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_STOCK_TRANSFER +
          " TEXT," +
          COLUMN_VAR_CUSTOMER_SALES_RETURN +
          " TEXT," +
          "varCustomer_FOC TEXT," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_PERSON_MST =
      "DELETE FROM " + TABLE_PERSON_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PERSON_MST = "CREATE TABLE IF NOT EXISTS " +
      TABLE_PERSON_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_CHAR_USER_TYPE +
      " TEXT," +
      COLUMN_FK_COUNTRY_GI_CODE +
      " INTEGER," +
      COLUMN_VAR_USER_ID +
      " TEXT," +
      COLUMN_VAR_PASSWORD +
      " TEXT," +
      COLUMN_VAR_SAP_CODE +
      " TEXT," +
      COLUMN_VAR_FIRST_NAME +
      " TEXT," +
      COLUMN_VAR_MIDDLE_NAME +
      " TEXT," +
      COLUMN_VAR_LAST_NAME +
      " TEXT," +
      COLUMN_VAR_ADDRESS +
      " TEXT," +
      COLUMN_VAR_EMAIL +
      " TEXT," +
      COLUMN_CHAR_USER_LOCK +
      " TEXT," +
      COLUMN_VAR_PHONENO +
      " TEXT," +
      COLUMN_VAR_MOBILE_NO +
      " TEXT," +
      COLUMN_VAR_FULL_NAME +
      " TEXT," +
      COLUMN_VAR_ORGANIZATION_NAME +
      " TEXT," +
      COLUMN_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE +
      " INTEGER," +
      COLUMN_FK_EMPLOYEE_TYPE_GI_CODE +
      " INTEGER," +
      COLUMN_FK_EMPLOYEE_DESIGNATION_COUNTRY_GI_CODE +
      " INTEGER," +
      COLUMN_FK_POLITICAL_GEO_GI_CODE +
      " INTEGER," +
      COLUMN_REF_PARENTGICODE +
      " INTEGER," +
      COLUMN_CHAR_GENDER +
      " TEXT," +
      COLUMN_DTDOB +
      " TEXT," +
      COLUMN_VAR_PINCODE +
      " TEXT," +
      COLUMN_VAR_LATITUDE +
      " TEXT," +
      COLUMN_VAR_LONGITUDE +
      " TEXT," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER," +
      COLUMN_DT_VALID_FROM +
      " TEXT," +
      COLUMN_DT_VALID_TO +
      " TEXT," +
      COLUMN_VAR_PRINTING_CODE +
      " TEXT," +
      COLUMN_CHAR_DEVICE_LOGIN +
      " TEXT," +
      COLUMN_DT_LAST_SYNC_DATE +
      " TEXT," +
      COLUMN_CHAR_SYNC +
      " TEXT," +
      COLUMN_CHAR_SYNC_DATE +
      " TEXT," +
      COLUMN_DT_SYNC_DATE +
      " TEXT," +
      COLUMN_CHR_AGREE +
      " TEXT," +
      COLUMN_DT_AGREE +
      " TEXT," +
      FK_LANGUAGE_GL_CODE +
      " INTEGER" +
      ")";

  //UOM_Mst column names
  static final String COLUMN_VAR_UOM_CODE = "varUOM_Code";
  static final String COLUMN_VAR_UOM_NAME = "varUOM_Name";
  static final String COLUMN_VAR_UOM_DESCRIPTION = "varUOM_Description";

  static final String DELETE_TABLE_UOM_MST = "DELETE FROM " + TABLE_UOM_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_UOM_MST = "CREATE TABLE IF NOT EXISTS " +
      TABLE_UOM_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_VAR_UOM_CODE +
      " TEXT," +
      COLUMN_VAR_UOM_NAME +
      " TEXT," +
      COLUMN_VAR_UOM_DESCRIPTION +
      " TEXT," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_REF_ENTRY_BY +
      " INTEGER," +
      COLUMN_DT_MODIFIED_DATE +
      " TEXT," +
      COLUMN_REF_MODIFIED_BY +
      " INTEGER" +
      ")";

  static final String DELETE_TABLE_MENU_MST = "DELETE FROM " + TABLE_MENU_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_MENU_MST = "CREATE TABLE IF NOT EXISTS " +
      TABLE_MENU_MST +
      "(" +
      COLUMN_INT_GI_CODE +
      " INTEGER PRIMARY KEY," +
      COLUMN_VAR_MENU_NAME +
      " TEXT," +
      COLUMN_VAR_DISPLAY_NAME +
      " TEXT," +
      COLUMN_VAR_URL +
      " TEXT," +
      COLUMN_INT_MENU_LEVEL +
      " INTEGER," +
      COLUMN_CHAR_ELEMENT_TYPE +
      " TEXT," +
      COLUMN_INT_DISPLAY_ORDER +
      " INTEGER," +
      COLUMN_VAR_ICON_PATH +
      " TEXT," +
      COLUMN_CHAR_DISPLAY +
      " TEXT," +
      COLUMN_CHAR_HEAD_TYPE +
      " TEXT," +
      COLUMN_CHAR_MENU_TYPE +
      " TEXT," +
      COLUMN_CHAR_DB_TYPE +
      " TEXT," +
      COLUMN_REF_PARENT_MENU_GI_CODE +
      " INTEGER," +
      COLUMN_VAR_TRANSACTION_CODE +
      " TEXT," +
      COLUMN_REF_SUB_MODULE_GI_CODE +
      " INTEGER," +
      COLUMN_DT_ENTRY_DATE +
      " TEXT," +
      COLUMN_DT_UPDATE_DATE +
      " TEXT," +
      COLUMN_FK_ENTRY_PERSON_GI_CODE +
      " INTEGER," +
      COLUMN_FK_UPDATE_PERSON_GI_CODE +
      " INTEGER," +
      COLUMN_CHAR_ACTIVE +
      " TEXT," +
      COLUMN_CHAR_SYNC +
      " TEXT," +
      COLUMN_CHAR_SYNC_DATE +
      " TEXT," +
      COLUMN_DT_SYNC_DATE +
      " TEXT" +
      ")";

  static final String DELETE_TABLE_PSKU_BATCH_STOCK =
      "DELETE FROM " + TABLE_PSKU_BATCH_STOCK;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_PSKU_BATCH_STOCK =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_PSKU_BATCH_STOCK +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_FK_CUSTOMER_GICODE +
          " INTEGER," +
          COLUMN_FK_PRODUCT_SKU_GI_CODE +
          " INTEGER," +
          COLUMN_FK_UOM_GICODE +
          " INTEGER," +
          COLUMN_VAR_BATCHNO +
          " TEXT," +
          COLUMN_DT_EXPIRY_DATE +
          " TEXT," +
          COLUMN_INT_QTY +
          " REAL," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_CUSTOMER_PARTNER_MST =
      "DELETE FROM " + TABLE_CUSTOMER_PARTNER_MST;

  // Table Create Statements
  // Todo table create statement
  static final String CREATE_TABLE_CUSTOMER_PARTNER_MST =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CUSTOMER_PARTNER_MST +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER PRIMARY KEY," +
          COLUMN_VAR_TYPE +
          " TEXT," +
          COLUMN_FK_FROM_CUSTOMER_GI_CODE +
          " INTEGER," +
          COLUMN_FK_TO_CUSTOMERGICODE +
          " INTEGER," +
          COLUMN_CHAR_ACTIVE +
          " TEXT," +
          COLUMN_DT_ENTRY_DATE +
          " TEXT," +
          COLUMN_REF_ENTRY_BY +
          " INTEGER," +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT," +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER," +
          COLUMN_CHAR_SYNC +
          " TEXT," +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT," +
          COLUMN_DT_SYNC_DATE +
          " TEXT" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_STICKER_DAMAGE;

  static final String CREATE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_STICKER_DAMAGE +
          "\n" +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
          COLUMN_INT_ROW_NO +
          " INTEGER NULL,\n" +
          COLUMN_VAR_TRANSACTION_CODE +
          " TEXT NULL,\n" +
          COLUMN_FK_RECEIVE_FROM_GL_CODE +
          " INTEGER NULL,\n" +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER NULL,\n" +
          COLUMN_FK_STICKER_GI_CODE +
          " INTEGER  NULL,\n" +
          COLUMN_VAR_STICKER +
          " TEXT NULL,\n" +
          COLUMN_CHAR_VALID +
          " TEXT NULL,\n" +
          COLUMN_CHAR_ACTIVE +
          " TEXT NULL,\n" +
          COLUMN_CHAR_VALID_SAVE +
          " TEXT NULL,\n" +
          COLUMN_CHAR_SYNC +
          " TEXT NULL,\n" +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT NULL,\n" +
          COLUMN_DT_SYNC_DATE +
          " TEXT NULL,\n" +
          COLUMN_REF_ENTRY_BY +
          " INTEGER NULL,\n" +
          COLUMN_DT_ENTRY_DATE +
          " TEXT NULL,\n" +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT NULL,\n" +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER NULL,\n" +
          CHR_REMOVE +
          " TEXT NULL,\n" +
          DT_REMOVE_DAMAGE +
          " TEXT NULL,\n" +
          FK_REMOVEBY +
          " INTEGER NULL\n" +
          ")";

  static final String DELETE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE =
      "DELETE FROM " + TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE;

  static final String CREATE_TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE =
      "CREATE TABLE IF NOT EXISTS " +
          TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE +
          "\n" +
          "(" +
          COLUMN_INT_GI_CODE +
          " INTEGER  NOT NULL PRIMARY KEY AUTOINCREMENT,\n" +
          COLUMN_INT_ROW_NO +
          " INTEGER NULL,\n" +
          COLUMN_VAR_TRANSACTION_CODE +
          " TEXT NULL,\n" +
          FK_STICKER_DAMAGEGLCODE +
          " INTEGER NULL,\n" +
          COLUMN_FK_CUSTOMER_GI_CODE +
          " INTEGER NULL,\n" +
          COLUMN_FK_STICKER_GI_CODE +
          " INTEGER  NULL,\n" +
          COLUMN_VAR_STICKER +
          " TEXT NULL,\n" +
          COLUMN_CHAR_VALID +
          " TEXT NULL,\n" +
          COLUMN_CHAR_ACTIVE +
          " TEXT NULL,\n" +
          COLUMN_CHAR_VALID_SAVE +
          " TEXT NULL,\n" +
          COLUMN_CHAR_SYNC +
          " TEXT NULL,\n" +
          COLUMN_CHAR_SYNC_DATE +
          " TEXT NULL,\n" +
          COLUMN_DT_SYNC_DATE +
          " TEXT NULL,\n" +
          COLUMN_REF_ENTRY_BY +
          " INTEGER NULL,\n" +
          COLUMN_DT_ENTRY_DATE +
          " TEXT NULL,\n" +
          COLUMN_DT_MODIFIED_DATE +
          " TEXT NULL,\n" +
          COLUMN_REF_MODIFIED_BY +
          " INTEGER NULL\n" +
          ")";
}
