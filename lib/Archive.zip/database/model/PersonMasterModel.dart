class PersonMasterModel{
  int intGlCode;
  String chrUserType;
  String fk_CountryGlCode;
  String varUserID;
  String varPassword;
  String varSAPCode;
  String varFirstName;
  String varMiddleName;
  String varLastName;
  String varAddress;
  String varEmail;
  String chrUserLock;
  String varPhoneNo;
  String varMobileNo;
  String varFullName;
  String fk_Customer_Type_CountryGlCode;
  String fk_Employee_TypeGlCode;
  String fk_Employee_Designation_CountryGlCode;
  String fk_Political_GeoGlCode;
  int refParentGlCode;
  String chrGender;
  String dtDOB;
  String varPincode;
  String varlatitude;
  String varlongitude;
  String varAgreementUrl;
  String chrAgree;
  String chrActive;
  String dtEntryString;
  String ref_Entry_By;
  String dtModifiedString;
  String ref_Modified_By;
  String dtValidFrom;
  String dtValidTo;
  String varPrintingCode;
  String varOrganisationName;
  String dtLastSyncDate;
  String varAPIToken;
  String varServerName;
  String strDateFormat_MSSQL;
  String strTimeFormat_MSSQL;
  String strDateTimeFormat_MSSQL;
  String varSync_Code;
  String dtSyncDate;
  String dtAgree;

  PersonMasterModel({this.intGlCode, this.chrUserType, this.fk_CountryGlCode,
      this.varUserID, this.varPassword, this.varSAPCode, this.varFirstName,
      this.varMiddleName, this.varLastName, this.varAddress, this.varEmail,
      this.chrUserLock, this.varPhoneNo, this.varMobileNo, this.varFullName,
      this.fk_Customer_Type_CountryGlCode, this.fk_Employee_TypeGlCode,
      this.fk_Employee_Designation_CountryGlCode, this.fk_Political_GeoGlCode,
      this.refParentGlCode, this.chrGender, this.dtDOB, this.varPincode,
      this.varlatitude, this.varlongitude, this.varAgreementUrl, this.chrAgree,
      this.chrActive, this.dtEntryString, this.ref_Entry_By,
      this.dtModifiedString, this.ref_Modified_By, this.dtValidFrom,
      this.dtValidTo, this.varPrintingCode, this.varOrganisationName,
      this.dtLastSyncDate, this.varAPIToken, this.varServerName,
      this.strDateFormat_MSSQL, this.strTimeFormat_MSSQL,
      this.strDateTimeFormat_MSSQL, this.varSync_Code, this.dtSyncDate,
      this.dtAgree});


}