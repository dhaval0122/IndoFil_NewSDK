import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/MyStockInfoModel.dart';
import 'package:flutter_basf_hk_app/notifications/NotificationScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';

class MyStockInfoScreen extends StatefulWidget {
  @override
  MyStockInfoScreenState createState() => MyStockInfoScreenState();
}

class MyStockInfoScreenState extends State<MyStockInfoScreen>
    implements PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Size screenSize;
  String userName, subTitle, doNo, lastLoginDate;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  List<MyStockInfoModel> listDisplay = List();
  List<MyStockInfoPopupModel> listDialogDisplay = List();
  bool loadingFlag = false, isNotification = false, isSync = false;
  final TextEditingController _search_controller = TextEditingController();
  String displayDateFormat = '';
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getString(PREF_LAST_SYNC_DATE).then((String lSyncDate) {
      if (mounted) {
        setState(() {
          print('======lSyncDate======$lSyncDate');
          if (lSyncDate.isEmpty) {
            lastLoginDate = '';
          } else {
            lastLoginDate =
                LocaleUtils.getString(mContext, 'LastSync') + ' : $lSyncDate';
          }
        });
      }
    });

    sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_DEFAULT_FORMAT;
          }
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData('');

    insertLogDetails();
  }


  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_MSI');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getData(String values) {
    if (mounted) {
      setState(() {
        loadingFlag = true;
      });
    }
    sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int initCode) {
      databaseHelper
          .getStockInfoList(initCode, values)
          .then((var custTypeList) {
        print('------custTypeList--------${custTypeList.length}');
        listDisplay.clear();
        if (mounted) {
          setState(() {
            loadingFlag = false;
            listDisplay.addAll(custTypeList);
          });
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(
                      userName, subTitle, 'assets/stock_info_icon.png', 0),
                  Container(
                      height: 30,
                      color: const Color(bgColor),
                      child: Center(
                        child: Text(lastLoginDate != null ? lastLoginDate : '',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'helvetica',
                                color: Colors.black)),
                      )),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 40,
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(7)),
                          color: Colors.white),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: _search_controller,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: TextStyle(color: Colors.grey[700]),
                                  hintText: LocaleUtils.getString(
                                      mContext, 'SearchArticleCodeOrName'),
                                  counterText: '',
                                ),
                                onChanged: (value) {
                                  filterSearchResults(
                                      value.trim().toLowerCase());
                                },
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {
                                  // _search_controller.clear();
                                },
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: !loadingFlag
                          // ? listDisplay.length > 0
                          ? listDisplay.length > 0
                              ? Container(
                                  color: const Color(bgColor),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    itemBuilder: (context, position) {
                                      return GestureDetector(
                                          child: Card(
                                            elevation: 4,
                                            margin: const EdgeInsets.only(
                                                left: 15,
                                                top: 7,
                                                right: 15,
                                                bottom: 7),
                                            child: Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                12.0,
                                                                12.0,
                                                                12.0,
                                                                3.0),
                                                        child: Text(
                                                          listDisplay[position]
                                                              .varProduct_SKU_Name,
                                                          style: prifixTxtStyle,
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                12.0,
                                                                3.0,
                                                                12.0,
                                                                12.0),
                                                        child: Text(
                                                          LocaleUtils.getString(
                                                                  mContext,
                                                                  'Units') +
                                                              ': ${listDisplay[position].decQty > 0 ? '${listDisplay[position].decQty.toInt()}' : '0'}  ' +
                                                              '${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'Qty')}.(${globals
                                                                  .KG_PCS}.): ${listDisplay[position]
                                                                  .qtyKG > 0
                                                                  ? listDisplay[position]
                                                                  .qtyKG
                                                                  .toStringAsFixed(
                                                                  2)
                                                                  : '0.00'}',
                                                          style: prifixTxtStyle,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                ),
                                                const Align(
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsets.all(8.0),
                                                    child: Icon(
                                                      Icons.info,
                                                      size: 25.0,
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                          onTap: () {
                                            getPopupRecords(
                                                listDisplay[position]);
                                          });
                                    },
                                    itemCount: listDisplay.length,
                                  ),
                                )
                              : Visibility(
                                  child: Container(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/nodata_icon.png',
                                          height: 100,
                                          width: 100,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10),
                                          child: Text(
                                            LocaleUtils.getString(
                                                mContext, 'NoDataFound'),
                                            style: prifixTxtStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  visible:
                                      listDisplay.length == 0 ? true : false,
                                  //listDisplay.length <= 0 ? true : false,
                                )
                          : const Center(
                              child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(colorPrimary))),
                            )),
                ],
              ),
            ),
          ],
        ),
      ),
        ));
  }

  void filterSearchResults(String query) {
    print(query);
    getData(query);
    /*List<MyStockInfoModel> dummySearchList = List<MyStockInfoModel>();
    dummySearchList.addAll(list);

    if (query.isNotEmpty) {
      List<MyStockInfoModel> dummyListData = List<MyStockInfoModel>();
      dummySearchList.forEach((item) {
        if (item.varProduct_SKU_Name.toLowerCase().contains(query) ||
            item.varProduct_SKU_Code.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted)
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(dummyListData);
        });
      return;
    } else {
      print(2);
      if (mounted)
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(list);
        });
    }*/
  }

  void getPopupRecords(MyStockInfoModel data) {
    sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int initCode) {
      databaseHelper
          .getStockInfoPopupList(
              initCode, data.fk_Product_SKU_Glcode.toString())
          .then((var custTypeList) {
        listDialogDisplay.clear();
        listDialogDisplay.addAll(custTypeList);
        _displayDialog(context, data);
      });
    });
  }

  Future _displayDialog(BuildContext context, MyStockInfoModel data) async {
    return showDialog<Map>(
        context: context,
        builder: (context) {
          return AlertDialog(
              contentPadding: const EdgeInsets.all(0.0),
              shape: RoundedRectangleBorder(
                  borderRadius: const BorderRadius.all(Radius.circular(5.0))),
              //title:  Text('Alert Dialog title'),
              content: Container(
                width: screenSize.width * 0.9,
                height: screenSize.height * 0.6,
                //height: 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: screenSize.width,
                      height: 40,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        child: MarqueeWidget(
                            direction: Axis.horizontal,
                            child: Text(
                                data.varProduct_SKU_Code +
                                    '-' +
                                    data.varProduct_SKU_Name,
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: 'helvetica',
                                    color: Colors.white))),
                        alignment: Alignment.center,
                      ),
                    ),
                    Container(
                      height: 35,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'BatchNo'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'ExpiryDate'),
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'Units'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  '${LocaleUtils.getString(
                                      mContext, 'Qty')}.(${globals.KG_PCS}.)',
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      color: const Color(colorAccent),
                      height: 1,
                      //margin: EdgeInsets.only(top: 7),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: listDialogDisplay.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          //return listDialogDisplay.length > 0
                          return listDialogDisplay.isNotEmpty
                              ? Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Container(
                                      height: 35,
                                      width: screenSize.width,
                                      child: Padding(
                                        padding: const EdgeInsets.only(
                                            top: 0, bottom: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: <Widget>[
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    listDialogDisplay[index]
                                                        .varBatchNo
                                                        .toString(),
                                                    style: TextStyle(
                                                      fontSize: 13.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: 'helvetica',
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    mUtils
                                                        .convertDateTimeDisplay1(
                                                            listDialogDisplay[
                                                                    index]
                                                                .dtExpiryDate,
                                                            displayDateFormat),
                                                    style: TextStyle(
                                                      fontSize: 13.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: 'helvetica',
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                      listDialogDisplay[index]
                                                                  .decQty >
                                                              0
                                                          ? '${listDialogDisplay[index].decQty.toInt()}'
                                                          : '0',
                                                      style: TextStyle(
                                                        fontSize: 13.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: 'helvetica',
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                      listDialogDisplay[index]
                                                                  .qtyKG >
                                                              0
                                                          ? listDialogDisplay[
                                                                  index]
                                                              .qtyKG
                                                              .toStringAsFixed(
                                                                  2)
                                                          : '0.00',
                                                      style: TextStyle(
                                                        fontSize: 13.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: 'helvetica',
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: screenSize.width,
                                      color: const Color(colorAccent),
                                      height: 1,
                                      //margin: EdgeInsets.only(top: 7),
                                    ),
                                    //Divider(color: Colors.black26),
                                  ],
                                )
                              : Container();
                        },
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Close'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
              //actions: _actionButton()
              );
        });
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
