class SalesInwardSummaryModel {
  int fk_Product_SKU_GlCode, intQuantity;
  String varProduct_SKU_Code;
  String varProduct_SKU_Name;
  double decQtyInKg;

  SalesInwardSummaryModel.fromJson(Map<String, dynamic> json)
      : fk_Product_SKU_GlCode = json['fk_Product_SKU_GlCode'],
        varProduct_SKU_Code = json['varProduct_SKU_Code'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'],
        intQuantity = json['intQuantity'],
        decQtyInKg = (json['decQtyInKg'] as double).toDouble();

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fk_Product_SKU_GlCode'] = this.fk_Product_SKU_GlCode;
    data['varProduct_SKU_Code'] = this.varProduct_SKU_Code;
    data['varProduct_SKU_Name'] = this.varProduct_SKU_Name;
    data['intQuantity'] = this.intQuantity;
    data['decQtyInKg'] = this.decQtyInKg;
    return data;
  }
}

class SalesInwardStickerDetailsModel {
  int intGlCode;
  String varSticker;
  int fk_StickerGlCode;
  int fk_PalletGlCode;
  String chrType;
  String chrValid;
  String chrBrak;
  String chrBreakConfirm;
  int fk_FromCustomerGlCode;
  int fk_ToCustomerGlCode;
  int fk_Last_DispatchedBy;
  int intPalletStickerCount;
  int intPalletScannCount;
  String varRemarks;
  String chrProcess;

  SalesInwardStickerDetailsModel.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        varSticker = json['varSticker'],
        fk_StickerGlCode = json['fk_StickerGlCode'],
        fk_PalletGlCode = json['fk_PalletGlCode'],
        chrType = json['chrType'],
        chrValid = json['chrValid'],
        chrBrak = json['chrBrak'],
        chrBreakConfirm = json['chrBreakConfirm'],
        fk_FromCustomerGlCode = json['fk_FromCustomerGlCode'],
        fk_ToCustomerGlCode = json['fk_ToCustomerGlCode'],
        fk_Last_DispatchedBy = json['fk_Last_DispatchedBy'],
        intPalletStickerCount = json['intPalletStickerCount'],
        intPalletScannCount = json['intPalletScannCount'],
        varRemarks = json['varRemarks'],
        chrProcess = json['chrProcess'];

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['intGlCode'] = this.intGlCode;
    data['varSticker'] = this.varSticker;
    data['fk_StickerGlCode'] = this.fk_StickerGlCode;
    data['fk_PalletGlCode'] = this.fk_PalletGlCode;
    data['chrType'] = this.chrType;
    data['chrValid'] = this.chrValid;
    data['chrBrak'] = this.chrBrak;
    data['chrBreakConfirm'] = this.chrBreakConfirm;
    data['fk_FromCustomerGlCode'] = this.fk_FromCustomerGlCode;
    data['fk_ToCustomerGlCode'] = this.fk_ToCustomerGlCode;
    data['fk_Last_DispatchedBy'] = this.fk_Last_DispatchedBy;
    data['intPalletStickerCount'] = this.intPalletStickerCount;
    data['intPalletScannCount'] = this.intPalletScannCount;
    data['varRemarks'] = this.varRemarks;
    data['chrProcess'] = this.chrProcess;
    return data;
  }
}

class SalesInwardDetailsModel {
  int intGlCode;
  String varSticker;
  String varLastSoldByName;
  String varLastReceivedByName;

  SalesInwardDetailsModel.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        varSticker = json['varSticker'],
        varLastSoldByName = json['varLastSoldByName'],
        varLastReceivedByName = json['varLastReceivedByName'];

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['intGlCode'] = this.intGlCode;
    data['varSticker'] = this.varSticker;
    data['varLastSoldByName'] = this.varLastSoldByName;
    data['varLastReceivedByName'] = this.varLastReceivedByName;
    return data;
  }
}

class SalesInwardCountModel {
  int intTotalArticle;
  int intTotalScannedQty;

  SalesInwardCountModel.fromJson(Map<String, dynamic> json)
      : intTotalArticle = json['intTotalArticle'],
        intTotalScannedQty = json['intTotalScannedQty'];
}

class StickerDetailModel {
  String varSticker;

  StickerDetailModel.fromJson(Map<String, dynamic> json)
      : varSticker = json['varSticker'];
}
