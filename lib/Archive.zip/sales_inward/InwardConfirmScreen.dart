import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBarForInward.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/sales_inward/InwardCongratulationScreen.dart';
import 'package:flutter_basf_hk_app/sales_inward/InwardScanScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

import 'SalesInwardModels.dart';

abstract class DialogLoadListener {
  void onLoad();

  void onCancel();
}

class InwardConfirmScreen extends StatefulWidget {
  int fk_OrderGlCode;

  InwardConfirmScreen({this.fk_OrderGlCode});

  @override
  InwardConfirmScreenState createState() => InwardConfirmScreenState();
}

class InwardConfirmScreenState extends State<InwardConfirmScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false, isNotification = false, isSync = false;
  String dropdownValue;
  Size screenSize;
  String userName = '', subTitle, topHeaderImage = 'assets/sales_inward.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  WSPresenter wsPresenter;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  int apiCallType = 0;
  List<SalesInwardSummaryModel> listSalesInwardSummary;
  SalesInwardCountModel dataSalesInwardCount;

  InwardConfirmScreenState();

  List<InwardScanModel> listSalesInwardSticker;
  List<SalesInwardDetailsModel> listSalesInwardDetails;
  List<SalesInwardDetailsModel> listSalesInwardDetailsDisplay;
  List<StickerDetailModel> invalidStickerList;

  SalesInwardSummaryModel selectedSalesInwardSummary;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() async {
    final Route route =
    CupertinoPageRoute(builder: (context) =>
        InwardScanScreen(isChange: true, scanData: listSalesInwardSticker,));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          apiCall(1, "");
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    pushNotificationServices = PushNotificationServices(this);
    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
            subTitle = LocaleUtils.getString(mContext, 'tag_sales_inward');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    listSalesInwardSticker = List();
    listSalesInwardDetails = List();
    listSalesInwardDetailsDisplay = List();
    listSalesInwardSummary = List();
    invalidStickerList = List();
    apiCall(1, "");
  }

  void apiCall(int type, String remarks) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGlCode) {
              param[PARAM_PERSON_ID] = loginID;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param[PARAM_DEVICE_ID] = deviceid;
                  if (type == 1) {
                    param[PARAM_ACTION] = "SalesInwardSummary";
                  } else if (type == 2) {
                    param[PARAM_ACTION] = "SalesInwardDetails";
                  } else if (type == 3) {
                    param[PARAM_ACTION] = "GetConfirm";
                  } else if (type == 4) {
                    param[PARAM_ACTION] = "Confirm";
                  } else if (type == 5) {
                    param[PARAM_ACTION] = "Close";
                  }

                  //param['DeviceId'] = '1234';
                  param['OrderProductId'] = '';
                  param['ToCustomerId'] = mainCustomerGlCode.toString();
                  param['ProductSkuId'] = type == 2
                      ? '${selectedSalesInwardSummary.fk_Product_SKU_GlCode}'
                      : '0';
                  param['JSONData'] = '';

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Sales_Inward', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (mounted) {
          if (apiCallType == 1) {
            setState(() {
              listSalesInwardSummary.clear();
              listSalesInwardSummary
                  .addAll(responseModel.getSalesInwardSummary());
            });

            dataSalesInwardCount = responseModel.getSalesInwardCount();

            listSalesInwardSticker.clear();
            listSalesInwardSticker
                .addAll(responseModel.getInwardScanRecords());

            //apiCall(2, "");
          } else if (apiCallType == 2) {
            listSalesInwardDetails.clear();
            listSalesInwardDetailsDisplay.clear();
            listSalesInwardDetails
                .addAll(responseModel.getSalesInwardDetails());
            listSalesInwardDetailsDisplay.addAll(listSalesInwardDetails);

            showDialog<Map>(
                context: context,
                builder: (context) =>
                    MyForm(
                      screenSize: screenSize,
                      selectedSalesInwardSummary: selectedSalesInwardSummary,
                      listSalesInwardDetails: listSalesInwardDetails,
                      listSalesInwardDetailsDisplay:
                      listSalesInwardDetailsDisplay,
                    ));
            //_displayDetailsDialog(context);
          } else if (apiCallType == 3) {
            SalesInwardCountModel data = responseModel.getSalesInwardCount();
            invalidStickerList.clear();
            invalidStickerList.addAll(responseModel.getInvalidStickers());

            showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return confirmDialog(
                    '${data.intTotalArticle}', '${data.intTotalScannedQty}');
              },
            );
          } else if (apiCallType == 4) {
            final Route route = CupertinoPageRoute(
                builder: (context) =>
                    InwardCongratulationScreen());
            Navigator.pushReplacement(mContext, route);
          } else if (apiCallType == 5) {
//            showDialog<Map>(
//              barrierDismissible: false,
//              context: mContext,
//              builder: (context) {
//                return CustomAlertDialog(
//                  content: responseModel.Message,
//                  title: PROJECT_NAME == 'BASF_HK'
//                      ? BASF_HK_APP_Name
//                      : Zydus_APP_Name,
//                  isShowNagativeButton: false,
//                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//                  onPressedPositive: () {
//                    Navigator.pop(mContext);
//                  },
//                );
//              },
//            );
            Navigator.pop(mContext);
          }
        }
      } else if (responseModel.Status.contains('2')) {
        if (apiCallType == 4) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {
                  redirectScanScreen();
                },
              );
            },
          );
        }
      } else {
        if (apiCallType != 1) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) => SyncScreen(
                                  isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final reScanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ReScan'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          redirectScanScreen();
        },
      ),
    );

    final closeButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Discard'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          closeOrder();
        },
      ),
    );

    final dispatchButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'inward'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          apiCall(3, '');
        },
      ),
    );

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      resizeToAvoidBottomPadding: false,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  CustomTopHeaderBarForInward(stage: SUB_HEADER_INWARD),
                  Container(
                    height: 40,
                    margin: EdgeInsets.only(top: 1),
                    color: const Color(colorAccent),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotUnits_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                  padding: const EdgeInsets.only(top: 2),
                                  child: Text(
                                    dataSalesInwardCount != null
                                        ? dataSalesInwardCount
                                        .intTotalScannedQty != null
                                        ? '${dataSalesInwardCount
                                        .intTotalScannedQty}'
                                        : '0'
                                        : '0',
                                    style: textPrimaryStyle,
                                  ))
                            ],
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: 1,
                          color: Colors.white70,
                        ),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotArticle_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                  padding: const EdgeInsets.only(top: 2),
                                  child: Text(
                                    dataSalesInwardCount != null
                                        ? '${dataSalesInwardCount
                                        .intTotalArticle}'
                                        : '0',
                                    style: textPrimaryStyle,
                                  ))
                            ],
                          ),
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.topLeft,
                      margin: const EdgeInsets.only(
                          top: 10, left: 15, right: 15, bottom: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 5, left: 0, bottom: 10),
                            child: Text(
                                LocaleUtils.getString(
                                    mContext, 'ScanningDetails'),
                                style: prifixTxtStyle),
                          ),
                          Expanded(
                            child: listSalesInwardSummary.isNotEmpty
                                ? Container(
                                    child: ListView.builder(
                                      itemCount: listSalesInwardSummary.length,
                                      shrinkWrap: true,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return GestureDetector(
                                            child: Card(
                                              margin: const EdgeInsets.only(
                                                  left: 0,
                                                  top: 7,
                                                  bottom: 7,
                                                  right: 0),
                                              elevation: 3,
                                              child: Container(
                                                padding:
                                                const EdgeInsets.all(10),
                                                width: screenSize.width,
                                                child: Column(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <Widget>[
                                                      Text(
                                                          '${listSalesInwardSummary[index]
                                                              .varProduct_SKU_Code} - ${listSalesInwardSummary[index]
                                                              .varProduct_SKU_Name}',
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w600,
                                                              fontFamily:
                                                              'helvetica',
                                                              color: Colors
                                                                  .black)),
                                                      Text(
                                                          '${LocaleUtils
                                                              .getString(
                                                              context,
                                                              'Scanned_')} ${listSalesInwardSummary[index]
                                                              .intQuantity
                                                              .toString()}' +
                                                              '\t\t\t${LocaleUtils
                                                                  .getString(
                                                                  context,
                                                                  PROJECT_NAME ==
                                                                      'BASF_HK'
                                                                      ? 'Units_'
                                                                      : 'pcs_')}${listSalesInwardSummary[index]
                                                                  .decQtyInKg
                                                                  .toString()}',
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                              FontWeight
                                                                  .w400,
                                                              fontFamily:
                                                              'helvetica',
                                                              color: Colors
                                                                  .black)),
                                                    ]),
                                              ),
                                            ),
                                            onTap: () {
                                              selectedSalesInwardSummary =
                                              listSalesInwardSummary[index];
                                              apiCall(2, '');
                                            });
                                      },
                                    ),
                                  )
                                : Container(
                                    width: screenSize.width,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/nodata_icon.png',
                                          height: 100,
                                          width: 100,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10),
                                          child: Text(
                                            LocaleUtils.getString(
                                                context, 'NoDataFound'),
                                            style: prifixTxtStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Container(
                    width: screenSize.width,
                    height: 45,
                    margin: const EdgeInsets.all(15),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: reScanButton,
                          flex: 1,
                        ),
                        Container(
                          width: 10,
                        ),
                        Expanded(
                          child: closeButton,
                          flex: 1,
                        ),
                        Container(
                          width: 10,
                        ),
                        Expanded(
                          child: dispatchButton,
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  closeOrder() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(
              mContext, 'AreYouSureUWant2DiscardTransaction'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: true,
          textNagativeButton: LocaleUtils.getString(mContext, 'no'),
          textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
          onPressedNegative: () {},
          onPressedPositive: () {
            apiCall(5, '');
          },
        );
      },
    );
  }

  void _showSnackBar(String text) {
    Flushbar(
      message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  Future _displayDetailsDialog(BuildContext context) async {
    return showDialog<Map>(
        context: context,
        builder: (context) {
          return AlertDialog(
              contentPadding: const EdgeInsets.all(0.0),
              shape: RoundedRectangleBorder(
                  borderRadius: const BorderRadius.all(Radius.circular(5.0))),
              //title:  Text('Alert Dialog title'),
              content: Container(
                width: screenSize.width * 0.9,
                height: screenSize.height * 0.6,
                //height: 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: screenSize.width,
                      height: 40,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        child: MarqueeWidget(
                            direction: Axis.horizontal,
                            child: Text(
                                selectedSalesInwardSummary.varProduct_SKU_Code +
                                    '-' +
                                    selectedSalesInwardSummary
                                        .varProduct_SKU_Name,
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: 'helvetica',
                                    color: Colors.white))),
                        alignment: Alignment.center,
                      ),
                    ),
                    Container(
                      height: 35,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'SerialNo_'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(
                                      mContext, 'last_rec_by'),
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(
                                      mContext, 'last_sold_by'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      color: const Color(colorAccent),
                      height: 1,
                      //margin: EdgeInsets.only(top: 7),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: listSalesInwardDetails.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          //return listDialogDisplay.length > 0
                          return listSalesInwardDetails.isNotEmpty
                              ? Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Container(
                                height: 35,
                                width: screenSize.width,
                                child: Padding(
                                  padding: const EdgeInsets.only(
                                      top: 0, bottom: 0),
                                  child: Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                    children: <Widget>[
                                      Expanded(
                                        child: Wrap(
                                          direction: Axis.horizontal,
                                          crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                          alignment: WrapAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              listSalesInwardDetails[
                                              index]
                                                  .varSticker,
                                              style: TextStyle(
                                                fontSize: 13.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: 'helvetica',
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: Wrap(
                                          direction: Axis.horizontal,
                                          crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                          alignment: WrapAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              listSalesInwardDetails[
                                              index]
                                                  .varLastReceivedByName,
                                              style: TextStyle(
                                                fontSize: 13.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: 'helvetica',
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                        flex: 1,
                                      ),
                                      Expanded(
                                        child: Wrap(
                                          direction: Axis.horizontal,
                                          crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                          alignment: WrapAlignment.center,
                                          children: <Widget>[
                                            Text(
                                              listSalesInwardDetails[
                                              index]
                                                  .varLastSoldByName,
                                              style: TextStyle(
                                                fontSize: 13.0,
                                                fontWeight:
                                                FontWeight.w500,
                                                fontFamily: 'helvetica',
                                              ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                width: screenSize.width,
                                color: const Color(colorAccent),
                                height: 1,
                                //margin: EdgeInsets.only(top: 7),
                              ),
                              //Divider(color: Colors.black26),
                            ],
                          )
                              : Container();
                        },
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                              LocaleUtils.getString(mContext, 'Close'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            //actions: _actionButton()
          );
        });
  }

  AlertDialog confirmDialog(String TotArticle, String TotScanned) {
    //print('======invalidStickerList===========${invalidStickerList.length}');

    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        //content: invalidStickerList.length > 0
        content: invalidStickerList.isNotEmpty
            ? Container(
          width: MediaQuery
              .of(context)
              .size
              .width * 0.8,
          height: MediaQuery
              .of(context)
              .size
              .height * 0.7,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: MarqueeWidget(
                      direction: Axis.horizontal,
                      child: Text(
                          LocaleUtils.getString(
                              context, 'tag_sales_inward'),
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'helvetica',
                              color: Colors.white))),
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 10),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                              LocaleUtils.getString(
                                  context, 'TotArticle'),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'helvetica',
                                  color: Colors.black)),
                          Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: Text(TotArticle,
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                              LocaleUtils.getString(
                                  context, 'TotScanned'),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'helvetica',
                                  color: Colors.black)),
                          Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: Text(TotScanned,
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 10),
                child: Text(
                    LocaleUtils.getString(context, 'InvalidCodes'),
                    style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'helvetica',
                        color: const Color(colorPrimary))),
              ),
              Container(
                margin: const EdgeInsets.only(top: 10, bottom: 10),
                padding: const EdgeInsets.only(left: 10, right: 10),
                child: Text(
                    LocaleUtils.getString(
                        context, 'ThisTranWillProceedWithoutBelowCode'),
                    style: TextStyle(
                        fontSize: 12.0,
                        fontWeight: FontWeight.w400,
                        fontFamily: 'helvetica',
                        color: Colors.black)),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: invalidStickerList.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                      height: 35,
                      alignment: Alignment.center,
                      child: Column(
                        children: <Widget>[
                          Text(
                            //invalidStickerList.length > 0
                              invalidStickerList.isNotEmpty
                                  ? '${invalidStickerList[index]
                                  .varSticker} (#${index + 1})'
                                  : '',
                              style: TextStyle(
                                  fontSize: 12.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'helvetica',
                                  color: Colors.red)),
                          Divider(color: Colors.black54),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Container(
                width: screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName:
                        LocaleUtils.getString(context, 'Cancel'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: 0.7,
                    ),
                    Expanded(
                      child: ButtonDialogWidgets(
                          buttonName:
                          LocaleUtils.getString(context, 'Confirm'),
                          buttonColor: const Color(colorPrimary),
                          textColor: Colors.white,
                          onTap: () {
                            Navigator.of(context).pop();
                            apiCall(4, '');
                          }),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
            : Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: MarqueeWidget(
                      direction: Axis.horizontal,
                      child: Text(
                          LocaleUtils.getString(
                              context, 'tag_sales_inward'),
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'helvetica',
                              color: Colors.white))),
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 20, bottom: 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.only(left: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                              LocaleUtils.getString(
                                  context, 'TotArticle'),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'helvetica',
                                  color: Colors.black)),
                          Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: Text(TotArticle,
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)))
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                              LocaleUtils.getString(
                                  context, 'TotScanned'),
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'helvetica',
                                  color: Colors.black)),
                          Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: Text(TotScanned,
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w400,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                width: screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName:
                        LocaleUtils.getString(context, 'Cancel'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: 0.7,
                    ),
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName:
                        LocaleUtils.getString(context, 'Confirm'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                          apiCall(4, '');
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      //actions: _actionButton()
    );
  }
}

// ignore: must_be_immutable
class MyForm extends StatefulWidget {
  Size screenSize;
  SalesInwardSummaryModel selectedSalesInwardSummary;
  List<SalesInwardDetailsModel> listSalesInwardDetails = List();
  List<SalesInwardDetailsModel> listSalesInwardDetailsDisplay = List();

  MyForm({
    this.screenSize,
    this.selectedSalesInwardSummary,
    this.listSalesInwardDetails,
    this.listSalesInwardDetailsDisplay,
  });

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        content: Container(
          width: widget.screenSize.width * 0.9,
          height: widget.screenSize.height * 0.6,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: widget.screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: MarqueeWidget(
                      direction: Axis.horizontal,
                      child: Text(
                          widget.selectedSalesInwardSummary
                              .varProduct_SKU_Code +
                              '-' +
                              widget.selectedSalesInwardSummary
                                  .varProduct_SKU_Name,
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'helvetica',
                              color: Colors.white))),
                  alignment: Alignment.center,
                ),
              ),
              Container(
                height: 35,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Wrap(
                        direction: Axis.horizontal,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        alignment: WrapAlignment.center,
                        children: <Widget>[
                          Text(
                            LocaleUtils.getString(context, 'SerialNo_'),
                            style: TextStyle(
                              fontSize: 13.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'helvetica',
                              color: const Color(colorPrimary),
                            ),
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Wrap(
                        direction: Axis.horizontal,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        alignment: WrapAlignment.center,
                        children: <Widget>[
                          Text(
                            LocaleUtils.getString(context, 'last_rec_by'),
                            style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'helvetica',
                              color: const Color(colorPrimary),
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Wrap(
                        direction: Axis.horizontal,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        alignment: WrapAlignment.center,
                        children: <Widget>[
                          Text(
                            LocaleUtils.getString(context, 'last_sold_by'),
                            style: TextStyle(
                              fontSize: 13.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'helvetica',
                              color: const Color(colorPrimary),
                            ),
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
              Container(
                width: widget.screenSize.width,
                color: const Color(colorAccent),
                height: 1,
                //margin: EdgeInsets.only(top: 7),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.only(
                    top: 5, bottom: 5, right: 10, left: 10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: searchController,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey),
                              hintText:
                              LocaleUtils.getString(context, 'Search'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: const Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                child: widget.listSalesInwardDetailsDisplay.length > 0
                    ? Container(
                  child: ListView.builder(
                    itemCount:
                    widget.listSalesInwardDetailsDisplay.length,
                    shrinkWrap: true,
                    itemBuilder: (BuildContext context, int index) {
                      //return listDialogDisplay.length > 0
                      return widget
                          .listSalesInwardDetailsDisplay.isNotEmpty
                          ? Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Container(
                            height: 35,
                            width: widget.screenSize.width,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 0, bottom: 0),
                              child: Row(
                                crossAxisAlignment:
                                CrossAxisAlignment.center,
                                mainAxisAlignment:
                                MainAxisAlignment.spaceAround,
                                children: <Widget>[
                                  Expanded(
                                    child: Wrap(
                                      direction: Axis.horizontal,
                                      crossAxisAlignment:
                                      WrapCrossAlignment.center,
                                      alignment:
                                      WrapAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          widget
                                              .listSalesInwardDetailsDisplay[
                                          index]
                                              .varSticker,
                                          style: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight:
                                            FontWeight.w500,
                                            fontFamily: 'helvetica',
                                          ),
                                          textAlign:
                                          TextAlign.center,
                                        ),
                                      ],
                                    ),
                                    flex: 1,
                                  ),
                                  Expanded(
                                    child: Wrap(
                                      direction: Axis.horizontal,
                                      crossAxisAlignment:
                                      WrapCrossAlignment.center,
                                      alignment:
                                      WrapAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          widget
                                              .listSalesInwardDetailsDisplay[
                                          index]
                                              .varLastReceivedByName,
                                          style: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight:
                                            FontWeight.w500,
                                            fontFamily: 'helvetica',
                                          ),
                                          textAlign:
                                          TextAlign.center,
                                        ),
                                      ],
                                    ),
                                    flex: 1,
                                  ),
                                  Expanded(
                                    child: Wrap(
                                      direction: Axis.horizontal,
                                      crossAxisAlignment:
                                      WrapCrossAlignment.center,
                                      alignment:
                                      WrapAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          widget
                                              .listSalesInwardDetailsDisplay[
                                          index]
                                              .varLastSoldByName,
                                          style: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight:
                                            FontWeight.w500,
                                            fontFamily: 'helvetica',
                                          ),
                                          textAlign:
                                          TextAlign.center,
                                        ),
                                      ],
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Container(
                            width: widget.screenSize.width,
                            color: const Color(colorAccent),
                            height: 1,
                            //margin: EdgeInsets.only(top: 7),
                          ),
                          //Divider(color: Colors.black26),
                        ],
                      )
                          : Container();
                    },
                  ),
                )
                    : Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Image.asset(
                        'assets/nodata_icon.png',
                        height: 100,
                        width: 100,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 10),
                        child: Text(
                          LocaleUtils.getString(context, 'NoDataFound'),
                          style: prifixTxtStyle,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: widget.screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(context, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
      //actions: _actionButton()
    );
  }

  void filterSearchResults(String query) {
    print(query);
    final List<SalesInwardDetailsModel> dummySearchList =
    List<SalesInwardDetailsModel>();
    dummySearchList.addAll(widget.listSalesInwardDetails);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<SalesInwardDetailsModel> dummyListData =
      List<SalesInwardDetailsModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query) ||
            item.varLastSoldByName.toLowerCase().contains(query) ||
            item.varLastReceivedByName.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listSalesInwardDetailsDisplay.clear();
          widget.listSalesInwardDetailsDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listSalesInwardDetailsDisplay.clear();
          widget.listSalesInwardDetailsDisplay
              .addAll(widget.listSalesInwardDetails);
        });
    }

    print(widget.listSalesInwardDetailsDisplay.length);
  }
}
