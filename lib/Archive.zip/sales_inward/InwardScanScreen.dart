import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBarForInward.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/sales_inward/InwardConfirmScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';

class InwardScanModel {
  int intGlCode;
  String varSticker;
  int fk_StickerGlCode;
  int fk_PalletGlCode;
  String chrType;
  String chrValid;
  String chrBreak;
  String chrBreakConfirm;
  int fk_FromCustomerGlCode;
  int fk_ToCustomerGlCode;
  int fk_Last_DispatchedBy;
  int intPalletStickerCount;
  int intPalletScannCount;
  String varRemarks;
  String chrProcess;
  bool isDeleted = false;
  bool isMultiDeleted = false;

  InwardScanModel({
    this.intGlCode,
    this.varSticker,
    this.fk_StickerGlCode,
    this.fk_PalletGlCode,
    this.chrType,
    this.chrValid,
    this.chrBreak,
    this.chrBreakConfirm,
    this.fk_FromCustomerGlCode,
    this.fk_ToCustomerGlCode,
    this.fk_Last_DispatchedBy,
    this.intPalletStickerCount,
    this.intPalletScannCount,
    this.varRemarks,
    this.chrProcess,
  });

  InwardScanModel.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        varSticker = json['varSticker'],
        fk_StickerGlCode = json['fk_StickerGlCode'],
        fk_PalletGlCode = json['fk_PalletGlCode'],
        chrType = json['chrType'],
        chrValid = json['chrValid'],
        chrBreak = json['chrBreak'],
        chrBreakConfirm = json['chrBreakConfirm'],
        fk_FromCustomerGlCode = json['fk_FromCustomerGlCode'],
        fk_ToCustomerGlCode = json['fk_ToCustomerGlCode'],
        fk_Last_DispatchedBy = json['fk_Last_DispatchedBy'],
        intPalletStickerCount = json['intPalletStickerCount'],
        intPalletScannCount = json['intPalletScannCount'],
        varRemarks = json['varRemarks'],
        chrProcess = json['chrProcess'];

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['intGlCode'] = this.intGlCode;
    data['varSticker'] = this.varSticker;
    data['fk_StickerGlCode'] = this.fk_StickerGlCode;
    data['fk_PalletGlCode'] = this.fk_PalletGlCode;
    data['chrType'] = this.chrType;
    data['chrValid'] = this.chrValid;
    data['chrBreak'] = this.chrBreak;
    data['chrBreakConfirm'] = this.chrBreakConfirm;
    data['fk_FromCustomerGlCode'] = this.fk_FromCustomerGlCode;
    data['fk_ToCustomerGlCode'] = this.fk_ToCustomerGlCode;
    data['fk_Last_DispatchedBy'] = this.fk_Last_DispatchedBy;
    data['intPalletStickerCount'] = this.intPalletStickerCount;
    data['intPalletScannCount'] = this.intPalletScannCount;
    data['varRemarks'] = this.varRemarks;
    data['chrProcess'] = this.chrProcess;
    return data;
  }
}

class InwardScanScreen extends StatefulWidget {
  final List<InwardScanModel> scanData;
  final bool isChange;

  InwardScanScreen({this.scanData, this.isChange});

  @override
  InwardScanScreenState createState() => InwardScanScreenState();
}

class InwardScanScreenState extends State<InwardScanScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '',
      subTitle = '',
      topHeaderImage = 'assets/sales_inward.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController serialNoTextController;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  String menufacturer = '';
  DatabaseHelper databaseHelper;
  int apiCallType = 0;
  WSPresenter wsPresenter;
  List<InwardScanModel> inwardScanList;
  bool isVerifyBtn = true;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    inwardScanList = new List();
    if (widget.scanData != null) {
      inwardScanList.addAll(widget.scanData);
    }

    serialNoTextController = TextEditingController();
//    _serialNoFocus = FocusNode();

    init();
  }

  void init() async {
    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullname = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullname != null ? fullname : '';
      subTitle = LocaleUtils.getString(mContext, 'tag_sales_inward');
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) async {
      try {
        print('=======state=======${state.toString()}');
        if (state['type'] == '11') {
          var detailsData = state['Details'];
          final dynamic lists = json.decode(detailsData);
          verifySticker(lists);
        }
      } catch (e) {
        print(e.toString());
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    if (!widget.isChange) {
      await apiCall(3, "");
    }

    await insertLogDetails();

    await _battery.hideKeyboardPlugin();

    if (mounted) {
      setState(() {});
    }
  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_SIR');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode =
    await databaseHelper.getSyncCodeFromLoginDetails(int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void verifySticker(dynamic lists) async {
    if (lists.length > 0) {
      for (var j in lists) {
        if (j.toString().trim().isNotEmpty) {
          List<String> code = j.toString().split("/");
          print('====F CODE=====${code.toString()}');
          if (code.length > 1) {
            if (code[1].toString() == '31') {
              insertStickerInList(code[0].toString().toUpperCase(), 'P');
            } else if (code[1].toString() == '21') {
              insertStickerInList(code[0].toString().toUpperCase(), 'S');
            }
          } else {
            insertStickerInList(code[0].toString().toUpperCase(), 'S');
          }
        }
      }
    }
  }

  void insertStickerInList(String sticker, String chrType) {
    bool isExist = stickerAlreadyExist(sticker);
    if (isExist) {
      int inwardScanListLength = inwardScanList.length;
      if (inwardScanListLength < globals.SCAN_LIMIT) {
        isVerifyBtn = true;
        isLaserScanLoad = false;
        inwardScanList.insert(
            0,
            InwardScanModel(
                intGlCode: 0,
                varSticker: sticker,
                fk_StickerGlCode: 0,
                fk_PalletGlCode: 0,
                chrType: chrType,
                chrValid: "N",
                chrBreak: "N",
                chrBreakConfirm: "N",
                fk_FromCustomerGlCode: 0,
                fk_ToCustomerGlCode: 0,
                fk_Last_DispatchedBy: 0,
                intPalletStickerCount: 0,
                intPalletScannCount: 0,
                varRemarks: "",
                chrProcess: "N"));
        if (mounted) {
          setState(() {});
        }
      } else {
        isLaserScanLoad = false;
        _showSnackBar(LocaleUtils.getString(mContext, 'you_reached_max_limit'));
      }
    } else {
      isLaserScanLoad = false;
      _showSnackBar(LocaleUtils.getString(mContext, 'LabelAlreadyExist'));
    }
  }

  bool stickerAlreadyExist(String sticker) {
    if (inwardScanList.isNotEmpty) {
      int lengthList = inwardScanList.length;
      for (int i = 0; i < lengthList; i++) {
        InwardScanModel inwardScanModel = inwardScanList[i];
        if (sticker.toUpperCase() == inwardScanModel.varSticker.toUpperCase()) {
          return false;
        }
      }
    }
    return true;
  }

  void _onTextChanged() async {
    final String value = serialNoTextController.text ?? '';
    if (value.isNotEmpty) {
      if (value.trim().length >= int.parse(globals.BARCODE_LENGTH)) {
        print('=====value=======$value');
        if (!isLaserScanLoad) {
          final List<String> scanList = List();
          isLaserScanLoad = true;
          await _battery.checkBarCode(value).then((String serialNo) async {
            if (!scanList.contains(serialNo)) {
              scanList.add(serialNo);
            }
            verifySticker(scanList);
            serialNoTextController.text = '';
          });
        } else {
          serialNoTextController.text = '';
        }
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(mContext).requestFocus(FocusNode());
        List<String> scanList = List();
        scanList.add(serialNoTextController.text);
        verifySticker(scanList);
        serialNoTextController.text = '';
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
            'false',
            'true',
            'false',
            '#004a96',
            PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
            LocaleUtils.getString(mContext, 'next'),
            PROJECT_NAME == 'BASF_HK'
                ? LocaleUtils.getString(mContext, 'scan_your_label_here')
                : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

  void redirectInwardConfirmScreen() {
    if (widget.isChange) {
      Navigator.pop(context, true);
    } else {
      final Route route =
      CupertinoPageRoute(builder: (context) => InwardConfirmScreen());
      Navigator.pushReplacement(mContext, route);
    }
  }

  void apiCall(int type, String jsonData) async {
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      _loading = true;
      dismissProgressHUD();

      Future.delayed(const Duration(milliseconds: 700), () async {
        var param = Map();
        String loginID = await sharedPrefs.getString(PREF_INIT_GI_CODE);
        param[PARAM_PERSON_ID] = loginID;
        param[PARAM_SUB_MODULE_NAME] =
        Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;
        param[PARAM_VERSION] = APP_VERSION;

        String deviceid = await sharedPrefs.getString(PREF_DEVICE_ID);
        String apiToken = await sharedPrefs.getString(PREF_API_TOKEN);
        param[PARAM_API_TOKEN] = apiToken;
        param[PARAM_DEVICE_ID] = deviceid;
        if (type == 1) {
          param[PARAM_ACTION] = "Verify";
        } else if (type == 2) {
          param[PARAM_ACTION] = "Save";
        } else if (type == 3) {
          param[PARAM_ACTION] = "CheckPendingInward";
        }

        param['ProductSkuId'] = '0';
        param['JsonData'] = jsonData;
        print(param);
        apiCallType = type;
        wsPresenter.callAPI(POST_METHOD, SALES_INWARD, param);
      });
    } else {
      await showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'no_internet_connection'),
            title:
            PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  void unSelectAll(bool flag) {
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        inwardScanList[i].isMultiDeleted = false;
        if (flag) {
          inwardScanList[i].isDeleted = false;
        }
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void selectAll() {
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        inwardScanList[i].isMultiDeleted = true;
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  bool isStickerSelected() {
    bool isSelected = false;

    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        if (inwardScanList[i].isMultiDeleted) {
          isSelected = true;
        }
      }
    }

    return isSelected;
  }

  void setSelection(int index) {
    if (inwardScanList[index].isMultiDeleted) {
      inwardScanList[index].isMultiDeleted = false;
    } else {
      inwardScanList[index].isMultiDeleted = true;
    }
    if (isCheckAllStickerSelected()) {
      isSelectAll = true;
    } else {
      isSelectAll = false;
    }
    if (mounted) {
      setState(() {});
    }
  }

  bool isCheckAllStickerSelected() {
    bool isSelected = true;

    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        if (!inwardScanList[i].isMultiDeleted) {
          isSelected = false;
        }
      }
    }

    return isSelected;
  }

  Flushbar flushBar;
  Timer _timer;
  bool isSelectAll = false;

  void removeMultiSelectedSticker() {
    isLaserScanLoad = true;
    int deleteCount = 0;
    for (int i = 0; i < inwardScanList.length; i++) {
      if (inwardScanList[i].isMultiDeleted) {
        inwardScanList[i].isMultiDeleted = false;
        inwardScanList[i].isDeleted = true;
        deleteCount = deleteCount + 1;
      }
    }
    if (mounted) {
      setState(() {});
    }

    flushBar = Flushbar<bool>(
      message: "$deleteCount ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
          isLaserScanLoad = false;
          unSelectAll(true);
          _timer.cancel();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    flushBar.show(context);

    _timer = new Timer(const Duration(seconds: 4), () async {
      isLaserScanLoad = false;
//      await Future.forEach(inwardScanList,
//          (InwardScanModel scanDataModel) async {
//        if (scanDataModel.isDeleted) {
//          inwardScanList.remove(scanDataModel);
//        }
//      });
      for (int i = (inwardScanList.length - 1); i >= 0; i--) {
        if (inwardScanList[i].isDeleted) {
          inwardScanList.removeAt(i);
        }
      }
      if (mounted) {
        setState(() {});
      }
    });
  }

  void removeSticker(int index) {
    isLaserScanLoad = true;
    String varSticker = inwardScanList[index].varSticker;
    if (inwardScanList[index].chrValid == 'Y') {
      isVerifyBtn = true;
    }
    inwardScanList[index].isDeleted = true;
    if (mounted) {
      setState(() {});
    }

    flushBar = Flushbar<bool>(
      message: "$varSticker ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
          isLaserScanLoad = false;
          inwardScanList[index].isDeleted = false;
          _timer.cancel();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    flushBar.show(context);

    _timer = new Timer(const Duration(seconds: 4), () async {
      print('=========DELETED========');
      isLaserScanLoad = false;
      inwardScanList.removeAt(index);
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'EnterSrNumber'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    final cameraIcon = InkWell(
      child: Padding(
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Icon(Icons.camera_alt, color: Colors.white)),
      onTap: () {
        startScanBtnCall();
      },
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: isVerifyBtn
            ? LocaleUtils.getString(mContext, 'verify')
            : LocaleUtils.getString(mContext, 'Save'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (inwardScanList.isEmpty) {
            showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return CustomAlertDialog(
                  content: LocaleUtils.getString(
                      mContext, 'YouHaveNotScannedAnyLabelYet'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                );
              },
            );
          } else {
            var json =
            jsonEncode(inwardScanList.map((e) => e.toJson()).toList());
            String jsonFull = '{"Sticker_Details":$json}';
            print(jsonFull);
            if (isVerifyBtn) {
              apiCall(1, jsonFull);
            } else {
              apiCall(2, jsonFull);
            }
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          FocusScope.of(mContext).requestFocus(FocusNode());
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              FocusScope.of(mContext).requestFocus(FocusNode());
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, subTitle, topHeaderImage, 0),
                        CustomTopHeaderBarForInward(
                            stage: SUB_HEADER_INWARD_SCAN),
                        Container(
                          margin:
                          const EdgeInsets.only(top: 20, right: 20, left: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Form(
                                  key: _formKey,
                                  autovalidate: _autoValidate,
                                  child: Container(
                                    height: 42,
                                    width: screenSize.width,
                                    padding:
                                    const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: serialNumberTxt,
                                  ),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                child: addButton,
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                height: 45,
                                decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  color: const Color(colorPrimary),
                                ),
                                child: cameraIcon,
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: const Color(bgColor),
                            child: Card(
                              elevation: 7,
                              margin: const EdgeInsets.only(
                                  top: 10, right: 15, left: 15),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Container(
                                    height: 40,
                                    padding: const EdgeInsets.only(left: 10),
                                    alignment: Alignment.centerLeft,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary)),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'ScannedSrNo'),
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w300,
                                        fontFamily: 'helvetica',
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  isStickerSelected()
                                      ? Container(
                                      color: const Color(colorAccent),
                                      height: 40,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Expanded(
                                              child: InkWell(
                                                child: Center(
                                                  child: Container(
                                                    width: 27,
                                                    height: 27,
                                                    decoration: BoxDecoration(
                                                        color: isSelectAll
                                                            ? const Color(
                                                            colorPrimary)
                                                            : const Color(
                                                            colorAccent),
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            color: const Color(
                                                                colorPrimary),
                                                            width: 1)),
                                                    child: isSelectAll
                                                        ? Icon(
                                                      Icons.done,
                                                      size: 15.0,
                                                      color: Colors.white,
                                                    )
                                                        : Container(),
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll(false);
                                                  }
                                                },
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                child: Text(
                                                  LocaleUtils.getString(
                                                      mContext, 'select_all'),
                                                  style: TextStyle(
                                                    fontSize: 15.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: 'helvetica',
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                  textAlign: TextAlign.left,
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll(false);
                                                  }
                                                },
                                              ),
                                              flex: 2,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                onTap: () {
                                                  removeMultiSelectedSticker();
                                                },
                                                child: isStickerSelected()
                                                    ? Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Icon(
                                                    Icons.delete,
                                                    size: 25.0,
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                )
                                                    : Container(),
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ))
                                      : Container(),
                                  Expanded(
                                    child: Container(
                                      child: ListView.builder(
                                        itemCount: inwardScanList.length,
                                        shrinkWrap: true,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return !inwardScanList[index]
                                              .isDeleted
                                              ? InkWell(
                                              onTap: () {
                                                if (isStickerSelected()) {
                                                  setSelection(index);
                                                }
                                              },
                                              onLongPress: () {
                                                setSelection(index);
                                              },
                                              child: Container(
                                                  color: Colors.white,
                                                  child: Column(
                                                    children: <Widget>[
                                                      Container(
                                                        height: 40,
                                                        width: screenSize.width,
                                                        color: inwardScanList[
                                                        index]
                                                            .isMultiDeleted
                                                            ? Colors.grey[200]
                                                            : Colors.white,
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: Center(
                                                                  child: inwardScanList[
                                                                  index]
                                                                      .isMultiDeleted
                                                                      ? Container(
                                                                    width:
                                                                    27,
                                                                    height:
                                                                    27,
                                                                    decoration:
                                                                    BoxDecoration(
                                                                      color:
                                                                      const Color(
                                                                          colorPrimary),
                                                                      shape:
                                                                      BoxShape
                                                                          .circle,
                                                                      //borderRadius: BorderRadius.all(Radius.circular(10))
                                                                    ),
                                                                    child:
                                                                    Icon(
                                                                      Icons
                                                                          .done,
                                                                      size:
                                                                      15.0,
                                                                      color:
                                                                      Colors
                                                                          .white,
                                                                    ),
                                                                  )
                                                                      : Text(
                                                                      '#${(index +
                                                                          1)}',
                                                                      style:
                                                                      TextStyle(
                                                                        fontSize:
                                                                        14.0,
                                                                        fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                        fontFamily:
                                                                        'helvetica',
                                                                        color: inwardScanList[index]
                                                                            .fk_StickerGlCode >
                                                                            0
                                                                            ? inwardScanList[index]
                                                                            .chrValid
                                                                            .contains(
                                                                            'N')
                                                                            ? Colors
                                                                            .red
                                                                            : Colors
                                                                            .black
                                                                            : const Color(
                                                                            colorPrimary),
                                                                      ))),
                                                              flex: 1,
                                                            ),
                                                            Expanded(
                                                              child: Align(
                                                                child: Text(
                                                                    inwardScanList[index]
                                                                        .intPalletStickerCount >
                                                                        0
                                                                        ? '${inwardScanList[index]
                                                                        .varSticker} - ${inwardScanList[index]
                                                                        .intPalletStickerCount}'
                                                                        : '${inwardScanList[index]
                                                                        .varSticker}',
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                        14.0,
                                                                        fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                        fontFamily:
                                                                        'helvetica',
                                                                        color: inwardScanList[index]
                                                                            .fk_StickerGlCode >
                                                                            0
                                                                            ? inwardScanList[index]
                                                                            .chrValid
                                                                            .contains(
                                                                            'N')
                                                                            ? Colors
                                                                            .red
                                                                            : Colors
                                                                            .black
                                                                            : const Color(
                                                                            colorPrimary))),
                                                                alignment: Alignment
                                                                    .centerLeft,
                                                              ),
                                                              flex: 2,
                                                            ),
                                                            Expanded(
                                                              child: !isStickerSelected()
                                                                  ? Align(
                                                                child:
                                                                GestureDetector(
                                                                  child: Icon(
                                                                      Icons
                                                                          .delete,
                                                                      color: inwardScanList[index]
                                                                          .fk_StickerGlCode >
                                                                          0
                                                                          ? inwardScanList[index]
                                                                          .chrValid
                                                                          .contains(
                                                                          'N')
                                                                          ? Colors
                                                                          .red
                                                                          : Colors
                                                                          .black
                                                                          : const Color(
                                                                          colorPrimary)),
                                                                  onTap:
                                                                      () {
//                                                            isFocusNodeEnable = false;
                                                                    removeSticker(
                                                                        index);
                                                                  },
                                                                ),
                                                                alignment:
                                                                Alignment
                                                                    .center,
                                                              )
                                                                  : Container(),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      const Divider(
                                                          height: 3,
                                                          color: Colors.black),
                                                    ],
                                                  )))
                                              : Container();
                                        },
                                      ),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: screenSize.width,
                          height: 45,
                          child: saveButton,
                          margin: const EdgeInsets.all(15),
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (apiCallType == 1) {
          inwardScanList.clear();
          inwardScanList.addAll(responseModel.getInwardScanRecords());
          checkBreakSticker(inwardScanList);
          isVerifyBtn = false;
          if (mounted) {
            setState(() {});
          }
        } else if (apiCallType == 2) {
          redirectInwardConfirmScreen();
        }
      } else {
        if (apiCallType == 3) {
          redirectInwardConfirmScreen();
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      }
    }
  }

  void checkBreakSticker(List<InwardScanModel> mData) {
    if (mData.isNotEmpty) {
      int lengths = mData.length;
      int fkPalletGlCode = 0;
      bool isShowDialog = true;
      for (int i = 0; i < lengths; i++) {
        InwardScanModel inwardScanModel = mData[i];
        if (inwardScanModel.chrValid == 'Y' &&
            inwardScanModel.chrType == 'S' &&
            inwardScanModel.chrBreakConfirm == 'N' &&
            inwardScanModel.chrBreak == 'Y') {
          fkPalletGlCode = inwardScanModel.fk_PalletGlCode;

          if (isShowDialog) {
            isShowDialog = false;
            showDialog<Map>(
              barrierDismissible: false,
              context: mContext,
              builder: (context) {
                return WillPopScope(
                  // ignore: missing_return
                    onWillPop: () {},
                    child: CustomAlertDialog(
                      content:
                      '${LocaleUtils.getString(
                          mContext, 'pallet_break_first')} ${inwardScanModel
                          .varSticker} ${LocaleUtils.getString(
                          mContext, 'pallet_break_second')}',
                      title: PROJECT_NAME == 'BASF_HK'
                          ? BASF_HK_APP_Name
                          : Zydus_APP_Name,
                      isShowNagativeButton: true,
                      textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                      textPositiveButton:
                      LocaleUtils.getString(mContext, 'yes'),
                      onPressedNegative: () {
                        removeStickerInList(fkPalletGlCode);
                      },
                      onPressedPositive: () {
                        updateStickerInList(fkPalletGlCode);
                      },
                    ));
              },
            );
          }
        }
      }
    }
  }

  void removeStickerInList(int fkPalletGlCode) {
    if (inwardScanList.isNotEmpty) {
      for (int i = (inwardScanList.length - 1); i >= 0; i--) {
        InwardScanModel inwardScanModel = inwardScanList[i];
        if (inwardScanModel.fk_PalletGlCode == fkPalletGlCode) {
          inwardScanList.removeAt(i);
        }
      }
      if (mounted) {
        setState(() {});
      }
    }
  }

  void updateStickerInList(int fkPalletGlCode) {
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        InwardScanModel inwardScanModel = inwardScanList[i];
        if (inwardScanModel.fk_PalletGlCode == fkPalletGlCode) {
          inwardScanList.removeAt(i);
          inwardScanModel.chrBreakConfirm = 'Y';
          inwardScanList.insert(i, inwardScanModel);
        }
      }
    }
    if (mounted) {
      setState(() {});
    }
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void _showSnackBar(String text) {
    Flushbar(
      message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
