import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Forgot.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/FooterWidgets.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/FirstTimeChangePassResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/dimens.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

const SUCCESS = 'Success', FAIL = 'Fail';

class FirstTimeChangePassword extends StatefulWidget {
  @override
  _FirstTimeChangePasswordState createState() =>
      _FirstTimeChangePasswordState();
}

//const PASSWORD_PATTERN = '((?=.*[a-z])(?=.*\d)(?=.*[A-Z])(?=.*[@!%*?&]).{8,40})';
const PASSWORD_PATTERN =
    '(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@%^&*-]).{8,}';

class _FirstTimeChangePasswordState extends State<FirstTimeChangePassword>
    implements WSInterface {
  _FirstTimeChangePasswordState() {
    wsPresenter = WSPresenter(this);
  }


  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _autoValidate = false, _loading = false;
  bool _obscureOldPassText = true,
      _obscureNewPassText = true,
      _obscureConfirmPassText = true;
  Size screenSize;
  String oldPassword, newPassword, confirmPassword;
  Utils mUtils;
  SharedPrefs sharedPrefs;
  WSPresenter wsPresenter;
  ProgressHUD _progressHUD;
  EcpSyncPlugin _battery;

  RegExp regExp = RegExp(
    PASSWORD_PATTERN,
    caseSensitive: true,
    multiLine: false,
  );

  BuildContext mContext;

  // Toggles the password show status
  void _toggleOldPassword() {
    if (mounted) {
      setState(() {
        _obscureOldPassText = !_obscureOldPassText;
      });
    }
  }

  void _toggleNewPassword() {
    if (mounted) {
      setState(() {
        _obscureNewPassText = !_obscureNewPassText;
      });
    }
  }

  void _toggleConfirmPassword() {
    if (mounted) {
      setState(() {
        _obscureConfirmPassText = !_obscureConfirmPassText;
      });
    }
  }

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(context, 'loading_dot'),
      loading: _loading,
    );
  }

  void _changePasswordnCall() async {
    FocusScope.of(context).requestFocus(FocusNode());

    int fkLanguageCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);

    await _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          sharedPrefs.getString(PREF_USER_ID).then((String userID) {
            _battery.getUniqueNumber().then((String syncCode) {
              mUtils
                  .encryptPassword(oldPassword, syncCode)
                  .then((String oldPass) {
                mUtils
                    .encryptPassword(newPassword, syncCode)
                    .then((String newPass) {
                  var param = Map();
                  param[PARAM_USERNAME] = userID;
                  param[PARAM_OLD_PASSWORD] = oldPass;
                  param[PARAM_NEW_PASSWORD] = newPass;
                  param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                      ? SUB_MODULE_NAME_ANDROID
                      : SUB_MODULE_NAME_IOS;
                  param[PARAM_VERSION] = APP_VERSION;
                  param[PARAM_LANGUAGE_ID] = fkLanguageCode.toString() != null
                      ? fkLanguageCode.toString()
                      : '0';
                  sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                    param[PARAM_DEVICE_ID] = deviceid;
                    print(param);
                    wsPresenter.callAPI(POST_METHOD, CHANGE_PASSWORD, param);
                  });
                });
              });
            });
          });
        });
      } else {
        //_showSnackBar('No Internet Connection');
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(context, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(context, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
        //_showErrorAlert(APP_Name, 'No Internet Connection', FAIL,'','OK',false);
      }
    });
  }

  void _showSnackBar(String text) {
    scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void backNavigationPage() {
    Navigator.of(context).pop();
  }

  void forgotNavigationPage() {
//    Navigator.of(context).pushNamed(FORGOT_SCREEN);
    final Route route = CupertinoPageRoute(builder: (context) => Forgot());
    Navigator.push(mContext, route);
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      if (oldPassword != newPassword) {
        if (newPassword == confirmPassword) {
          if (regExp.hasMatch(newPassword)) {
            _changePasswordnCall();
          } else {
            _showSnackBar(LocaleUtils.getString(
                context, 'password_must_be_at_least_8_character'));
          }
        } else {
          _showSnackBar(
              LocaleUtils.getString(context, 'new_password_does_not_match'));
        }
      } else {
        _showSnackBar(LocaleUtils.getString(
            context, 'your_old_and_new_password_can_not_be_same'));
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  /*void _showErrorAlert(String title, String content, String passFlag,
      String textNagativeButton, String textPositiveButton,
      bool isShowNagativeButton) {
    showDialog<Map>(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return CustomAlertDialog(
          content: content,
          title: title,
          isShowNagativeButton: isShowNagativeButton,
          textNagativeButton: textNagativeButton,
          textPositiveButton: textPositiveButton,
          onPressedNegative: () {
            onDialogNagativeButton(passFlag);
          },
          onPressedPositive: () {
            onDialogPositiveButton(passFlag);
          },
        );
      },
    );
  }

  void onDialogNagativeButton(String passFlag) {
    print('==========onDialogNagativeButton============$passFlag');
    if (passFlag.contains(SUCCESS)) {

    } else if (passFlag.contains(FAIL)) {

    } else {

    }
  }

  void onDialogPositiveButton(String passFlag) {
    print('==========onDialogPositiveButton============$passFlag');
    if (passFlag.contains(SUCCESS)) {

    } else if (passFlag.contains(FAIL)) {

    } else {

    }
  }*/

  @override
  void initState() {
    super.initState();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    _battery = EcpSyncPlugin();

//    try {
//      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
//        final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
//        _firebaseMessaging.configure(
//          onMessage: (Map<String, dynamic> message) async {
//            print('onMessage: $message');
//            //_showItemDialog(message);
//            if (message.containsKey('notification')) {
//              final PushNotificationModel items =
//                  PushNotificationModel.fromMap(message);
//              print('======notification======={$items}');
//              //_showNotification(items.title, items.body);
//            }
//          },
//          onLaunch: (Map<String, dynamic> message) async {
//            print('onLaunch: $message');
//            //_navigateToItemDetail(message);
//          },
//          onResume: (Map<String, dynamic> message) async {
//            print('onResume: $message');
//            //_navigateToItemDetail(message);
//          },
//        );
//        _firebaseMessaging.requestNotificationPermissions(
//            const IosNotificationSettings(
//                sound: true, badge: true, alert: true));
//        _firebaseMessaging.onIosSettingsRegistered
//            .listen((IosNotificationSettings settings) {
//          print('Settings registered: $settings');
//        });
//        _firebaseMessaging.getToken().then((String token) {
//          assert(token != null);
//          /*setState(() {
//        final String _homeScreenText = 'Push Messaging token: $token';
//        print(_homeScreenText);
//      });*/
//          //print(_homeScreenText);
//        });
//      }
//    } catch (e) {
//      print(e);
//    }

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        //BaseClassChina().initilizeFirebase(pus)
      }
    } catch (e) {
      print(e);
    }

    _initLoading();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final oldPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      /*validator: (val) => val.length < 6 ? 'Password too short.' : null,
      onSaved: (val) => _password = val,*/
      validator: (String arg) {
        //if (arg.length < 1)
        if (arg.isEmpty)
          return LocaleUtils.getString(
              context, 'please_enter_your_old_password');
        else
          return null;
      },
      onSaved: (String val) {
        oldPassword = val;
      },
      obscureText: _obscureOldPassText,
      style: inputTextStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 'old_password'),
        contentPadding: const EdgeInsets.fromLTRB(0, p_15, 0, 0),
        errorStyle: errorStyle,
        prefixIcon: const Icon(Icons.lock, color: Colors.white),
        suffixIcon: IconButton(
            icon: Icon(
              _obscureOldPassText ? Icons.visibility_off : Icons.visibility,
              color: Colors.white,
            ),
            onPressed: _toggleOldPassword),
        hintStyle: TextStyle(color: Colors.grey[400]),
        focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey[100])),
        enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: const Color(colorAccent))),
      ),
    );

    final newPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      /*validator: (val) => val.length < 6 ? 'Password too short.' : null,
      onSaved: (val) => _password = val,*/
      validator: (String arg) {
        //if (arg.length < 1) {
        if (arg.isEmpty) {
          return LocaleUtils.getString(
              context, 'please_enter_your_new_password');
        } else {
          return null;
        }
      },
      onSaved: (String val) {
        newPassword = val;
      },
      obscureText: _obscureNewPassText,
      style: inputTextStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 'new_password'),
        contentPadding: const EdgeInsets.fromLTRB(0, p_15, 0, 0),
        errorStyle: errorStyle,
        prefixIcon: const Icon(Icons.lock, color: Colors.white),
        suffixIcon: IconButton(
            icon: Icon(
              _obscureNewPassText ? Icons.visibility_off : Icons.visibility,
              color: Colors.white,
            ),
            onPressed: _toggleNewPassword),
        hintStyle: TextStyle(color: Colors.grey[400]),
        focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey[100])),
        enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: const Color(colorAccent))),
      ),
    );

    final confirmPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      validator: (String arg) {
        // if (arg.length < 1) {
        if (arg.isEmpty) {
          return LocaleUtils.getString(
              context, 'please_enter_your_confirm_password');
        } else {
          return null;
        }
      },
      onSaved: (String val) {
        confirmPassword = val;
      },
      obscureText: _obscureConfirmPassText,
      style: inputTextStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 're_enter_password'),
        contentPadding: const EdgeInsets.fromLTRB(0, p_15, 0, 0),
        errorStyle: errorStyle,
        prefixIcon: const Icon(Icons.lock, color: Colors.white),
        suffixIcon: IconButton(
            icon: Icon(
              _obscureConfirmPassText ? Icons.visibility_off : Icons.visibility,
              color: Colors.white,
            ),
            onPressed: _toggleConfirmPassword),
        hintStyle: TextStyle(color: Colors.grey[400]),
        focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey[100])),
        enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: const Color(colorAccent))),
      ),
    );

    final welcomeText = Padding(
      padding: const EdgeInsets.only(top: p_100),
      child: Text(
        LocaleUtils.getString(context, 'ChangePassword'),
        style: TextStyle(
          fontSize: 24.0,
          fontWeight: FontWeight.w400,
          fontFamily: 'helvetica',
          color: Colors.white,
        ),
        textAlign: TextAlign.left,
      ),
    );

    final loginButton = Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(context, 'ChangePassword'),
        buttonColor: const Color(colorAccent),
        textColor: Colors.black,
        onTap: _validateInputs,
      ),
    );

    return Scaffold(
        key: scaffoldKey,
        bottomNavigationBar: Container(
          height: p_45,
          child: FooterWidgets(),
        ),
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              Container(
                width: screenSize.width,
                height: screenSize.height,
                decoration: BoxDecoration(color: const Color(colorPrimary)),
                child: Column(
                  children: <Widget>[
                    Expanded(
                      child: SingleChildScrollView(
                        child: Form(
                          child: Container(
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 50),
                                  child: GestureDetector(
                                    child: const Icon(Icons.arrow_back,
                                        color: Colors.white, size: 30),
                                    onTap: backNavigationPage,
                                  ),
                                ),
                                Image.asset(
                                    PROJECT_NAME == 'BASF_HK'
                                        ? 'assets/basf_appicon.png'
                                        : 'assets/zydus_appicon.png',
                                    width: p_100,
                                    height: p_100),
                                welcomeText,
                                //pleaseLoginAccessText,
                                Padding(
                                  padding: const EdgeInsets.only(top: p_50),
                                  child: oldPasswordTxt,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: p_15),
                                  child: newPasswordTxt,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: p_15),
                                  child: confirmPasswordTxt,
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: p_15),
                                  child: loginButton,
                                )
                              ],
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                            ),
                            padding: const EdgeInsets.fromLTRB(
                                p_25, p_40, p_25, p_40),
                            alignment: Alignment.topLeft,
                          ),
                          autovalidate: _autoValidate,
                          key: _formKey,
                        ),
                        scrollDirection: Axis.vertical,
                        controller: ScrollController(),
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
              _progressHUD,
            ],
          ),
        ));
//        child:
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();

    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content: errorTxt,
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(context, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            ));
      },
    );
    //_showErrorAlert(APP_Name, errorTxt, FAIL, '', 'OK', false);
  }

  @override
  void onLoginSuccess(String response) {
    _loading = false;
    dismissProgressHUD();

    print(response);
    final dynamic jsonResponse = json.decode(response.toString().trim());
    final FirstTimeChangePassResponseModel responseModel =
        FirstTimeChangePassResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      /* Success Response. */
      sharedPrefs.setString(PREF_USER_ID, '').then((bool isGender) {
        navigationPage(responseModel.Message, true);
      });
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  sharedPrefs.setString(PREF_USER_ID, '').then((bool isGender) {
                    navigationPage(responseModel.Message, false);
                  });
                },
              ));
        },
      );
    } else {
      /* Show error dialog. */
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {},
              ));
        },
      );
      //_showErrorAlert(APP_Name, responseModel.Message, FAIL, '', 'OK', false);
    }
  }

  void navigationPage(String message, bool isShowDialog) {
    if (isShowDialog) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: message,
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  Navigator.of(context).pop();
                },
              ));
        },
      );
    } else {
      Navigator.of(context).pop();
    }
  }
}
