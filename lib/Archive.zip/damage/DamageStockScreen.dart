import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/MyStockInfoModel.dart';
import 'package:flutter_basf_hk_app/notifications/NotificationScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';

class DamageStockScreen extends StatefulWidget {
  @override
  DamageStockScreenState createState() => DamageStockScreenState();
}

class DamageStockScreenState extends State<DamageStockScreen>
    implements PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Size screenSize;
  String userName, subTitle, doNo;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  List<MyStockInfoModel> listDisplay = List();
  List<MyStockInfoPopupModel> listDialogDisplay = List();
  bool loadingFlag = false, isNotification = false, isSync = false;
  final TextEditingController _search_controller = TextEditingController();
  String displayDateFormat = '';
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    _battery = EcpSyncPlugin();
    subTitle = LocaleUtils.getString(mContext, 'DamageStock');
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });

    sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_DEFAULT_FORMAT;
          }
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData('');

  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  void getData(String values) {
    if (mounted) {
      setState(() {
        loadingFlag = true;
      });
    }
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
      databaseHelper.getDamageList(initCode, values).then((var custTypeList) {
        print('------custTypeList--------${custTypeList.length}');
        listDisplay.clear();
        if (mounted)
          // ignore: curly_braces_in_flow_control_structures
          setState(() {
            loadingFlag = false;
            listDisplay.addAll(custTypeList);
          });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      floatingActionButton: SpeedDial(
        // both default to 16
        marginRight: 18,
        marginBottom: 20,
        //animatedIcon: AnimatedIcons.menu_close,
        animatedIconTheme: const IconThemeData(size: 22.0),
        // this is ignored if animatedIcon is non null
        // child: Icon(Icons.add),
        child: Container(
          child: Image.asset(
            'assets/qrcode_icon.png',
            color: Colors.white,
            height: 25,
            width: 25,
          ),
        ),
        visible: true,
        curve: Curves.bounceIn,
        overlayColor: Colors.black,
        overlayOpacity: 0.5,
        //tooltip: LocaleUtils.getString(mContext, 'SpeedDial'),
        heroTag: 'speed-dial-hero-tag',
        backgroundColor: const Color(colorPrimary),
        foregroundColor: Colors.black,
        elevation: 8.0,
        shape: CircleBorder(),
        children: [
          SpeedDialChild(
              child: const Icon(Icons.add, color: Colors.white),
              backgroundColor: Colors.green[900],
              label: LocaleUtils.getString(mContext, 'AddDamage'),
              labelBackgroundColor: Colors.black,
              labelStyle: TextStyle(
                fontSize: 15.0,
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
              onTap: () {
                sharedPrefs
                    .setString(PREF_SCREEN_STATE, TAG_ADD_DAMAGE_STOCK)
                    .then((isBool) {
                  _battery.getUniqueNumber().then((String uniqueNumber) {
                    sharedPrefs
                        .setString(PREF_DAMAGE_TRANS_CODE, uniqueNumber)
                        .then((bool isAdd) {
//                      Navigator.of(mContext).pushReplacementNamed(SCANNING_SCREEN);
                      final Route route = CupertinoPageRoute(
                          builder: (context) => ScanningScreen());
                      Navigator.pushReplacement(mContext, route);
                    });
                  });
                });
              }),
          SpeedDialChild(
            child: const Icon(Icons.delete, color: Colors.white),
            backgroundColor: Colors.red[900],
            label: LocaleUtils.getString(mContext, 'RemoveDamage'),
            labelBackgroundColor: Colors.black,
            labelStyle: TextStyle(
              fontSize: 15.0,
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
            onTap: () {
              sharedPrefs
                  .setString(PREF_SCREEN_STATE, TAG_REMOVE_DAMAGE_STOCK)
                  .then((isBool) {
                _battery.getUniqueNumber().then((String uniqueNumber) {
                  sharedPrefs
                      .setString(PREF_DAMAGE_TRANS_CODE, uniqueNumber)
                      .then((bool isAdd) {
//                    Navigator.of(mContext).pushReplacementNamed(SCANNING_SCREEN);
                    final Route route = CupertinoPageRoute(
                        builder: (context) => ScanningScreen());
                    Navigator.pushReplacement(mContext, route);
                  });
                });
              });
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(
                      userName,
                      LocaleUtils.getString(mContext, 'DamageStock'),
                      'assets/damaged_icon.png',
                      0),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.only(top: 1),
                    child: Container(
                      height: 40,
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(7)),
                          color: Colors.white),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: _search_controller,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: TextStyle(color: Colors.grey[700]),
                                  hintText: LocaleUtils.getString(
                                      mContext, 'SearchArticle'),
                                  counterText: '',
                                ),
                                onChanged: (value) {
                                  filterSearchResults(
                                      value.trim().toLowerCase());
                                },
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {
                                  // _search_controller.clear();
                                },
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                      flex: 1,
                      child: !loadingFlag
                          // ? listDisplay.length > 0
                          ? listDisplay.length > 0
                              ? Container(
                                  color: const Color(bgColor),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    itemBuilder: (context, position) {
                                      return GestureDetector(
                                          child: Card(
                                            elevation: 4,
                                            margin: const EdgeInsets.only(
                                                left: 15,
                                                top: 10,
                                                right: 15,
                                                bottom: 7),
                                            child: Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceEvenly,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                12.0,
                                                                12.0,
                                                                12.0,
                                                                3.0),
                                                        child: Text(
                                                          listDisplay[position]
                                                              .varProduct_SKU_Name,
                                                          style: prifixTxtStyle,
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                    .fromLTRB(
                                                                12.0,
                                                                3.0,
                                                                12.0,
                                                                12.0),
                                                        child: Text(
                                                          LocaleUtils.getString(
                                                                  mContext,
                                                                  'Units_') +
                                                              '${listDisplay[position]
                                                                  .totalUnit
                                                                  .toStringAsFixed(
                                                                  2)}  ${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'Qty')}.(${globals
                                                                  .KG_PCS}.): ${listDisplay[position]
                                                                  .qtyKG > 0
                                                                  ? listDisplay[position]
                                                                  .qtyKG
                                                                  .toStringAsFixed(
                                                                  2)
                                                                  : '0.00'}',
                                                          style: prifixTxtStyle,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                ),
                                                const Align(
                                                  alignment:
                                                      Alignment.centerRight,
                                                  child: Padding(
                                                    padding:
                                                        EdgeInsets.all(8.0),
                                                    child: Icon(
                                                      Icons.info,
                                                      size: 25.0,
                                                      color: Colors.orange,
                                                    ),
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                          onTap: () {
                                            getPopupRecords(
                                                listDisplay[position]);
                                          });
                                    },
                                    itemCount: listDisplay.length,
                                  ),
                                )
                              : Visibility(
                                  child: Container(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/nodata_icon.png',
                                          height: 100,
                                          width: 100,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10),
                                          child: Text(
                                            LocaleUtils.getString(mContext,
                                                'NoDamageStockAvailable'),
                                            style: prifixTxtStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  visible:
                                      listDisplay.length == 0 ? true : false,
                                  //listDisplay.length <= 0 ? true : false,
                                )
                          : const Center(
                              child: CircularProgressIndicator(
                                  valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(colorPrimary))),
                            )),
                ],
              ),
            ),
          ],
        ),
      ),
        ));
  }

  void filterSearchResults(String query) {
    print(query);
    getData(query);
  }

  void getPopupRecords(MyStockInfoModel data) {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
      print(
          '======fk_Product_SKU_Glcode=======${data.fk_Product_SKUGlCode.toString()}');
      databaseHelper
          .getDamageStockPopupList(
              initCode, data.fk_Product_SKUGlCode.toString())
          .then((var custTypeList) {
        listDialogDisplay.clear();
        listDialogDisplay.addAll(custTypeList);
        _displayDialog(context, data);
      });
    });
  }

  _displayDialog(BuildContext context, MyStockInfoModel data) async {
    return showDialog<Map>(
        context: context,
        builder: (context) {
          return AlertDialog(
              contentPadding: EdgeInsets.all(0.0),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(5.0))),
              //title:  Text('Alert Dialog title'),
              content: Container(
                width: screenSize.width * 0.9,
                height: screenSize.height * 0.6,
                //height: 200,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      width: screenSize.width,
                      height: 40,
                      padding: EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        child: MarqueeWidget(
                            direction: Axis.horizontal,
                            child: Text(
                                data.varProduct_SKU_Code.isNotEmpty
                                    ? data.varProduct_SKU_Code +
                                        '-' +
                                        data.varProduct_SKU_Name
                                    : data.varProduct_SKU_Name,
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500,
                                    fontFamily: 'helvetica',
                                    color: Colors.white))),
                        alignment: Alignment.center,
                      ),
                    ),
                    Container(
                      height: 35,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'BatchNo'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'ExpiryDate'),
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  LocaleUtils.getString(mContext, 'Units'),
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Wrap(
                              direction: Axis.horizontal,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              alignment: WrapAlignment.center,
                              children: <Widget>[
                                Text(
                                  '${LocaleUtils.getString(
                                      mContext, 'Qty')}.(${globals.KG_PCS}.)',
                                  style: TextStyle(
                                    fontSize: 13.0,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'helvetica',
                                    color: const Color(colorPrimary),
                                  ),
                                ),
                              ],
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      color: Color(colorAccent),
                      height: 1,
                      //margin: EdgeInsets.only(top: 7),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: listDialogDisplay.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          //return listDialogDisplay.length > 0
                          return listDialogDisplay.isNotEmpty
                              ? Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: <Widget>[
                                    Container(
                                      height: 35,
                                      width: screenSize.width,
                                      child: Padding(
                                        padding:
                                            EdgeInsets.only(top: 0, bottom: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceAround,
                                          children: <Widget>[
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    listDialogDisplay[index]
                                                        .varBatchNo
                                                        .toString(),
                                                    style: TextStyle(
                                                      fontSize: 13.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: 'helvetica',
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                    mUtils
                                                        .convertDateTimeDisplay1(
                                                            listDialogDisplay[
                                                                    index]
                                                                .dtExpiryDate,
                                                            displayDateFormat),
                                                    style: TextStyle(
                                                      fontSize: 13.0,
                                                      fontWeight:
                                                          FontWeight.w500,
                                                      fontFamily: 'helvetica',
                                                    ),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                      listDialogDisplay[index]
                                                          .decQty
                                                          .toStringAsFixed(2),
                                                      style: TextStyle(
                                                        fontSize: 13.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: 'helvetica',
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: Wrap(
                                                direction: Axis.horizontal,
                                                crossAxisAlignment:
                                                    WrapCrossAlignment.center,
                                                alignment: WrapAlignment.center,
                                                children: <Widget>[
                                                  Text(
                                                      listDialogDisplay[index]
                                                                  .qtyKG >
                                                              0
                                                          ? listDialogDisplay[
                                                                  index]
                                                              .qtyKG
                                                              .toStringAsFixed(
                                                                  2)
                                                          : '0.00',
                                                      style: TextStyle(
                                                        fontSize: 13.0,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                        fontFamily: 'helvetica',
                                                      )),
                                                ],
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      width: screenSize.width,
                                      color: Color(colorAccent),
                                      height: 1,
                                      //margin: EdgeInsets.only(top: 7),
                                    ),
                                    //Divider(color: Colors.black26),
                                  ],
                                )
                              : Container();
                        },
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Close'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
              //actions: _actionButton()
              );
        });
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
