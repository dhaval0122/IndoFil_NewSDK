import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';

abstract class WSInterface {
  void onLoginSuccess(String response);
  void onLoginError(String errorTxt);
}


abstract class PushNotificationListener {
  void onLoadNotificationCount(String response);
}

abstract class ItemClickSearchableSpinner {
  void onItemClickSearchableSpinner(SpinnerModel model);
}