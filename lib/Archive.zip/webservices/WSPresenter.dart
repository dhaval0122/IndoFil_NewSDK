import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WebServiceAPI.dart';

class WSPresenter {
  WSPresenter(this.wsInterface);

  WSInterface wsInterface;
  WebServiceAPI webServiceAPI = WebServiceAPI();

  void callAPI(bool isGetMethod, String url, Map param) {
    webServiceAPI.doProcess(isGetMethod, url, param).then((String response) {
      if (response != null) {
        wsInterface.onLoginSuccess(response);
      } else {
        wsInterface
            .onLoginError('102-Server not responding, Please try again..');
      }
    }).catchError((Object error) {
      print('======ERROR=====$error');
      wsInterface.onLoginError('102-Server not responding, Please try again..');
    });
  }
}
