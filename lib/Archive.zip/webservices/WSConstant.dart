
/* DEV URL */
const APP_VERSION = '18.0.11';
const BASE_URL = 'http://172.16.8.198/';
const MODULE = 'BASF_HK_Webservice/Services.asmx/';

/* IQA URL */
//const APP_VERSION = '19.4.3';
//const BASE_URL = 'http://172.16.9.6/';
//const MODULE = 'BASF_HK_Webservice_IQA/Services.asmx/';

/* CQA URL */
//const APP_VERSION = '19.3.5';
//const BASE_URL = 'https://cqa-basf-dlite3-fulfil.ecubix.com/';
//const MODULE = 'service/services.asmx/';

/* PAS URL */
//const APP_VERSION = '19.3.0';
//const BASE_URL = 'https://basf-dlite3-fulfil.ecubix.com/';
//const MODULE = 'service/services.asmx/';

/* WAF URL */
//const APP_VERSION = '19.2.1';
//const BASE_URL = 'https://hk-waf.ecubix.com:8443/';
//const MODULE = 'services/services.asmx/';

/*
*
* Zydus URL Link
*
* */

/* IQA URL */
//const APP_VERSION = '19.4.3';
//const BASE_URL = 'http://172.16.9.18/';
//const MODULE = 'ZYDUS_RE_PLUS_Webservice_IQA/services.asmx/';

/* CQA URL */
//const APP_VERSION = '19.3.2';
//const BASE_URL = 'https://cqa-zydus-tnt.ecubix.com/';
//const MODULE = 'service/services.asmx/';

/* PAS URL */
//const APP_VERSION = '19.3.3';
//const BASE_URL = 'https://zydus-tnt.ecubix.com/';
//const MODULE = 'service/services.asmx/';

const SUB_MODULE_NAME_ANDROID = 'BASF_HK_FLUTTER_ANDROID';
const SUB_MODULE_NAME_IOS = 'BASF_HK_FLUTTER_IOS';

const PROJECT_NAME = "BASF_HK";
//const PROJECT_NAME = "Zydus";

const int EditTxtMaxLengths = 50;
const int RemarksMaxLengths = 120;

const GET_METHOD = true;
const POST_METHOD = false;

const LOGIN = 'Login';
const CHECK_VERSION = 'CheckVersion';
const FORGOT = 'ForgotPassword';
const CHANGE_PASSWORD = 'ChangePassword';
const APPLICATION_AGREEMENT = 'ApplicatioAgreement';
const DASHBOARD_FILTER = 'DashboardFilter';
const DISPATCH_SUMMARY = 'DispatchSummary';
const STOCK_SUMMARY = 'StockSummary';
const EXPIRY_VISIBILITY = 'ExpiryVisibility';
const FORECAST_ACTUAL = 'ForecastVSActual';
const SYNCHRONIZE_DATABASE = 'SynchronizeDatabase';
const SYNCHRONIZE_FILE = 'SynchronizeFile';
const SYNCHRONIZE_LOG = 'DeviceSyncLog';
const DATE_VALIDATION = 'DateValidation';
const EDIT_DO = 'Edit_DO';
const NOTIFICATION = 'Notification';
const USER_PROFILE_SETTING = 'UserProfileSetting';
const LANGUAGE_DETAILS = 'LanguageDetails';
const SALES_INWARD = 'Sales_Inward';

const PARAM_USERNAME = 'UserName';
const PARAM_PASSWORD = 'Password';
const PARAM_SUB_MODULE_NAME = 'SubModuleName';
const PARAM_VERSION = 'Version';
const PARAM_DEVICE_ID = 'DeviceId';
const PARAM_IS_VERSION_CHECK = 'IsVersionCheck';
const PARAM_FCM_TOKEN = 'FCMToken';
const PARAM_API_TOKEN = 'APIToken';
const PARAM_MONTH_NAME = 'MonthName';
const PARAM_DATE = 'Date';
const PARAM_LANGUAGE_ID = 'LanguageId';

const PARAM_LOGIN_ID = 'LoginId';
const PARAM_PERSON_ID = 'PersonId';
const PARAM_COUNTRY_ID = 'CountryID';
const PARAM_COUNTRY_TYPE_REGIONAL_ID = 'CustomerTypeRegionalId';
const PARAM_CUSTOMER_ID = 'CustomerId';
const PARAM_ACTION = 'Action';

const PARAM_OLD_PASSWORD = 'OldPassword';
const PARAM_NEW_PASSWORD = 'NewPassword';

const PARAM_AGREE_FORM = 'AgreeForm';

const SUB_HEADER_DISPATCH_FIRST = 'Dispatch_First';
const SUB_HEADER_SCANNING = 'Scanning';
const SUB_HEADER_DISPATCH_THIRD = 'Dispatch_Third';
const SUB_HEADER_CONGRATULATION = 'Congratulation';

const SUB_HEADER_INWARD_SCAN = 'Inward_Scan';
const SUB_HEADER_INWARD = 'Inward';
const SUB_HEADER_INWARD_CONGRATULATION = 'Inward_Congratulation';

/*
   * BASF-HK Date Format.
   * */
const String DATE_DEFAULT_FORMAT = 'MM/dd/yyyy';
const String TIME_DEFAULT_FORMAT = 'HH:mm:ss';
const String DATE_WITH_TIME_DEFAULT_FORMAT = 'MM/dd/yyyy HH:mm:ss';

/*
   * Zydus Date Format.
   * */
//const String DATE_DEFAULT_FORMAT = 'dd/MM/yyyy';
//const String TIME_DEFAULT_FORMAT = 'HH:mm:ss';
//const String DATE_WITH_TIME_DEFAULT_FORMAT = 'dd/MM/yyyy HH:mm:ss';

const String TAG_DISPATCH = 'Dispatch';
const String TAG_SALES_RETURN = 'Sales Return';
const String TAG_STOCK_TRANSFER = 'Stock Transfer';
String TAG_EDIT_DO = 'Edit DO';
const String TAG_ADD_DAMAGE_STOCK = 'Add Damage Stock';
const String TAG_REMOVE_DAMAGE_STOCK = 'Remove Damage Stock';
const String TAG_RECEIVE = 'Receive';
const String TAG_MY_STOCK_INFO = 'My Stock Info';
const String TAG_KNOW_YOUR_BOX = 'Know Your Box';
const String TAG_STOCK_VISIBILITY = 'Stock Visibility';
const String TAG_SALES_SUMMARY = 'Stock Summary';
const String TAG_SETTINGS = 'Settings';
const String TAG_AVAILABLE_TO_PROMISE = 'Available To Promise';
const String TAG_FOC = 'FOC';

const String CHIPhER_LAB = 'CipherLab';
String lang_change = 'en';

const String TAG_SCRAP_STOCK = 'Scrap Stock';
const String TAG_CONSUME_STOCK = 'Consume Stock';
