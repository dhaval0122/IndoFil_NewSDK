import 'dart:async';

import 'package:flutter_basf_hk_app/webservices/WebServiceMethod.dart';

class WebServiceAPI {
  final WebServiceMethod _netUtil = WebServiceMethod();

  Future<String> doProcess(bool isGetMethod, String url, Map params) {
    if (isGetMethod) {
      return _netUtil.get(url).then((dynamic res) {
        return res.toString();
      });
    } else {
      return _netUtil.post(url, body: params).then((dynamic res) {
        return res != null ? res.toString() : null;
      });
    }
  }
}
