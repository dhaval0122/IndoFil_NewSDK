import 'dart:async';
import 'dart:convert' show utf8;
import 'dart:convert';

import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:http/http.dart' as http;

class WebServiceMethod {
  // next three lines makes this class a Singleton
  static final WebServiceMethod _instance = WebServiceMethod.internal();

  WebServiceMethod.internal();

  factory WebServiceMethod() => _instance;

  //final JsonDecoder _decoder =  JsonDecoder();

  Future<dynamic> get(String url) {
    String URL = BASE_URL + MODULE + url;
    //print('======URL===GET====$URL');
    Future<dynamic> response;

    try {
      response = http.get(URL, headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded'
      }).then((http.Response response) {
        final String res = response.body;
        final int statusCode = response.statusCode;
        if (statusCode < 200 || statusCode > 400 || json == null) {
          //print('=========Exception===GET======');
          throw Exception('Error while fetching data');
        }
        return res;
      });
    } on TimeoutException {
      throw Exception('Timeout Exception!');
    }
    return response;
  }

  Future<dynamic> post(String url, {Map headers, body, encoding}) async {
    String URL = BASE_URL + MODULE + url;
    print('======URL====POST===$URL');
    try {
      final response = await http
          .post(URL,
              body: body,
              headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded',
              },
              encoding: Encoding.getByName('UTF-8'))
          .timeout(Duration(minutes: 6));
      if (response.statusCode == 200) {
        print('======response====== ' + utf8.decode(response.bodyBytes));
        return utf8.decode(response.bodyBytes);
      } else {
        print('======response====== ${response.body}');
        return null;
      }
    } on TimeoutException {
      return null;
    }
  }
}
