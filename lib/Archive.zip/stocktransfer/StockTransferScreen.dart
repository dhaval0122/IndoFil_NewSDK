import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/components/SearchableSpinner.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/AdvanceSearchScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class StockTransferScreen extends StatefulWidget {
  @override
  StockTransferScreenState createState() => StockTransferScreenState();
}

class StockTransferScreenState extends State<StockTransferScreen>
    implements PushNotificationListener, ItemClickSearchableSpinner {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  CountryMasterModel selectedCountryModel;
  CustomerTypeModel selectedCustomerTypeModel;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '', doNo;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  List<CountryMasterModel> countryList;
  List<CustomerTypeModel> customerTypeList;
  TextEditingController doTextController = TextEditingController();
  EcpSyncPlugin _battery;
  final FocusNode _donoFocus = FocusNode();
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    Route route = CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.pushReplacement(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    countryList = List();
    customerTypeList = List();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_STOCK_TRANSFER) {
        topHeaderImage = 'assets/stock_transfer_small_top.png';
      } else if (screenState.toUpperCase() == TAG_EDIT_DO.toLowerCase()) {
        topHeaderImage = 'assets/edit_do_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    databaseHelper.getCountryAllRecords().then((var couList) {
      print('=====countryList=====SIZE====${couList.length}');
      if (mounted) {
        setState(() {
          countryList.addAll(couList);

          sharedPrefs
              .getBool(PREF_CHANGE_DETAILS_STATE_BOOL)
              .then((bool isChangeState) {
            if (isChangeState) {
              getChangeDetailsRecord();
            }
          });
        });
      }
    });
    _initLoading();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void getChangeDetailsRecord() {
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
      databaseHelper
          .getCustomerDetailsForChange(fkDispatchGlCode)
          .then((CustomerChangeDetailsModel customerDetailsChangeModel) {
        //if (countryList.length > 0 && customerDetailsChangeModel != null) {
        if (countryList.isNotEmpty && customerDetailsChangeModel != null) {
          for (int i = 0; i < countryList.length; i++) {
            final CountryMasterModel countryMasterModel = countryList[i];
            if (countryMasterModel.intGlCode ==
                customerDetailsChangeModel.fk_CountryGLCode) {
              selectedCountryModel = countryMasterModel;
            }
          }
        }

        setUpCustomerTypeForChangeDetails(customerDetailsChangeModel);
      });
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int customerGlCode) {
        sharedPrefs
            .getInt(PREF_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE)
            .then((int fkCustomerTypeCountryGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getBool(PREF_CHANGE_DETAILS_STATE_BOOL)
                .then((isChangeDetails) {
              if (isChangeDetails) {
                sharedPrefs
                    .getInt(PREF_FK_DISPATCH_GL_CODE)
                    .then((int fkDispatchGlCode) {
                  databaseHelper
                      .updateChangeDetails(
                          fkDispatchGlCode,
                          selectedCustomerTypeModel.fk_Customer_TypeGlCode,
                          selectedCustomerTypeModel
                              .fk_Customer_Type_CountryGlCode,
                          selectedCustomerTypeModel.fk_Customer_TypeGlCode,
                          selectedCustomerTypeModel
                              .fk_Customer_Type_CountryGlCode,
                      doNo,
                      0,
                      "",
                      "",
                      "")
                      .then((int id) {
                    if (id > 0) {
                      sharedPrefs
                          .setInt(PREF_FK_LAST_DISPATCHED_TO,
                              selectedCustomerTypeModel.fk_Customer_TypeGlCode)
                          .then((bool fkCustomerTypeModel) {
                        sharedPrefs
                            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, false)
                            .then((bool fkCustomerTypeModel) {
                          sharedPrefs
                              .setInt(
                                  PREF_FK_SOLD_TO_PARTY_GL_CODE,
                                  selectedCustomerTypeModel
                                      .fk_Customer_TypeGlCode)
                              .then((bool fkCustomerTypeModel) {
                            sharedPrefs
                                .setString(PREF_DO_NO, doNo)
                                .then((bool fkCustomerTypeModel) {
                              Navigator.pop(context, true);
                            });
                          });
                        });
                      });
                    }
                  });
                });
              } else {
                _battery.getUniqueNumber().then((String syncCode) {
                  databaseHelper
                      .insertCustomerDispatch(
                          customerGlCode,
                          fkCustomerTypeCountryGlCode,
                          selectedCustomerTypeModel.fk_Customer_TypeGlCode,
                          selectedCustomerTypeModel
                              .fk_Customer_Type_CountryGlCode,
                          selectedCustomerTypeModel.fk_Customer_TypeGlCode,
                          selectedCustomerTypeModel
                              .fk_Customer_Type_CountryGlCode,
                          doNo,
                          syncCode,
                          int.parse(initGlCode),
                      'S',
                      0,
                      "",
                      "",
                      "")
                      .then((int id) {
                    if (id > 0) {
                      sharedPrefs
                          .setInt(PREF_FK_DISPATCH_GL_CODE, id)
                          .then((bool isDisGlCode) {
                        sharedPrefs
                            .setInt(
                                PREF_FK_LAST_DISPATCHED_TO,
                                selectedCustomerTypeModel
                                    .fk_Customer_TypeGlCode)
                            .then((bool fkCustomerTypeModel) {
                          sharedPrefs
                              .setInt(
                                  PREF_FK_SOLD_TO_PARTY_GL_CODE,
                                  selectedCustomerTypeModel
                                      .fk_Customer_TypeGlCode)
                              .then((bool fkCustomerTypeModel) {
                            sharedPrefs
                                .setString(PREF_DO_NO, doNo)
                                .then((bool fkCustomerTypeModel) {
                              redirectScanScreen();
                            });
                          });
                        });
                      });
                    }
                  });
                });
              }
            });
          });
        });
      });
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void setUpCustomerTypeForChangeDetails(
      CustomerChangeDetailsModel customerDetailsChangeModel) {
    customerTypeList.clear();
    selectedCustomerTypeModel = null;
    if (selectedCountryModel != null) {
      final int fkCountryGlCode = selectedCountryModel.intGlCode;
      sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
        databaseHelper
            .getCustomerLevelForStockTransfer(int.parse(initCode))
            .then((var customerLevel) {
          sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int customerGlCode) {
            databaseHelper
                .getSoldToPartyRecord(
                    fkCountryGlCode, customerGlCode, 'SOLDTO', customerLevel)
                .then((var custTypeList) {
              //if (custTypeList.length > 0) {
              if (custTypeList.isNotEmpty) {
                customerTypeList.addAll(custTypeList);
                for (int i = 0; i < customerTypeList.length; i++) {
                  final CustomerTypeModel customerTypeModel =
                      customerTypeList[i];
                  if (customerTypeModel.fk_Customer_TypeGlCode ==
                      customerDetailsChangeModel.fk_Sold_To_Party_GlCode) {
                    if (mounted) {
                      setState(() {
                        selectedCustomerTypeModel = customerTypeModel;
                        doTextController.text =
                            customerDetailsChangeModel.varDONo;
                      });
                    }
                  }
                }
              }
            });
          });
        });
      });
    }
  }

  void setUpCustomerType(bool isLoad) {
    customerTypeList.clear();
    if (isLoad) {
      selectedCustomerTypeModel = null;
    }
    if (selectedCountryModel != null) {
      final int fkCountryGlCode = selectedCountryModel.intGlCode;
      sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
        databaseHelper
            .getCustomerLevelForStockTransfer(int.parse(initCode))
            .then((var customerLevel) {
          sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int customerGlCode) {
            databaseHelper
                .getSoldToPartyRecord(
                    fkCountryGlCode, customerGlCode, 'SOLDTO', customerLevel)
                .then((var custTypeList) {
              print('------custTypeList--------${custTypeList.length}');
              //if (custTypeList.length > 0) {
              if (custTypeList.isNotEmpty) {
                if (mounted) {
                  setState(() {
                    customerTypeList.addAll(custTypeList);
                  });
                }
              }
            });
          });
        });
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  void redirectAdvanceSearchScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => AdvanceSearchScreen(isDispatchScreen: 1));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            AdvanceSearchModel advanceSearchModel = globals.advanceSearchModel;
            print(
                '====fk_CountryGlCode====${advanceSearchModel.fk_CountryGlCode}');
//              selectedCountryModel.setIntGlCode = advanceSearchModel.fk_CountryGlCode;
//              selectedCountryModel.name = advanceSearchModel.varName;
            selectedCountryModel = new CountryMasterModel(
                advanceSearchModel.fk_CountryGlCode,
                advanceSearchModel.varName);
            selectedCustomerTypeModel = new CustomerTypeModel(
                advanceSearchModel.fk_CustomeGlCode,
                advanceSearchModel.varCustomer_Type_Name,
                advanceSearchModel.fk_Customer_Type_CountryGlCode,
                advanceSearchModel.varSAPCode,
                advanceSearchModel.varCustomerName);
            setUpCustomerType(false);
//            selectedCustomerTypeModel.varCustomer_Type_Name =
//                advanceSearchModel.varCustomer_Type_Name;
//            selectedCustomerTypeModel.varCustomerTypeName =
//                advanceSearchModel.varCustomerName;
//            selectedCustomerTypeModel.fk_Customer_TypeGlCode =
//                advanceSearchModel.fk_CustomeGlCode;
//            selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode =
//                advanceSearchModel.fk_Customer_Type_CountryGlCode;
            if (mounted) {
              setState(() {});
            }
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final doNoTxt = TextFormField(
      controller: doTextController,
      //enableInteractiveSelection: false,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      focusNode: _donoFocus,
      onFieldSubmitted: (value) {
        _donoFocus.unfocus();
      },
      autofocus: false,
      autocorrect: false,
      validator: (String arg) {},
      onSaved: (String val) {
        doNo = val;
      },
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: '${LocaleUtils.getString(mContext, 'enter')} ${globals
            .STO_NO}.',
        border: InputBorder.none,
        //contentPadding: EdgeInsets.fromLTRB(0, p_15, 0, 0),
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final loginButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'proceed'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (selectedCountryModel != null) {
            if (selectedCustomerTypeModel != null) {
              if (doTextController.text.isNotEmpty) {
                _validateInputs();
              } else {
                _showSnackBar('${LocaleUtils.getString(
                    mContext, 'plz_enter_your')} ${globals.STO_NO}.');
              }
            } else {
              _showSnackBar(
                  LocaleUtils.getString(mContext, 'plz_sel_ship2party_cust'));
            }
          } else {
            _showSnackBar(LocaleUtils.getString(mContext, 'plz_sel_country'));
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_FIRST, false),
                  Expanded(
                    child: Form(
                      child: Container(
                        color: const Color(bgColor),
                        child: Card(
                          elevation: 7,
                          margin: const EdgeInsets.all(15),
                          child: Container(
                            padding: const EdgeInsets.all(15),
                            child: ListView(
                              shrinkWrap: true,
                              children: <Widget>[
                                Container(
                                  height: 20,
                                  alignment: Alignment.centerRight,
                                  margin: const EdgeInsets.only(bottom: 10),
                                  padding:
                                      const EdgeInsets.fromLTRB(15, 0, 0, 0),
//                                      child: Row(
//                                        crossAxisAlignment:
//                                        CrossAxisAlignment.center,
//                                        mainAxisAlignment: MainAxisAlignment.end,
//                                        children: <Widget>[
//                                          Container(
//                                            height: 40,
//                                            padding: const EdgeInsets.fromLTRB(
//                                                15, 0, 15, 0),
//                                            decoration: BoxDecoration(
//                                                border: Border.all(
//                                                    color: const Color(0xFF000000)),
//                                                borderRadius: _getRadiusDropDown()),
//                                            child: Row(
//                                              crossAxisAlignment:
//                                              CrossAxisAlignment.center,
//                                              children: <Widget>[
//                                                Text(
//                                                  'Advance Search',
//                                                  style: TextStyle(
//                                                    fontSize: 15.0,
//                                                    fontWeight: FontWeight.w500,
//                                                    fontFamily: 'helvetica',
//                                                    color: Colors.black,
//                                                  ),
//                                                ),
//                                                Padding(
//                                                  padding:
//                                                  EdgeInsets.only(left: 10),
//                                                  child: Icon(Icons.search),
//                                                ),
//                                              ],
//                                            ),
//                                          ),
//                                        ],
//                                      )
                                  child: InkWell(
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'advance_search'),
                                      style: TextStyle(
                                          fontSize: 15.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: 'helvetica',
                                          color: Color(colorPrimary),
                                          letterSpacing: 0.5,
                                          decoration: TextDecoration.underline),
                                    ),
                                    onTap: () {
                                      selectedCountryModel = null;
                                      selectedCustomerTypeModel = null;
                                      globals.advanceSearchModel = null;
                                      redirectAdvanceSearchScreen();
                                    },
                                  ),
                                ),
                                InkWell(
                                  child: Container(
                                      height: 42,
                                      width: screenSize.width,
                                      alignment: Alignment.centerLeft,
                                      margin: const EdgeInsets.only(top: 12),
                                      padding: const EdgeInsets.fromLTRB(
                                          15, 0, 15, 0),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: const Color(0xFF000000)),
                                          borderRadius: _getRadiusDropDown()),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text(
                                            selectedCountryModel != null
                                                ? selectedCountryModel.name
                                                : LocaleUtils.getString(
                                                    mContext, 'sel_country'),
                                            style: selectedCountryModel != null
                                                ? textStyle
                                                : hintStyle,
                                          ),
                                          Icon(Icons.arrow_drop_down)
                                        ],
                                      )),
                                  onTap: () {
                                    List<SpinnerModel> countrytemp = countryList
                                        .map((countryMasterModel) =>
                                            SpinnerModel(
                                                countryMasterModel.intGlCode,
                                                countryMasterModel.name,
                                                1))
                                        .toList();
                                    showDialog<Map>(
                                      barrierDismissible: true,
                                      context: context,
                                      builder: (context) {
                                        return SearchableSpinner(
                                          screenSize: screenSize,
                                          listSticker: countrytemp,
                                          itemClickSearchableSpinner: this,
                                        );
                                      },
                                    );
                                  },
                                ),
                                InkWell(
                                  child: Container(
                                      height: 42,
                                      width: screenSize.width,
                                      margin: const EdgeInsets.only(top: 20),
                                      alignment: Alignment.centerLeft,
                                      padding: const EdgeInsets.fromLTRB(
                                          15, 0, 15, 0),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: const Color(0xFF000000)),
                                          borderRadius: _getRadiusDropDown()),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text(
                                            selectedCustomerTypeModel != null
                                                ? selectedCustomerTypeModel
                                                    .varCustomer_Type_Name
                                                : LocaleUtils.getString(
                                                    mContext, 'ship2party'),
                                            style: selectedCustomerTypeModel !=
                                                    null
                                                ? textStyle
                                                : hintStyle,
                                          ),
                                          Icon(Icons.arrow_drop_down)
                                        ],
                                      )),
                                  onTap: () {
                                    List<SpinnerModel> customertemp =
                                        customerTypeList
                                            .map((customerTypeModel) =>
                                                SpinnerModel(
                                                    customerTypeModel
                                                        .fk_Customer_TypeGlCode,
                                                    customerTypeModel
                                                        .varCustomer_Type_Name,
                                                    2))
                                            .toList();
                                    print(
                                        '===customertemp===${customertemp.length}');
                                    showDialog<Map>(
                                      barrierDismissible: true,
                                      context: context,
                                      builder: (context) {
                                        return SearchableSpinner(
                                          screenSize: screenSize,
                                          listSticker: customertemp,
                                          itemClickSearchableSpinner: this,
                                        );
                                      },
                                    );
                                  },
                                ),
                                Container(
                                    height: 42,
                                    width: screenSize.width,
                                    margin: const EdgeInsets.only(top: 20),
                                    padding:
                                        const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        selectedCustomerTypeModel != null
                                            ? selectedCustomerTypeModel
                                                .varCustomerTypeName
                                            : LocaleUtils.getString(
                                                mContext, 'ship2party_type'),
                                        style: selectedCustomerTypeModel != null
                                            ? textStyle
                                            : hintStyle,
                                      ),
                                    )),
                                Container(
                                  height: 42,
                                  width: screenSize.width,
                                  margin: const EdgeInsets.only(top: 20),
                                  padding:
                                      const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: const Color(0xFF000000)),
                                      borderRadius: _getRadiusDropDown()),
                                  child: doNoTxt,
                                ),
                                Container(
                                  width: screenSize.width,
                                  height: 45,
                                  child: loginButton,
                                  margin: const EdgeInsets.only(top: 30),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      autovalidate: _autoValidate,
                      key: _formKey,
                    ),
                    flex: 1,
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    if (model.spinnerID == 1) {
      setSelectedCountryValues(model.initcode);
    } else if (model.spinnerID == 2) {
      setSelectedCustomerValues(model.initcode);
    }
  }

  void setSelectedCountryValues(int initId) {
    for (int i = 0; i < countryList.length; i++) {
      if (countryList[i].intGlCode == initId) {
        if (mounted) {
          setState(() {
            selectedCountryModel = countryList[i];
            setUpCustomerType(true);
          });
        }
      }
    }
  }

  void setSelectedCustomerValues(int initId) {
    for (int i = 0; i < customerTypeList.length; i++) {
      if (customerTypeList[i].fk_Customer_TypeGlCode == initId) {
        if (mounted) {
          setState(() {
            selectedCustomerTypeModel = customerTypeList[i];
          });
        }
      }
    }
  }
}
