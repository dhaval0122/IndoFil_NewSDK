import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/Application.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:wave_progress_widget/wave_progress_widget.dart';

class SyncAnimationScreen extends StatefulWidget {
  final bool isDbSync;
  final bool isDashboard;

  SyncAnimationScreen({this.isDbSync, this.isDashboard});

  @override
  SyncAnimationScreenState createState() => SyncAnimationScreenState();
}

class SyncAnimationScreenState extends State<SyncAnimationScreen>
    implements WSInterface {
//  String _platformVersion = 'Unknown';
  EcpSyncPlugin _battery = EcpSyncPlugin();
  Map _batteryState;
  StreamSubscription<Map> _batteryStateSubscription;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  DatabaseHelper databaseHelper;
  bool isFirstTimeForSync = false;

  //bool isFirstTimeForFail = false;
  WSPresenter wsPresenter;
  bool _loading = false;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  bool isDbSyncFlag = false;

  SyncAnimationScreenState() {
    wsPresenter = WSPresenter(this);
  }

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();
    isFirstTimeForSync = false;
    //isFirstTimeForFail = false;
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    if (widget.isDbSync) {
      sharedPrefs.setString(PREF_LAST_SYNC_DATE, '');
    }

    _initLoading();

    manageBattryCallback();

    if (databaseHelper != null) {
      databaseHelper.syncTimeRealseEditDO().then((int id) {
        sharedPrefs.getString(PREF_LAST_SYNC_DATE).then((String isLastSync) {
          if (isLastSync != null && isLastSync.trim().isNotEmpty) {
            isDbSyncFlag = false;
            dateValidationCall();
          } else {
            isDbSyncFlag = true;
            dateValidationCall();
          }
        });
      });
    } else {
      sharedPrefs.getString(PREF_LAST_SYNC_DATE).then((String isLastSync) {
        if (isLastSync != null && isLastSync.trim().isNotEmpty) {
          isDbSyncFlag = false;
          dateValidationCall();
        } else {
          isDbSyncFlag = true;
          dateValidationCall();
        }
      });
    }

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        //BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }
  }

  void manageBattryCallback() {
    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) {
      _batteryState = state;
      if (_batteryState != null) {
        if (_batteryState['type'] == '3' &&
            _batteryState['progress'] == '100') {
          databaseHelper = DatabaseHelper.get();
          Timer(const Duration(seconds: 2), () {
            if (_batteryState['Details'] != 'progress' &&
                _batteryState['Details'] != 'Update Count Auto') {
              if (!isFirstTimeForSync) {
                isFirstTimeForSync = true;
                if (mounted) {
                  setState(() {
                    print('-----Details-----${_batteryState['Details']}');
                    showDialog<Map>(
                      barrierDismissible: false,
                      context: mContext,
                      builder: (context) {
                        return WillPopScope(
                            // ignore: missing_return
                            onWillPop: () {},
                            child: CustomAlertDialog(
                              /*content: LocaleUtils.getString(mContext,
                              'synchronization_successfully_completed'),*/
                              content: _batteryState['Details'].toString(),
                              title: PROJECT_NAME == 'BASF_HK'
                                  ? BASF_HK_APP_Name
                                  : Zydus_APP_Name,
                              isShowNagativeButton: false,
                              textNagativeButton: '',
                              textPositiveButton:
                                  LocaleUtils.getString(mContext, 'OK'),
                              onPressedNegative: () {},
                              onPressedPositive: () {
                                syncComplete();
                              },
                            ));
                      },
                    );
                  });
                }
              }
            }
          });
        } else if (_batteryState['type'] == '1') {
          if (mounted) {
            setState(() {});
          }
        } else if (_batteryState['type'] == '2') {
          if (_batteryState['Details'] != 'progress' &&
              _batteryState['Details'] != 'Update Count Auto') {
            if (!isFirstTimeForSync) {
              isFirstTimeForSync = true;
              String msg = '';
              if (_batteryState['Details'] != null) {
                if (_batteryState['Details'].toString().length < 5) {
                  msg = _batteryState['Details'].toString();
                }
              }

              if (msg.isNotEmpty) {
                msg = msg +
                    '-${LocaleUtils.getString(mContext, 'server_not_res_try_again')}';
              } else {
                msg =
                    '102--${LocaleUtils.getString(mContext, 'server_not_res_try_again_')}';
              }

              showDialog<Map>(
                barrierDismissible: false,
                context: mContext,
                builder: (context) {
                  return WillPopScope(
                      // ignore: missing_return
                      onWillPop: () {},
                      child: CustomAlertDialog(
                        content: msg,
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'Later'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'Retry'),
                        onPressedNegative: () {
                          //syncComplete();
                          close();
                        },
                        onPressedPositive: () {
                          isFirstTimeForSync = false;
                          //isFirstTimeForFail = false;
                          /*databaseHelper = DatabaseHelper.get();
                        databaseHelper.removeLogs();
                        databaseHelper.close();*/

                          if (_batteryStateSubscription != null)
                            // ignore: curly_braces_in_flow_control_structures
                            _batteryStateSubscription.cancel();

                          manageBattryCallback();

                          pressDetails();
                        },
                      ));
                },
              );
            }
          }
        }
      }
    });
  }

  void syncComplete() async {
    await getLanguagesRecord();
    await sharedPrefs.setString(PREF_LATER_DATE_TIME, '');
    await databaseHelper.getStatusMaster();
    String userID = await sharedPrefs.getString(PREF_USER_ID);
    PersonModel personMasterList =
        await databaseHelper.getPersonMasterRecords(userID);
    print('========personMasterList=====$personMasterList');
    if (personMasterList != null) {
      insertGlobalDataSharedPref(personMasterList);
    } else {
      close();
    }
  }

  void getLanguagesRecord() async {
    List<LanguageDetails> languageList = new List();
    languageList = await databaseHelper.getLanguageMasterAllRecords();

    if (languageList.isNotEmpty) {
      int fkLanguageGlCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);
      String languageCode =
          await databaseHelper.getLanguageCode(fkLanguageGlCode);
      selectDefault(languageCode);
    }

    if (mounted) {
      setState(() {});
    }
  }

  void selectDefault(String languageCode) {
    print("=====languageCode========$languageCode");
    List<String> langTemp = languageCode.split('-');
    print('=====langTemp======${langTemp[0]}');
    lang_change = langTemp[0];
    onLocaleChange(Locale(langTemp[0]));
  }

  void onLocaleChange(Locale locale) {
    setState(() {
      application.onLocaleChanged(locale);
    });
  }

  void close() {
    try {
      if (_batteryStateSubscription != null) {
        _batteryStateSubscription.cancel();
      }
      //isFirstTimeForFail = false;
      isFirstTimeForSync = false;
      _battery = null;
      _batteryState.clear();
    } catch (e) {
      print('===========${e.toString()}');
    }

    navigationDashboard();
  }

  void navigationDashboard() {
    if (widget.isDashboard) {
      Route route = MaterialPageRoute(builder: (context) => Dashboard());
      Navigator.pushReplacement(context, route);
    } else {
      Route route = MaterialPageRoute(builder: (context) => Dashboard());
      Navigator.pushAndRemoveUntil(
          context, route, (Route<dynamic> route) => false);
    }
  }

  void deleteLoginDetails() async {
    globals.KG_PCS =
        await databaseHelper.getConfiguration('CPM', 'KG/L', "Kg", 'value1');

    globals.DO_NO =
        await databaseHelper.getConfiguration('CPM', 'DONO', "DO No", 'value1');

    globals.DO =
        await databaseHelper.getConfiguration('CPM', 'DO', "DO", 'value1');

    globals.STO =
        await databaseHelper.getConfiguration('CPM', 'STO', "STO", 'value1');

    globals.STO_NO = await databaseHelper.getConfiguration(
        'CPM', 'STONO', "STO No", 'value1');

    globals.DO_OR_STO = await databaseHelper.getConfiguration(
        'CPM', 'DO/STO', "DO/STO", 'value1');

    globals.COMPANY_NAME = await databaseHelper.getConfiguration(
        'CPM', 'CompanyName', "", 'value1');

    globals.COMPANY_CODE = await databaseHelper.getConfiguration(
        'CPM', 'CompanyCode', "", 'value1');

    globals.AUTO_DISPATCH_DO_CONFIRM = await databaseHelper.getConfiguration(
        'CPM', 'AutoDispatchDOConfirm', "N", 'value1');

    globals.AUTO_DISPATCH_STO_CONFIRM = await databaseHelper.getConfiguration(
        'CPM', 'AutoDispatchSTOConfirm', "N", 'value1');

    globals.BARCODE_LENGTH = await databaseHelper.getConfiguration('CPM',
        'BarcodeLength', PROJECT_NAME == 'BASF_HK' ? '14' : '12', 'value1');

    globals.PUSH_NOTIFICATION_CUST = await databaseHelper.getConfiguration(
        'CPM', 'PushNotification', "Y", 'value1');

    globals.BATCH_VALIDATION = await databaseHelper.getConfiguration(
        'CPM', 'BatchValidation', "N", 'value1');

    globals.SETTLE_DO =
        await databaseHelper.getConfiguration('CPM', 'SettleDO', "N", 'value1');

    globals.RETURN =
        await databaseHelper.getConfiguration('CPM', 'RETURN', "RN", 'value1');

    globals.RETURN_NO = await databaseHelper.getConfiguration(
        'CPM', 'RETURNNO', "RN No", 'value1');

    globals.AutoSalesReturnConfirm = await databaseHelper.getConfiguration(
        'CPM', 'AutoSalesReturnConfirm', "Y", 'value1');

    globals.LANGUAGE =
        await databaseHelper.getConfiguration('CPM', 'Language', "N", 'value1');

    await databaseHelper
        .getConfiguration('CPM', 'SyncAlert', "30", 'value1')
        .then((String doValue) {
      try {
        globals.SyncAlertValue1 = int.parse(doValue) ?? 30;
      } catch (e) {
        globals.SyncAlertValue1 = 30;
      }
    });

    await databaseHelper
        .getConfiguration('CPM', 'SyncAlert', "20", 'value2')
        .then((String doValue) {
      try {
        globals.SyncAlertValue2 = int.parse(doValue) ?? 20;
      } catch (e) {
        globals.SyncAlertValue2 = 20;
      }
    });

    await databaseHelper
        .getConfiguration('CPM', 'Inward_Scanning_LMT', "200", 'value1')
        .then((String doValue) {
      try {
        globals.SCAN_LIMIT = int.parse(doValue) ?? 200;
      } catch (e) {
        globals.SCAN_LIMIT = 200;
      }
    });

    globals.FOC =
        await databaseHelper.getConfiguration('CPM', 'FOC', "FOC", 'value1');

    globals.FOC_NO = await databaseHelper.getConfiguration(
        'CPM', 'FOCNO', "FOCNO", 'value1');

    globals.AutoFOCConfirm = await databaseHelper.getConfiguration(
        'CPM', 'AutoFOCConfirm', "N", 'value1');

    globals.DOConfiguration = await databaseHelper.getConfiguration(
        'CPM', 'DOConfiguration', "Y", 'value1');

    globals.STOConfiguration = await databaseHelper.getConfiguration(
        'CPM', 'STOConfiguration', "Y", 'value1');

    globals.SRConfiguration = await databaseHelper.getConfiguration(
        'CPM', 'SRConfiguration', "Y", 'value1');

    globals.FOCConfiguration = await databaseHelper.getConfiguration(
        'CPM', 'FOCConfiguration', "N", 'value1');

    globals.sapDocNoConfiguration = await databaseHelper.getConfiguration(
        'CPM', 'SR_Receive_DOC_Config', "N", 'value1');

    globals.sapDocNoTitle = await databaseHelper.getConfiguration(
        'CPM', 'SR_Receive_DOC_Config', "SAP Document No.", 'value2');

    globals.sapDocNoMandatoryConfiguration = await databaseHelper
        .getConfiguration('CPM', 'SR_Receive_DOC_Config', "N", 'value3');

    await databaseHelper.deleteLoginFormDetails();
    await databaseHelper.deleteLoginFailAttempt_Details();
    await databaseHelper.deleteLoginDetails();
    await navigationDashboard();
  }

  void insertGlobalDataSharedPref(PersonModel personModel) async {
    await sharedPrefs.setInt(
        PREF_FK_LANGUAGE_GL_CODE, personModel.fk_LanguageGlCode);
    await sharedPrefs
        .getString(PREF_DATE_TIME_FORMAT)
        .then((String dateTimeFormat) {
      _battery
          .getTimeFromUTC(personModel.dtLastSyncDate, dateTimeFormat)
          .then((String lastSyncDateFormatted) {
        print(
            '====personModel====dtLastSyncDate====${personModel.dtLastSyncDate}');
        print('====lastSyncDateFormatted====$lastSyncDateFormatted');
        sharedPrefs
            .setString(PREF_LAST_SYNC_DATE, lastSyncDateFormatted)
            .then((bool status) {
          sharedPrefs
              .setString(PREF_INIT_GI_CODE, personModel.intGlCode.toString())
              .then((bool status) {
            sharedPrefs
                .setString(PREF_USER_ID, personModel.varUserID.toString())
                .then((bool isUserID) {
              sharedPrefs
                  .setString(PREF_GENDER, personModel.chrGender.toString())
                  .then((bool isGender) {
                sharedPrefs
                    .setString(PREF_USER_TYPE, personModel.chrUserType)
                    .then((bool isGender) {
                  sharedPrefs
                      .setInt(
                          PREF_FK_COUNTRY_GI_CODE, personModel.fk_CountryGlCode)
                      .then((bool isGender) {
                    sharedPrefs
                        .setString(PREF_FULL_NAME, personModel.varFirstName)
                        .then((bool isGender) {
                      sharedPrefs
                          .setString(PREF_ORGANIZATION_NAME,
                              personModel.varOrganisationName)
                          .then((bool isGender) {
                        sharedPrefs
                            .setInt(PREF_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE,
                                personModel.fk_Customer_Type_CountryGlCode)
                            .then((bool isGender) {
                          sharedPrefs
                              .setInt(PREF_FK_EMPLOYEE_TYPE_GI_CODE,
                                  personModel.fk_Employee_TypeGlCode)
                              .then((bool isGender) {
                            sharedPrefs
                                .setInt(
                                    PREF_FK_EMPLOYEE_DESIGNATION_COUNTRY_GI_CODE,
                                    personModel
                                        .fk_Employee_Designation_CountryGlCode)
                                .then((bool isGender) {
                              sharedPrefs
                                  .setInt(PREF_FK_POLITICAL_GEO_GI_CODE,
                                      personModel.fk_Political_GeoGlCode)
                                  .then((bool isGender) {
                                sharedPrefs
                                    .setString(PREF_SERVER_NAME,
                                        personModel.varServerName)
                                    .then((bool isGender) {
                                  int parentGlCode = -1;
                                  print(
                                      '====refParentGlCode====${personModel.refParentGlCode}');
                                  if (personModel.refParentGlCode > 0) {
                                    parentGlCode = personModel.refParentGlCode;
                                  } else {
                                    parentGlCode = personModel.intGlCode;
                                  }
                                  sharedPrefs
                                      .setInt(PREF_MAIN_CUSTOMER_GI_CODE,
                                          parentGlCode)
                                      .then((bool isGender) {
                                    deleteLoginDetails();
                                  });
                                });
                              });
                            });
                          });
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  }

  pressDetails() {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String personID) {
      sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceID) {
        sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
          initPlatformState(personID, deviceID, apiToken);
        });
      });
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    //isFirstTimeForFail = false;
    isFirstTimeForSync = false;
    _battery = null;
    _batteryState = null;
  }

  Future<void> initPlatformState(
      String personID, String deviceID, String apiToken) async {
    // ignore: unused_local_variable
    String platformVersion;

    try {
      if (isDbSyncFlag) {
        print('=====personID======$personID');
        print('=====deviceID======$deviceID');
        print('=====apiToken======$apiToken');
        print('=====URL======${BASE_URL + MODULE}');
        print('=====SYNCHRONIZE_DATABASE======$SYNCHRONIZE_DATABASE');
        print('=====APP_VERSION======$APP_VERSION');
        print('=====isDbSyncFlag======$isDbSyncFlag');

        //urlUpload: BASE_URL + MODULE,

        platformVersion = await EcpSyncPlugin().syncronizeData(
            userName: apiToken,
            fkEmpGlCode: personID,
            urlUpload: BASE_URL + MODULE,
            iMei: deviceID,
            appVersion: APP_VERSION,
            uploadMethod: SYNCHRONIZE_DATABASE,
            clientName: Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS,
            databaseName: DatabaseHelper.DATABASE_NAME,
            packageName: PROJECT_NAME == 'BASF_HK'
                ? 'com.ecubix.basf'
                : 'com.ecubix.zydustrackntrace',
            dbPassword: 'Vcs@1234',
            methodSyncID: SYNCHRONIZE_LOG,
            isDbEncripted: 'true');
      } else {
        print('=====personID======$personID');
        print('=====deviceID======$deviceID');
        print('=====apiToken======$apiToken');
        print('=====URL======${BASE_URL + MODULE}');
        print('=====SYNCHRONIZE_FILE======$SYNCHRONIZE_FILE');
        print('=====SYNCHRONIZE_LOG======$SYNCHRONIZE_LOG');
        print('=====APP_VERSION======$APP_VERSION');
        print('=====isDbSyncFlag======$isDbSyncFlag');

        platformVersion = await EcpSyncPlugin().syncronizeDataFile(
            userName: apiToken,
            fkEmpGlCode: personID,
            urlUpload: BASE_URL + MODULE,
            iMei: deviceID,
            appVersion: APP_VERSION,
            uploadMethod: SYNCHRONIZE_FILE,
            logUploadMethod: SYNCHRONIZE_LOG,
            methodSyncID: SYNCHRONIZE_LOG,
            clientName: Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS,
            databaseName: DatabaseHelper.DATABASE_NAME,
            packageName: PROJECT_NAME == 'BASF_HK'
                ? 'com.ecubix.basf'
                : 'com.ecubix.zydustrackntrace',
            dbPassword: 'Vcs@1234',
            isDbEncripted: 'true');
      }
    } on PlatformException {
      platformVersion =
          LocaleUtils.getString(mContext, 'failed_to_get_platform_version');
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.
    if (!mounted) {
      return;
    }
    /*setState(() {
      _platformVersion = platformVersion;
      print(_platformVersion);
    });*/
  }

  @override
  Widget build(BuildContext context) {
    mContext = context;
    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
            appBar: AppBar(
              title:
                  Text(LocaleUtils.getString(mContext, 'Synchronization') + ''),
              automaticallyImplyLeading: false,
            ),
            body: Stack(
              children: <Widget>[
                Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(bottom: 30),
                        child: Text(
                          isDbSyncFlag
                              ? LocaleUtils.getString(
                                  mContext, 'data_synchronization__')
                              : LocaleUtils.getString(
                                  mContext, 'data_synchronization___'),
                          style: TextStyle(
                            fontSize: 18.0,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'helvetica',
                            color: const Color(colorPrimary),
                          ),
                        ),
                      ),
//                      Container(
//                          width: 250,
//                          height: 250,
//                          child: Stack(
//                            children: <Widget>[
//                              CircleProgressBar(
//                                backgroundColor: Colors.grey,
//                                foregroundColor: const Color(colorPrimary),
//                                value: (_batteryState != null
//                                        ? double.parse(
//                                            _batteryState['progress'])
//                                        : 0.0) /
//                                    100,
//                                animationDuration: const Duration(seconds: 1),
//                              ),
//                              Center(
//                                  child: Text(
//                                '${_batteryState != null ? int.parse(_batteryState['progress']) : '0'}%',
//                                style: TextStyle(
//                                  fontSize: 25.0,
//                                  fontWeight: FontWeight.w400,
//                                  fontFamily: 'helvetica',
//                                  color: const Color(colorPrimary),
//                                ),
//                              ))
//                            ],
//                          )),
                      Container(
                          width: 250,
                          height: 250,
                          decoration: BoxDecoration(
                              color: Colors.white, shape: BoxShape.circle),
                          child: Stack(
                            children: <Widget>[
                              WaveProgress(
                                  100.0,
                                  Colors.white,
                                  Color(colorPrimaryTrans),
                                  (_batteryState != null
                                          ? double.parse(
                                              _batteryState['progress'])
                                          : 0.0) /
                                      100),
//                              Center(
//                                child: Container(
//                                  margin: EdgeInsets.all(50),
//                                  child: Image.asset(
//                                    PROJECT_NAME == 'BASF_HK'
//                                        ? 'assets/inner_header_logo.png'
//                                        : 'assets/zydus_inner_header_logo.png',
//                                    fit: BoxFit.fill,
//                                  ),
//                                ),
//                              ),
                            ],
                          )),
                      Padding(
                        padding: const EdgeInsets.only(top: 30),
                        child: Text(
                          LocaleUtils.getString(
                              mContext, 'records_r_processing_plz_wait'),
                          style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'helvetica',
                            color: Colors.black,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                ),
                _progressHUD
              ],
            )));
  }

  @override
  void onLoginError(String errorTxt) {
    //if (_loading) {

    _loading = false;
    dismissProgressHUD();
    //}

    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            // ignore: missing_return
            onWillPop: () {},
            child: CustomAlertDialog(
              content: errorTxt,
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {
                close();
              },
            ));
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    //if (_loading) {

    _loading = false;
    dismissProgressHUD();
    //}

    print(response);

    final dynamic jsonResponse = json.decode(response.toString().trim());
    final LoginResponseModel responseModel =
        LoginResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status == '1') {
      databaseHelper.close();
      pressDetails();
    } else if (responseModel.Status == '0') {
      final StringBuffer strMsg = StringBuffer();
      final List<String> finalMsg = responseModel.Message.split('||');

      //if (finalMsg.length > 0) {
      if (finalMsg.isNotEmpty) {
        for (int i = 0; i < finalMsg.length; i++) {
          final List<String> values1 = finalMsg[i].split('|');
          //if (values1.length > 0) {
          if (values1.isNotEmpty) {
            for (int j = 0; j < values1.length; j++) {
              strMsg.write(values1[j]);
              strMsg.write('\n');
            }
          } else {
            strMsg.write(finalMsg[i]);
            strMsg.write('\n');
          }
        }
      } else {
        strMsg.write(responseModel.Message);
      }

      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              // ignore: missing_return
              onWillPop: () {},
              child: CustomAlertDialog(
                content: strMsg.toString(),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  close();
                },
              ));
        },
      );
    } else if (responseModel.Status == '2') {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              // ignore: missing_return
              onWillPop: () {},
              child: CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  navigationDashboard();
                },
              ));
        },
      );
    } else {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              // ignore: missing_return
              onWillPop: () {},
              child: CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  close();
                },
              ));
        },
      );
    }
  }

  void dateValidationCall() {
    print('============dateValidationCall===============');
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        Future.delayed(const Duration(milliseconds: 700), () {
          _loading = true;
          dismissProgressHUD();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
            sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
              databaseHelper.getDateForSyncTime().then((String date) {
                var param = Map();
                param[PARAM_PERSON_ID] = initCode;
                param[PARAM_DATE] = date != null ? date : '';
                param[PARAM_API_TOKEN] = apiToken;
                param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                    ? SUB_MODULE_NAME_ANDROID
                    : SUB_MODULE_NAME_IOS;
                param[PARAM_VERSION] = APP_VERSION;
                sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                  param[PARAM_DEVICE_ID] = deviceid;
                  print(param);
                  wsPresenter.callAPI(POST_METHOD, DATE_VALIDATION, param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    close();
                  },
                ));
          },
        );
        /*_showErrorAlert(
            APP_Name, 'No Internet Connection', FAIL, '', 'OK', false);*/
      }
    });
  }
}

//3a7a7e6de831dd19
