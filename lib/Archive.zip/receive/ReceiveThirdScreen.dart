import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/ScreenRautes.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/CongratulationScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveFirstScreen.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveSecondScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:progress_hud/progress_hud.dart';

class TotalProductUnitsModel {
  int intTotalUnit;
  int intProductCount;
  int intPendingCount;
  int totalUnit;
  int totalProduct;

  TotalProductUnitsModel(
      {this.intTotalUnit,
      this.intProductCount,
      this.intPendingCount,
        this.totalUnit,
        this.totalProduct});

  TotalProductUnitsModel.fromMap(Map<String, dynamic> json) {
    this.intTotalUnit =
        json.containsKey('intTotalUnit') ? json['intTotalUnit'] : 0;
    this.intProductCount =
        json.containsKey('intProductCount') ? json['intProductCount'] : 0;
    this.intPendingCount =
        json.containsKey('intPendingCount') ? json['intPendingCount'] : 0;
    this.totalUnit = json.containsKey('TotalUnit') ? json['TotalUnit'] : 0;
    this.totalProduct =
        json.containsKey('TotalProduct') ? json['TotalProduct'] : 0;
  }
}

class ReceiveThirdScreen extends StatefulWidget {
  @override
  ReceiveThirdScreenState createState() => ReceiveThirdScreenState();
}

class ReceiveThirdScreenState extends State<ReceiveThirdScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false;
  bool loadingFlag = false, isNotification = false, isSync = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '',
      subTitle = '',
      topHeaderImage = '',
      finalSettleMessage = '';
  int receiveCount = 0;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  String dispatchDate = '',
      DoStoNo = '',
      doSTOTitle = '',
      settleDoTitle = '',
      varOrganizationName = '';
  List<ReceiveDataModel> receiveDataList;
  List<ReceiveScanRecordModel> receiveStickerListClone;
  List<ReceiveScanRecordModel> receiveStickerList;
  List<ScanDataModel> invalidStickerList;
  int notificationCount = 0;
  final TextEditingController _search_controller = TextEditingController();
  final TextEditingController _controllerSAPDocNo = TextEditingController();
  PushNotificationServices pushNotificationServices;
  String chrTranType = '';

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    receiveStickerList = List();
    receiveStickerListClone = List();
    invalidStickerList = List();
    receiveDataList = List();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_CHAR_TRAN_TYPE_DISPATCH).then((String chrTran) {
      chrTranType = chrTran;
    });

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_RECEIVE) {
        topHeaderImage = 'assets/receive_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_RECEIVE_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          receiveCount = count;
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getReceiveRecords();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void getReceiveRecords() async {
    setState(() {
      loadingFlag = true;
    });

    await sharedPrefs
        .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
        .then((int fkMainCustomerGlCode) {
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        databaseHelper
            .getReceiveSecondRecordList(fkMainCustomerGlCode, fkDispatchGlCode)
            .then((List<ReceiveRecordModel> data) {
          print('=====DATA=========${data.toString()}');
          //if (data.length > 0) {
          if (data.isNotEmpty) {
            varOrganizationName = data[0].varFullName;
            getDateTimeFormat(data[0].dtDispatchDate);
            sharedPrefs
                .getString(PREF_CHAR_TRAN_TYPE_DISPATCH)
                .then((String chrType) {
              if (chrType.contains('S')) {
                DoStoNo = data[0].varDONO;
                doSTOTitle = '${data[0].varEntityName}: ';
                settleDoTitle = 'Settle ${globals.STO}';
                finalSettleMessage = 'Settle ${globals.STO} successfully.';
              } else {
                DoStoNo = data[0].varDONO;
                doSTOTitle = '${data[0].varEntityName}: ';
                settleDoTitle = 'Settle ${globals.DO}';
                finalSettleMessage = 'Settle ${globals.DO} successfully.';
              }
            });

            databaseHelper
                .getReceiveSecondDataList(
                    fkMainCustomerGlCode, fkDispatchGlCode)
                .then((List<ReceiveDataModel> data) {
              receiveDataList.clear();
              if (mounted) {
                loadingFlag = false;
                setState(() {
                  receiveDataList.addAll(data);
                });
              }
            });
          }
        });
      });
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) => SyncScreen(
                                  isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
              // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getDateTimeFormat(String date) {
    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      _battery.getTimeFromUTC(date, dateFormat).then((String dateFormatted) {
        if (mounted) {
          setState(() {
            dispatchDate = dateFormatted;
          });
        }
      });
    });
  }

  int calUUnitProductTotal(List<ReceiveDataModel> dispatchScanModelsList) {
    int unitTotal = 0;
    for (int i = 0; i < dispatchScanModelsList.length; i++) {
      final ReceiveDataModel scanRecordModel = dispatchScanModelsList[i];
      unitTotal = unitTotal + scanRecordModel.intTotalUnit;
    }
    return unitTotal;
  }

  /*void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }*/

  void reScanBtn() {
    sharedPrefs
        .setBool(IS_CHANGE_SCANNING_STATE, true)
        .then((bool isChangeScan) {
      if (isChangeScan) {
        scanScreenLoad();
      }
    });
  }

  void scanScreenLoad() async {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            getReceiveRecords();
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void getStickerRecordListViewItem(
      int fkProductSKUGlCode, String selectedProductName) {
    _loading = true;
    dismissProgressHUD();

    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs
          .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
          .then((int fkMainCustomerGlCode) {
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fkDispatchGlCode) {
          sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fkDispatchGlCode) {
            sharedPrefs
                .getInt(PREF_FK_RECEIVE_GL_CODE)
                .then((int fkReceiveGlCode) {
              databaseHelper
                  .getReceiveStickerRecord(
                      fkReceiveGlCode, fkDispatchGlCode, fkProductSKUGlCode, '')
                  .then((List<ReceiveScanRecordModel> data) {
                _loading = false;
                dismissProgressHUD();

                receiveStickerList.clear();
                receiveStickerListClone.clear();
                receiveStickerList.addAll(data);
                receiveStickerListClone.addAll(data);
                showDialog<Map>(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
//                    return scanRecordShowDialog(selectedProductName);
                    return StickerDialog(
                        screenSize: screenSize,
                        listSticker: receiveStickerListClone,
                        listStickerDisplay: receiveStickerList);
                  },
                );
              });
            });
          });
        });
      });
    });
  }

  AlertDialog scanRecordShowDialog(String selectedProductName) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        content: Container(
          width: MediaQuery.of(context).size.width * 0.8,
          height: MediaQuery.of(context).size.height * 0.7,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(
                      selectedProductName != null ? selectedProductName : '',
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.center,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: _search_controller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey[700]),
                              hintText: LocaleUtils.getString(
                                  mContext, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Container(
                width: screenSize.width,
                height: 35,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Align(
                        child: Text(LocaleUtils.getString(mContext, 'SerialNo'),
                            style: TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w500,
                                fontFamily: 'helvetica',
                                color: Colors.black)),
                        alignment: Alignment.center,
                      ),
                      flex: 1,
                    ),
                    Expanded(
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(LocaleUtils.getString(mContext, 'BatchNo'),
                            style: TextStyle(
                                fontSize: 14.0,
                                fontWeight: FontWeight.w500,
                                fontFamily: 'helvetica',
                                color: Colors.black)),
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: receiveStickerList.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    //return receiveStickerList.length > 0
                    return receiveStickerList.isNotEmpty
                        ? Column(
                            children: <Widget>[
                              Container(
                                height: 35,
                                width: screenSize.width,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                            receiveStickerList[index]
                                                .varSticker
                                                .toString(),
                                            style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w400,
                                              fontFamily: 'helvetica',
                                              color: getColorCode(index),
                                            )),
                                      ),
                                      flex: 1,
                                    ),
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                            receiveStickerList[index]
                                                .varBatch_No,
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: 'helvetica',
                                                color: getColorCode(index))),
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              ),
                              Divider(color: Colors.black54),
                            ],
                          )
                        : Container();
                  },
                ),
              ),
              Container(
                width: screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(mContext, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  Color getColorCode(int index) {
    if (receiveStickerList[index].varColor.contains('N')) {
      return Colors.red;
    } else if (receiveStickerList[index].varColor.contains('G')) {
      return const Color(0xFF00793A);
    } else {
      return Colors.black;
    }
  }

  void filterSearchResults(String query) {
    print(query);
    //openScanRecordDialog(query, false);
  }

  void cancelReceive() {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs.getInt(PREF_FK_RECEIVE_GL_CODE).then((int fkReceiveGlCode) {
        databaseHelper
            .cancelTransactionForReceive(int.parse(initGlCode), fkReceiveGlCode)
            .then((int id) {
          //Navigator.pop(context, false);
          if (Navigator.canPop(context)) {
            Navigator.pop(mContext);
          } else {
            final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
            Navigator.pushAndRemoveUntil(
                context, route, (Route<dynamic> route) => false);
          }
        });
      });
    });
  }

  void receiveBtnCall() {
    _loading = true;
    dismissProgressHUD();
    sharedPrefs.getInt(PREF_FK_RECEIVE_GL_CODE).then((int fkReceiveGlCode) {
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        databaseHelper
            .getTotalArticleUnitsForReceive(fkReceiveGlCode, fkDispatchGlCode)
            .then((TotalProductUnitsModel model) {
          if (model != null) {
            if (model.intTotalUnit > 0) {
              databaseHelper
                  .getInvalidStickerForReceive(fkReceiveGlCode)
                  .then((List<ScanDataModel> invalidList) {
                _loading = false;
                dismissProgressHUD();
                invalidStickerList.clear();
                invalidStickerList.addAll(invalidList);
                showDialog<Map>(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
                    return dispatchDialog(model.intProductCount,
                        model.intTotalUnit, model.intPendingCount);
                  },
                );
              });
            } else {
              _loading = false;
              dismissProgressHUD();
              showDialog<Map>(
                barrierDismissible: false,
                context: context,
                builder: (context) {
                  return CustomAlertDialog(
                    content: LocaleUtils.getString(
                        mContext, 'YouHaveNotScannedAnyLabelYet'),
                    title: PROJECT_NAME == 'BASF_HK'
                        ? BASF_HK_APP_Name
                        : Zydus_APP_Name,
                    isShowNagativeButton: false,
                    textNagativeButton: '',
                    textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                    onPressedNegative: () {},
                    onPressedPositive: () {},
                  );
                },
              );
            }
          } else {
            _loading = false;
            dismissProgressHUD();
            showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return CustomAlertDialog(
                  content: LocaleUtils.getString(
                      mContext, 'YouHaveNotScannedAnyLabelYet'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                );
              },
            );
          }
        });
      });
    });
  }

  AlertDialog dispatchDialog(
      int totalArticle, int totalScanned, int totalRemain) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        //content: invalidStickerList.length > 0
        content: invalidStickerList.isNotEmpty
            ? Container(
                width: MediaQuery.of(context).size.width * 0.8,
                height: MediaQuery.of(context).size.height * 0.7,
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      height: 40,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: MarqueeWidget(
                          direction: Axis.horizontal,
                          child: Text(
                              varOrganizationName != null
                                  ? LocaleUtils.getString(mContext, 'RecFrom') +
                                      '$varOrganizationName'
                                  : '',
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'helvetica',
                                  color: Colors.white)),
                        ),
                      ),
                      width: screenSize.width,
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(mContext, 'TotUnits'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalScanned.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalArticle.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10),
                      child: Text(
                          LocaleUtils.getString(mContext, 'InvalidCodes'),
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'helvetica',
                              color: const Color(colorPrimary))),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 10),
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Text(
                          LocaleUtils.getString(
                              mContext, 'ThisTranWillProceedWithoutBelowCode'),
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'helvetica',
                              color: Colors.black)),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: invalidStickerList.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            height: 35,
                            alignment: Alignment.center,
                            child: Column(
                              children: <Widget>[
                                Text(
                                    //invalidStickerList.length > 0
                                    invalidStickerList.isNotEmpty
                                        ? '${invalidStickerList[index].varSticker} (#${invalidStickerList[index].intRowNo})'
                                        : '',
                                    style: TextStyle(
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'helvetica',
                                        color: Colors.red)),
                                Divider(color: Colors.black54),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'RemainingUnits_'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalRemain.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    chrTranType.contains('R') &&
                        globals.sapDocNoConfiguration == 'Y' ? Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: _controllerSAPDocNo,
                        autofocus: false,
                        autocorrect: false,
                        decoration: InputDecoration(
                          border: new OutlineInputBorder(
                              borderSide:
                              new BorderSide(color: Colors.grey)),
                          hintStyle: TextStyle(color: Colors.grey[700]),
                          hintText: '${globals.sapDocNoTitle}',
                          counterText: '',
                        ),
                        maxLines: 1,
                        maxLength: EditTxtMaxLengths,
                      ),
                    )
                        : Container(),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Cancel'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                                _controllerSAPDocNo.clear();
                              },
                            ),
                            flex: 1,
                          ),
                          Container(
                            width: 0.7,
                          ),
                          Expanded(
                            child: ButtonDialogWidgets(
                                buttonName:
                                    LocaleUtils.getString(mContext, 'Confirm'),
                                buttonColor: const Color(colorPrimary),
                                textColor: Colors.white,
                                onTap: () {
                                  if (chrTranType.contains('R') &&
                                      globals.sapDocNoConfiguration == 'Y' &&
                                      globals.sapDocNoMandatoryConfiguration ==
                                          'Y') {
                                    if (_controllerSAPDocNo.text.isNotEmpty) {
                                      finalReceive(
                                          _controllerSAPDocNo.text.toString());
                                    } else {
                                      Fluttertoast.showToast(
                                          msg:
                                          '${LocaleUtils.getString(mContext,
                                              'plz_enter_your')} ${globals
                                              .sapDocNoTitle}',
                                          toastLength: Toast.LENGTH_SHORT,
                                          gravity: ToastGravity.BOTTOM,
                                          timeInSecForIos: 1,
                                          backgroundColor: Colors.grey,
                                          textColor: Colors.black,
                                          fontSize: 16.0);
                                    }
                                  } else {
                                    finalReceive('');
                                  }
                                }),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            : Container(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: screenSize.width,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: MarqueeWidget(
                          direction: Axis.horizontal,
                          child: Text(
                              varOrganizationName != null
                                  ? LocaleUtils.getString(mContext, 'RecFrom') +
                                      ' $varOrganizationName'
                                  : '',
                              style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'helvetica',
                                  color: Colors.white)),
                        ),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 20, bottom: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(mContext, 'TotUnits'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalScanned.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalArticle.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'RemainingUnits_'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(totalRemain.toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    chrTranType.contains('R') &&
                        globals.sapDocNoConfiguration == 'Y'
                        ? Padding(
                      padding: const EdgeInsets.all(10),
                      child: TextFormField(
                        controller: _controllerSAPDocNo,
                        autofocus: false,
                        autocorrect: false,
                        decoration: InputDecoration(
                          border: new OutlineInputBorder(
                              borderSide:
                              new BorderSide(color: Colors.grey)),
                          hintStyle: TextStyle(color: Colors.grey[700]),
                          hintText: '${globals.sapDocNoTitle}',
                          counterText: '',
                        ),
                        maxLines: 1,
                        maxLength: EditTxtMaxLengths,
                      ),
                    )
                        : Container(),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Cancel'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                                _controllerSAPDocNo.clear();
                              },
                            ),
                            flex: 1,
                          ),
                          Container(
                            width: 0.7,
                          ),
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Confirm'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                //if (globals.SAPDocNoMandatoryConfiguration == 'Y') {
                                if (chrTranType.contains('R') &&
                                    globals.sapDocNoConfiguration == 'Y' &&
                                    globals.sapDocNoMandatoryConfiguration ==
                                        'Y') {
                                  if (_controllerSAPDocNo.text.isNotEmpty) {
                                    finalReceive(
                                        _controllerSAPDocNo.text.toString());
                                  } else {
                                    Fluttertoast.showToast(
                                        msg:
                                        '${LocaleUtils.getString(mContext,
                                            'plz_enter_your')} ${globals
                                            .sapDocNoTitle}',
                                        toastLength: Toast.LENGTH_SHORT,
                                        gravity: ToastGravity.BOTTOM,
                                        timeInSecForIos: 1,
                                        backgroundColor: Colors.grey,
                                        textColor: Colors.black,
                                        fontSize: 16.0);
                                  }
                                } else {
                                  finalReceive('');
                                }
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
        );
  }

  void finalReceive(String SAPDocNo) {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        sharedPrefs.getInt(PREF_FK_RECEIVE_GL_CODE).then((int fkReceiveGlCode) {
          sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int fkMainCustomerGlCode) {
            databaseHelper
                .updateStickerDetailsForReceive(int.parse(initGlCode),
                    fkReceiveGlCode, fkMainCustomerGlCode)
                .then((int id) {
              databaseHelper
                  .updateCPMCustomerReceive(
                  int.parse(initGlCode), fkReceiveGlCode, SAPDocNo)
                  .then((int id) {
                databaseHelper
                    .updatePalletBreakForReceive(
                        int.parse(initGlCode), fkReceiveGlCode)
                    .then((int id) {
                  databaseHelper
                      .updateCPMCustomerDispatchProduct(
                          int.parse(initGlCode),
                          fkReceiveGlCode,
                          fkDispatchGlCode,
                          fkMainCustomerGlCode)
                      .then((int id) {
                    databaseHelper
                        .updateCPMDispatchForReceive(
                            int.parse(initGlCode), fkDispatchGlCode)
                        .then((int id) {
                      sharedPrefs.setInt(PREF_FK_RECEIVE_GL_CODE, 0);
                      final Route route = CupertinoPageRoute(
                          builder: (context) => CongratulationScreen());
                      Navigator.pushAndRemoveUntil(context, route,
                          ModalRoute.withName(DASHBOARD_SCREEN));
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final reScanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ReScan'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          reScanBtn();
        },
      ),
    );

    final closeButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Discard'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(
                    mContext, 'AreYouSureUWant2DiscardTransaction'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  cancelReceive();
                },
              );
            },
          );
        },
      ),
    );

    final receiveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Receive'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          receiveBtnCall();
        },
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          if (Navigator.canPop(context)) {
            Navigator.pop(mContext, true);
          } else {
            final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
            Navigator.pushAndRemoveUntil(
                context, route, (Route<dynamic> route) => false);
          }
          // Future.value(false);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (Navigator.canPop(context)) {
                Navigator.pop(mContext, true);
              } else {
                final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
                Navigator.pushAndRemoveUntil(
                    context, route, (Route<dynamic> route) => false);
              }
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName, subTitle, topHeaderImage, receiveCount),
                      CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_THIRD, true),
                      Container(
                        child: Card(
                          elevation: 3,
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Expanded(
                                  child: Row(
                                    children: <Widget>[
                                      Text(
                                        LocaleUtils.getString(
                                            mContext, 'Date_'),
                                        style: TextStyle(
                                          fontSize: 15.0,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 2),
                                        child: Text(
                                          dispatchDate,
                                          style: TextStyle(
                                            fontSize: 14.0,
                                            color: Colors.black,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                        ),
                                      )
                                    ],
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.max,
                                  ),
                                  flex: 2,
                                ),
                                Expanded(
                                  child: Center(
                                    child: Wrap(
                                      children: <Widget>[
                                        Text(
                                          doSTOTitle,
                                          style: TextStyle(
                                            fontSize: 15.0,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w700,
                                          ),
                                        ),
                                        Text(
                                          DoStoNo,
                                          style: TextStyle(
                                            fontSize: 14.0,
                                            color: Colors.black,
                                          ),
                                        ),
                                      ],
                                      alignment: WrapAlignment.center,
                                      crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                      direction: Axis.horizontal,
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 40,
                        color: const Color(colorAccent),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotUnits_'),
                                    style: prifixTxtPrimaryStyle,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(
                                      calUUnitProductTotal(receiveDataList)
                                          .toString(),
                                      style: textPrimaryStyle,
                                    ),
                                  )
                                ],
                              ),
                              flex: 1,
                            ),
                            Container(
                              width: 1,
                              color: Colors.white70,
                            ),
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle_'),
                                    style: prifixTxtPrimaryStyle,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(
                                      receiveDataList.length.toString(),
                                      style: textPrimaryStyle,
                                    ),
                                  )
                                ],
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          alignment: Alignment.topLeft,
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Text(
                                    LocaleUtils.getString(
                                        mContext, 'ScanningDetails'),
                                    style: prifixTxtStyle),
                              ),
                              Expanded(
                                child: !loadingFlag
                                    //? receiveDataList.length > 0
                                    ? receiveDataList.isNotEmpty
                                        ? Container(
                                            child: ListView.builder(
                                              itemCount: receiveDataList.length,
                                              shrinkWrap: true,
                                              itemBuilder:
                                                  (BuildContext context,
                                                      int index) {
                                                return InkWell(
                                                  child: Card(
                                                      margin:
                                                          const EdgeInsets.only(
                                                              left: 0,
                                                              top: 7,
                                                              bottom: 7,
                                                              right: 0),
                                                      elevation: 3,
                                                      child: Container(
                                                        padding:
                                                            const EdgeInsets
                                                                .all(10),
                                                        child: Column(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 0),
                                                              child: Wrap(
                                                                direction: Axis
                                                                    .horizontal,
                                                                alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                children: <
                                                                    Widget>[
//                                                              Text(
//                                                                LocaleUtils
//                                                                    .getString(
//                                                                        mContext,
//                                                                        'ArticleName_'),
//                                                                style:
//                                                                    prifixTxtStyle,
//                                                              ),
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        top: 0),
                                                                    child: Text(
                                                                      receiveDataList[
                                                                              index]
                                                                          .varProduct_SKU_NAME,
                                                                      style:
                                                                          textStyle,
                                                                    ),
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      top: 3),
                                                              child: Row(
                                                                children: <
                                                                    Widget>[
                                                                  Expanded(
                                                                    child: Row(
                                                                      children: <
                                                                          Widget>[
                                                                        Text(
                                                                          LocaleUtils.getString(
                                                                              mContext,
                                                                              'Units_'),
                                                                          style:
                                                                              titleBoldStyle,
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              const EdgeInsets.only(top: 2),
                                                                          child:
                                                                              Text(
                                                                            receiveDataList[index].intTotalUnit.toString(),
                                                                            style:
                                                                                textNormalStyle,
                                                                          ),
                                                                        )
                                                                      ],
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      mainAxisAlignment:
                                                                          MainAxisAlignment
                                                                              .start,
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                  Expanded(
                                                                    child: Row(
                                                                      children: <
                                                                          Widget>[
                                                                        Text(
                                                                          LocaleUtils.getString(
                                                                              mContext,
                                                                              'Scanned_'),
                                                                          style:
                                                                              titleBoldStyle,
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              const EdgeInsets.only(top: 2),
                                                                          child:
                                                                              Text(
                                                                            receiveDataList[index].intScanCount.toString(),
                                                                            style:
                                                                                textNormalStyle,
                                                                          ),
                                                                        )
                                                                      ],
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                  Expanded(
                                                                    child: Row(
                                                                      crossAxisAlignment:
                                                                          CrossAxisAlignment
                                                                              .center,
                                                                      children: <
                                                                          Widget>[
                                                                        Text(
                                                                          LocaleUtils.getString(
                                                                              mContext,
                                                                              'Pending'),
                                                                          style:
                                                                              titleBoldStyle,
                                                                        ),
                                                                        Padding(
                                                                          padding:
                                                                              const EdgeInsets.only(top: 2),
                                                                          child:
                                                                              Text(
                                                                            receiveDataList[index].intPendingCount.toString(),
                                                                            style:
                                                                                textNormalStyle,
                                                                          ),
                                                                        )
                                                                      ],
                                                                    ),
                                                                    flex: 1,
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      )),
                                                  onTap: () {
                                                    getStickerRecordListViewItem(
                                                        receiveDataList[index]
                                                            .fk_Product_SKUGlCode,
                                                        receiveDataList[index]
                                                            .varProduct_SKU_NAME);
                                                  },
                                                );
                                              },
                                            ),
                                          )
                                        : Container()
                                    : Center(
                                        child: const CircularProgressIndicator(
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                                    Color(colorPrimary))),
                                      ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                        flex: 1,
                      ),
                      Container(
                        width: screenSize.width,
                        height: 45,
                        margin: const EdgeInsets.all(15),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: reScanButton,
                              flex: 1,
                            ),
                            Container(
                              width: 10,
                            ),
                            Expanded(
                              child: closeButton,
                              flex: 1,
                            ),
                            Container(
                              width: 10,
                            ),
                            Expanded(
                              child: receiveButton,
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

// ignore: must_be_immutable
class StickerDialog extends StatefulWidget {
  Size screenSize;
  List<ReceiveScanRecordModel> listSticker = List();
  List<ReceiveScanRecordModel> listStickerDisplay = List();

  StickerDialog({this.screenSize, this.listSticker, this.listStickerDisplay});

  @override
  _StickerDialogState createState() => _StickerDialogState();
}

class _StickerDialogState extends State<StickerDialog> {
  TextEditingController _search_controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      // ignore: missing_return
      onWillPop: () {
        // Future.value(false);
      },
      child: AlertDialog(
          contentPadding: const EdgeInsets.all(0.0),
          shape: RoundedRectangleBorder(
              borderRadius: const BorderRadius.all(Radius.circular(5.0))),
          //title:  Text('Alert Dialog title'),
          content: Container(
            width: widget.screenSize.width * 0.9,
            height: widget.screenSize.height * 0.5,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  width: widget.screenSize.width,
                  height: 40,
                  padding: const EdgeInsets.only(left: 10, right: 10),
                  color: const Color(colorPrimary),
                  child: Align(
                    child: Text(
                        LocaleUtils.getString(context, 'ScannedSerialNo'),
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'helvetica',
                            color: Colors.white)),
                    alignment: Alignment.centerLeft,
                  ),
                ),
                Container(
                  color: const Color(colorAccent),
                  padding: const EdgeInsets.all(10),
                  child: Container(
                    height: 40,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(7)),
                        color: Colors.white),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Flexible(
                          child: Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: TextField(
                              controller: _search_controller,
                              //enableInteractiveSelection: false,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintStyle: TextStyle(color: Colors.grey[700]),
                                hintText: LocaleUtils.getString(
                                    context, 'SearchLabel'),
                                counterText: '',
                              ),
                              onChanged: (value) {
                                filterSearchResults(value);
                              },
                              maxLines: 1,
                              maxLength: EditTxtMaxLengths,
                            ),
                          ),
                          flex: 1,
                        ),
                        Flexible(
                          child: IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.search,
                                color: Color(colorPrimary),
                              )),
                          flex: 0,
                        )
                      ],
                    ),
                  ),
                ),
                Expanded(
                  //child: widget.listStickerDisplay.length > 0
                  child: widget.listStickerDisplay.isNotEmpty
                      ? Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Container(
                                height: 35,
                                child: Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Align(
                                        child: Text(
                                            LocaleUtils.getString(
                                                context, 'SerialNo'),
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: 'helvetica',
                                                color: Colors.black)),
                                        alignment: Alignment.center,
                                      ),
                                      flex: 2,
                                    ),
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Text(
                                            LocaleUtils.getString(
                                                context, 'BatchNo'),
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: 'helvetica',
                                                color: Colors.black)),
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              ),
                              Divider(color: Colors.black54),
                              Expanded(
                                child: ListView.builder(
                                  itemCount: widget.listStickerDisplay.length,
                                  shrinkWrap: true,
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    //return widget.listStickerDisplay.length > 0
                                    return widget.listStickerDisplay.isNotEmpty
                                        ? Column(
                                            children: <Widget>[
                                              Container(
                                                height: 35,
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceEvenly,
                                                  children: <Widget>[
                                                    Expanded(
                                                      child: Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Text(
                                                            widget.listStickerDisplay[index]
                                                                        .intNoOfSticker >
                                                                    0
                                                                ? '${widget.listStickerDisplay[index].varSticker} - (${widget.listStickerDisplay[index].intNoOfSticker})'
                                                                : '${widget.listStickerDisplay[index].varSticker}',
                                                            style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontFamily:
                                                                  'helvetica',
                                                              color:
                                                                  getColorCode(
                                                                      index),
                                                            )),
                                                      ),
                                                      flex: 2,
                                                    ),
                                                    Expanded(
                                                      child: Align(
                                                        alignment:
                                                            Alignment.center,
                                                        child: Text(
                                                            widget
                                                                .listStickerDisplay[
                                                                    index]
                                                                .varBatch_No,
                                                            style: TextStyle(
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400,
                                                                fontFamily:
                                                                    'helvetica',
                                                                color:
                                                                    getColorCode(
                                                                        index))),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Divider(color: Colors.black54),
                                            ],
                                          )
                                        : Container();
                                  },
                                ),
                              ),
                            ],
                          ),
                        )
                      : Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Image.asset(
                                'assets/nodata_icon.png',
                                height: 100,
                                width: 100,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 10),
                                child: Text(
                                  LocaleUtils.getString(context, 'NoDataFound'),
                                  style: prifixTxtStyle,
                                ),
                              ),
                            ],
                          ),
                        ),
                  flex: 1,
                ),
                Container(
                  width: widget.screenSize.width,
                  height: 45,
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: ButtonDialogWidgets(
                          buttonName: LocaleUtils.getString(context, 'Close'),
                          buttonColor: const Color(colorPrimary),
                          textColor: Colors.white,
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )
          //actions: _actionButton()
          ),
    );
  }

  Color getColorCode(int index) {
    if (widget.listStickerDisplay[index].varColor.contains('N')) {
      return Colors.red;
    } else if (widget.listStickerDisplay[index].varColor.contains('G')) {
      return const Color(0xFF00793A);
    } else {
      return Colors.black;
    }
  }

  void filterSearchResults(String query) {
    print(query);
    final List<ReceiveScanRecordModel> dummySearchList =
        List<ReceiveScanRecordModel>();
    dummySearchList.addAll(widget.listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<ReceiveScanRecordModel> dummyListData =
          List<ReceiveScanRecordModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(widget.listSticker);
        });
    }

    //print(widget.listStickerDisplay.length);
  }
}
