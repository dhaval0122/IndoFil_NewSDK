import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/ScreenRautes.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveFirstScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class ReceiveDataModel {
  int fk_Product_SKUGlCode;
  String varProduct_SKU_NAME;
  int intTotalUnit;
  int intScanCount;
  int intPendingCount;

  ReceiveDataModel({
    this.fk_Product_SKUGlCode,
    this.varProduct_SKU_NAME,
    this.intTotalUnit,
    this.intScanCount,
    this.intPendingCount,
  });

  ReceiveDataModel.fromMap(Map<String, dynamic> json) {
    this.fk_Product_SKUGlCode = json['fk_Product_SKUGlCode'];
    this.varProduct_SKU_NAME = json['varProduct_SKU_NAME'];
    this.intTotalUnit = json['intTotalUnit'];
    this.intScanCount = json['intScanCount'];
    this.intPendingCount = json['intPendingCount'];
  }
}

class ReceiveScanRecordModel {
  String varSticker;
  String varColor;
  String varBatch_No;
  int intNoOfSticker;

  ReceiveScanRecordModel(
      {this.varSticker, this.varColor, this.varBatch_No, this.intNoOfSticker});

  ReceiveScanRecordModel.fromMap(Map<String, dynamic> json) {
    this.varSticker = json['varSticker'];
    this.varColor = json['varColor'];
    this.varBatch_No = json['varBatch_No'];
    this.intNoOfSticker =
        json.containsKey('intNoOfSticker') ? json['intNoOfSticker'] : 0;
  }
}

class ReceiveSecondScreen extends StatefulWidget {
  @override
  ReceiveSecondScreenState createState() => ReceiveSecondScreenState();
}

class ReceiveSecondScreenState extends State<ReceiveSecondScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false;
  bool loadingFlag = false, isNotification = false, isSync = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '',
      subTitle = '',
      topHeaderImage = '',
      finalSettleMessage = '';
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  String dispatchDate = '',
      DoStoNo = '',
      doSTOTitle = '',
      settleDoTitle = '',
      varOrganizationName = '';
  List<ReceiveDataModel> receiveDataList;
  List<ReceiveScanRecordModel> receiveStickerList;
  List<ReceiveScanRecordModel> receiveStickerListClone;
  int receiveCount = 0;
  final TextEditingController searchcontroller = TextEditingController();
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    receiveStickerList = List();
    receiveStickerListClone = List();
    receiveDataList = List();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_RECEIVE) {
        topHeaderImage = 'assets/receive_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_RECEIVE_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          receiveCount = count;
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getReceiveRecords();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void getStickerRecordListViewItem(
      int fkProductSKUGlCode, String selectedProductName) {
    _loading = true;
    dismissProgressHUD();

    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs
          .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
          .then((int fkMainCustomerGlCode) {
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fkDispatchGlCode) {
          sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fkDispatchGlCode) {
            sharedPrefs
                .getInt(PREF_FK_RECEIVE_GL_CODE)
                .then((int fkReceiveGlCode) {
              databaseHelper
                  .getReceiveStickerRecord(
                      fkReceiveGlCode, fkDispatchGlCode, fkProductSKUGlCode, '')
                  .then((List<ReceiveScanRecordModel> data) {
                _loading = false;
                dismissProgressHUD();
                print('=========fkReceiveGlCode======$fkReceiveGlCode');
                receiveStickerList.clear();
                receiveStickerListClone.clear();
                receiveStickerList.addAll(data);
                receiveStickerListClone.addAll(data);
                showDialog<Map>(
                  barrierDismissible: false,
                  context: context,
                  builder: (context) {
//                    return scanRecordShowDialog(selectedProductName);
                    return MyForm(
                        screenSize: screenSize,
                        listSticker: receiveStickerListClone,
                        listStickerDisplay: receiveStickerList);
                  },
                );
              });
            });
          });
        });
      });
    });
  }

  void getReceiveRecords() async {
    setState(() {
      loadingFlag = true;
    });

    await sharedPrefs
        .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
        .then((int fkMainCustomerGlCode) {
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        databaseHelper
            .getReceiveSecondRecordList(fkMainCustomerGlCode, fkDispatchGlCode)
            .then((List<ReceiveRecordModel> data) {
          print('=====DATA=========${data.toString()}');
          // if (data.length > 0) {
          if (data.isNotEmpty) {
            varOrganizationName = data[0].varFullName;
            getDateTimeFormat(data[0].dtDispatchDate);
            sharedPrefs
                .getString(PREF_CHAR_TRAN_TYPE_DISPATCH)
                .then((String chrType) {
              if (chrType.contains('S')) {
                print('1----------- ${data[0].varDONO}');
                DoStoNo = data[0].varDONO;
                doSTOTitle = '${data[0].varEntityName}: ';
                settleDoTitle = 'Settle ${globals.STO}';
                finalSettleMessage = 'Settle ${globals.STO} successfully.';
              } else {
                print('2----------- ${data[0].varDONO}');
                DoStoNo = data[0].varDONO;

                // DoStoNo = (DoStoNo == "akash " ? "akash":"Kanu");
                doSTOTitle = '${data[0].varEntityName}: ';
                settleDoTitle = 'Settle ${globals.DO}';
                finalSettleMessage = 'Settle ${globals.DO} successfully.';
              }
            });

            databaseHelper
                .getReceiveSecondDataList(
                    fkMainCustomerGlCode, fkDispatchGlCode)
                .then((List<ReceiveDataModel> data) {
              receiveDataList.clear();
              if (mounted) {
                loadingFlag = false;
                setState(() {
                  receiveDataList.addAll(data);
                });
              }
            });
          }
        });
      });
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getDateTimeFormat(String date) {
    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      _battery.getTimeFromUTC(date, dateFormat).then((String dateFormatted) {
        print('===getDateTimeFormat==dateFormatted===$dateFormatted');
        if (mounted) {
          setState(() {
            dispatchDate = dateFormatted;
          });
        }
      });
    });
  }

  int calUUnitProductTotal(List<ReceiveDataModel> dispatchScanModelsList) {
    int unitTotal = 0;
    for (int i = 0; i < dispatchScanModelsList.length; i++) {
      final ReceiveDataModel scanRecordModel = dispatchScanModelsList[i];
      unitTotal = unitTotal + scanRecordModel.intTotalUnit;
    }
    return unitTotal;
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void finalSettleCall(String resonText) {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs
          .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
          .then((int fkMainCustomerGlCode) {
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fkDispatchGlCode) {
          _battery.getUniqueNumber().then((String syncCode) {
            databaseHelper
                .insertCustomerReceiveForReject(resonText, "", syncCode,
                    int.parse(initGlCode), fkDispatchGlCode)
                .then((int id) {
              databaseHelper.getMaxReceiveID().then((int fkReceiveGlCode) {
                databaseHelper
                    .insertCustomerReceiveProductDetailsForReject(
                        fkReceiveGlCode,
                        syncCode,
                        int.parse(initGlCode),
                        fkDispatchGlCode)
                    .then((int id) {
                  databaseHelper
                      .updateCustomerDispatchProductDetailsForReject(
                          fkMainCustomerGlCode,
                          fkDispatchGlCode,
                          fkReceiveGlCode)
                      .then((int id) {
                    databaseHelper
                        .updateStickerDetailsForReject(fkMainCustomerGlCode,
                            int.parse(initGlCode), fkReceiveGlCode)
                        .then((int id) {
                      databaseHelper
                          .updateCustomerReceiveForReject(fkReceiveGlCode)
                          .then((int id) {
                        databaseHelper
                            .updateCPMDispatchForReceiveForReject(
                                int.parse(initGlCode), fkDispatchGlCode)
                            .then((int id) {
                          showDialog<Map>(
                            barrierDismissible: false,
                            context: context,
                            builder: (context) {
                              return WillPopScope(
                                  onWillPop: () {},
                                  child: CustomAlertDialog(
                                    content: finalSettleMessage,
                                    title: PROJECT_NAME == 'BASF_HK'
                                        ? BASF_HK_APP_Name
                                        : Zydus_APP_Name,
                                    isShowNagativeButton: false,
                                    textNagativeButton: '',
                                    textPositiveButton:
                                        LocaleUtils.getString(mContext, 'OK'),
                                    onPressedNegative: () {},
                                    onPressedPositive: () {
                                      Navigator.pop(context, true);
                                    },
                                  ));
                            },
                          );
                        });
                      });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  }

  void settleBtnDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'AreYouSureYouWantToSettle'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'no'),
              textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
              onPressedNegative: () {},
              onPressedPositive: () {
                /*showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return dispatchDialog();
                return dispatchDialog();
              },
            );*/
                _showDialog();
              },
            ));
      },
    );
  }

  void _showDialog() async {
    final TextEditingController _textFieldController = TextEditingController();

    await showDialog<Map>(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return AlertDialog(
            contentPadding: const EdgeInsets.all(16.0),
            content: Row(
              children: <Widget>[
                Expanded(
                    child: TextField(
                  autofocus: true,
                  //enableInteractiveSelection: false,
                  keyboardType: TextInputType.multiline,
                  maxLines: 3,
                  controller: _textFieldController,
                  decoration: InputDecoration(
                    //labelText: 'Please enter reason for settle order.',
                    hintText: LocaleUtils.getString(
                        mContext, 'PlzEnterReason4SettleOrder'),
                    hintStyle: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'helvetica',
                      color: Colors.black54,
                    ),
                  ),
                ))
              ],
            ),
            actions: <Widget>[
              FlatButton(
                  child: Text(LocaleUtils.getString(mContext, 'no'),
                      style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.w400,
                        fontFamily: 'helvetica',
                        color: Colors.black,
                      )),
                  onPressed: () {
                    Navigator.pop(context);
                  }),
              FlatButton(
                  child: Text(LocaleUtils.getString(mContext, 'yes'),
                      style: TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'helvetica',
                        color: Colors.black,
                      )),
                  onPressed: () {
                    Navigator.pop(context);
                    if (_textFieldController.text.trim().isEmpty) {
                      _showSnackBar(LocaleUtils.getString(
                          mContext, 'PlzEnterReason4Settlement'));
                    } else {
                      finalSettleCall(_textFieldController.text.toString());
                    }
                  })
            ],
            title: Text(
              LocaleUtils.getString(mContext, 'PlzEnterReason4SettleOrder'),
              style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'helvetica',
                  color: Colors.black),
              textAlign: TextAlign.left,
            ),
            titlePadding:
                const EdgeInsets.only(left: 16.0, top: 16.0, right: 16.0),
          );
        });
  }

  void receiveBtnCall() {
    sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        _battery.getUniqueNumber().then((String syncCode) {
          databaseHelper
              .insertCPMCustomerReceive(
              syncCode, int.parse(initGlCode), fkDispatchGlCode, "")
              .then((int id) {
            databaseHelper.getMaxReceiveID().then((int fkReceiveGlCode) {
              sharedPrefs
                  .setInt(PREF_FK_RECEIVE_GL_CODE, fkReceiveGlCode)
                  .then((bool isFkReceive) {
                redirectScanScreen();
              });
            });
          });
        });
      });
    });
  }

  void redirectScanScreen() {
    /*Navigator.pushNamedAndRemoveUntil(
        context, SCANNING_SCREEN, ModalRoute.withName(DASHBOARD_SCREEN));*/
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.pushAndRemoveUntil(
        context, route, ModalRoute.withName(DASHBOARD_SCREEN));
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final settleBtn = Padding(
      padding: EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: settleDoTitle,
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          settleBtnDialog();
        },
      ),
    );

    final receiveBtn = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Receive'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          receiveBtnCall();
        },
      ),
    );

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      resizeToAvoidBottomPadding: false,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(
                      userName, subTitle, topHeaderImage, receiveCount),
                  CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_FIRST, true),
                  Container(
                    child: Card(
                      elevation: 3,
                      margin: const EdgeInsets.only(
                          top: 10, left: 15, right: 15, bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                children: <Widget>[
                                  Text(LocaleUtils.getString(mContext, 'Date_'),
                                      style: titleBoldStyle),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2),
                                    child: Text(dispatchDate,
                                        style: textNormalStyle),
                                  )
                                ],
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                              ),
                              flex: 2,
                            ),
                            Expanded(
                              child: Center(
                                child: Wrap(
                                  children: <Widget>[
                                    Text(
                                      doSTOTitle,
                                      style: TextStyle(
                                        fontSize: 15.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    Text(
                                      DoStoNo,
                                      //style: textStyle,
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ],
                                  alignment: WrapAlignment.center,
                                  crossAxisAlignment: WrapCrossAlignment.center,
                                  direction: Axis.horizontal,
                                ),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    color: const Color(colorAccent),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotUnits_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Text(
                                  calUUnitProductTotal(receiveDataList)
                                      .toString(),
                                  style: textPrimaryStyle,
                                ),
                              )
                            ],
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: 1,
                          color: Colors.white70,
                        ),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotArticle_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 2),
                                child: Text(
                                  receiveDataList.length.toString(),
                                  style: textPrimaryStyle,
                                ),
                              )
                            ],
                          ),
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.topLeft,
                      margin: const EdgeInsets.only(
                          top: 10, left: 15, right: 15, bottom: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(top: 5),
                            child: Text(
                                LocaleUtils.getString(
                                    mContext, 'ScanningDetails'),
                                style: prifixTxtStyle),
                          ),
                          Expanded(
                            child: !loadingFlag
                                //? receiveDataList.length > 0
                                ? receiveDataList.length > 0
                                    ? Container(
                                        child: ListView.builder(
                                          itemCount: receiveDataList.length,
                                          shrinkWrap: true,
                                          itemBuilder: (BuildContext context,
                                              int index) {
                                            return InkWell(
                                              child: Card(
                                                  margin: const EdgeInsets.only(
                                                      left: 0,
                                                      top: 7,
                                                      bottom: 7,
                                                      right: 0),
                                                  elevation: 3,
                                                  child: Container(
                                                    padding:
                                                        const EdgeInsets.all(
                                                            10),
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      children: <Widget>[
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 0),
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            alignment:
                                                                WrapAlignment
                                                                    .start,
                                                            crossAxisAlignment:
                                                                WrapCrossAlignment
                                                                    .center,
                                                            children: <Widget>[
//                                                              Text(
//                                                                LocaleUtils
//                                                                    .getString(
//                                                                        mContext,
//                                                                        'ArticleName_'),
//                                                                style:
//                                                                    titleBoldStyle,
//                                                              ),
                                                              Padding(
                                                                padding:
                                                                    const EdgeInsets
                                                                            .only(
                                                                        top: 0),
                                                                child: Text(
                                                                  '${receiveDataList[index]
                                                                      .varProduct_SKU_NAME}',
                                                                  style:
                                                                      textNormalStyle,
                                                                ),
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                        Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(top: 3),
                                                          child: Row(
                                                            children: <Widget>[
                                                              Expanded(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      LocaleUtils.getString(
                                                                          mContext,
                                                                          'Units_'),
                                                                      style:
                                                                          titleBoldStyle,
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              2),
                                                                      child:
                                                                          Text(
                                                                        receiveDataList[index]
                                                                            .intTotalUnit
                                                                            .toString(),
                                                                        style:
                                                                            textNormalStyle,
                                                                      ),
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                              Expanded(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      LocaleUtils.getString(
                                                                          mContext,
                                                                          'Scanned_'),
                                                                      style:
                                                                          titleBoldStyle,
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              2),
                                                                      child:
                                                                          Text(
                                                                        receiveDataList[index]
                                                                            .intScanCount
                                                                            .toString(),
                                                                        style:
                                                                            textNormalStyle,
                                                                      ),
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                              Expanded(
                                                                child: Row(
                                                                  crossAxisAlignment:
                                                                      CrossAxisAlignment
                                                                          .center,
                                                                  mainAxisAlignment:
                                                                      MainAxisAlignment
                                                                          .start,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      LocaleUtils.getString(
                                                                          context,
                                                                          'Pending'),
                                                                      style:
                                                                          titleBoldStyle,
                                                                    ),
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              2),
                                                                      child:
                                                                          Text(
                                                                        receiveDataList[index]
                                                                            .intPendingCount
                                                                            .toString(),
                                                                        style:
                                                                            textNormalStyle,
                                                                      ),
                                                                    )
                                                                  ],
                                                                ),
                                                                flex: 1,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  )),
                                              onTap: () {
                                                getStickerRecordListViewItem(
                                                    receiveDataList[index]
                                                        .fk_Product_SKUGlCode,
                                                    receiveDataList[index]
                                                        .varProduct_SKU_NAME);
                                              },
                                            );
                                          },
                                        ),
                                      )
                                    : Container()
                                : Center(
                                    child: const CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Color(colorPrimary))),
                                  ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Container(
                      width: screenSize.width,
                      height: 45,
                      margin: const EdgeInsets.all(15),
                      child: globals.SETTLE_DO == 'Y'
                          ? Row(
                              children: <Widget>[
                                Expanded(
                                  child: settleBtn,
                                  flex: 1,
                                ),
                                Container(
                                  width: 10,
                                ),
                                Expanded(
                                  child: receiveBtn,
                                  flex: 1,
                                ),
                              ],
                            )
                          : Row(
                              children: <Widget>[
                                Expanded(
                                  child: receiveBtn,
                                  flex: 1,
                                ),
                              ],
                            )),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

/*class _SystemPadding extends StatelessWidget {
  final Widget child;

  _SystemPadding({Key key, this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var mediaQuery = MediaQuery.of(context);
    return AnimatedContainer(
        padding: mediaQuery.viewInsets,
        duration: const Duration(milliseconds: 300),
        child: child);
  }
}*/

class MyForm extends StatefulWidget {
  Size screenSize;
  List<ReceiveScanRecordModel> listSticker = List();
  List<ReceiveScanRecordModel> listStickerDisplay = List();

  MyForm({this.screenSize, this.listSticker, this.listStickerDisplay});

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  TextEditingController searchcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: widget.screenSize.width * 0.9,
          height: widget.screenSize.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: widget.screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(LocaleUtils.getString(context, 'ScannedSerialNo'),
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.centerLeft,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: searchcontroller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey[700]),
                              hintText:
                                  LocaleUtils.getString(context, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                //child: widget.listStickerDisplay.length > 0
                child: widget.listStickerDisplay.isNotEmpty
                    ? Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: <Widget>[
                            Container(
                              height: 35,
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Padding(
                                      padding: EdgeInsets.only(left: 20),
                                      child: Align(
                                        child: Text(
                                            LocaleUtils.getString(
                                                context, 'SerialNo'),
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: 'helvetica',
                                                color: Colors.black)),
                                        alignment: Alignment.centerLeft,
                                      ),
                                    ),
                                    flex: 2,
                                  ),
                                  Expanded(
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(
                                          LocaleUtils.getString(
                                              context, 'BatchNo'),
                                          style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: 'helvetica',
                                              color: Colors.black)),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                            Divider(color: Colors.black54),
                            Expanded(
                              child: ListView.builder(
                                itemCount: widget.listStickerDisplay.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  //return widget.listStickerDisplay.length > 0
                                  return widget.listStickerDisplay.isNotEmpty
                                      ? Column(
                                          children: <Widget>[
                                            Container(
                                              height: 35,
                                              child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceAround,
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 20),
                                                        child: Align(
                                                          alignment: Alignment
                                                              .centerLeft,
                                                          child: Text(
                                                            widget.listStickerDisplay[index]
                                                                        .intNoOfSticker >
                                                                    0
                                                                ? '${widget.listStickerDisplay[index].varSticker} - (${widget.listStickerDisplay[index].intNoOfSticker})'
                                                                : '${widget.listStickerDisplay[index].varSticker}',
                                                            style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontFamily:
                                                                  'helvetica',
                                                              color:
                                                                  getColorCode(
                                                                      index),
                                                            ),
                                                            textAlign:
                                                                TextAlign.left,
                                                          ),
                                                        )),
                                                    flex: 2,
                                                  ),
                                                  Expanded(
                                                    child: Align(
                                                      alignment:
                                                          Alignment.center,
                                                      child: Text(
                                                          widget
                                                              .listStickerDisplay[
                                                                  index]
                                                              .varBatch_No,
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              fontFamily:
                                                                  'helvetica',
                                                              color:
                                                                  getColorCode(
                                                                      index))),
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Divider(color: Colors.black54),
                                          ],
                                        )
                                      : Container();
                                },
                              ),
                            ),
                          ],
                        ),
                      )
                    : Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              'assets/nodata_icon.png',
                              height: 100,
                              width: 100,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                LocaleUtils.getString(context, 'NoDataFound'),
                                style: prifixTxtStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                flex: 1,
              ),
              Container(
                width: widget.screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(context, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  Color getColorCode(int index) {
    if (widget.listStickerDisplay[index].varColor.contains('N')) {
      return Colors.red;
    } else if (widget.listStickerDisplay[index].varColor.contains('G')) {
      return const Color(0xFF00793A);
    } else {
      return Colors.black;
    }
  }

  void filterSearchResults(String query) {
    final List<ReceiveScanRecordModel> dummySearchList =
        List<ReceiveScanRecordModel>();
    dummySearchList.addAll(widget.listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<ReceiveScanRecordModel> dummyListData =
          List<ReceiveScanRecordModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(widget.listSticker);
        });
    }

    print(widget.listStickerDisplay.length);
  }
}
