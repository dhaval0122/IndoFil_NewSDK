import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/MultiSelectDialogItem.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveSecondScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class ReceiveRecordModel {
  int intGlCode;
  String chrTransType;
  String varFullName;
  String varDONO;
  String varSONO;
  int intTotalUnit;
  int intTotalProduct;
  String varTranType;
  String chrColor;
  String dtDispatchDate;
  String varEntityName;
  String varReturnStatus;

  ReceiveRecordModel(
      {this.intGlCode,
        this.chrTransType,
        this.varFullName,
        this.varDONO,
        this.varSONO,
        this.intTotalUnit,
        this.intTotalProduct,
        this.varTranType,
        this.chrColor,
        this.dtDispatchDate,
        this.varEntityName,
        this.varReturnStatus});

  ReceiveRecordModel.fromMap(Map<String, dynamic> json) {
    this.intGlCode = json['intGlCode'];
    this.chrTransType = json['chrTransType'];
    this.varFullName = json['varFullName'];
    this.varDONO = json['varDONO'];
    this.varSONO = json['varSONO'];
    this.intTotalUnit = json['intTotalUnit'];
    this.intTotalProduct = json['intTotalProduct'];
    this.varTranType = json['varTranType'];
    this.chrColor = json['chrColor'];
    this.dtDispatchDate = json['dtDispatchDate'];
    this.varReturnStatus = json['varReturnStatus'];
    this.varEntityName = json.containsKey('varEntityName')
        ? json['varEntityName']
        .toString()
        .trim()
        .length == 0
        ? json['chrTransType'].toString().toLowerCase() == 's'
        ? 'STO No'
        : 'DO No'
        : json['varEntityName']
        : '';
  }
}

class FilterModel {
  String varTransactionType;
  String chrTransType;
  int intCount;

  FilterModel({this.varTransactionType, this.chrTransType, this.intCount});

  FilterModel.fromMap(Map<String, dynamic> json) {
    this.varTransactionType = json['varTransactionType'];
    this.chrTransType = json['chrTransType'];
    this.intCount = json['intCount'];
  }
}

class ReceiveFirstScreen extends StatefulWidget {
  @override
  ReceiveFirstScreenState createState() => ReceiveFirstScreenState();
}

class ReceiveFirstScreenState extends State<ReceiveFirstScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false;
  bool loadingFlag = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '', subTitle = '', topHeaderImage = '';
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController searchcontroller;
  List<ReceiveRecordModel> receiveRecordModelList;
  EcpSyncPlugin _battery;
  String displayDateFormat = '';
  int receiveCount = 0;
  bool isReloadDashboard = false, isNotification = false, isSync = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  String selectedTransactionType = "";
  String selectedTransactionCode = "";
  var selectedString;
  String mScreenState;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: 'Loading...',
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    searchcontroller = TextEditingController();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    _battery = EcpSyncPlugin();
    receiveRecordModelList = List();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });

    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_WITH_TIME_DEFAULT_FORMAT;
          }
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      mScreenState = screenState;
      if (screenState == TAG_RECEIVE) {
        topHeaderImage = 'assets/receive_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_RECEIVE_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          receiveCount = count;
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }
    setDefaultStatus();
    getReceiveRecords('', sharedPrefs, _battery, selectedTransactionCode);
  }

  void setDefaultStatus() async {
    selectedTransactionCode = "'D','R','S','F'";

    List<int> values = new List();
    values.add(1);
    if (globals.DOConfiguration == 'Y') {
      values.add(2);
      selectedString = values
          .map((int multiSelectDialogItem) => multiSelectDialogItem)
          .toSet();
    }
    if (globals.STOConfiguration == 'Y') {
      values.add(3);
      selectedString = values
          .map((int multiSelectDialogItem) => multiSelectDialogItem)
          .toSet();
    }
    if (globals.SRConfiguration == 'Y') {
      values.add(4);
      selectedString = values
          .map((int multiSelectDialogItem) => multiSelectDialogItem)
          .toSet();
    }
    if (globals.FOCConfiguration == 'Y') {
      values.add(5);
      selectedString = values
          .map((int multiSelectDialogItem) => multiSelectDialogItem)
          .toSet();
    }

    if (selectedString != null) {
      selectedTransactionType = "";
      selectedTransactionCode = "";
      await Future.forEach(selectedString, (int no) async {
        print('===selectedString===$no}');
        if (no == 2) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'DO';
          } else {
            selectedTransactionType = selectedTransactionType + ",DO";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'D'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'D'";
          }
        }
        if (no == 3) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'STO';
          } else {
            selectedTransactionType = selectedTransactionType + ",STO";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'S'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'S'";
          }
        }
        if (no == 4) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'Sales Return';
          } else {
            selectedTransactionType = selectedTransactionType + ",Sales Return";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'R'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'R'";
          }
        }
        if (no == 5) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'FOC';
          } else {
            selectedTransactionType = selectedTransactionType + ",FOC";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'F'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'F'";
          }
        }
      });
      print(selectedTransactionCode);
      await setStateCall();
    }
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void getReceiveRecords(String doNo, SharedPrefs sharedPrefs,
      EcpSyncPlugin _battery, String transactionCode) async {
    setState(() {
      loadingFlag = true;
    });

    await sharedPrefs
        .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
        .then((int fkMainCustomerGlCode) async {
      await databaseHelper
          .getReceiveDataList(fkMainCustomerGlCode, doNo, transactionCode)
          .then((List<ReceiveRecordModel> data) {
        receiveRecordModelList.clear();
        if (mounted) {
          setState(() {
            loadingFlag = false;
            receiveRecordModelList.addAll(data);
            sharedPrefs.setInt(PREF_RECEIVE_COUNT, data.length);
            receiveCount = data.length;
          });
        }
      });
    });
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                        LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                        LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                        LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void filterSearchResults(String doNo) {
    print(doNo);
    //openScanRecordDialog(query, false);
    getReceiveRecords(doNo, sharedPrefs, _battery, selectedTransactionCode);
  }

  String getDateTimeFormat(String date) {
    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      _battery.getTimeFromUTC(date, dateFormat).then((String dateFormatted) {
        print('===getDateTimeFormat==dateFormatted===$dateFormatted');
        return dateFormatted;
      });
    });
    return '';
  }

  String getLabelDate(int index) {
    String mChrType = receiveRecordModelList[index].chrTransType;
    if (mChrType == 'S') {
      return LocaleUtils.getString(mContext, 'transferDt');
    } else if (mChrType == 'D') {
      return LocaleUtils.getString(mContext, 'DispatchDt');
    } else if (mChrType == 'R') {
      return LocaleUtils.getString(mContext, 'returnDt');
    } else if (mChrType == 'F') {
      return LocaleUtils.getString(mContext, 'FocDt');
    } else {
      return LocaleUtils.getString(mContext, 'DispatchDt');
    }
  }

  String getDoSTOValues(int index) {
    if (receiveRecordModelList[index].chrTransType.contains('S')) {
      return receiveRecordModelList[index].varDONO;
    } else {
      return receiveRecordModelList[index].varDONO;
    }
  }

  void listViewClickEvent(int index) {
    print(
        '===listViewClickEvent=======${receiveRecordModelList[index].chrTransType}');
    sharedPrefs
        .setString(PREF_CHAR_TRAN_TYPE_DISPATCH,
        receiveRecordModelList[index].chrTransType)
        .then((bool isBool) {
      sharedPrefs
          .setInt(
          PREF_FK_DISPATCH_GL_CODE, receiveRecordModelList[index].intGlCode)
          .then((bool isBool) {
        receiveSecondScreenRedirect();
      });
    });
  }

  void receiveSecondScreenRedirect() async {
    final Route route =
    CupertinoPageRoute(builder: (context) => ReceiveSecondScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            isReloadDashboard = true;
            getReceiveRecords(
                '', sharedPrefs, _battery, selectedTransactionCode);
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void _showMultiSelect(BuildContext context) async {
    int fkMainCustomerGlCode =
    await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
    List<FilterModel> data =
    await databaseHelper.getFilterCountForReceive(fkMainCustomerGlCode);
    int salesReturnCount = 0;
    int stoCount = 0;
    int doCount = 0;
    int focCount = 0;
    if (data.isNotEmpty) {
      await Future.forEach(data, (FilterModel filterModel) async {
        if (filterModel.chrTransType == 'R') {
          salesReturnCount = filterModel.intCount;
        }
        if (filterModel.chrTransType == 'D') {
          doCount = filterModel.intCount;
        }
        if (filterModel.chrTransType == 'S') {
          stoCount = filterModel.intCount;
        }
        if (filterModel.chrTransType == 'F') {
          focCount = filterModel.intCount;
        }
      });
    }

    var items = <MultiSelectDialogItem<int>>[];
    items.add(MultiSelectDialogItem(
        1, 'All', (salesReturnCount + stoCount + doCount + focCount)));
    if (globals.DOConfiguration == 'Y') {
      items.add(MultiSelectDialogItem(2, 'DO', doCount));
    }
    if (globals.STOConfiguration == 'Y') {
      items.add(MultiSelectDialogItem(3, 'STO', stoCount));
    }
    if (globals.SRConfiguration == 'Y') {
      items.add(MultiSelectDialogItem(4, 'Sales Return', salesReturnCount));
    }
    if (globals.FOCConfiguration == 'Y') {
      items.add(MultiSelectDialogItem(5, 'FOC', focCount));
    }

    if (items != null) {
      final selectedValue = await showDialog<Set<int>>(
        context: context,
        builder: (BuildContext context) {
          return MultiSelectDialog(
            items: items,
            isAllDisable: true,
            isBASF_HK: true,
            initialSelectedValues:
            selectedString != null ? selectedString.toSet() : [0].toSet(),
          );
        },
      );

      print(selectedString);

      if (selectedValue != null) {
        selectedString = selectedValue;
      }
    }

    if (selectedString != null) {
      selectedTransactionType = "";
      selectedTransactionCode = "";
      await Future.forEach(selectedString, (int no) async {
        print('===selectedString===$no}');
        if (no == 2) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'DO';
          } else {
            selectedTransactionType = selectedTransactionType + ",DO";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'D'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'D'";
          }
        }
        if (no == 3) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'STO';
          } else {
            selectedTransactionType = selectedTransactionType + ",STO";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'S'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'S'";
          }
        }
        if (no == 4) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'Sales Return';
          } else {
            selectedTransactionType = selectedTransactionType + ",Sales Return";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'R'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'R'";
          }
        }

        if (no == 5) {
          if (selectedTransactionType.isEmpty) {
            selectedTransactionType = 'FOC';
          } else {
            selectedTransactionType = selectedTransactionType + ",FOC";
          }

          if (selectedTransactionCode.isEmpty) {
            selectedTransactionCode = "'F'";
          } else {
            selectedTransactionCode = selectedTransactionCode + ",'F'";
          }
        }
      });
      print(selectedTransactionCode);
      await setStateCall();
    }
  }

  void setStateCall() {
    if (mounted) {
      setState(() {});
    }

    getReceiveRecords('', sharedPrefs, _battery, selectedTransactionCode);
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName, subTitle, topHeaderImage, receiveCount),
                      CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_FIRST, true),
                      Container(
                        padding: const EdgeInsets.all(10),
                        child: Container(
                          height: 45,
                          decoration: BoxDecoration(
                              borderRadius:
                              const BorderRadius.all(Radius.circular(7)),
                              border: Border.all(
                                  color: const Color(colorPrimary), width: 2),
                              color: Colors.white),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: TextField(
                                    controller: searchcontroller,
                                    //enableInteractiveSelection: false,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintStyle:
                                      TextStyle(color: Colors.grey[700]),
                                      hintText:
                                      '${LocaleUtils.getString(
                                          mContext, 'search_by')} ${globals
                                          .DO_OR_STO}',
                                      counterText: '',
                                    ),
                                    onChanged: (value) {
                                      filterSearchResults(value);
                                    },
                                    maxLines: 1,
                                    maxLength: EditTxtMaxLengths,
                                  ),
                                ),
                                flex: 1,
                              ),
                              Flexible(
                                child: IconButton(
                                    onPressed: () {},
                                    icon: const Icon(
                                      Icons.search,
                                      color: Color(colorPrimary),
                                    )),
                                flex: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      InkWell(
                        child: Container(
                            height: 45,
                            padding: const EdgeInsets.all(10),
                            margin: EdgeInsets.only(left: 10, right: 10),
                            decoration: BoxDecoration(
                                borderRadius:
                                const BorderRadius.all(Radius.circular(7)),
                                border: Border.all(
                                    color: const Color(colorPrimary), width: 2),
                                color: Colors.white),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Text(
                                  selectedTransactionType.isEmpty
                                      ? LocaleUtils.getString(
                                      mContext, 'select_transaction_type')
                                      : selectedTransactionType,
                                  style: selectedTransactionType != null
                                      ? textStyle
                                      : Colors.grey[700],
                                ),
                                Icon(Icons.arrow_drop_down)
                              ],
                            )),
                        onTap: () {
                          _showMultiSelect(context);
                        },
                      ),
                      Expanded(
                        child: !loadingFlag
                            ? receiveRecordModelList.length > 0
                            ? Container(
                          child: ListView.builder(
                            itemCount: receiveRecordModelList.length,
                            shrinkWrap: true,
                            itemBuilder:
                                (BuildContext context, int index) {
                              return InkWell(
                                  onTap: () {
                                    print(
                                        '===========TAP=============$index');
                                    listViewClickEvent(index);
                                  },
                                  onLongPress: () {
                                    if (receiveRecordModelList[index]
                                        .chrTransType ==
                                        'R') {
                                      databaseHelper
                                          .getReturnRemarks(
                                          receiveRecordModelList[
                                          index]
                                              .intGlCode)
                                          .then((String remarks) {
                                        showDialog<Map>(
                                          barrierDismissible: false,
                                          context: mContext,
                                          builder: (context) {
                                            //_writeToFile('======STEP 15=======');
                                            return CustomAlertDialog(
                                              content: remarks,
                                              title: LocaleUtils
                                                  .getString(mContext,
                                                  'remarks'),
                                              isShowNagativeButton:
                                              false,
                                              textNagativeButton: '',
                                              textPositiveButton:
                                              LocaleUtils
                                                  .getString(
                                                  mContext,
                                                  'OK'),
                                              onPressedNegative:
                                                  () {},
                                              onPressedPositive:
                                                  () {},
                                            );
                                          },
                                        );
                                      });
                                    }
                                  },
                                  child: Card(
                                      margin: const EdgeInsets.only(
                                          left: 10,
                                          top: 7,
                                          bottom: 7,
                                          right: 10),
                                      elevation: 3,
                                      child: Container(
                                        color: receiveRecordModelList[
                                        index]
                                            .chrColor
                                            .contains('B')
                                            ? const Color(0xFFa6c0da)
                                            : Colors.white,
                                        padding:
                                        const EdgeInsets.all(10),
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment
                                              .start,
                                          mainAxisAlignment:
                                          MainAxisAlignment.start,
                                          children: <Widget>[
                                            Row(
                                              children: <Widget>[
                                                Expanded(
                                                  child: Wrap(
                                                    direction: Axis
                                                        .horizontal,
                                                    runAlignment:
                                                    WrapAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Text(
                                                        LocaleUtils.getString(
                                                            mContext,
                                                            'RecFrom'),
                                                        style:
                                                        prifixTxtStyle,
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                ),
                                                Expanded(
                                                  child: Wrap(
                                                    direction: Axis
                                                        .horizontal,
                                                    runAlignment:
                                                    WrapAlignment
                                                        .start,
                                                    children: <
                                                        Widget>[
                                                      Text(
                                                        receiveRecordModelList[index]
                                                            .varFullName !=
                                                            null
                                                            ? receiveRecordModelList[
                                                        index]
                                                            .varFullName
                                                            : '',
                                                        style:
                                                        textStyle,
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(top: 5),
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Wrap(
                                                      direction: Axis
                                                          .horizontal,
                                                      runAlignment:
                                                      WrapAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          '${receiveRecordModelList[index]
                                                              .varEntityName}: ',
                                                          style:
                                                          prifixTxtStyle,
                                                        ),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Wrap(
                                                      direction: Axis
                                                          .horizontal,
                                                      runAlignment:
                                                      WrapAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          getDoSTOValues(
                                                              index),
                                                          style:
                                                          textStyle,
                                                        ),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(top: 5),
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Wrap(
                                                      direction: Axis
                                                          .horizontal,
                                                      alignment:
                                                      WrapAlignment
                                                          .start,
                                                      crossAxisAlignment:
                                                      WrapCrossAlignment
                                                          .center,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          LocaleUtils.getString(
                                                              mContext,
                                                              'TotUnits_'),
                                                          style:
                                                          titleBoldStyle,
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                              top: 2),
                                                          child: Text(
                                                            receiveRecordModelList[index]
                                                                .intTotalUnit !=
                                                                null
                                                                ? receiveRecordModelList[index]
                                                                .intTotalUnit
                                                                .toString()
                                                                : '',
                                                            style:
                                                            textNormalStyle,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Wrap(
                                                      alignment:
                                                      WrapAlignment
                                                          .start,
                                                      crossAxisAlignment:
                                                      WrapCrossAlignment
                                                          .center,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          LocaleUtils.getString(
                                                              mContext,
                                                              'TotArticle_'),
                                                          style:
                                                          prifixTxtStyle,
                                                        ),
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                              top: 2),
                                                          child: Text(
                                                            receiveRecordModelList[index]
                                                                .intTotalProduct !=
                                                                null
                                                                ? receiveRecordModelList[index]
                                                                .intTotalProduct
                                                                .toString()
                                                                : '',
                                                            style:
                                                            textStyle,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(top: 3),
                                              child: Row(
                                                children: <Widget>[
                                                  Expanded(
                                                    child: Wrap(
                                                      direction: Axis
                                                          .horizontal,
                                                      runAlignment:
                                                      WrapAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          getLabelDate(
                                                              index),
                                                          style:
                                                          prifixTxtStyle,
                                                        ),
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Wrap(
                                                      direction: Axis
                                                          .horizontal,
                                                      runAlignment:
                                                      WrapAlignment
                                                          .start,
                                                      children: <
                                                          Widget>[
                                                        Padding(
                                                          padding: const EdgeInsets
                                                              .only(
                                                              top: 2),
                                                          child: Text(
                                                            receiveRecordModelList[index]
                                                                .dtDispatchDate !=
                                                                null
                                                                ? mUtils
                                                                .convertDateTimeDisplay1(
                                                                receiveRecordModelList[index]
                                                                    .dtDispatchDate,
                                                                displayDateFormat)
                                                                : '',
                                                            style:
                                                            textStyle,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Padding(
                                              padding:
                                              const EdgeInsets
                                                  .only(top: 5),
                                              child: receiveRecordModelList[
                                              index]
                                                  .chrTransType ==
                                                  'R'
                                                  ? Row(
                                                children: <
                                                    Widget>[
                                                  Expanded(
                                                    child: Wrap(
                                                      direction:
                                                      Axis.horizontal,
                                                      alignment:
                                                      WrapAlignment
                                                          .start,
                                                      crossAxisAlignment:
                                                      WrapCrossAlignment
                                                          .center,
                                                      children: <
                                                          Widget>[
                                                        Text(
                                                          '${LocaleUtils
                                                              .getString(
                                                              mContext,
                                                              'reason')}: ',
                                                          style:
                                                          titleBoldStyle,
                                                        ),
                                                        Padding(
                                                          padding:
                                                          const EdgeInsets.only(
                                                              top: 2),
                                                          child:
                                                          Text(
                                                            receiveRecordModelList[index]
                                                                .varReturnStatus !=
                                                                null
                                                                ? receiveRecordModelList[index]
                                                                .varReturnStatus
                                                                : '',
                                                            style:
                                                            textNormalStyle,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    flex: 1,
                                                  ),
//                                              Expanded(
//                                                child: Wrap(
//                                                  alignment:
//                                                  WrapAlignment
//                                                      .start,
//                                                  crossAxisAlignment:
//                                                  WrapCrossAlignment
//                                                      .center,
//                                                  children: <
//                                                      Widget>[
//                                                    Text(
//                                                      LocaleUtils
//                                                          .getString(
//                                                          mContext,
//                                                          'TotArticle_'),
//                                                      style:
//                                                      prifixTxtStyle,
//                                                    ),
//                                                    Padding(
//                                                      padding: const EdgeInsets
//                                                          .only(
//                                                          top:
//                                                          2),
//                                                      child:
//                                                      Text(
//                                                        receiveRecordModelList[index]
//                                                            .intTotalProduct !=
//                                                            null
//                                                            ? receiveRecordModelList[index]
//                                                            .intTotalProduct
//                                                            .toString()
//                                                            : '',
//                                                        style:
//                                                        textStyle,
//                                                      ),
//                                                    )
//                                                  ],
//                                                ),
//                                                flex: 1,
//                                              ),
                                                ],
                                              )
                                                  : Container(),
                                            ),
                                          ],
                                        ),
                                      )));
                            },
                          ),
                        )
                            : Container(
                          child: Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.center,
                            mainAxisAlignment:
                            MainAxisAlignment.center,
                            children: <Widget>[
                              Image.asset(
                                'assets/nodata_icon.png',
                                height: 100,
                                width: 100,
                              ),
                              Padding(
                                padding:
                                const EdgeInsets.only(top: 10),
                                child: Text(
                                  LocaleUtils.getString(
                                      mContext, 'NoDataFound'),
                                  style: prifixTxtStyle,
                                ),
                              ),
                            ],
                          ),
                        )
                            : Center(
                          child: const CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  Color(colorPrimary))),
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
