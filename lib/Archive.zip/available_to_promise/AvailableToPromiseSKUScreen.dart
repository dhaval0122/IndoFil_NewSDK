import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/available_to_promise/AvailableToPromise.dart';
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:xml/xml.dart' as xml;

class AvailableToPromiseSKUScreen extends StatefulWidget {
  AvailableToPromiseProductModel prdModel;
  AvailableToPromiseCustomerModel custModel;

  AvailableToPromiseSKUScreen(AvailableToPromiseProductModel prdModel,
      AvailableToPromiseCustomerModel custModel) {
    this.prdModel = prdModel;
    this.custModel = custModel;
  }

  @override
  AvailableToPromiseSKUScreenState createState() =>
      AvailableToPromiseSKUScreenState();
}

class AvailableToPromiseSKUScreenState
    extends State<AvailableToPromiseSKUScreen>
    implements WSInterface, PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false,
      isNotification = false,
      isSync = false,
      isNoData = false;
  Size screenSize;
  String userName, subTitle, doNo, topHeaderImage = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;

  List<AvailableToPromiseSKUModel> list = List();
  List<AvailableToPromiseSKUModel> listDisplay = List();

  List<AvailableToPromiseSKUDialogData> listDialogDisplay = List();

  static int apiCallType = 0;

  final TextEditingController _search_controller = TextEditingController();

  WSPresenter wsPresenter;
  String selectedProductName = '';
  PushNotificationServices pushNotificationServices;
  int notificationCount = 0;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    apiCallType = 0;

    mUtils = Utils();
    _battery = EcpSyncPlugin();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);
    databaseHelper = DatabaseHelper.get();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      topHeaderImage = 'assets/promise_one.png';
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData(1, 0);
    _initLoading();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  // type : 1 = GetCustomer, 2 = GetPRD
  void getData(int type, int PSKUGlCode) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                //setCommonParam(param);
                param[PARAM_API_TOKEN] = apiToken;
                param['EmployeeGlCode'] = loginID;
                param[PARAM_DEVICE_ID] = deviceid;
                param['Filter'] = '';
                param['Version'] = APP_VERSION;

                param['CustomerGlCode'] =
                    widget.custModel.fkUserGlCode.toString();
                param['PRDGlCode'] = widget.prdModel.fkPRDGlCode.toString();
                param['Filter'] = '';
                param['Favourite'] = '';

                param[PARAM_ACTION] = type == 1 ? 'GETPSKU' : 'GetAllData';
                param['PSKUGlCode'] = PSKUGlCode.toString();
                param['StockBlockXML'] = '';

                print(param);
                apiCallType = type;
                wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  /*void setCommonParam(Map param) {
    param[PARAM_API_TOKEN] = '07EBCB3A-C2E1-4C48-8A15-EDF1BAEB9B37';
    param['EmployeeGlCode'] = '268';
    param[PARAM_DEVICE_ID] = '000000000000000';
    param['Filter'] = '';
    param['Version'] = '18.0.11';

    param['CustomerGlCode'] = widget.custModel.fk_UserGlCode.toString();
    param['PRDGlCode'] = widget.prdModel.fk_PRDGlCode.toString();
    param['Filter'] = '';
    param['Favourite'] = '';
  }*/

  void InsertAvailableToPromise(int type, String StockBlockXML) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                //setCommonParam(param);
                param[PARAM_API_TOKEN] = apiToken;
                param['EmployeeGlCode'] = loginID;
                param[PARAM_DEVICE_ID] = deviceid;
                param['Filter'] = '';
                param['Version'] = APP_VERSION;

                param['CustomerGlCode'] =
                    widget.custModel.fkUserGlCode.toString();
                param['PRDGlCode'] = widget.prdModel.fkPRDGlCode.toString();
                param['Filter'] = '';
                param['Favourite'] = '';

                param[PARAM_ACTION] = 'InsertAvailableToPromise';
                param['PSKUGlCode'] = '0';
                param['StockBlockXML'] = StockBlockXML;

                print(param);
                apiCallType = type;
                wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void showNoInternetDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(mContext, 'no_internet_connection'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    final dynamic jsonResponse = json.decode(response.toString().trim());
    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      if (apiCallType == 1) {
        if (mounted) {
          setState(() {
            list.clear();
            listDisplay.clear();

            listDisplay.addAll(responseModel.getAvailableToPromiseSKUList());
            list.addAll(listDisplay);
            if (listDisplay.length > 0) {
              isNoData = false;
            } else {
              isNoData = true;
            }
          });
        }
      } else if (apiCallType == 2) {
        displayDialog(responseModel.Message);
      } else if (apiCallType == 3) {
        if (mounted) {
          setState(() {
            listDialogDisplay.clear();
            listDialogDisplay
                .addAll(responseModel.getAvailableToPromiseSKUDialogList());

            //if (listDialogDisplay.length > 0) {
            if (listDialogDisplay.isNotEmpty) {
              showDialog<Map>(
                barrierDismissible: false,
                context: context,
                builder: (context) {
                  return scanRecordShowDialog(selectedProductName);
                },
              );
            } else {
              _showSnackBar(
                  LocaleUtils.getString(mContext, 'NoDataFound'));
            }
          });
        }
      }
    } else if (responseModel.Status.contains('2')) {
      //displayDialog(responseModel.Message);
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    } else {
      if (apiCallType == 2) {
        displayDialog(responseModel.Message);
      }
    }

    dismissProgressHUD();
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void displayDialog(String message) {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: message,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {
            final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
            Navigator.pushAndRemoveUntil(
                context, route, (Route<dynamic> route) => false);
          },
        );
      },
    );
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: 'Are you sure you want to perform Synchronization?',
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: 'No',
                textPositiveButton: 'Yes',
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 42,
                      width: screenSize.width,
                      padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.black, width: 1),
                          borderRadius: _getRadiusDropDown()),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<AvailableToPromiseCustomerModel>(
                            hint: Text(
                              widget.custModel.varName,
                              style: prifixTxtStyle,
                              textAlign: TextAlign.left,
                            ),
                            onChanged: null),
                      ),
                    ),
                  ),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 40,
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(7)),
                          color: Colors.white),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: _search_controller,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: prifixTxtPrimaryStyle,
                                  hintText: LocaleUtils.getString(
                                      mContext, 'SearchArticle'),
                                  counterText: '',
                                ),
                                onChanged: (value) {
                                  filterSearchResults(value.trimLeft());
                                },
                                style: prifixTxtPrimaryStyle,
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {
                                  // _search_controller.clear();
                                },
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    margin: const EdgeInsets.only(
                        left: 10, top: 10, bottom: 10, right: 10),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        widget.prdModel.varPRDName,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    //child: listDisplay.length > 0
                    child: listDisplay.length > 0
                        ? Container(
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemBuilder: (context, position) {
                                return GestureDetector(
                                    child: Card(
                                        margin: const EdgeInsets.only(
                                            left: 10,
                                            top: 0,
                                            bottom: 10,
                                            right: 10),
                                        elevation: 3,
                                        child: Container(
                                          padding: const EdgeInsets.only(
                                              left: 10, top: 10, bottom: 10),
                                          child: IntrinsicHeight(
                                            child: Row(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                children: [
                                                  Expanded(
                                                    child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        children: [
                                                          Text(
                                                            (listDisplay[position]
                                                                .varPRDCode !=
                                                                null
                                                                ? listDisplay[position]
                                                                .varPRDCode
                                                                : '')
                                                                + ' - '
                                                                +
                                                                (listDisplay[position]
                                                                    .varProductSKUName !=
                                                                    null
                                                                    ? listDisplay[position]
                                                                    .varProductSKUName
                                                                    : '')
                                                            ,
                                                            style: TextStyle(
                                                              fontSize: 14.0,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w500,
                                                              fontFamily:
                                                                  'helvetica',
                                                            ),
                                                          ),
                                                          Container(
                                                            margin:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 8,
                                                                    bottom: 3),
                                                            child: Text(
                                                              '${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'Qty')}.(${globals
                                                                  .KG_PCS}.): ' +
                                                                  listDisplay[
                                                                          position]
                                                                      .decQty
                                                                      .toString(),
                                                              style: TextStyle(
                                                                fontSize: 14.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w500,
                                                                fontFamily:
                                                                    'helvetica',
                                                              ),
                                                            ),
                                                          ),
                                                        ]),
                                                    flex: 1,
                                                  ),
                                                  Expanded(
                                                    child: Container(
                                                      child: IconButton(
                                                        icon: Image.asset(
                                                            'assets/info_icon.png'),
                                                        onPressed: null,
                                                        color: const Color(
                                                            colorPrimary),
                                                      ),
                                                    ),
                                                    flex: 0,
                                                  ),
                                                ]),
                                          ),
                                        )),
                                    onTap: () {
                                      getData(3,
                                          listDisplay[position].fkPSKUGlCode);
                                      selectedProductName =
                                          listDisplay[position]
                                              .varProductSKUName;
                                    });
                              },
                              itemCount: listDisplay.length,
                            ),
                          )
                        : Visibility(
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Image.asset(
                                    'assets/nodata_icon.png',
                                    height: 100,
                                    width: 100,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'NoDataFound'),
                                      style: prifixTxtStyle,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            visible: isNoData,
                          ),
                  ),
                  Visibility(
                    child: Container(
                      margin: const EdgeInsets.only(
                          left: 10, top: 10, bottom: 10, right: 10),
                      width: MediaQuery.of(context).size.width,
                      child: FlatButton(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        onPressed: () {
                          validateData();
                        },
                        color: const Color(colorPrimary),
                        child: Text(
                          LocaleUtils.getString(mContext, 'RESERVE'),
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ),
                    visible: false,
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void validateData() {
    final List<AvailableToPromiseSKUModel> listTmp =
        List<AvailableToPromiseSKUModel>();

    var builder = xml.XmlBuilder();

    builder.element('Stocks', nest: () {
      for (int i = 0; i < list.length; i++) {
        if (list[i].blockQty > 0) {
          AvailableToPromiseSKUModel data = list[i];
          listTmp.add(data);

          builder.element('BlockStock', nest: () {
            builder.element('fk_PRDGlCode', nest: data.fkPRDGlCode);
            builder.element('fk_Product_SKUGlCode', nest: data.fkPSKUGlCode);
            builder.element('decQty', nest: data.blockQty);
          });
        }
      }
    });

    //if (listTmp.length <= 0) {
    if (listTmp.isNotEmpty) {
      displayDialog('${LocaleUtils.getString(mContext, 'PlzEnterQty')}');
      return;
    }

    final String xmlData = builder.build().toString();
    print(xmlData);

    InsertAvailableToPromise(2, xmlData);
  }

  void filterSearchResults(String query) {
    final List<AvailableToPromiseSKUModel> dummySearchList =
        List<AvailableToPromiseSKUModel>();
    dummySearchList.addAll(list);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<AvailableToPromiseSKUModel> dummyListData =
          List<AvailableToPromiseSKUModel>();
      dummySearchList.forEach((item) {
        if (item.varProductSKUName.toLowerCase().contains(query)
            || item.varPRDCode.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(dummyListData);
        });
      }
      return;
    } else {
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(list);
        });
      }
    }
  }

  AlertDialog scanRecordShowDialog(String selectedProductName) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: screenSize.width * 0.9,
          height: screenSize.height * 0.5,
          //height: 200,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: MarqueeWidget(
                      direction: Axis.horizontal,
                      child: Text(
                          selectedProductName != null
                              ? selectedProductName
                              : '',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'helvetica',
                              color: Colors.white))),
                  alignment: Alignment.center,
                ),
              ),
              Container(
                height: 35,
                color: const Color(colorAccent),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            LocaleUtils.getString(mContext, 'Country'),
                            style: prifixTxtPrimaryStyle,
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: 1,
                      color: Colors.white70,
                    ),
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            LocaleUtils.getString(mContext, 'Customer'),
                            style: prifixTxtPrimaryStyle,
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: 1,
                      color: Colors.white70,
                    ),
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            '${LocaleUtils.getString(
                                mContext, 'Qty')}.(${globals.KG_PCS}.)',
                            style: prifixTxtPrimaryStyle,
                          ),
                        ],
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: listDialogDisplay.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    // return listDialogDisplay.length > 0
                    return listDialogDisplay.isNotEmpty
                        ? Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Container(
                                //height: 35,
                                width: screenSize.width,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: <Widget>[
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2, right: 2),
                                          child: Text(
                                            listDialogDisplay[index]
                                                .countryName
                                                .toString(),
                                            style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: 'helvetica',
                                            ),
                                          ),
                                        ),
                                      ),
                                      flex: 1,
                                    ),
                                    Container(
                                      width: 1,
                                      color: Colors.black12,
                                      height: 25,
                                      margin: const EdgeInsets.only(
                                          top: 5, bottom: 5),
                                    ),
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2, right: 2),
                                          child: Text(
                                            listDialogDisplay[index]
                                                .wareHouseName
                                                .toString(),
                                            style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w500,
                                              fontFamily: 'helvetica',
                                            ),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ),
                                      flex: 1,
                                    ),
                                    Container(
                                      width: 1,
                                      color: Colors.black12,
                                      height: 25,
                                      margin: const EdgeInsets.only(
                                          top: 5, bottom: 5),
                                    ),
                                    Expanded(
                                      child: Align(
                                        alignment: Alignment.center,
                                        child: Padding(
                                          padding: const EdgeInsets.only(
                                              left: 2, right: 2),
                                          child: Text(
                                              listDialogDisplay[index]
                                                  .decQty
                                                  .toString(),
                                              style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w500,
                                                fontFamily: 'helvetica',
                                              )),
                                        ),
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: screenSize.width,
                                color: Colors.black12,
                                height: 1,
                                //margin: EdgeInsets.only(top: 7),
                              ),
                              //Divider(color: Colors.black26),
                            ],
                          )
                        : Container();
                  },
                ),
              ),
              Container(
                width: screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(mContext, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class DecimalTextInputFormatter extends TextInputFormatter {
  DecimalTextInputFormatter({this.decimalRange})
      : assert(decimalRange == null || decimalRange > 0);

  final int decimalRange;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue, // unused.
    TextEditingValue newValue,
  ) {
    TextSelection newSelection = newValue.selection;
    String truncated = newValue.text;

    if (decimalRange != null) {
      final String value = newValue.text;

      if (value.contains('.') &&
          value.substring(value.indexOf('.') + 1).length > decimalRange) {
        truncated = oldValue.text;
        newSelection = oldValue.selection;
      } else if (value == '.') {
        truncated = '0.';

        newSelection = newValue.selection.copyWith(
          baseOffset: math.min(truncated.length, truncated.length + 1),
          extentOffset: math.min(truncated.length, truncated.length + 1),
        );
      }

      return TextEditingValue(
        text: truncated,
        selection: newSelection,
        composing: TextRange.empty,
      );
    }
    return newValue;
  }
}
