import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/available_to_promise/AvailableToPromiseSKUScreen.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

class AvailableToPromiseCustomerModel {
  int fkUserGlCode;

//  int fk_UserGlCode;
  String varCode;
  String varName;

  AvailableToPromiseCustomerModel.fromJson(Map<String, dynamic> json)
      : fkUserGlCode = json['fk_UserGlCode'],
        varCode = json['varCode'],
        varName = json['varName'];
}

class AvailableToPromiseProductModel {
//  int fk_PRDGlCode;
  int fkPRDGlCode;
  String varPRDName;
  double decQty;
  String favourite;

  AvailableToPromiseProductModel.fromJson(Map<String, dynamic> json)
      : fkPRDGlCode = json['fk_PRDGlCode'],
        varPRDName = json['varPRD_Name'],
        decQty = json['decQty'],
        favourite = json['Favourite'];
}

class AvailableToPromiseSKUModel {
  int fkPRDGlCode;
  int fkPSKUGlCode;
  String varPRDCode;
  String varProductSKUName;
  double decQty;
  double blockQty;
  double blockQtyChanged;

  AvailableToPromiseSKUModel.fromJson(Map<String, dynamic> json)
      : fkPRDGlCode = json['fk_PRDGlCode'],
        fkPSKUGlCode = json['fk_PSKUGlCode'],
        varPRDCode = json['varPRD_Code'],
        varProductSKUName = json['varProduct_SKU_Name'],
        decQty = json['decQty'],
        blockQty = json['BlockQty'],
        blockQtyChanged = json['BlockQty'];

  String getBlockQty() {
    if (blockQty % 1 == 0) {
      return blockQty.toInt().toString();
    } else {
      return blockQty.toString();
    }
  }
}

class AvailableToPromiseSKUDialogData {
  int fkCustomerGlCode;
  String countryName;
  String wareHouseName;
  int fkPRDGlCode;
  int fkProductSKUGlCode;
  double decQty;

  AvailableToPromiseSKUDialogData.fromJson(Map<String, dynamic> json)
      : fkCustomerGlCode = json['fk_Customer_GlCode'],
        countryName = json['CountryName'],
        wareHouseName = json['WareHouseName'],
        fkPRDGlCode = json['fk_PRDGlCode'],
        fkProductSKUGlCode = json['fk_Product_SKU_GlCode'],
        decQty = json['decQty'];
}

class AvailableToPromiseScreen extends StatefulWidget {
  @override
  AvailableToPromiseScreenState createState() =>
      AvailableToPromiseScreenState();
}

class AvailableToPromiseScreenState extends State<AvailableToPromiseScreen>
    implements WSInterface, PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false,
      isNotification = false,
      isSync = false,
      isNoData = false;
  Size screenSize;
  String userName, subTitle, doNo, topHeaderImage = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;

  List<AvailableToPromiseCustomerModel> listCustomer = List();
  List<AvailableToPromiseProductModel> list = List();
  List<AvailableToPromiseProductModel> listDisplay = List();

  static int apiCallType = 0;

  final TextEditingController searchController = TextEditingController();

  WSPresenter wsPresenter;

  AvailableToPromiseCustomerModel selectedCustomerModel;
  bool isOpen = false;
  PushNotificationServices pushNotificationServices;
  int notificationCount = 0;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    apiCallType = 0;
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    _battery = EcpSyncPlugin();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      topHeaderImage = 'assets/promise_one.png';
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData(1, 0);
    _initLoading();

    insertLogDetails();

  }


  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_REP_ATP');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }


  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  // type : 1 = GetCustomer, 2 = GetPRD
  void getData(int type, int customerGlCode) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceId) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
//                setCommonParam(param);

                param[PARAM_API_TOKEN] = apiToken;
                param['EmployeeGlCode'] = loginID;
                param[PARAM_DEVICE_ID] = deviceId;
                param['Filter'] = '';
                //param['Version'] = APP_VERSION;

                param[PARAM_ACTION] = type == 1 ? 'GetCustomer' : 'GetPRD';
                param['PRDGlCode'] = '0';
                param['PSKUGlCode'] = '0';
                param['StockBlockXML'] = '';
                param['Favourite'] = '';
                param['CustomerGlCode'] = customerGlCode.toString();

                print(param);
                apiCallType = type;
                wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  /*void setCommonParam(Map param) {
    param[PARAM_API_TOKEN] = '07EBCB3A-C2E1-4C48-8A15-EDF1BAEB9B37';
    param['EmployeeGlCode'] = '268';
    param[PARAM_DEVICE_ID] = '000000000000000';
    param['Filter'] = '';
    param['Version'] = '18.0.11';
  }*/

  void markFavourite(int type, int prdGlCode, String favourite) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                //setCommonParam(param);
                param[PARAM_API_TOKEN] = apiToken;
                param['EmployeeGlCode'] = loginID;
                param[PARAM_DEVICE_ID] = deviceid;
                param['Filter'] = '';
                //param['Version'] = APP_VERSION;

                param[PARAM_ACTION] = favourite.toLowerCase() == 'y'
                    ? 'MarkFavourite'
                    : 'UnMarkFavourite';
                param['PRDGlCode'] = prdGlCode.toString();
                param['PSKUGlCode'] = '0';
                param['StockBlockXML'] = '';
                param['Favourite'] = favourite;
                param['CustomerGlCode'] = '964';

                print(param);
                apiCallType = type;
                wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void showNoInternetDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(mContext, 'no_internet_connection'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    dismissProgressHUD();

    if (responseModel.Status.contains('1')) {
      if (apiCallType == 1) {
        listCustomer.clear();

        if (mounted) {
          setState(() {
            listCustomer
                .addAll(responseModel.getAvailableToPromiseCustomerList());
            if (listCustomer.length > 0) {
              selectedCustomerModel = listCustomer[0];
            }
          });
        }
        // For Testing Purpose
        if (selectedCustomerModel != null) {
          getData(2, selectedCustomerModel.fkUserGlCode);
        }
        return;
      } else if (apiCallType == 2) {
        if (mounted) {
          setState(() {
            list.clear();
            listDisplay.clear();

            //for (int i = 0; i < 25; i++) {
            listDisplay
                .addAll(responseModel.getAvailableToPromiseProductList());
            list.addAll(listDisplay);

            if (listDisplay.length > 0) {
              isNoData = false;
            } else {
              isNoData = true;
            }
            //}
          });
        }
      } else if (apiCallType == 3) {
        getData(2, selectedCustomerModel.fkUserGlCode);
        return;
      }
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: 'Are you sure you want to perform Synchronization?',
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: 'No',
                textPositiveButton: 'Yes',
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;
    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
//      floatingActionButton:  Builder(builder: (BuildContext context) {
//        return Container(
//          height: isOpen ? 0 : 40,
//          width: isOpen ? 0 : 40,
//          child:  RawMaterialButton(
//            shape:  CircleBorder(),
//            elevation: 0.0,
//            child: Image.asset(
//              'assets/know_your_box_icon.png',
//              height: 30,
//              width: 30,
//            ),
//            onPressed: () {
//              if (mounted) {
//                setState(() {
//                  isOpen = true;
//                });
//              }
//              Scaffold.of(context)
//                  .showBottomSheet((BuildContext context) {
//                    return MyForm(screenSize: screenSize);
//                  })
//                  .closed
//                  .whenComplete(() {
//                    print('Closed');
//                    if (mounted) {
//                      setState(() {
//                        isOpen = false;
//                      });
//                    }
//                  });
//            },
//          ),
//        );
//      }),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 42,
                      width: screenSize.width,
                      padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color(colorPrimary), width: 2),
                          borderRadius: _getRadiusDropDown()),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<AvailableToPromiseCustomerModel>(
                          value: selectedCustomerModel,
                          onChanged:
                              (AvailableToPromiseCustomerModel newValue) {
                            searchController.text = '';
                            if (mounted) {
                              setState(() {
                                selectedCustomerModel = newValue;
                                getData(2, selectedCustomerModel.fkUserGlCode);
                              });
                            }
                          },
                          hint: Text(
                            LocaleUtils.getString(mContext, 'sel_customer'),
                            style: prifixTxtPrimaryStyle,
                            textAlign: TextAlign.left,
                          ),
                          isExpanded: true,
                          items: listCustomer != null
                              ? listCustomer
                                  .map((AvailableToPromiseCustomerModel value) {
                                  return DropdownMenuItem<
                                      AvailableToPromiseCustomerModel>(
                                    value: value,
                                    child: Text(
                                      value.varName,
                                      style: prifixTxtPrimaryStyle,
                                    ),
                                  );
                                }).toList()
                              : List(),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 40,
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(7)),
                          color: Colors.white),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: searchController,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: prifixTxtPrimaryStyle,
                                  hintText: LocaleUtils.getString(
                                      mContext, 'SearchPRD'),
                                  counterText: '',
                                ),
                                onChanged: (value) {
                                  filterSearchResults(value.trimLeft());
                                },
                                style: prifixTxtPrimaryStyle,
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {
                                  // _search_controller.clear();
                                },
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                LocaleUtils.getString(mContext, 'PRD'),
                                style: prifixTxtPrimaryStyle,
                              ),
                            ),
                            flex: 2,
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                '${LocaleUtils.getString(
                                    mContext, 'Qty')}.(${globals.KG_PCS}.)',
                                style: prifixTxtPrimaryStyle,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Padding(
                              padding:
                                  const EdgeInsets.only(left: 10, right: 5),
                              child: Text(
                                LocaleUtils.getString(mContext, 'fav'),
                                style: prifixTxtPrimaryStyle,
                                textAlign: TextAlign.right,
                              ),
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    //child: listDisplay.length > 0
                    child: listDisplay.length > 0
                        ? Column(children: [
                            Expanded(
                                child: Container(
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    itemBuilder: (context, position) {
                                      return GestureDetector(
                                          child: Card(
                                              margin: const EdgeInsets.only(
                                                  left: 7,
                                                  top: 7,
                                                  bottom: 7,
                                                  right: 7),
                                              elevation: 3,
                                              child: Container(
                                                padding:
                                                    const EdgeInsets.all(2),
                                                child: Row(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(left: 5),
                                                        child: Text(
                                                          listDisplay[position]
                                                              .varPRDName,
                                                        ),
                                                      ),
                                                      flex: 2,
                                                    ),
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(left: 5),
                                                        child: Text(
                                                          listDisplay[position]
                                                              .decQty
                                                              .toString(),
                                                          textAlign:
                                                              TextAlign.center,
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                    Expanded(
                                                      child: Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(left: 5),
                                                        child: Align(
                                                          alignment: Alignment
                                                              .centerRight,
                                                          child: IconButton(
                                                            onPressed: () {
                                                              markFavourite(
                                                                  3,
                                                                  listDisplay[
                                                                          position]
                                                                      .fkPRDGlCode,
                                                                  listDisplay[position]
                                                                          .favourite
                                                                          .contains(
                                                                              'Y')
                                                                      ? 'N'
                                                                      : 'Y');
                                                            },
                                                            icon: Image.asset(listDisplay[
                                                                        position]
                                                                    .favourite
                                                                    .contains(
                                                                        'Y')
                                                                ? 'assets/star_yellow.png'
                                                                : 'assets/star_theme.png'),
                                                          ),
                                                        ),
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                              )),
                                          onTap: () {
                                            final Route route = CupertinoPageRoute(
                                                builder: (context) =>
                                                    AvailableToPromiseSKUScreen(
                                                        listDisplay[position],
                                                        selectedCustomerModel));
                                            Navigator.push(mContext, route);
                                          });
                                    },
                                    itemCount: listDisplay.length,
                                  ),
                                ),
                                flex: 1),
                          ])
                        : Visibility(
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Image.asset(
                                    'assets/nodata_icon.png',
                                    height: 100,
                                    width: 100,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'NoDataFound'),
                                      style: prifixTxtStyle,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            visible: isNoData,
                          ),
                  )
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void filterSearchResults(String query) {
    print(query);

    final List<AvailableToPromiseProductModel> dummySearchList =
        List<AvailableToPromiseProductModel>();
    dummySearchList.addAll(list);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<AvailableToPromiseProductModel> dummyListData =
          List<AvailableToPromiseProductModel>();
      dummySearchList.forEach((item) {
        if (item.varPRDName.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(dummyListData);
        });
      }
      return;
    } else {
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(list);
        });
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class MyForm extends StatefulWidget {
  final Size screenSize;

  MyForm({this.screenSize});

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  int radioValuePrd = 0;
  int radioValueCustomer = 0;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.screenSize.height,
      padding: const EdgeInsets.all(10),
      child: Column(children: [
        Row(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(left: 5),
                  child: Image.asset(
                    'assets/dropdown_dark_arrow.png',
                    height: 20,
                    width: 20,
                  ),
                ),
                flex: 0,
              ),
              Expanded(
                child: Text(
                  LocaleUtils.getString(context, 'filter'),
                  textAlign: TextAlign.center,
                  style: prifixTxtStyle,
                ),
                flex: 2,
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 5),
                  child: GestureDetector(
                    onTap: () {
                      _handleRadioValueChangePrd(0);
                      _handleRadioValueChangeCust(0);
                    },
                    child: Text(
                      LocaleUtils.getString(context, 'Reset'),
                      style: TextStyle(color: const Color(colorPrimary)),
                    ),
                  ),

                  /* FlatButton(
                    onPressed: () {
                      _handleRadioValueChangePrd(0);
                      _handleRadioValueChangeCust(0);
                    },
                    child: Text(
                      'Reset',
                      style: TextStyle(color: Color(colorPrimary)),
                    ),
                  ),*/
                ),
                flex: 0,
              ),
            ]),
        Container(
          height: 30,
          padding: const EdgeInsets.only(top: 20, left: 10),
          alignment: Alignment.centerLeft,
          child: Text(
            LocaleUtils.getString(context, 'product_wise'),
            style: textStyle,
          ),
        ),
        Container(
          margin: const EdgeInsets.only(top: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Radio(
                value: 0,
                groupValue: radioValuePrd,
                onChanged: _handleRadioValueChangePrd,
              ),
              Text(
                LocaleUtils.getString(context, 'PMG'),
                style: TextStyle(fontSize: 16.0),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Radio(
                  value: 1,
                  groupValue: radioValuePrd,
                  onChanged: _handleRadioValueChangePrd,
                ),
              ),
              Text(
                LocaleUtils.getString(context, 'PRD'),
                style: TextStyle(
                  fontSize: 16.0,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Radio(
                  value: 2,
                  groupValue: radioValuePrd,
                  onChanged: _handleRadioValueChangePrd,
                ),
              ),
              Text(
                LocaleUtils.getString(context, 'Article'),
                style: TextStyle(fontSize: 16.0),
              ),
            ],
          ),
        ),
        Container(
          height: 30,
          padding: const EdgeInsets.only(top: 20, left: 10),
          alignment: Alignment.centerLeft,
          child: Text(
            LocaleUtils.getString(context, 'Customer_type'),
            style: textStyle,
          ),
        ),
        Container(
          margin: const EdgeInsets.only(top: 5),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Radio(
                value: 0,
                groupValue: radioValueCustomer,
                onChanged: _handleRadioValueChangeCust,
              ),
              Text(
                'SSC',
                style: TextStyle(fontSize: 16.0),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 15),
                child: Radio(
                  value: 1,
                  groupValue: radioValueCustomer,
                  onChanged: _handleRadioValueChangeCust,
                ),
              ),
              Text(
                'WH',
                style: TextStyle(
                  fontSize: 16.0,
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 20, left: 10, right: 10),
          child: Container(
            height: 42,
            width: widget.screenSize.width,
            padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
            decoration: BoxDecoration(
                border: Border.all(color: const Color(colorPrimary), width: 2),
                borderRadius: _getRadiusDropDown()),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<AvailableToPromiseCustomerModel>(
                //value: selectedCustomerModel,
                onChanged: (AvailableToPromiseCustomerModel newValue) {
                  if (mounted) {
                    setState(() {
                      /*selectedCustomerModel = newValue;
                      getData(2, selectedCustomerModel.fk_UserGlCode);*/
                    });
                  }
                },
                items: null,
                hint: Text(
                  LocaleUtils.getString(context, 'sel_country'),
                  style: prifixTxtPrimaryStyle,
                  textAlign: TextAlign.left,
                ),
                isExpanded: true,
                /*items: listCust != null
                    ? listCust
                    .map((AvailableToPromiseCustomerModel value) {
                  return DropdownMenuItem<
                      AvailableToPromiseCustomerModel>(
                    value: value,
                    child: Text(
                      value.varName,
                      style: prifixTxtPrimaryStyle,
                    ),
                  );
                }).toList()
                    :  List(),*/
              ),
            ),
          ),
        ),
      ]),
    );
  }

  void _handleRadioValueChangePrd(int value) {
    setState(() {
      radioValuePrd = value;

      switch (radioValuePrd) {
        case 0:
          break;
        case 1:
          break;
        case 2:
          break;
      }
    });
  }

  void _handleRadioValueChangeCust(int value) {
    setState(() {
      radioValueCustomer = value;
      switch (radioValueCustomer) {
        case 0:
          break;
        case 1:
          break;
        case 2:
          break;
      }
    });
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }
}
