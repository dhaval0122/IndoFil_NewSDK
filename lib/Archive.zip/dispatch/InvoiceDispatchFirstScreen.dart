import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/components/SearchableSpinner.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/notifications/NotificationScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class InvoiceDispatchFirstScreen extends StatefulWidget {
  @override
  InvoiceDispatchFirstScreenState createState() =>
      InvoiceDispatchFirstScreenState();
}

class InvoiceModel {
  int fk_FromCustomerGlCode;
  String var_From_OrganizationName;
  int fk_Sold_To_Party_GlCode;
  String var_SoldTo_OrganizationName;
  int fk_Shipt_To_Party_GlCode;
  String var_ShipTo_OrganizationName;
  String varInvoiceNo;
  int fk_From_Customer_Type_CountryGlCode;
  int fk_SoldTo_Customer_Type_CountryGlCode;
  int fk_ShipTo_Customer_Type_CountryGlCode;

  InvoiceModel({
    this.fk_FromCustomerGlCode,
    this.var_From_OrganizationName,
    this.fk_Sold_To_Party_GlCode,
    this.var_SoldTo_OrganizationName,
    this.fk_Shipt_To_Party_GlCode,
    this.var_ShipTo_OrganizationName,
    this.varInvoiceNo,
    this.fk_From_Customer_Type_CountryGlCode,
    this.fk_SoldTo_Customer_Type_CountryGlCode,
    this.fk_ShipTo_Customer_Type_CountryGlCode,
  });

  InvoiceModel.fromMap(Map<String, dynamic> json) {
    this.fk_FromCustomerGlCode = json['fk_FromCustomerGlCode'];
    this.var_From_OrganizationName = json['var_From_OrganizationName'];
    this.fk_Sold_To_Party_GlCode = json['fk_Sold_To_Party_GlCode'];
    this.var_SoldTo_OrganizationName = json['var_SoldTo_OrganizationName'];
    this.fk_Shipt_To_Party_GlCode = json['fk_Shipt_To_Party_GlCode'];
    this.var_ShipTo_OrganizationName = json['var_ShipTo_OrganizationName'];
    this.varInvoiceNo = json['varInvoiceNo'];
    this.fk_From_Customer_Type_CountryGlCode =
        json['fk_From_Customer_Type_CountryGlCode'];
    this.fk_SoldTo_Customer_Type_CountryGlCode =
        json['fk_SoldTo_Customer_Type_CountryGlCode'];
    this.fk_ShipTo_Customer_Type_CountryGlCode =
        json['fk_ShipTo_Customer_Type_CountryGlCode'];
  }
}

class InvoiceDispatchFirstScreenState extends State<InvoiceDispatchFirstScreen>
    implements PushNotificationListener, ItemClickSearchableSpinner {

  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;

  //String dropdownValue;
//  CountryMasterModel selectedCountryModel;
//  CustomerTypeModel selectedCustomerTypeModel;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  List<InvoiceModel> invoiceList;
  InvoiceModel invoiceModel;

//  List<CountryMasterModel> countryList;
//  List<CustomerTypeModel> customerTypeList;
//  TextEditingController doTextController = TextEditingController();
  EcpSyncPlugin _battery;

//  final FocusNode _donoFocus = FocusNode();
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
//    Navigator.popAndPushNamed(mContext, SCANNING_SCREEN);
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.pushReplacement(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    invoiceList = List();
//    customerTypeList = List();
    _battery = EcpSyncPlugin();

    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_DISPATCH) {
        topHeaderImage = 'assets/dispatch_icon.png';
      } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        topHeaderImage = 'assets/edit_do_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int customerGlCode) {
      databaseHelper.getInvoiceAllRecords(customerGlCode).then((var couList) {
        //print('=====countryList=====SIZE====${couList.length}');
        if (mounted) {
          setState(() {
            invoiceList.addAll(couList);
          });
        }
      });
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    _initLoading();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int customerGlCode) {
        sharedPrefs
            .getInt(PREF_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE)
            .then((int fkCustomerTypeCountryGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getBool(PREF_CHANGE_DETAILS_STATE_BOOL)
                .then((isChangeDetails) {
              if (isChangeDetails) {
                sharedPrefs
                    .getInt(PREF_FK_DISPATCH_GL_CODE)
                    .then((int fkDispatchGlCode) {
                  databaseHelper
                      .updateChangeDetails(
                          fkDispatchGlCode,
                          invoiceModel.fk_Shipt_To_Party_GlCode,
                          invoiceModel.fk_ShipTo_Customer_Type_CountryGlCode,
                          invoiceModel.fk_Sold_To_Party_GlCode,
                          invoiceModel.fk_SoldTo_Customer_Type_CountryGlCode,
                      invoiceModel.varInvoiceNo,
                      0,
                      "",
                      "",
                      "")
                      .then((int id) {
                    if (id > 0) {
                      sharedPrefs
                          .setInt(PREF_FK_LAST_DISPATCHED_TO,
                              invoiceModel.fk_Shipt_To_Party_GlCode)
                          .then((bool fkCustomerTypeModel) {
                        sharedPrefs
                            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, false)
                            .then((bool fkCustomerTypeModel) {
                          Navigator.pop(context, true);
                        });
                      });
                    }
                  });
                });
              } else {
                _battery.getUniqueNumber().then((String syncCode) {
                  databaseHelper
                      .insertCustomerDispatch(
                          customerGlCode,
                          fkCustomerTypeCountryGlCode,
                          invoiceModel.fk_Shipt_To_Party_GlCode,
                          invoiceModel.fk_ShipTo_Customer_Type_CountryGlCode,
                          invoiceModel.fk_Sold_To_Party_GlCode,
                          invoiceModel.fk_SoldTo_Customer_Type_CountryGlCode,
                          invoiceModel.varInvoiceNo,
                          syncCode,
                          int.parse(initGlCode),
                      'D',
                      0,
                      "",
                      "",
                      "")
                      .then((int id) {
                    if (id > 0) {
                      sharedPrefs
                          .setInt(PREF_FK_DISPATCH_GL_CODE, id)
                          .then((bool isDisGlCode) {
                        sharedPrefs
                            .setInt(PREF_FK_LAST_DISPATCHED_TO,
                                invoiceModel.fk_Shipt_To_Party_GlCode)
                            .then((bool fkCustomerTypeModel) {
                          sharedPrefs
                              .setInt(PREF_FK_SOLD_TO_PARTY_GL_CODE,
                                  invoiceModel.fk_Sold_To_Party_GlCode)
                              .then((bool fkCustomerTypeModel) {
                            sharedPrefs
                                .setString(
                                    PREF_DO_NO, invoiceModel.varInvoiceNo)
                                .then((bool fkCustomerTypeModel) {
                              redirectScanScreen();
                            });
                          });
                        });
                      });
                    }
                  });
                });
              }
            });
          });
        });
      });
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final loginButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'proceed'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (invoiceModel != null) {
//            if (doTextController.text.isNotEmpty) {
            _validateInputs();
//            } else {
//              _showSnackBar('Please enter your ${globals.DO_NO}.');
//            }
          } else {
            //_showSnackBar('Select ${globals.DO_NO}');
            _showSnackBar(
                LocaleUtils.getString(mContext, 'plz_sel_invoice'));
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_FIRST, false),
                  Expanded(
                    child: Form(
                      child: Container(
                        color: const Color(bgColor),
                        child: Card(
                          elevation: 7,
                          margin: const EdgeInsets.all(15),
                          child: Container(
                            padding: const EdgeInsets.all(15),
                            child: ListView(
                              shrinkWrap: true,
                              children: <Widget>[
                                InkWell(
                                  child: Container(
                                      height: 42,
                                      width: screenSize.width,
                                      alignment: Alignment.centerLeft,
                                      margin: const EdgeInsets.only(top: 15),
                                      padding: const EdgeInsets.fromLTRB(
                                          15, 0, 15, 0),
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: const Color(0xFF000000)),
                                          borderRadius: _getRadiusDropDown()),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: <Widget>[
                                          Text(
                                            invoiceModel != null
                                                ? invoiceModel.varInvoiceNo
                                                : 'Select ${globals.DO_NO}',
                                            style: invoiceModel != null
                                                ? textStyle
                                                : hintStyle,
                                          ),
                                          Icon(Icons.arrow_drop_down)
                                        ],
                                      )),
                                  onTap: () {
                                    List<SpinnerModel> countrytemp = invoiceList
                                        .map((countryMasterModel) =>
                                            SpinnerModel(
                                                countryMasterModel
                                                    .fk_FromCustomerGlCode,
                                                countryMasterModel.varInvoiceNo,
                                                1))
                                        .toList();
                                    showDialog<Map>(
                                      barrierDismissible: true,
                                      context: context,
                                      builder: (context) {
                                        return SearchableSpinner(
                                          screenSize: screenSize,
                                          listSticker: countrytemp,
                                          itemClickSearchableSpinner: this,
                                        );
                                      },
                                    );
                                  },
                                ),
                                Container(
                                    height: 42,
                                    width: screenSize.width,
                                    margin: const EdgeInsets.only(top: 20),
                                    padding:
                                        const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        invoiceModel != null
                                            ? invoiceModel
                                                .var_SoldTo_OrganizationName
                                            : LocaleUtils.getString(
                                                mContext, 'sold2party'),
                                        style: invoiceModel != null
                                            ? textStyle
                                            : hintStyle,
                                      ),
                                    )),
                                Container(
                                    height: 42,
                                    width: screenSize.width,
                                    margin: const EdgeInsets.only(top: 20),
                                    padding:
                                        const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: Align(
                                      alignment: Alignment.centerLeft,
                                      child: Text(
                                        invoiceModel != null
                                            ? invoiceModel
                                                .var_ShipTo_OrganizationName
                                            : LocaleUtils.getString(
                                                mContext, 'ship2party'),
                                        style: invoiceModel != null
                                            ? textStyle
                                            : hintStyle,
                                      ),
                                    )),
                                Container(
                                  width: screenSize.width,
                                  height: 45,
                                  child: loginButton,
                                  margin: const EdgeInsets.only(top: 30),
                                  //margin: EdgeInsets.all(15),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      autovalidate: _autoValidate,
                      key: _formKey,
                    ),
                    flex: 1,
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    if (model.spinnerID == 1) {
      setSelectedCountryValues(model.name);
    }
  }

  void setSelectedCountryValues(String doNo) {
    for (int i = 0; i < invoiceList.length; i++) {
      if (invoiceList[i].varInvoiceNo.toLowerCase() == doNo.toLowerCase()) {
        if (mounted) {
          setState(() {
            invoiceModel = invoiceList[i];
          });
        }
      }
    }
  }

/*void setSelectedCustomerValues(int initId){
    for(int i=0;i<customerTypeList.length;i++){
      if(customerTypeList[i].fk_Customer_TypeGlCode == initId){
        if(mounted){
          setState(() {
            selectedCustomerTypeModel = customerTypeList[i];
          });
        }
      }
    }
  }*/
}
