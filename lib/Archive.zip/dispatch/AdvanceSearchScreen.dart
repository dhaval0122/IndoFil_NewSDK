import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';

class AdvanceSearchScreen extends StatefulWidget {
  final int isDispatchScreen;

  AdvanceSearchScreen({this.isDispatchScreen});

  @override
  AdvanceSearchScreenState createState() => AdvanceSearchScreenState();
}

class AdvanceSearchScreenState extends State<AdvanceSearchScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Size screenSize;
  String userName, subTitle, doNo;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  List<AdvanceSearchModel> listDisplay = List();
  bool loadingFlag = false, isNotification = false, isSync = false;
  final TextEditingController _search_controller = TextEditingController();
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  var customerLevel;

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }
    loadData();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void loadData() async {
    await getCustomerLevel();
    await getData('');
  }

  void getCustomerLevel() async {
    await sharedPrefs
        .getString(PREF_INIT_GI_CODE)
        .then((String initCode) async {
      if (widget.isDispatchScreen == 0) {
        await databaseHelper
            .getCustomerLevelForDispatch(int.parse(initCode))
            .then((var customerLevel1) {
          customerLevel = customerLevel1;
        });
      }
      if (widget.isDispatchScreen == 1) {
        await databaseHelper
            .getCustomerLevelForStockTransfer(int.parse(initCode))
            .then((var customerLevel1) {
          customerLevel = customerLevel1;
        });
      }
      if (widget.isDispatchScreen == 2) {
        await databaseHelper
            .getCustomerLevelForSalesReturn(int.parse(initCode))
            .then((var customerLevel1) {
          customerLevel = customerLevel1;
        });
      }
    });
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getData(String values) {
    if (values.trim().isNotEmpty) {
      if (mounted) {
        setState(() {
          loadingFlag = true;
        });
      }

      sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE).then((int customerGlCode) {
        databaseHelper
            .getAllCountryCustomerForAdvanceSearch(
                customerGlCode, values, customerLevel)
            .then((List<AdvanceSearchModel> data) {
          listDisplay.clear();
          if (mounted)
            setState(() {
              loadingFlag = false;
              listDisplay.addAll(data);
            });
        });
      });
    } else {
      if (mounted) {
        setState(() {
          listDisplay.clear();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, false);
        },
        child: MyCustomScaffold(
          resizeToAvoidBottomPadding: false,
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, false);
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName, subTitle, 'assets/stock_info_icon.png', 0),
                      Container(
                        color: const Color(colorAccent),
                        padding: const EdgeInsets.all(10),
                        margin: EdgeInsets.only(top: 1),
                        child: Container(
                          height: 40,
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(7)),
                              color: Colors.white),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Flexible(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: TextField(
                                    controller: _search_controller,
                                    //enableInteractiveSelection: false,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintStyle:
                                          TextStyle(color: Colors.grey[700]),
                                      hintText: LocaleUtils.getString(
                                          mContext, 'SearchSAPCodeOrName'),
                                      counterText: '',
                                    ),
                                    onChanged: (value) {
                                      filterSearchResults(
                                          value.trim().toLowerCase());
                                    },
                                    maxLines: 1,
                                    maxLength: EditTxtMaxLengths,
                                  ),
                                ),
                                flex: 1,
                              ),
                              Flexible(
                                child: IconButton(
                                    onPressed: () {
                                      // _search_controller.clear();
                                    },
                                    icon: const Icon(
                                      Icons.search,
                                      color: Color(colorPrimary),
                                    )),
                                flex: 0,
                              )
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                          flex: 1,
                          child: !loadingFlag
                              // ? listDisplay.length > 0
                              ? listDisplay.length > 0
                                  ? Container(
                                      color: const Color(bgColor),
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        itemBuilder: (context, position) {
                                          return GestureDetector(
                                              child: Card(
                                                elevation: 4,
                                                margin: const EdgeInsets.only(
                                                    left: 10,
                                                    top: 5,
                                                    right: 10,
                                                    bottom: 5),
                                                child: Container(
                                                  padding: EdgeInsets.all(10),
                                                  child: Column(
                                                    children: <Widget>[
                                                      Row(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Text(
                                                            '${LocaleUtils
                                                                .getString(
                                                                mContext,
                                                                'code')}',
                                                            style: prifixTxtStyle,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                            child: Text(
                                                              listDisplay[
                                                                      position]
                                                                  .varSAPCode,
                                                              style:
                                                                  prifixTxtStyle,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets.only(top: 5),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                          children: <Widget>[
                                                            Text(
                                                              '${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'name')}',
                                                              style: prifixTxtStyle,
                                                            ),
                                                            Expanded(
                                                              child: Padding(
                                                                padding:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                                child: Wrap(
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      listDisplay[
                                                                      position]
                                                                          .varOrganizationName,
                                                                      style:
                                                                      prifixTxtStyle,
                                                                    )
                                                                  ],
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets
                                                            .only(top: 5),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                          children: <Widget>[
                                                            Text(
                                                              '${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'Country_')}',
                                                              style: prifixTxtStyle,
                                                            ),
                                                            Expanded(
                                                              child: Padding(
                                                                padding:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                                child: Wrap(
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      listDisplay[
                                                                      position]
                                                                          .varName,
                                                                      style:
                                                                      prifixTxtStyle,
                                                                    )
                                                                  ],
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding: const EdgeInsets
                                                            .only(top: 5),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .start,
                                                          children: <Widget>[
                                                            Text(
                                                              '${LocaleUtils
                                                                  .getString(
                                                                  mContext,
                                                                  'Customer_type')}: ',
                                                              style: prifixTxtStyle,
                                                            ),
                                                            Expanded(
                                                              child: Padding(
                                                                padding:
                                                                EdgeInsets.only(
                                                                    left: 5),
                                                                child: Wrap(
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      listDisplay[
                                                                      position]
                                                                          .varCustomerName,
                                                                      style:
                                                                      prifixTxtStyle,
                                                                    )
                                                                  ],
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              onTap: () {
//                                                AdvanceSearchModel advanceSearchModel = listDisplay[position];
//                                                selectedCountryModel.intGlCode =
//                                                    advanceSearchModel.fk_CountryGlCode;
//                                                selectedCountryModel.name = advanceSearchModel.varName;
//                                                selectedCustomerTypeModel.varCustomer_Type_Name =
//                                                    advanceSearchModel.varCustomer_Type_Name;
//                                                DispatchFirstScreen.selectedCustomerTypeModel.varCustomerTypeName =
//                                                    advanceSearchModel.varCustomerName;
//                                                DispatchFirstScreen.selectedCustomerTypeModel.fk_Customer_TypeGlCode =
//                                                    advanceSearchModel.fk_CustomeGlCode;
//                                                DispatchFirstScreen.selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode =
//                                                    advanceSearchModel.fk_Customer_Type_CountryGlCode;
                                                globals.advanceSearchModel =
                                                    listDisplay[position];
                                                Navigator.pop(context, true);
                                              });
                                        },
                                        itemCount: listDisplay.length,
                                      ),
                                    )
                                  : Visibility(
                                      child: Container(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            Image.asset(
                                              'assets/nodata_icon.png',
                                              height: 100,
                                              width: 100,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 10),
                                              child: Text(
                                                LocaleUtils.getString(
                                                    mContext, 'NoDataFound'),
                                                style: prifixTxtStyle,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      visible: listDisplay.length == 0
                                          ? true
                                          : false,
                                      //listDisplay.length <= 0 ? true : false,
                                    )
                              : const Center(
                                  child: CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          Color(colorPrimary))),
                                )),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  void filterSearchResults(String query) {
    print(query);
    getData(query);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
