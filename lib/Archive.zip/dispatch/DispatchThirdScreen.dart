import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonEditDOWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MarqueeWidget.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/CongratulationScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/sales_return/SalesReturnScreen.dart';
import 'package:flutter_basf_hk_app/stocktransfer/StockTransferScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/utility/foc/FOCScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class CustomerDetailsModel {
  int fk_DispatchGlCode;
  String varSONO;
  String varDONO;
  String varCustomerName;
  String varCustomer_Name;
  String varCustomerSAPCode;
  String varCustType;
  String varCountryName;
  String varOrgName;

  CustomerDetailsModel(
      {this.fk_DispatchGlCode,
      this.varSONO,
      this.varDONO,
      this.varCustomerName,
        this.varCustomer_Name,
      this.varCustomerSAPCode,
      this.varCustType,
      this.varCountryName,
      this.varOrgName});

  CustomerDetailsModel.fromMap(Map<String, dynamic> json) {
    this.fk_DispatchGlCode = json['fk_DispatchGlCode'];
    this.varSONO = json['varSONO'];
    this.varDONO = json['varDONO'];
    this.varCustomerName = json['varCustomerName'];
    this.varCustomer_Name =
    json.containsKey('varCustomer_Name') ? json['varCustomer_Name'] : '';
    this.varCustomerSAPCode = json['varCustomerSAPCode'];
    this.varCustType = json['varCustType'];
    this.varCountryName = json['varCountryName'];
    this.varOrgName = json['varOrgName'];
  }
}

class ScanRecordModel {
  int intGlCode;
  String varProduct_SKU_Name;
  int intTotalUnit;
  double qtyKG;

//  String varLastDispatchBy;
//  String dtLastDispatchDate;

  ScanRecordModel({this.intGlCode,
    this.varProduct_SKU_Name,
    this.intTotalUnit,
    this.qtyKG});

  ScanRecordModel.fromMap(Map<String, dynamic> json) {
    this.intGlCode = json['intGlCode'];
    this.varProduct_SKU_Name = json['varProduct_SKU_Name'];
    this.intTotalUnit = json['intTotalUnit'];
    this.qtyKG = json['qtyKG'];
//    this.varLastDispatchBy =
//    json.containsKey('varLastDispatchBy') ? json['varLastDispatchBy'] : "";
//    this.dtLastDispatchDate = json.containsKey('dtLastDispatchDate')
//        ? json['dtLastDispatchDate']
//        : "";
  }
}

abstract class DialogLoadListener {
  void onLoad();

  void onCancel();
}

// ignore: must_be_immutable
class DispatchThirdScreen extends StatefulWidget {
  String subTitleTxt = '';
  bool isRedirectToEditScreen;

  DispatchThirdScreen({this.isRedirectToEditScreen, this.subTitleTxt});

  @override
  DispatchThirdScreenState createState() => DispatchThirdScreenState();
}

class DispatchThirdScreenState extends State<DispatchThirdScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false, isNotification = false, isSync = false;
  String dropdownValue;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '', doNo;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  List<ScanRecordModel> scanRecordList;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  CustomerDetailsModel customerDetailsModel;
  String closeTitle = '',
      DoSTONoTitle = '';
  int totalArticle, totalUnits;
  String dispatchBtnTitle = '';
  List<ScanDataModel> invalidStickerList;
  List<ScanDataModel> scanRecordDialogList;
  List<ScanDataModel> scanDialogList;
  ScanRecordModel selectedScanDataModelForDialog;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  String mScreenState;
  String mChrType;
  String displayDateFormat = '';

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  // ignore: missing_return
  String getSoNoDoNo() {
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String tranType) {
      if (tranType == TAG_DISPATCH || tranType == TAG_FOC) {
        return customerDetailsModel != null ? customerDetailsModel.varDONO : '';
      } else {
        return customerDetailsModel != null ? customerDetailsModel.varSONO : '';
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _initLoading();
    scanRecordList = List();
    invalidStickerList = List();
    scanRecordDialogList = List();
    scanDialogList = List();
    pushNotificationServices = PushNotificationServices(this);

    _battery = EcpSyncPlugin();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });

    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_WITH_TIME_DEFAULT_FORMAT;
          }
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      mScreenState = screenState;
      if (screenState == TAG_DISPATCH) {
        topHeaderImage = 'assets/dispatch_icon.png';
        closeTitle = LocaleUtils.getString(mContext, 'Discard');
        dispatchBtnTitle = LocaleUtils.getString(mContext, 'tag_dispatch');
        DoSTONoTitle = '${globals.DO_NO}: ';
      } else if (screenState == TAG_FOC) {
        topHeaderImage = 'assets/foc_icon.png';
        closeTitle = LocaleUtils.getString(mContext, 'Discard');
        dispatchBtnTitle = LocaleUtils.getString(mContext, 'tag_foc');
        DoSTONoTitle = '${globals.FOC_NO}: ';
      } else if (screenState == TAG_STOCK_TRANSFER) {
        topHeaderImage = 'assets/stock_transfer_small_top.png';
        DoSTONoTitle = '${globals.STO_NO}: ';
        dispatchBtnTitle = LocaleUtils.getString(mContext, 'transfer');
        closeTitle = LocaleUtils.getString(mContext, 'Discard');
      } else if (screenState == TAG_SALES_RETURN) {
        topHeaderImage = 'assets/sidebar_placegoodsreturn.png';
        DoSTONoTitle = '${globals.RETURN_NO}: ';
        dispatchBtnTitle = LocaleUtils.getString(mContext, 'return');
        closeTitle = LocaleUtils.getString(mContext, 'Discard');
      } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        topHeaderImage = 'assets/edit_do_icon.png';
        sharedPrefs
            .getString(PREF_CHAR_TRAN_TYPE_DISPATCH)
            .then((String chrType) {
          mChrType = chrType;
          print('====chrType====${chrType} : ');
          if (chrType == 'S') {
            DoSTONoTitle = '${globals.STO_NO}: ';
            dispatchBtnTitle = LocaleUtils.getString(mContext, 'transfer');
            if (globals.DO.length > 2) {
              String invoice = globals.DO.substring(0, 3).toUpperCase();
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} $invoice';
            } else {
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} ${globals.DO}';
            }
          } else if (chrType == 'D') {
            if (globals.DO.length > 2) {
              String invoice = globals.DO.substring(0, 3).toUpperCase();
              print('===invoice====$invoice :');
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} $invoice';
            } else {
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} ${globals.DO}';
            }
            dispatchBtnTitle = LocaleUtils.getString(mContext, 'tag_dispatch');
            DoSTONoTitle = '${globals.DO_NO}: ';
          } else if (chrType == 'R') {
            DoSTONoTitle = '${globals.RETURN_NO}: ';
            dispatchBtnTitle = LocaleUtils.getString(mContext, 'return');
            closeTitle = LocaleUtils.getString(mContext, 'Discard');
          } else if (chrType == 'F') {
            DoSTONoTitle = '${globals.FOC_NO}: ';
            dispatchBtnTitle = LocaleUtils.getString(mContext, 'tag_foc');
            closeTitle = LocaleUtils.getString(mContext, 'Discard');
          } else {
            if (globals.DO.length > 2) {
              String invoice = globals.DO.substring(0, 3).toUpperCase();
              print('===invoice====$invoice');
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} $invoice';
            } else {
              closeTitle =
              '${LocaleUtils.getString(mContext, 'Cancel')} ${globals.DO}';
            }
            dispatchBtnTitle = LocaleUtils.getString(mContext, 'tag_dispatch');
            DoSTONoTitle = '${globals.DO_NO}: ';
          }
        });
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getChangeDetailsDataFromDB();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    }
    /*else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    }*/
    else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_FOC) {
      return LocaleUtils.getString(mContext, 'tag_foc');
    } else {
      return '';
    }
  }

  void getChangeDetailsDataFromDB() {
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int initGlCode) {
      databaseHelper
          .getCustomerDetails(initGlCode.toString())
          .then((CustomerDetailsModel custDetailsModel) {
        if (mounted) {
          setState(() {
            customerDetailsModel = custDetailsModel;
          });
        }
        print(
            '------customerDetailsModel--------${customerDetailsModel.toString()}');
        getScanRecordFromDB();
      });
    });
  }

  void getScanRecordFromDB() {
    scanRecordList.clear();
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int initGlCode) {
      databaseHelper
          .getScannedRecord(initGlCode)
          .then((List<ScanRecordModel> result) {
        try {
          if (result != null) {
            if (mounted) {
              setState(() {
                print('======getScanRecordFromDB========${result.length}');
                scanRecordList.addAll(result);
                totalUnits = calUUnitProductTotal(result);
                totalArticle = scanRecordList.length;
              });
            }
          }
        } catch (e) {
          print(e.toString());
        }
      });
    });
  }

  int calUUnitProductTotal(List<ScanRecordModel> dispatchScanModelsList) {
    int unitTotal = 0;
    for (int i = 0; i < dispatchScanModelsList.length; i++) {
      final ScanRecordModel scanRecordModel = dispatchScanModelsList[i];
      unitTotal = unitTotal + scanRecordModel.intTotalUnit;
    }
    return unitTotal;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void changeDetailsBtn() {
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_DISPATCH) {
        sharedPrefs
            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
            .then((bool isChange) {
          _navigateAndDisplaySelection(1);
        });
      } else if (screenState == TAG_FOC) {
        sharedPrefs
            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
            .then((bool isChange) {
          _navigateAndDisplaySelection(4);
        });
      } else if (screenState == TAG_STOCK_TRANSFER) {
        sharedPrefs
            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
            .then((bool isChange) {
          _navigateAndDisplaySelection(2);
        });
      } else if (screenState == TAG_SALES_RETURN) {
        sharedPrefs
            .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
            .then((bool isChange) {
          _navigateAndDisplaySelection(3);
        });
      } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        sharedPrefs
            .getString(PREF_CHAR_TRAN_TYPE_DISPATCH)
            .then((String chrType) {
          if (chrType == 'S') {
            sharedPrefs
                .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
                .then((bool isChange) {
              _navigateAndDisplaySelection(2);
            });
          } else if (chrType == 'D') {
            sharedPrefs
                .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
                .then((bool isChange) {
              _navigateAndDisplaySelection(1);
            });
          } else if (chrType == 'R') {
            sharedPrefs
                .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
                .then((bool isChange) {
              _navigateAndDisplaySelection(3);
            });
          } else if (chrType == 'F') {
            sharedPrefs
                .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
                .then((bool isChange) {
              _navigateAndDisplaySelection(4);
            });
          } else {
            sharedPrefs
                .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, true)
                .then((bool isChange) {
              _navigateAndDisplaySelection(1);
            });
          }
        });
      }
    });
  }

  void reScanBtn() {
    sharedPrefs
        .setBool(IS_CHANGE_SCANNING_STATE, true)
        .then((bool isChangeScan) {
      if (isChangeScan) {
        scanScreenLoad();
      }
    });
  }

  String getPopupTitleName() {
    String customerName =
    customerDetailsModel != null ? customerDetailsModel.varOrgName : '';
    if (mScreenState == TAG_DISPATCH) {
      return '${LocaleUtils.getString(mContext, 'DispatchTo_')} $customerName';
    } else if (mScreenState == TAG_STOCK_TRANSFER) {
      return '${LocaleUtils.getString(mContext, 'transfer_to')} $customerName';
    } else if (mScreenState == TAG_SALES_RETURN) {
      return '${LocaleUtils.getString(mContext, 'return_to')} $customerName';
    } else if (mScreenState == TAG_EDIT_DO) {
      if (mChrType == 'S') {
        return '${LocaleUtils.getString(
            mContext, 'transfer_to')} $customerName';
      } else if (mChrType == 'D') {
        return '${LocaleUtils.getString(
            mContext, 'DispatchTo_')} $customerName';
      } else if (mChrType == 'R') {
        return '${LocaleUtils.getString(mContext, 'return_to')} $customerName';
      } else if (mChrType == 'F') {
        return '${LocaleUtils.getString(mContext, 'tag_foc')}';
      } else {
        return '${LocaleUtils.getString(
            mContext, 'DispatchTo_')} $customerName';
      }
    } else if (mScreenState == TAG_FOC) {
      return '${LocaleUtils.getString(mContext, 'tag_foc')}';
    } else {
      return '${LocaleUtils.getString(mContext, 'DispatchTo_')} $customerName';
    }
  }

  void closeBtn() async {
    String tranType = await sharedPrefs.getString(PREF_SCREEN_STATE);

    await showDialog<Map>(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(
              mContext, 'AreYouSureUWant2DiscardTransaction'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: true,
          textNagativeButton: LocaleUtils.getString(mContext, 'no'),
          textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
          onPressedNegative: () {},
          onPressedPositive: () {
            if (tranType == TAG_DISPATCH ||
                tranType == TAG_FOC ||
                tranType == TAG_SALES_RETURN ||
                tranType == TAG_STOCK_TRANSFER) {
              closeDispatch();
            } else if (tranType.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
              cancelDOSTO();
            }
          },
        );
      },
    );
  }

  void closeDispatch() {
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
      sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
        databaseHelper
            .cancelDispatch(fkDispatchGlCode, int.parse(initGlCode))
            .then((int id) {
          Navigator.pop(context);
        });
      });
    });
  }

  void cancelDOSTO() {
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
      sharedPrefs
          .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
          .then((int fkMainCustomerGlCode) {
        sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
          databaseHelper
              .updateCPMStickerDetailsForCancelDO(
                  globals.intPrinted,
                  globals.intReceived,
                  fkDispatchGlCode,
                  int.parse(initGlCode),
                  'PRINTED',
                  'RECEIVED',
                  fkMainCustomerGlCode)
              .then((int id1) {
            databaseHelper
                .updateCPMCustomerDispatchProductDetailsForCancelDO(
                int.parse(initGlCode),
                fkDispatchGlCode,
                fkMainCustomerGlCode)
                .then((int id) {
              databaseHelper
                  .updateCPMCustomerDispatchForCancelDO(fkMainCustomerGlCode,
                      int.parse(initGlCode), fkDispatchGlCode)
                  .then((int id) {
                Navigator.pop(context);
              });
            });
          });
        });
      });
    });
  }

  void finalDispatchEditDO(int fkStatus) {
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
      sharedPrefs
          .getInt(PREF_FK_LAST_DISPATCHED_TO)
          .then((int fkLastDispatchGlCode) {
        sharedPrefs
            .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
            .then((int fkMainCustomerGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            databaseHelper
                .customerTypeContryMstForCancelDO(fkMainCustomerGlCode)
                .then((int id) {
              if (id > 0) {
                databaseHelper
                    .updateCPMStickerDetailsForEditDO(
                        globals.intPrinted,
                        fkDispatchGlCode,
                        int.parse(initGlCode),
                        'PRINTED',
                        fkMainCustomerGlCode)
                    .then((int id1) {
                  databaseHelper
                      .updateStickerDetails(
                          int.parse(initGlCode),
                          fkDispatchGlCode,
                          fkLastDispatchGlCode,
                          fkMainCustomerGlCode,
                          fkStatus)
                      .then((int id) {
                    databaseHelper
                        .updateCPMProductDetailsForEditDO(
                            fkDispatchGlCode, int.parse(initGlCode))
                        .then((int id) {
                      databaseHelper
                          .updateCPMCustomerDispatchForEditDO(
                              int.parse(initGlCode),
                              fkDispatchGlCode,
                              fkMainCustomerGlCode)
                          .then((int id) {
                        _loading = false;
                        dismissProgressHUD();
//                        Navigator.popAndPushNamed(context, CONGRATULATION_SCREEN);
                        final Route route = CupertinoPageRoute(
                            builder: (context) => CongratulationScreen());
                        Navigator.pushReplacement(mContext, route);
                      });
                    });
                  });
                });
              } else {
                databaseHelper
                    .updateCPMStickerDetailsForEditDO(
                        globals.intReceived,
                        fkDispatchGlCode,
                        int.parse(initGlCode),
                        'RECEIVED',
                        fkMainCustomerGlCode)
                    .then((int id1) {
                  databaseHelper
                      .updateStickerDetails(
                          int.parse(initGlCode),
                          fkDispatchGlCode,
                          fkLastDispatchGlCode,
                          fkMainCustomerGlCode,
                          fkStatus)
                      .then((int id) {
                    databaseHelper
                        .updateCPMProductDetailsForEditDO(
                            fkDispatchGlCode, int.parse(initGlCode))
                        .then((int id) {
                      databaseHelper
                          .updateCPMCustomerDispatchForEditDO(
                              int.parse(initGlCode),
                              fkDispatchGlCode,
                              fkMainCustomerGlCode)
                          .then((int id) {
                        _loading = false;
                        dismissProgressHUD();
//                        Navigator.popAndPushNamed(context, CONGRATULATION_SCREEN);
                        final Route route = CupertinoPageRoute(
                            builder: (context) => CongratulationScreen());
                        Navigator.pushReplacement(mContext, route);
                      });
                    });
                  });
                });
              }
            });
          });
        });
      });
    });
  }

  void disaptchBtn() {
    //if (scanRecordList.length > 0) {
    if (scanRecordList.isNotEmpty) {
      _loading = true;
      dismissProgressHUD();
      sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
        databaseHelper
            .getInvalidSticker(fkDispatchGlCode)
            .then((List<ScanDataModel> invalidList) {
          invalidStickerList.clear();
          invalidStickerList.addAll(invalidList);
          _loading = false;
          dismissProgressHUD();
          showDialog<Map>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return dispatchDialog();
            },
          );
        });
      });
    } else {
      showDialog<Map>(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return CustomAlertDialog(
            content:
                LocaleUtils.getString(mContext, 'YouHaveNotScannedAnyLabelYet'),
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  AlertDialog dispatchDialog() {
    //print('======invalidStickerList===========${invalidStickerList.length}');

    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        content: invalidStickerList.isNotEmpty
            ? Container(
                width: MediaQuery.of(context).size.width * 0.8,
                height: MediaQuery.of(context).size.height * 0.7,
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      height: 40,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: MarqueeWidget(
                            direction: Axis.horizontal,
                            child: Text(
//                                mScreenState == TAG_FOC
//                                    ? getPopupTitleName()
//                                    : customerDetailsModel != null
//                                    ? getPopupTitleName() +
//                                        ' ${customerDetailsModel.varOrgName}'
//                                    : '',
                                getPopupTitleName(),
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w400,
                                    fontFamily: 'helvetica',
                                    color: Colors.white))),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 0),
                                    child: Text(
                                        scanRecordList != null
                                            ? scanRecordList.length.toString()
                                            : '0',
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotScanned'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 0),
                                    child: Text(
                                        calUUnitProductTotal(scanRecordList)
                                            .toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10),
                      child: Text(
                          LocaleUtils.getString(mContext, 'InvalidCodes'),
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              fontFamily: 'helvetica',
                              color: const Color(colorPrimary))),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 10, bottom: 10),
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      child: Text(
                          LocaleUtils.getString(
                              mContext, 'ThisTranWillProceedWithoutBelowCode'),
                          style: TextStyle(
                              fontSize: 12.0,
                              fontWeight: FontWeight.w400,
                              fontFamily: 'helvetica',
                              color: Colors.black)),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: invalidStickerList.length,
                        shrinkWrap: true,
                        itemBuilder: (BuildContext context, int index) {
                          return Container(
                            height: 35,
                            alignment: Alignment.center,
                            child: Column(
                              children: <Widget>[
                                Text(
                                    //invalidStickerList.length > 0
                                    invalidStickerList.isNotEmpty
                                        ? '${invalidStickerList[index].varSticker} (#${invalidStickerList[index].intRowNo})'
                                        : '',
                                    style: TextStyle(
                                        fontSize: 12.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'helvetica',
                                        color: Colors.red)),
                                Divider(color: Colors.black54),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Cancel'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            flex: 1,
                          ),
                          Container(
                            width: 0.7,
                          ),
                          Expanded(
                            child: ButtonDialogWidgets(
                                buttonName:
                                    LocaleUtils.getString(mContext, 'Confirm'),
                                buttonColor: const Color(colorPrimary),
                                textColor: Colors.white,
                                onTap: () {
                                  Navigator.of(context).pop();
                                  dispatchDialogBtnEvent();
                                }),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            : Container(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      height: 40,
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      color: const Color(colorPrimary),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: MarqueeWidget(
                            direction: Axis.horizontal,
                            child: Text(
//                                mScreenState == TAG_FOC
//                                    ? getPopupTitleName()
//                                    : customerDetailsModel != null
//                                        ? getPopupTitleName() +
//                                            ' ${customerDetailsModel.varOrgName}'
//                                        : '',
                                getPopupTitleName(),
                                style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w400,
                                    fontFamily: 'helvetica',
                                    color: Colors.white))),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 20, bottom: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 0),
                                    child: Text(
                                        scanRecordList != null
                                            ? scanRecordList.length.toString()
                                            : '0',
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 10),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotScanned'),
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w500,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                                Padding(
                                    padding: const EdgeInsets.only(top: 0),
                                    child: Text(
                                        calUUnitProductTotal(scanRecordList)
                                            .toString(),
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Cancel'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            flex: 1,
                          ),
                          Container(
                            width: 0.7,
                          ),
                          Expanded(
                            child: ButtonDialogWidgets(
                              buttonName:
                                  LocaleUtils.getString(mContext, 'Confirm'),
                              buttonColor: const Color(colorPrimary),
                              textColor: Colors.white,
                              onTap: () {
                                Navigator.of(context).pop();
                                dispatchDialogBtnEvent();
                              },
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
        //actions: _actionButton()
        );
  }

  void filterSearchResults(String query) {
    print(query);
    openScanRecordDialog(query, false);
  }

  void removeSticker(int fkCustomerDispatchProductGLCode,
      int fk_Customer_DispatchGlCode, String chrPallet) {
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String state) {
      if (state == TAG_DISPATCH ||
          state.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
          state == TAG_STOCK_TRANSFER ||
          state == TAG_FOC ||
          state == TAG_SALES_RETURN) {
        showDialog<Map>(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'del_conform'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'no'),
              textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
              onPressedNegative: () {},
              onPressedPositive: () {
                Navigator.of(context).pop();
                String chrActiveType;
                if (state == TAG_DISPATCH ||
                    state == TAG_STOCK_TRANSFER ||
                    state == TAG_FOC ||
                    state == TAG_SALES_RETURN) {
                  chrActiveType = 'N';
                } else if (state.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
                  chrActiveType = 'E';
                }

                print(
                    '======fk_Customer_DispatchProduct_GLCode=====$fkCustomerDispatchProductGLCode');
                print('======chrActiveType=====$chrActiveType');

                databaseHelper
                    .updateStickerForDelete(fkCustomerDispatchProductGLCode,
                    fk_Customer_DispatchGlCode, chrActiveType, chrPallet)
                    .then((int id) {
                  if (id > 0) {
                    sharedPrefs
                        .getInt(PREF_FK_DISPATCH_GL_CODE)
                        .then((int fkCustomerDispatchProductGLCode) {
                      openScanRecordDialog('', false);
                      getScanRecordFromDB();
                    });
                  }
                });
              },
            );
          },
        );
      }
    });
  }

  void dispatchDialogBtnEvent() {
    _loading = true;
    dismissProgressHUD();

    sharedPrefs.getString(PREF_SCREEN_STATE).then((String tranType) {
      if (tranType == TAG_DISPATCH || tranType == TAG_FOC) {
        int fkStatus =
        tranType == TAG_DISPATCH ? globals.intDispatched : globals.intFOC;
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fk_Customer_DispatchGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGLCode) {
              sharedPrefs
                  .getInt(PREF_FK_LAST_DISPATCHED_TO)
                  .then((int fk_Last_DispatchedTo) {
                databaseHelper
                    .updateStickerDetails(
                        int.parse(initGlCode),
                        fk_Customer_DispatchGlCode,
                        fk_Last_DispatchedTo,
                        mainCustomerGLCode,
                        fkStatus)
                    .then((int id) {
                  databaseHelper
                      .updateCPMCustomerDispatch(
                          int.parse(initGlCode), fk_Customer_DispatchGlCode)
                      .then((int id1) {
                    databaseHelper
                        .updatePalletForBreak(
                            int.parse(initGlCode), fk_Customer_DispatchGlCode)
                        .then((int id1) {
                      _loading = false;
                      dismissProgressHUD();
//                    Navigator.popAndPushNamed(context, CONGRATULATION_SCREEN);
                      sharedPrefs.setInt(PREF_FK_DISPATCH_GL_CODE, 0);
                      sharedPrefs.setInt(PREF_FK_SOLD_TO_PARTY_GL_CODE, 0);
                      sharedPrefs.setString(PREF_DO_NO, '');
                      final Route route = CupertinoPageRoute(
                          builder: (context) => CongratulationScreen());
                      Navigator.pushReplacement(mContext, route);
                    });
                  });
                });
              });
            });
          });
        });
      } else if (tranType == TAG_STOCK_TRANSFER) {
        int fk_Status = globals.intTransfered;
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fk_Customer_DispatchGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGLCode) {
              sharedPrefs
                  .getInt(PREF_FK_LAST_DISPATCHED_TO)
                  .then((int fk_Last_DispatchedTo) {
                databaseHelper
                    .updateStickerDetails(
                    int.parse(initGlCode),
                    fk_Customer_DispatchGlCode,
                    fk_Last_DispatchedTo,
                    mainCustomerGLCode,
                    fk_Status)
                    .then((int id) {
                  databaseHelper
                      .updateCPMCustomerDispatch(
                      int.parse(initGlCode), fk_Customer_DispatchGlCode)
                      .then((int id1) {
                    databaseHelper
                        .updatePalletForBreak(
                        int.parse(initGlCode), fk_Customer_DispatchGlCode)
                        .then((int id1) {
                      _loading = false;
                      dismissProgressHUD();
//                    Navigator.popAndPushNamed(context, CONGRATULATION_SCREEN);
                      final Route route = CupertinoPageRoute(
                          builder: (context) => CongratulationScreen());
                      Navigator.pushReplacement(mContext, route);
                    });
                  });
                });
              });
            });
          });
        });
      } else if (tranType == TAG_SALES_RETURN) {
        int fk_Status = globals.intSalesReturn;
        sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fk_Customer_DispatchGlCode) {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGLCode) {
              sharedPrefs
                  .getInt(PREF_FK_LAST_DISPATCHED_TO)
                  .then((int fk_Last_DispatchedTo) {
                databaseHelper
                    .updateStickerDetails(
                    int.parse(initGlCode),
                    fk_Customer_DispatchGlCode,
                    fk_Last_DispatchedTo,
                    mainCustomerGLCode,
                    fk_Status)
                    .then((int id) {
                  databaseHelper
                      .updateCPMCustomerDispatch(
                      int.parse(initGlCode), fk_Customer_DispatchGlCode)
                      .then((int id1) {
                    databaseHelper
                        .updatePalletForBreak(
                        int.parse(initGlCode), fk_Customer_DispatchGlCode)
                        .then((int id1) {
                      _loading = false;
                      dismissProgressHUD();
//                    Navigator.popAndPushNamed(context, CONGRATULATION_SCREEN);
                      final Route route = CupertinoPageRoute(
                          builder: (context) => CongratulationScreen());
                      Navigator.pushReplacement(mContext, route);
                    });
                  });
                });
              });
            });
          });
        });
      } else if (tranType.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
          sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) {
            databaseHelper
                .updatePalletForBreak(
                    int.parse(initGlCode), fk_Customer_DispatchGlCode)
                .then((int id1) {
              sharedPrefs
                  .getString(PREF_CHAR_TRAN_TYPE_DISPATCH)
                  .then((String chrType) {
                if (chrType == 'S') {
                  finalDispatchEditDO(globals.intTransfered);
                } else if (chrType == 'D') {
                  finalDispatchEditDO(globals.intDispatched);
                } else if (chrType == 'R') {
                  finalDispatchEditDO(globals.intSalesReturn);
                } else if (chrType == 'F') {
                  finalDispatchEditDO(globals.intDispatched);
                }
              });
            });
          });
        });
      }
    });
  }

  void _navigateAndDisplaySelection(int isDispatch) async {
    if (isDispatch == 1) {
      final Route route =
          CupertinoPageRoute(builder: (context) => DispatchFirstScreen());
      final result = await Navigator.push(mContext, route);
      try {
        if (result != null) {
          if (result) {
            if (mounted) {
              getChangeDetailsDataFromDB();
            }
          }
        }
      } catch (e) {
        print(e.toString());
      }
    } else if (isDispatch == 2) {
      final Route route =
          CupertinoPageRoute(builder: (context) => StockTransferScreen());
      final result = await Navigator.push(mContext, route);
      try {
        if (result != null) {
          if (result) {
            if (mounted) {
              getChangeDetailsDataFromDB();
            }
          }
        }
      } catch (e) {
        print(e.toString());
      }
    } else if (isDispatch == 3) {
      final Route route =
      CupertinoPageRoute(builder: (context) => SalesReturnScreen());
      final result = await Navigator.push(mContext, route);
      try {
        if (result != null) {
          if (result) {
            if (mounted) {
              getChangeDetailsDataFromDB();
            }
          }
        }
      } catch (e) {
        print(e.toString());
      }
    } else if (isDispatch == 4) {
      final Route route = CupertinoPageRoute(builder: (context) => FOCScreen());
      final result = await Navigator.push(mContext, route);
      try {
        if (result != null) {
          if (result) {
            if (mounted) {
              getChangeDetailsDataFromDB();
            }
          }
        }
      } catch (e) {
        print(e.toString());
      }
    } else {
      final Route route =
      CupertinoPageRoute(builder: (context) => DispatchFirstScreen());
      final result = await Navigator.push(mContext, route);
      try {
        if (result != null) {
          if (result) {
            if (mounted) {
              getChangeDetailsDataFromDB();
            }
          }
        }
      } catch (e) {
        print(e.toString());
      }
    }
  }

  void scanScreenLoad() async {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            getScanRecordFromDB();
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void openScanRecordDialog(String values, bool isFirstTime) {
    //if (scanRecordDialogList.length > 0) {
    _loading = true;
    dismissProgressHUD();
    sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE).then((int fkDispatchGlCode) {
      databaseHelper
          .showStickerDialogSearchTask(values, fkDispatchGlCode,
              selectedScanDataModelForDialog.intGlCode)
          .then((List<ScanDataModel> invalidList) {
        print('======invalidList======${invalidList.length}');
        print('======isFirstTime======$isFirstTime');

        _loading = false;
        dismissProgressHUD();
        if (isFirstTime) {
          scanDialogList.clear();
          scanRecordDialogList.clear();
          scanRecordDialogList.addAll(invalidList);
          scanDialogList.addAll(invalidList);
          showDialog<Map>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return MyForm(
                screenSize: screenSize,
                listSticker: scanDialogList,
                listStickerDisplay: scanRecordDialogList,
                dispatchThirdScreen: this,
              );
            },
          );
        } else {
          if (mounted) {
            setState(() {
              scanRecordDialogList.clear();
              scanDialogList.clear();
              scanRecordDialogList.addAll(invalidList);
              scanDialogList.addAll(invalidList);
            });
          }
        }
      });
    });
    // }
  }

  void deleteScanRecordsEvent(ScanRecordModel scanRecordModel) {
    showDialog<Map>(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return CustomAlertDialog(
          content: '${globals.DO} you want to delete?',
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: true,
          textNagativeButton: LocaleUtils.getString(mContext, 'no'),
          textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
          onPressedNegative: () {},
          onPressedPositive: () {
            showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return CustomAlertDialog(
                  content: LocaleUtils.getString(mContext, 'del_conform'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: true,
                  textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                  textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    _loading = true;
                    dismissProgressHUD();
                    sharedPrefs
                        .getInt(PREF_FK_DISPATCH_GL_CODE)
                        .then((int fkDispatchGlCode) {
                      sharedPrefs
                          .getString(PREF_INIT_GI_CODE)
                          .then((String initGlCode) {
                        final int fk_Product_SKU_Glcode =
                            scanRecordModel.intGlCode;
                        databaseHelper
                            .deleteDispatchRecords(int.parse(initGlCode),
                                fkDispatchGlCode, fk_Product_SKU_Glcode)
                            .then((int id) {
                          _loading = false;
                          dismissProgressHUD();
                          getScanRecordFromDB();
                        });
                      });
                    });
                  },
                );
              },
            );
          },
        );
      },
    );
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
              // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final changeDetailsButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ChangeDetails'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: changeDetailsBtn,
      ),
    );

    final reScanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ReScan'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: reScanBtn,
      ),
    );

    final closeButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonEditDOWidgets(
        buttonName: closeTitle,
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        textSize: closeTitle.contains(
            LocaleUtils.getString(mContext, 'Discard'))
            ? 16.0
            : 13.0,
        onTap: closeBtn,
      ),
    );

    final dispatchButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: dispatchBtnTitle,
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: disaptchBtn,
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName,
                          widget.isRedirectToEditScreen
                              ? widget.subTitleTxt
                              : subTitle,
                          topHeaderImage,
                          0),
                      CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_THIRD, false),
                      Container(
                        child: Card(
                          elevation: 7,
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Container(
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: Wrap(
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            LocaleUtils.getString(
                                                mContext, 'Country_'),
                                            style: prifixTxtStyle,
                                          ),
                                          Text(
                                            customerDetailsModel != null
                                                ? customerDetailsModel
                                                .varCountryName
                                                : '',
                                            style: textStyle,
                                          ),
                                        ],
                                      ),
                                      flex: 1,
                                    ),
                                    mScreenState == TAG_FOC
                                        ? Container()
                                        : Expanded(
                                      child: Wrap(
                                        direction: Axis.horizontal,
                                        runAlignment: WrapAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            LocaleUtils.getString(
                                                mContext, 'CustType_'),
                                            style: prifixTxtStyle,
                                          ),
                                          Text(
                                            customerDetailsModel != null
                                                ? customerDetailsModel
                                                .varCustType
                                                : '',
                                            style: textStyle,
                                          ),
                                        ],
                                      ),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Wrap(
                                    direction: Axis.horizontal,
                                    runAlignment: WrapAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        mScreenState == TAG_FOC
                                            ? LocaleUtils.getString(
                                            mContext, 'ship_to_name')
                                            : LocaleUtils.getString(
                                            mContext, 'CustName_'),
                                        style: prifixTxtStyle,
                                      ),
                                      Text(
                                        customerDetailsModel != null
                                            ? customerDetailsModel
                                            .varCustomerName.contains('Other')
                                            ? '${customerDetailsModel
                                            .varCustomerName} - ${customerDetailsModel
                                            .varCustomer_Name}'
                                            : customerDetailsModel
                                            .varCustomerName : '',
                                        style: textStyle,
                                      ),
                                    ],
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          mainAxisSize: MainAxisSize.max,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                          children: <Widget>[
                                            Wrap(
                                              direction: Axis.horizontal,
                                              crossAxisAlignment:
                                              WrapCrossAlignment.center,
                                              alignment: WrapAlignment.start,
                                              children: <Widget>[
                                                Text(
                                                  DoSTONoTitle,
                                                  style: prifixTxtStyle,
                                                ),
                                                Padding(
                                                    padding:
                                                    const EdgeInsets.only(
                                                        top: 1),
                                                    child: Text(
                                                      customerDetailsModel !=
                                                          null
                                                          ? customerDetailsModel
                                                          .varDONO
                                                          : '',
                                                      style: textStyle,
                                                    ))
                                              ],
                                            ),
                                            mScreenState == TAG_FOC
                                                ? Container()
                                                : Padding(
                                              padding:
                                              const EdgeInsets.only(
                                                  top: 4),
                                              child: Wrap(
                                                direction:
                                                Axis.horizontal,
                                                runAlignment:
                                                WrapAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                    LocaleUtils.getString(
                                                        mContext,
                                                        'SAPCode_'),
                                                    style: prifixTxtStyle,
                                                  ),
                                                  Text(
                                                    customerDetailsModel !=
                                                        null
                                                        ? customerDetailsModel
                                                        .varCustomerSAPCode
                                                        : '',
                                                    style: textStyle,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                        flex: 2,
                                      ),
                                      globals.AUTO_DISPATCH_DO_CONFIRM == 'N'
                                          ? globals.AUTO_DISPATCH_STO_CONFIRM ==
                                          'N'
                                          ? globals.AutoSalesReturnConfirm ==
                                          'N'
                                          ? globals.AutoFOCConfirm ==
                                          'N'
                                          ? Container()
                                          : changeDetailsButton
                                          : changeDetailsButton
                                          : changeDetailsButton
                                          : changeDetailsButton,
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: 40,
                        color: const Color(colorAccent),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotUnits_'),
                                    style: prifixTxtPrimaryStyle,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top: 2),
                                      child: Text(
                                        totalUnits != null
                                            ? totalUnits.toString()
                                            : '0',
                                        style: textPrimaryStyle,
                                      ))
                                ],
                              ),
                              flex: 1,
                            ),
                            Container(
                              width: 1,
                              color: Colors.white70,
                            ),
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'TotArticle_'),
                                    style: prifixTxtPrimaryStyle,
                                  ),
                                  Padding(
                                      padding: const EdgeInsets.only(top: 2),
                                      child: Text(
                                        totalArticle != null
                                            ? totalArticle.toString()
                                            : '0',
                                        style: textPrimaryStyle,
                                      ))
                                ],
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          alignment: Alignment.topLeft,
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 5, left: 0, bottom: 10),
                                child: Text(
                                    LocaleUtils.getString(
                                        mContext, 'ScanningDetails'),
                                    style: prifixTxtStyle),
                              ),
                              Expanded(
                                child: Container(
                                  child: ListView.builder(
                                    itemCount: scanRecordList.length,
                                    shrinkWrap: true,
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return GestureDetector(
                                          onLongPress: () {
                                            if (mScreenState == TAG_DISPATCH) {
                                              deleteScanRecordsEvent(
                                                  scanRecordList[index]);
                                            }
                                          },
                                          onTap: () {
                                            selectedScanDataModelForDialog =
                                            scanRecordList[index];
                                            openScanRecordDialog('', true);
                                          },
                                          child: Card(
                                              elevation: 7,
                                              child: Container(
                                                  padding: EdgeInsets.all(5),
                                                  child: Column(
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .start,
                                                    children: <Widget>[
                                                      Padding(
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 5,
                                                            left: 10,
                                                            right: 10),
                                                        child: Wrap(
                                                          direction:
                                                          Axis.horizontal,
                                                          runAlignment:
                                                          WrapAlignment
                                                              .start,
                                                          children: <Widget>[
                                                            Padding(
                                                                padding: EdgeInsets
                                                                    .only(
                                                                    top: 0),
                                                                child: Text(
                                                                  scanRecordList
                                                                      .isNotEmpty
                                                                      ? scanRecordList[
                                                                  index]
                                                                      .varProduct_SKU_Name
                                                                      : '',
                                                                  style:
                                                                  textStyle,
                                                                ))
                                                          ],
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:
                                                        EdgeInsets.only(
                                                            top: 3,
                                                            left: 10,
                                                            right: 10,
                                                            bottom: 3),
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          //mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                          children: <Widget>[
                                                            Wrap(
                                                              direction: Axis
                                                                  .horizontal,
                                                              alignment:
                                                              WrapAlignment
                                                                  .start,
                                                              crossAxisAlignment:
                                                              WrapCrossAlignment
                                                                  .center,
                                                              children: <
                                                                  Widget>[
                                                                Text(
                                                                  LocaleUtils
                                                                      .getString(
                                                                      context,
                                                                      "Scanned_"),
                                                                  style:
                                                                  titleBoldStyle,
                                                                ),
                                                                Padding(
                                                                    padding: EdgeInsets
                                                                        .only(
                                                                        top:
                                                                        2),
                                                                    child: Text(
                                                                      scanRecordList
                                                                          .isNotEmpty
                                                                          ? scanRecordList[index]
                                                                          .intTotalUnit
                                                                          .toString()
                                                                          : '',
                                                                      style:
                                                                      textNormalStyle,
                                                                    ))
                                                              ],
                                                            ),
                                                            Padding(
                                                              padding: EdgeInsets
                                                                  .only(
                                                                  left: 20),
                                                              child: Wrap(
                                                                direction: Axis
                                                                    .horizontal,
                                                                alignment:
                                                                WrapAlignment
                                                                    .start,
                                                                crossAxisAlignment:
                                                                WrapCrossAlignment
                                                                    .center,
                                                                children: <
                                                                    Widget>[
                                                                  Text(
                                                                    '${LocaleUtils
                                                                        .getString(
                                                                        context,
                                                                        'Qty')}.(${globals
                                                                        .KG_PCS}.): ',
                                                                    style:
                                                                    titleBoldStyle,
                                                                  ),
                                                                  Padding(
                                                                      padding: EdgeInsets
                                                                          .only(
                                                                          top:
                                                                          2),
                                                                      child:
                                                                      Text(
                                                                        scanRecordList
                                                                            .isNotEmpty
                                                                            ? scanRecordList[index]
                                                                            .qtyKG
                                                                            .toStringAsFixed(
                                                                            2)
                                                                            .toString()
                                                                            : '',
                                                                        style:
                                                                        textNormalStyle,
                                                                      ))
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
//                                                  Padding(
//                                                    padding: EdgeInsets.only(
//                                                        top: 0,
//                                                        left: 10,
//                                                        right: 10),
//                                                    child: Wrap(
//                                                      direction:
//                                                      Axis.horizontal,
//                                                      runAlignment:
//                                                      WrapAlignment.start,
//                                                      children: <Widget>[
//                                                        Text(
//                                                          LocaleUtils.getString(
//                                                              context,
//                                                              "last_dispatch_by"),
//                                                          style: prifixTxtStyle,
//                                                        ),
//                                                        Padding(
//                                                            padding:
//                                                            EdgeInsets.only(
//                                                                top: 2),
//                                                            child: Text(
//                                                              scanRecordList
//                                                                  .isNotEmpty
//                                                                  ? '${scanRecordList[index]
//                                                                  .varLastDispatchBy} ${mUtils
//                                                                  .convertDateTimeDisplay1(
//                                                                  scanRecordList[index]
//                                                                      .dtLastDispatchDate,
//                                                                  displayDateFormat)}'
//                                                                  : '',
//                                                              style: textStyle,
//                                                            ))
//                                                      ],
//                                                    ),
//                                                  ),
                                                      //Divider(color: Colors.black87),
                                                    ],
                                                  ))));
                                    },
                                  ),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                        flex: 1,
                      ),
                      Container(
                        width: screenSize.width,
                        height: 45,
                        margin: const EdgeInsets.all(15),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: reScanButton,
                              flex: 1,
                            ),
                            Container(
                              width: 10,
                            ),
                            Expanded(
                              child: closeButton,
                              flex: 1,
                            ),
                            Container(
                              width: 10,
                            ),
                            Expanded(
                              child: dispatchButton,
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

// ignore: must_be_immutable
class MyForm extends StatefulWidget {
  Size screenSize;
  List<ScanDataModel> listSticker = List();
  List<ScanDataModel> listStickerDisplay = List();

  //final TextEditingController _search_controller =  TextEditingController();
  DispatchThirdScreenState dispatchThirdScreen;

  MyForm(
      {this.screenSize,
      this.listSticker,
      this.listStickerDisplay,
      this.dispatchThirdScreen});

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final TextEditingController searchcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: widget.screenSize.width * 0.9,
          height: widget.screenSize.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: widget.screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(LocaleUtils.getString(context, 'ScannedSerialNo'),
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.centerLeft,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: searchcontroller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey[700]),
                              hintText:
                                  LocaleUtils.getString(context, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                //child: widget.listStickerDisplay.length > 0
                child: widget.listStickerDisplay.isNotEmpty
                    ? Container(
                        child: ListView.builder(
                          itemCount: widget.listStickerDisplay.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return Column(
                              children: <Widget>[
                                Container(
                                  height: 35,
                                  width: widget.screenSize.width,
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                            child: Text(
                                                '#' +
                                                    widget
                                                        .listStickerDisplay[
                                                            index]
                                                        .intRows
                                                        .toString(),
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'helvetica',
                                                    color: widget
                                                            .listStickerDisplay[
                                                                index]
                                                            .chrValid
                                                            .contains('N')
                                                        ? Colors.red
                                                        : Colors.black))),
                                      ),
                                      Expanded(
                                        child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 0),
                                            child: Text(
                                                widget.listStickerDisplay[index]
                                                            .intNoOfSticker >
                                                        0
                                                    ? '${widget.listStickerDisplay[index].varSticker} - (${widget.listStickerDisplay[index].intNoOfSticker})'
                                                    : '${widget.listStickerDisplay[index].varSticker}',
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'helvetica',
                                                    color: widget
                                                            .listStickerDisplay[
                                                                index]
                                                            .chrValid
                                                            .contains('N')
                                                        ? Colors.red
                                                        : Colors.black))),
                                        flex: 3,
                                      ),
                                      Expanded(
                                        child: Align(
                                          child: GestureDetector(
                                            child: Icon(Icons.delete,
                                                color: widget
                                                        .listStickerDisplay[
                                                            index]
                                                        .chrValid
                                                        .contains('N')
                                                    ? Colors.red
                                                    : Colors.black),
                                            onTap: () {
                                              widget.dispatchThirdScreen
                                                  .removeSticker(
                                                  widget
                                                      .listStickerDisplay[index]
                                                      .fk_Customer_DispatchProduct_GLCode,
                                                  widget
                                                      .listStickerDisplay[index]
                                                      .fk_Customer_DispatchGlCode,
                                                  widget
                                                      .listStickerDisplay[index]
                                                      .chrPallet);
                                            },
                                          ),
                                          alignment: Alignment.center,
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: widget.screenSize.width,
                                  color: Colors.black12,
                                  height: 1,
                                ),
                              ],
                            );
                          },
                        ),
                      )
                    : Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              'assets/nodata_icon.png',
                              height: 100,
                              width: 100,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                LocaleUtils.getString(context, 'NoDataFound'),
                                style: prifixTxtStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                flex: 1,
              ),
              Container(
                width: widget.screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(context, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  void filterSearchResults(String query) {
    print(query);
    final List<ScanDataModel> dummySearchList = List<ScanDataModel>();
    dummySearchList.addAll(widget.listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<ScanDataModel> dummyListData = List<ScanDataModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(widget.listSticker);
        });
    }

    print(widget.listStickerDisplay.length);
  }
}
