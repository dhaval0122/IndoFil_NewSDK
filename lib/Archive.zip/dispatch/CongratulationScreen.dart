import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

class CongratulationScreen extends StatefulWidget {
  @override
  CongratulationScreenState createState() => CongratulationScreenState();
}

class CongratulationScreenState extends State<CongratulationScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '', subTitle = '';
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  bool isReceiveScreen = false, isNotification = false, isSync = false;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  String mScreenState,
      topHeaderImage = '';

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();
    _initLoading();
    _battery = EcpSyncPlugin();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    pushNotificationServices = PushNotificationServices(this);

    init();
  }

  void init() async {
    String fullname = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullname != null ? fullname : '';
    }

    String screenState = await sharedPrefs.getString(PREF_SCREEN_STATE);
    mScreenState = screenState;
    if (screenState == TAG_DISPATCH) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/dispatch_icon.png';
    } else if (screenState == TAG_STOCK_TRANSFER) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/stock_transfer_small_top.png';
    } else if (screenState == TAG_SALES_RETURN) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/sidebar_placegoodsreturn.png';
    } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/edit_do_icon.png';
    } else if (screenState == TAG_ADD_DAMAGE_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_REMOVE_DAMAGE_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_RECEIVE) {
      isReceiveScreen = true;
      topHeaderImage = 'assets/receive_icon.png';
    } else if (screenState == TAG_FOC) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/foc_icon.png';
    } else if (screenState == TAG_SCRAP_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/scrap_big.png';
    } else if (screenState == TAG_CONSUME_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/consume_big.png';
    }

    if (subTitle.isEmpty) {
      subTitle = getTitleName(screenState);
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    String userType = await sharedPrefs.getString(PREF_USER_TYPE);
    if (userType.contains('E')) {
      isSync = false;
    } else {
      isSync = true;
    }

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    if (mounted) {
      setState(() {});
    }
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_CONSUME_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_consume');
    } else if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_FOC) {
      return LocaleUtils.getString(mContext, 'tag_foc');
    } else if (tagName == TAG_SCRAP_STOCK) {
      return LocaleUtils.getString(mContext, 'Scrap');
    } else {
      return tagName;
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
              // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void doneBtnCall() {
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        _clickSync(false);
      } else {
        //if(screenState == TAG_RECEIVE){
        final Route route =
            CupertinoPageRoute(builder: (mContext) => Dashboard());
        Navigator.pushAndRemoveUntil(
            context, route, (Route<dynamic> route) => false);
        //} else {
        // Navigator.pop(context);
        //}
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final doneBtn = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonDialogWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Done'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          doneBtnCall();
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          doneBtnCall();
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              doneBtnCall();
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName, subTitle, topHeaderImage, -1),
                      mScreenState == TAG_SCRAP_STOCK ||
                          mScreenState == TAG_CONSUME_STOCK
                          ? Container()
                          : CustomTopSubHeaderBar(
                          SUB_HEADER_CONGRATULATION, isReceiveScreen),
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Image.asset(
                                'assets/congratulations_icon.png',
                                height: 80,
                                width: 80,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Text(
                                    LocaleUtils.getString(
                                        mContext, 'Congratulation'),
                                    style: TextStyle(
                                        fontSize: 25.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'helvetica',
                                        color: const Color(0xFF669900))),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                        LocaleUtils.getString(
                                            mContext, 'URDoingGood'),
                                        style: TextStyle(
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: const Color(0xFF669900))),
                                    Image.asset(
                                      'assets/congratulations_smiley_icon.png',
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                        flex: 1,
                      ),
                      Container(
                        width: screenSize.width,
                        height: 45,
                        //margin: EdgeInsets.all(15),
                        child: doneBtn,
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
