import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/Application.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/setting/ChangePasswordScreen.dart';
import 'package:flutter_basf_hk_app/setting/PrivacyPolicy.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

class SettingModel {
  int fk_PersonGlCode;
  String chrNotification;

  SettingModel({this.fk_PersonGlCode, this.chrNotification});

  SettingModel.fromJson(Map<String, dynamic> json)
      : fk_PersonGlCode = json['fk_PersonGlCode'],
        chrNotification = json['chrNotification'];
}

class SettingScreen extends StatefulWidget {
  @override
  SettingScreenState createState() => SettingScreenState();
}

class SettingScreenState extends State<SettingScreen>
    implements WSInterface, PushNotificationListener {
  static final List<String> languageCodesList =
      application.supportedLanguagesCodes;
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false; //_autoValidate = false,
  //String dropdownValue;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '', doNo;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  bool isSwitched = true, isNotification = false, isSync = false;
  WSPresenter wsPresenter;
  String apiCall = '';
  bool isChangeNotification;
  bool isLanguageChange = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  List<LanguageDetails> languageList;
  bool isLanguageVisible = false;
  LanguageDetails mLanguageDetails;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();
    isChangeNotification = false;
    pushNotificationServices = PushNotificationServices(this);

    languageList = new List();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (screenState == TAG_DISPATCH) {
        topHeaderImage = 'assets/dispatch_icon.png';
      } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        topHeaderImage = 'assets/edit_do_icon.png';
      }

      if (subTitle.isEmpty) {
        if (mounted) {
          setState(() {
            subTitle = getTitleName(screenState);
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getLanguagesRecord();

    _initLoading();

    updateNotificationAPI('', 'GetProfile');

    insertLogDetails();

  }


  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_SET');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void getLanguagesRecord() async {
    if (globals.LANGUAGE == 'Y') {
      isLanguageVisible = true;
    } else {
      isLanguageVisible = false;
    }
    languageList.clear();
    languageList = await databaseHelper.getLanguageMasterAllRecords();

    if (languageList.isNotEmpty) {
      int fkLanguageGlCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);
      String languageCode =
      await databaseHelper.getLanguageCode(fkLanguageGlCode);
      selectDefault(languageCode);

      int langLength = languageList.length;
      for (int i = 0; i < langLength; i++) {
        if (languageList[i].intGlCode == fkLanguageGlCode) {
          mLanguageDetails = languageList[i];
        }
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void _select(LanguageDetails language) async {
    print("=====varLanguageName========" + language.varLanguageName);
    List<String> langTemp = language.varLanguageCode.split('-');
    print('=====langTemp======${langTemp[0]}');
    await sharedPrefs.setInt(PREF_FK_LANGUAGE_GL_CODE, language.intGlCode);
    await sharedPrefs.setString(PREF_LANGUAGE_CODE, language.varLanguageCode);
    await sharedPrefs.setBool(PREF_IS_LANGUAGE_CHANGE, true);
//    await sharedPrefs.setBool(PREF_IS_LOGIN_SCREEN_LANGUAGE, false);
    lang_change = langTemp[0];
    onLocaleChange(Locale(langTemp[0]));
    updateNotificationAPI('', 'GetProfile');
  }

  void selectDefault(String languageCode) {
    print("=====languageCode========$languageCode");
    //lang_change = languagesMap[language];
    List<String> langTemp = languageCode.split('-');
    print('=====langTemp======${langTemp[0]}');
    lang_change = langTemp[0];
    onLocaleChange(Locale(langTemp[0]));
  }

  void onLocaleChange(Locale locale) {
    setState(() {
      //LocaleUtils.load(locale);
      application.onLocaleChanged(locale);
    });
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  /*void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }*/

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                        LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                        LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                        LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
              LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          if (isChangeNotification || isLanguageChange) {
            Navigator.pop(context, true);
          } else {
            Navigator.pop(context, false);
          }
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (isChangeNotification || isLanguageChange) {
                Navigator.pop(context, true);
              } else {
                Navigator.pop(context, false);
              }
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Container(
                        color: const Color(colorAccent),
                        margin: const EdgeInsets.only(top: 20),
                        padding: const EdgeInsets.only(top: 10, bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                  LocaleUtils.getString(mContext, 'Setting'),
                                  style: TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)),
                            ),
                          ],
                        ),
                      ),
                      Card(
                        elevation: 7,
                        margin: const EdgeInsets.only(
                            top: 30, left: 15, right: 15, bottom: 15),
                        child: InkWell(
                            onTap: () {
                              final Route route = CupertinoPageRoute(
                                  builder: (context) => ChangePasswordScreen());
                              Navigator.push(mContext, route);
                            },
                            child: Container(
                              height: 60,
                              padding: const EdgeInsets.only(right: 8),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  ClipRRect(
                                    borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(8.0),
                                        bottomLeft: Radius.circular(8.0)),
                                    child: Container(
                                      height: 60,
                                      width: 8,
                                      color: const Color(colorPrimary),
                                      margin: const EdgeInsets.only(right: 22),
                                    ),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Text(
                                        LocaleUtils.getString(
                                            mContext, 'ChangePwd'),
                                        style: TextStyle(
                                            fontSize: 17.0,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)),
                                  ),
                                  const Expanded(
                                    flex: 0,
                                    child: Icon(Icons.lock,
                                        color: Color(colorPrimary)),
                                  ),
                                ],
                              ),
                            )),
                      ),
                      Card(
                        elevation: 7,
                        margin: const EdgeInsets.all(15),
                        child: Container(
                          height: 60,
                          padding: const EdgeInsets.only(right: 8),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              ClipRRect(
                                borderRadius: const BorderRadius.only(
                                    topLeft: Radius.circular(8.0),
                                    bottomLeft: Radius.circular(8.0)),
                                child: Container(
                                  height: 60,
                                  width: 8,
                                  color: const Color(colorPrimary),
                                  margin: const EdgeInsets.only(right: 22),
                                ),
                              ),
                              Expanded(
                                flex: 1,
                                child: Text(
                                    LocaleUtils.getString(
                                        mContext, 'Notification'),
                                    style: TextStyle(
                                        fontSize: 17.0,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'helvetica',
                                        color: Colors.black)),
                              ),
                              Container(
                                child: Switch(
                                  value: isSwitched,
                                  onChanged: (value) {
                                    setState(() {
                                      isSwitched = value;
                                      isChangeNotification = true;
                                    });

                                    updateNotificationAPI(
                                        isSwitched ? 'Y' : 'N',
                                        'UpdateNotification');
                                    //print('=======isSwitched=======$isSwitched');
                                  },
                                  activeTrackColor: const Color(colorAccent),
                                  activeColor: const Color(colorPrimary),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Card(
                        elevation: 7,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        margin: const EdgeInsets.all(15),
                        child: InkWell(
                          onTap: () {
                            final Route route = CupertinoPageRoute(
                                builder: (context) => PrivacyPolicy());
                            Navigator.push(mContext, route);
                          },
                          child: Container(
                            height: 60,
                            padding: const EdgeInsets.only(right: 15),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                ClipRRect(
                                  borderRadius: const BorderRadius.only(
                                      topLeft: Radius.circular(8.0),
                                      bottomLeft: Radius.circular(8.0)),
                                  child: Container(
                                    height: 60,
                                    width: 8,
                                    color: const Color(colorPrimary),
                                    margin: const EdgeInsets.only(right: 22),
                                  ),
                                ),
                                Expanded(
                                  flex: 1,
                                  child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'PrivacyPolicy'),
                                      style: TextStyle(
                                          fontSize: 17.0,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'helvetica',
                                          color: Colors.black)),
                                ),
                                const Expanded(
                                  flex: 0,
                                  child: Icon(Icons.lock,
                                      color: Color(colorPrimary)),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      isLanguageVisible
                          ? Container(
                        color: const Color(colorAccent),
                        margin: const EdgeInsets.only(top: 20),
                        padding:
                        const EdgeInsets.only(top: 10, bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.only(left: 20),
                              child: Text(
                                  LocaleUtils.getString(
                                      mContext, 'language'),
                                  style: TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'helvetica',
                                      color: Colors.black)),
                            ),
                          ],
                        ),
                      )
                          : Container(),
                      isLanguageVisible
                          ? Padding(
                        padding: const EdgeInsets.all(15),
                        child: Container(
                          height: 42,
                          width: screenSize.width,
                          margin: const EdgeInsets.only(top: 10),
                          padding:
                          const EdgeInsets.fromLTRB(15, 0, 15, 0),
                          decoration: BoxDecoration(
                              border: Border.all(
                                  color: const Color(colorPrimary),
                                  width: 2),
                              borderRadius: _getRadiusDropDown()),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<LanguageDetails>(
                              value: mLanguageDetails,
                              onChanged: (LanguageDetails newValue) {
                                _battery
                                    .checkInternet()
                                    .then((String isConnection) {
                                  if (isConnection.contains('true')) {
                                    isLanguageChange = true;
                                    mLanguageDetails = newValue;
                                    _select(mLanguageDetails);
                                  } else {
                                    showDialog<Map>(
                                      barrierDismissible: false,
                                      context: mContext,
                                      builder: (context) {
                                        return CustomAlertDialog(
                                          content:
                                          LocaleUtils.getString(mContext,
                                              'no_internet_connection'),
                                          title:
                                          PROJECT_NAME == 'BASF_HK'
                                              ? BASF_HK_APP_Name
                                              : Zydus_APP_Name,
                                          isShowNagativeButton: false,
                                          textNagativeButton: '',
                                          textPositiveButton: LocaleUtils
                                              .getString(mContext, 'OK'),
                                          onPressedNegative: () {},
                                          onPressedPositive: () {},
                                        );
                                      },
                                    );
                                  }
                                });
                              },
                              hint: Text(
                                LocaleUtils.getString(
                                    mContext, 'select_language'),
                                style: prifixTxtPrimaryStyle,
                                textAlign: TextAlign.left,
                              ),
                              isExpanded: true,
                              items: languageList != null
                                  ? languageList
                                  .map((LanguageDetails value) {
                                return DropdownMenuItem<
                                    LanguageDetails>(
                                  value: value,
                                  child: Text(
                                    value.varLanguageName,
                                    style: prifixTxtPrimaryStyle,
                                  ),
                                );
                              }).toList()
                                  : List(),
                            ),
                          ),
                        ),
                      )
                          : Container(),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void updateNotificationAPI(String chrNotification, String action) async {
    int fkLanguageCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);

    await _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                param[PARAM_API_TOKEN] = apiToken;
                param['PersonId'] = loginID;
                param[PARAM_DEVICE_ID] = deviceid;
                param['Action'] = action;
                param['Version'] = APP_VERSION;
                param['chrNotification'] = chrNotification;
                param['SubModuleName'] = Platform.isAndroid
                    ? SUB_MODULE_NAME_ANDROID
                    : SUB_MODULE_NAME_IOS;
                param[PARAM_LANGUAGE_ID] = fkLanguageCode.toString() != null
                    ? fkLanguageCode.toString()
                    : '0';
                apiCall = action;
                print(param);
                wsPresenter.callAPI(POST_METHOD, USER_PROFILE_SETTING, param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void loginCall() async {
    int fkLanguageCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);
    await _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
//        _loading = true;
//        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            _battery.getUniqueNumber().then((String syncCode) {
              databaseHelper.getPassword(initGlCode).then((String passEncrypt) {
                sharedPrefs.getString(PREF_USER_ID).then((String _username) {
                  sharedPrefs
                      .getString(PREF_NOTIFICATION_TOKEN)
                      .then((String token) {
                    param[PARAM_USERNAME] = _username.trim();
                    param[PARAM_PASSWORD] = passEncrypt;
                    param[PARAM_FCM_TOKEN] = token;
                    param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                        ? SUB_MODULE_NAME_ANDROID
                        : SUB_MODULE_NAME_IOS;
                    param[PARAM_IS_VERSION_CHECK] = 'Y';
                    param[PARAM_VERSION] = APP_VERSION;
                    param[PARAM_LANGUAGE_ID] = fkLanguageCode.toString() != null
                        ? fkLanguageCode.toString()
                        : '0';
                    sharedPrefs
                        .getString(PREF_DEVICE_ID)
                        .then((String deviceid) {
                      param[PARAM_DEVICE_ID] = deviceid;
                      print(param);
                      apiCall = LOGIN;
                      wsPresenter.callAPI(POST_METHOD, LOGIN, param);
                    });
                  });
                });
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void showNoInternetDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content:
              LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            ));
      },
    );
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) async {
    if (apiCall == LOGIN) {
      _loading = false;
      dismissProgressHUD();
      final dynamic jsonResponse = json.decode(response.toString().trim());
      final LoginResponseModel responseModel =
      LoginResponseModel.fromJson(jsonResponse);
      print(responseModel.Status);
      print(responseModel.Message);

      if (responseModel.Status.contains('1')) {
        /* Success Response. */
        final List<MenuMasterModel> menuMasterList =
            responseModel?.Response?.Menu_Mst;
        if (menuMasterList?.length > 0) {
          await databaseHelper.deleteMenuMaster().then((int id) async {
            await Future.forEach(menuMasterList,
                    (MenuMasterModel menuMasterModel) async {
                  await databaseHelper.insertMenuMaster(menuMasterModel);
                });
          });
        }
      } else if (responseModel.Status.contains('0')) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) {
          databaseHelper.updateUserLockPersonMaster(initGlCode).then((int id) {
            showDialog<Map>(
              barrierDismissible: false,
              context: mContext,
              builder: (context) {
                return CustomAlertDialog(
                  content: LocaleUtils.getString(mContext, 'Session_warning'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    final Route route =
                    CupertinoPageRoute(builder: (context) => Dashboard());
                    Navigator.pushAndRemoveUntil(
                        context, route, (Route<dynamic> route) => false);
                  },
                );
              },
            );
          });
        });
      } else if (responseModel.Status.contains('9')) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) {
          databaseHelper.updateUserLockPersonMaster(initGlCode).then((int id) {
            showDialog<Map>(
              barrierDismissible: false,
              context: mContext,
              builder: (context) {
                return CustomAlertDialog(
                  content: responseModel.Message,
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    final Route route =
                    CupertinoPageRoute(builder: (context) => Dashboard());
                    Navigator.pushAndRemoveUntil(
                        context, route, (Route<dynamic> route) => false);
                  },
                );
              },
            );
          });
        });
      }
    } else {
      final dynamic jsonResponse = json.decode(response.toString().trim());
      final GeneralResponseModel responseModel =
      GeneralResponseModel.fromJsonStatus(jsonResponse);

      print(responseModel.Status);
      print(responseModel.Message);

      if (responseModel.Status.contains('1')) {
        if (apiCall == 'GetProfile') {
          if (responseModel
              .getSettingsModelList()[0]
              .chrNotification
              .contains('Y')) {
            await sharedPrefs.setBool(IS_NOTIFICATION, true);
            if (mounted) {
              setState(() {
                isSwitched = true;
                isNotification = isSwitched;
              });
            }
          } else {
            await sharedPrefs.setBool(IS_NOTIFICATION, false);
            if (mounted) {
              setState(() {
                isSwitched = false;
                isNotification = isSwitched;
              });
            }
          }

          bool isChange = await sharedPrefs.getBool(PREF_IS_LANGUAGE_CHANGE);
          if (isChange) {
            loginCall();
          } else {
            _loading = false;
            dismissProgressHUD();
          }
        } else {
          _loading = false;
          dismissProgressHUD();
          await sharedPrefs.setBool(IS_NOTIFICATION, isSwitched);
          if (mounted) {
            setState(() {
              isNotification = isSwitched;
            });
          }
        }
      } else if (responseModel.Status.contains('2')) {
        _loading = false;
        dismissProgressHUD();
        await showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content: LocaleUtils.getString(mContext, 'Session_warning'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    final Route route =
                    CupertinoPageRoute(builder: (context) => Dashboard());
                    Navigator.pushAndRemoveUntil(
                        context, route, (Route<dynamic> route) => false);
                  },
                ));
          },
        );
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
