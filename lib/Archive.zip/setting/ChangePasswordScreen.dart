import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/ForgotResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/dimens.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

const SUCCESS = 'Success', FAIL = 'Fail';

class ChangePasswordScreen extends StatefulWidget {
  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

const PASSWORD_PATTERN =
    '(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@%^&*-]).{8,}';

class _ChangePasswordScreenState extends State<ChangePasswordScreen>
    implements WSInterface, PushNotificationListener {
  _ChangePasswordScreenState() {
    wsPresenter = WSPresenter(this);
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _autoValidate = false,
      _loading = false; // _isLoginButtonDisable = false;
  bool _obscureOldPassText = true,
      _obscureNewPassText = true,
      _obscureConfirmPassText = true,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String oldPassword, newPassword, confirmPassword;
  Utils mUtils;
  SharedPrefs sharedPrefs;
  WSPresenter wsPresenter;
  ProgressHUD _progressHUD;
  EcpSyncPlugin _battery;
  DatabaseHelper databaseHelper;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  RegExp regExp = RegExp(
    PASSWORD_PATTERN,
    caseSensitive: true,
    multiLine: false,
  );

  BuildContext mContext;

  // Toggles the password show status
  void _toggleOldPassword() {
    if (mounted) {
      setState(() {
        _obscureOldPassText = !_obscureOldPassText;
      });
    }
  }

  void _toggleNewPassword() {
    if (mounted) {
      setState(() {
        _obscureNewPassText = !_obscureNewPassText;
      });
    }
  }

  void _toggleConfirmPassword() {
    if (mounted) {
      setState(() {
        _obscureConfirmPassText = !_obscureConfirmPassText;
      });
    }
  }

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void _changePasswordnCall() async {
    FocusScope.of(context).requestFocus(FocusNode());

    int fkLanguageCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);

    await _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          sharedPrefs.getString(PREF_USER_ID).then((String userID) {
            _battery.getUniqueNumber().then((String syncCode) {
              mUtils
                  .encryptPassword(oldPassword, syncCode)
                  .then((String oldPass) {
                mUtils
                    .encryptPassword(newPassword, syncCode)
                    .then((String newPass) {
                  var param = Map();
                  param[PARAM_USERNAME] = userID;
                  param[PARAM_OLD_PASSWORD] = oldPass;
                  param[PARAM_NEW_PASSWORD] = newPass;
                  param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                      ? SUB_MODULE_NAME_ANDROID
                      : SUB_MODULE_NAME_IOS;
                  param[PARAM_VERSION] = APP_VERSION;
                  param[PARAM_LANGUAGE_ID] = fkLanguageCode.toString() != null
                      ? fkLanguageCode.toString()
                      : '0';
                  sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                    param[PARAM_DEVICE_ID] = deviceid;
                    print(param);
                    wsPresenter.callAPI(POST_METHOD, CHANGE_PASSWORD, param);
                  });
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void _showSnackBar(String text) {
    scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void backNavigationPage() {
    Navigator.of(context).pop();
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (oldPassword != newPassword) {
        if (newPassword == confirmPassword) {
          if (regExp.hasMatch(newPassword)) {
            _changePasswordnCall();
          } else {
            _showSnackBar(LocaleUtils.getString(
                context, 'password_must_be_at_least_8_character'));
          }
        } else {
          _showSnackBar(
              LocaleUtils.getString(context, 'new_password_does_not_match'));
        }
      } else {
        _showSnackBar(LocaleUtils.getString(
            context, 'your_old_and_new_password_can_not_be_same'));
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    _battery = EcpSyncPlugin();
    databaseHelper = DatabaseHelper.get();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

//    try {
//      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
//        final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
//        _firebaseMessaging.configure(
//          onMessage: (Map<String, dynamic> message) async {
//            print('onMessage: $message');
//            //_showItemDialog(message);
//            if (message.containsKey('notification')) {
//              final PushNotificationModel items =
//                  PushNotificationModel.fromMap(message);
//              print('======notification======={$items}');
//              await pushNotificationServices.showNotification(
//                  items.title, items.body);
//            }
//          },
//          onLaunch: (Map<String, dynamic> message) async {
//            print('onLaunch: $message');
//            //_navigateToItemDetail(message);
//          },
//          onResume: (Map<String, dynamic> message) async {
//            print('onResume: $message');
//            //_navigateToItemDetail(message);
//          },
//        );
//        _firebaseMessaging.requestNotificationPermissions(
//            const IosNotificationSettings(
//                sound: true, badge: true, alert: true));
//        _firebaseMessaging.onIosSettingsRegistered
//            .listen((IosNotificationSettings settings) {
//          print('Settings registered: $settings');
//        });
//        _firebaseMessaging.getToken().then((String token) {
//          assert(token != null);
//          /*setState(() {
//        String _homeScreenText = 'Push Messaging token: $token';
//        print(_homeScreenText);
//      });*/
//          //print(_homeScreenText);
//        });
//      }
//    } catch (e) {
//      print(e);
//    }

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    _initLoading();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final oldPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      validator: (String arg) {
        //if (arg.length < 1)
        if (arg.isEmpty)
          return LocaleUtils.getString(
              context, 'please_enter_your_old_password');
        else
          return null;
      },
      onSaved: (String val) {
        oldPassword = val;
      },
      obscureText: _obscureOldPassText,
      style: prifixTxtStyle,
      maxLines: 1,
      maxLength: EditTxtMaxLengths,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 'old_password'),
        counterText: '',
        fillColor: Colors.white,
        filled: true,
        contentPadding: const EdgeInsets.fromLTRB(p_15, p_15, 0, 0),
        errorStyle: errorStyle,
        suffixIcon: IconButton(
            icon: Icon(
              _obscureOldPassText ? Icons.visibility_off : Icons.visibility,
              color: const Color(colorPrimary),
            ),
            onPressed: _toggleOldPassword),
        hintStyle: TextStyle(color: Colors.grey[700]),
        border: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
        enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
      ),
    );

    final newPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      /*validator: (val) => val.length < 6 ? 'Password too short.' : null,
      onSaved: (val) => _password = val,*/
      validator: (String arg) {
        //if (arg.length < 1) {
        if (arg.isEmpty) {
          return LocaleUtils.getString(
              context, 'please_enter_your_new_password');
        } else {
          return null;
        }
      },
      onSaved: (String val) {
        newPassword = val;
      },
      obscureText: _obscureNewPassText,
      style: prifixTxtStyle,
      maxLines: 1,
      maxLength: EditTxtMaxLengths,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 'new_password'),
        counterText: '',
        fillColor: Colors.white,
        filled: true,
        contentPadding: const EdgeInsets.fromLTRB(p_15, p_15, 0, 0),
        errorStyle: errorStyle,
        suffixIcon: IconButton(
            icon: Icon(
              _obscureNewPassText ? Icons.visibility_off : Icons.visibility,
              color: const Color(colorPrimary),
            ),
            onPressed: _toggleNewPassword),
        hintStyle: TextStyle(color: Colors.grey[700]),
        border: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
        enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
      ),
    );

    final confirmPasswordTxt = TextFormField(
      keyboardType: TextInputType.text,
      //enableInteractiveSelection: false,
      textInputAction: TextInputAction.next,
      autofocus: false,
      autocorrect: false,
      validator: (String arg) {
        //if (arg.length < 1) {
        if (arg.isEmpty) {
          return LocaleUtils.getString(
              context, 'please_enter_your_confirm_password');
        } else {
          return null;
        }
      },
      onSaved: (String val) {
        confirmPassword = val;
      },
      obscureText: _obscureConfirmPassText,
      style: prifixTxtStyle,
      maxLines: 1,
      maxLength: EditTxtMaxLengths,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 're_enter_password'),
        counterText: '',
        fillColor: Colors.white,
        filled: true,
        contentPadding: const EdgeInsets.fromLTRB(p_15, p_15, 0, 0),
        errorStyle: errorStyle,
        suffixIcon: IconButton(
            icon: Icon(
              _obscureConfirmPassText ? Icons.visibility_off : Icons.visibility,
              color: const Color(colorPrimary),
            ),
            onPressed: _toggleConfirmPassword),
        hintStyle: TextStyle(color: Colors.grey[700]),
        border: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
        enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: const Color(colorPrimary), width: 2)),
      ),
    );

    return Scaffold(
        appBar: CustomAppbar(
          isShowNotification: isNotification,
          isShowSync: isSync,
          isShowHomeIcon: true,
          mContext: context,
          notificationCount: notificationCount,
          databaseHelper: databaseHelper,
          syncPlugin: _battery,
          onBackPress: () {
            Navigator.pop(context, false);
          },
        ).appBar(),
        key: scaffoldKey,
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              Container(
                width: screenSize.width,
                height: screenSize.height,
                decoration: const BoxDecoration(color: Color(bgColor)),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    Container(
                      color: const Color(colorAccent),
                      margin: const EdgeInsets.only(top: 20),
                      height: 40,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(left: 20),
                            child: Text(
                                LocaleUtils.getString(
                                    context, 'ChangePassword'),
                                style: TextStyle(
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'helvetica',
                                    color: Colors.black)),
                          ),
                        ],
                      ),
                    ),
                    /*Expanded(
                      child: Form(
                        child:  Container(
                          child:  Column(
                            children: <Widget>[
                              Padding(
                                padding: EdgeInsets.only(top: p_15),
                                child: oldPasswordTxt,
                              ),
                              Padding(
                                padding: EdgeInsets.only(top: p_15),
                                child: newPasswordTxt,
                              ),
                              Padding(
                                padding: EdgeInsets.only(top: p_15),
                                child: confirmPasswordTxt,
                              ),
                              Expanded(
                                flex: 1,
                                child: Container(),
                              ),
                              Container(
                                width: screenSize.width,
                                height: 45,
                                child:  ButtonWidgets(
                                  buttonName: 'Change Password',
                                  buttonColor: const Color(colorPrimary),
                                  textColor: Colors.white,
                                  onTap: _isLoginButtonDisable
                                      ? null
                                      : _validateInputs,
                                ),
                                margin: EdgeInsets.only(top: p_15),
                              ),
                            ],
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          padding: EdgeInsets.fromLTRB(p_25, p_40, p_25, p_40),
                          alignment: Alignment.topLeft,
                        ),
                        autovalidate: _autoValidate,
                        key: _formKey,
                      ),
                      flex: 1,
                    ),*/

                    Expanded(
                      child: Container(
                        child: SingleChildScrollView(
                          child: Form(
                            child: Container(
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Padding(
                                    padding: const EdgeInsets.only(top: p_15),
                                    child: oldPasswordTxt,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: p_15),
                                    child: newPasswordTxt,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: p_15),
                                    child: confirmPasswordTxt,
                                  ),
                                  /*Expanded(
                                  flex: 1,
                                  child: Container(),
                                ),*/
                                  Container(
                                    width: screenSize.width,
                                    height: 45,
                                    child: ButtonWidgets(
                                      buttonName: LocaleUtils.getString(
                                          context, 'ChangePassword'),
                                      buttonColor: const Color(colorPrimary),
                                      textColor: Colors.white,
                                      onTap: _validateInputs,
                                    ),
                                    margin: const EdgeInsets.only(top: 25),
                                  ),
                                ],
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                              ),
                              padding: const EdgeInsets.fromLTRB(
                                  p_25, p_40, p_25, p_40),
                              alignment: Alignment.topLeft,
                            ),
                            autovalidate: _autoValidate,
                            key: _formKey,
                          ),
                          scrollDirection: Axis.vertical,
                          physics: const AlwaysScrollableScrollPhysics(),
                        ),
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
              _progressHUD,
            ],
          ),
        ));
//        child:
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();

    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content: errorTxt,
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(context, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            ));
      },
    );
    //_showErrorAlert(APP_Name, errorTxt, FAIL, '', 'OK', false);
  }

  @override
  void onLoginSuccess(String response) {
    _loading = false;
    dismissProgressHUD();

    print(response);
    /*final dynamic jsonResponse = json.decode(response.toString().trim());
    FirstTimeChangePassResponseModel responseModel =
        FirstTimeChangePassResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);*/

    final dynamic jsonResponse = json.decode(response.toString().trim());
    final ForgotResponseModel responseModel =
        ForgotResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      /* Success Response. */
      /*sharedPrefs.setString(PREF_USER_ID, '').then((bool isGender) {
        navigationPage();
      });*/

      final List<ForgotResponseDataModel> forgotList = responseModel.Response;
      String newPassword = '';
      //if (forgotList?.length > 0) {
      if (forgotList.isNotEmpty) {
        newPassword = forgotList[0].varPassword;
      }
      updatePasswordPersonMaster(newPassword, responseModel.Message);
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  final Route route =
                      CupertinoPageRoute(builder: (context) => Dashboard());
                  Navigator.pushAndRemoveUntil(
                      context, route, (Route<dynamic> route) => false);
                },
              ));
        },
      );
    } else {
      /* Show error dialog. */
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {},
              ));
        },
      );
      //_showErrorAlert(APP_Name, responseModel.Message, FAIL, '', 'OK', false);
    }
  }

  void updatePasswordPersonMaster(String password, String message) {
    sharedPrefs.getString(PREF_USER_ID).then((String userID) {
      databaseHelper
          .updatePasswordPersonMaster(password, userID)
          .then((int id) {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content: message,
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(context, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {
                    navigationPage();
                  },
                ));
          },
        );
      });
    });
  }

  void navigationPage() {
    Navigator.of(context).pop();
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
