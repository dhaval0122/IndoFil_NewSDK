import 'dart:async';
import 'dart:convert';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Login.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/AgreementResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String SUCCESS = 'Success', FAIL = 'Fail', ERROR = 'Error';
const String CHECK_AGREE = 'CheckAgree', AGREE = 'Agree';

class PrivacyPolicy extends StatefulWidget {
  @override
  _PrivacyPolicyState createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy>
    implements WSInterface, PushNotificationListener {
  _PrivacyPolicyState() {
    wsPresenter = WSPresenter(this);
  }


  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _loading = false,
      isNotification = false,
      isSync = false; //_isLoginButtonDisable = false,
  Size screenSize;
  String agreementURL = '';
  Utils mUtils;
  SharedPrefs sharedPrefs;
  WSPresenter wsPresenter;
  ProgressHUD _progressHUD;
  DatabaseHelper databaseHelper;
  String API_CALLING_STATUS = '';
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  BuildContext mContext;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  /*void _agreementPolicyCall(String action) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();
        Future.delayed(const Duration(milliseconds: 1000), () {
          var param = Map();
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String userID) {
            param[PARAM_PERSON_ID] = userID;
            param[PARAM_AGREE_FORM] = 'AND';
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;
            param[PARAM_ACTION] = action;
            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                param[PARAM_API_TOKEN] = apiToken;
                param[PARAM_DEVICE_ID] = deviceid;
                print(param);
                API_CALLING_STATUS = action;
                wsPresenter.callAPI(POST_METHOD, APPLICATION_AGREEMENT, param);
              });
            });
          });
        });
      } else {
        //_showSnackBar('No Internet Connection');
        _showErrorAlert(
            APP_Name,
            LocaleUtils.getString(context, 'no_internet_connection'),
            FAIL,
            '',
            LocaleUtils.getString(context, 'OK'),
            false);
      }
    });
  }*/

  void redirectToDashboard() {
    final Route route = CupertinoPageRoute(builder: (context) => Dashboard());
    Navigator.pushReplacement(mContext, route);
  }

  /*void _validateInputs() {
    _agreementPolicyCall(AGREE);
  }*/

  void _showErrorAlert(
      String title,
      String content,
      String passFlag,
      String textNagativeButton,
      String textPositiveButton,
      bool isShowNagativeButton) {
    showDialog<Map>(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content: content,
              title: title,
              isShowNagativeButton: isShowNagativeButton,
              textNagativeButton: textNagativeButton,
              textPositiveButton: textPositiveButton,
              onPressedNegative: () {
                onDialogNagativeButton(passFlag);
              },
              onPressedPositive: () {
                onDialogPositiveButton(passFlag);
              },
            ));
      },
    );
  }

  void onDialogNagativeButton(String passFlag) {
    //print('==========onDialogNagativeButton============$passFlag');
    if (passFlag.contains(SUCCESS)) {
    } else if (passFlag.contains(FAIL)) {
    } else if (passFlag == ERROR) {
    } else {}
  }

  void onDialogPositiveButton(String passFlag) {
    //print('==========onDialogPositiveButton============$passFlag');
    if (passFlag.contains(SUCCESS)) {
    } else if (passFlag.contains(FAIL)) {
    } else if (passFlag == ERROR) {
      // call check agreement API
    } else {}
  }

  @override
  void initState() {
    super.initState();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    _battery = EcpSyncPlugin();
    databaseHelper = DatabaseHelper.get();
    pushNotificationServices = PushNotificationServices(this);
    _initLoading();

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

//    try {
//      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
//        final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
//        _firebaseMessaging.configure(
//          onMessage: (Map<String, dynamic> message) async {
//            //print('onMessage: $message');
//            //_showItemDialog(message);
//            if (message.containsKey('notification')) {
//              final PushNotificationModel items =
//                  PushNotificationModel.fromMap(message);
//              //print('======notification======={$items}');
//              await pushNotificationServices.showNotification(
//                  items.title, items.body);
//            }
//          },
//          onLaunch: (Map<String, dynamic> message) async {
//            //print('onLaunch: $message');
//            //_navigateToItemDetail(message);
//          },
//          onResume: (Map<String, dynamic> message) async {
//            //print('onResume: $message');
//            //_navigateToItemDetail(message);
//          },
//        );
//        _firebaseMessaging.requestNotificationPermissions(
//            const IosNotificationSettings(
//                sound: true, badge: true, alert: true));
//        _firebaseMessaging.onIosSettingsRegistered
//            .listen((IosNotificationSettings settings) {
//          print('Settings registered: $settings');
//        });
//        _firebaseMessaging.getToken().then((String token) {
//          assert(token != null);
//          /*setState(() {
//        String _homeScreenText = 'Push Messaging token: $token';
//        print(_homeScreenText);
//      });*/
//          //print(_homeScreenText);
//        });
//      }
//    } catch (e) {
//      print(e);
//    }

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    agreementURL =
        'https://basf-dlite3-fulfil.ecubix.com/CC/PrivacyPolicy.html';
    //_agreementPolicyCall('https://basf-dlite3-fulfil.ecubix.com/CC/PrivacyPolicy.html');
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          // _isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          // _isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  void updateSyncFlag(bool flag) {
    //print(flag);
    if (mounted) {
      setState(() {
        isSyncClick = flag;
      });
    }
  }

  bool isSyncClick = false;
  num _stackToView = 1;

  void _handleLoad(String value) {
    setState(() {
      _stackToView = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    //print('====agreementURL===$agreementURL');

    return MyCustomScaffold(
        appBar: CustomAppbar(
          isShowNotification: isNotification,
          isShowSync: isSync,
          isShowHomeIcon: true,
          mContext: context,
          notificationCount: notificationCount,
          databaseHelper: databaseHelper,
          syncPlugin: _battery,
          onBackPress: () {
            Navigator.pop(context, false);
          },
        ).appBar(),
        key: _key,
        body: SafeArea(
            child: IndexedStack(
          index: _stackToView,
          children: [
            Column(
              children: <Widget>[
                Expanded(
                    child: WebView(
                  //key: _key,
                  javascriptMode: JavascriptMode.unrestricted,
                  initialUrl: agreementURL,
                  onPageFinished: _handleLoad,
                )),
              ],
            ),
            Container(
              color: Colors.white,
              child: Center(
                  child: const CircularProgressIndicator(
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Color(colorPrimary)))),
            ),
          ],
        )
            /*child: Stack(
          children: <Widget>[
            Visibility(
              child: Container(
                child: WebviewScaffold(
                  url: agreementURL,
                  withZoom: false,
                  withLocalStorage: false,
                  hidden: true,
                  withJavascript: true,
                  initialChild: Container(
                    color: Colors.white,
                    child: const Center(
                      child: Text('Waiting.....',
                          style: TextStyle(
                              fontSize: 18.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'helvetica',
                              color: Colors.white)),
                    ),
                  ),
                ),
              ),
              visible: isSyncClick ? false : true,
            ),
            _progressHUD
          ],
        ),*/
            ));
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();

    _showErrorAlert(PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name, errorTxt, ERROR, '',
        LocaleUtils.getString(mContext, 'OK'), true);
  }

  void logout() {
    final Future<String> usernameTemp = sharedPrefs.getString(PREF_USER_NAME);
    final Future<String> passwordTemp = sharedPrefs.getString(PREF_PASSWORD);
    sharedPrefs.clearPrefs().then((bool flag) {
      if (flag) {
        usernameTemp.then((String uname) {
          passwordTemp.then((String pwd) {
            sharedPrefs.setString(PREF_USER_NAME, uname).then((bool flag1) {
              sharedPrefs.setString(PREF_PASSWORD, pwd).then((bool flag2) {
                final Route route =
                    CupertinoPageRoute(builder: (context) => Login());
                Navigator.pushAndRemoveUntil(
                    context, route, (Route<dynamic> route) => false);
              });
            });
          });
        });
      }
    });
  }

  @override
  void onLoginSuccess(String response) {
    _loading = false;
    dismissProgressHUD();

    print(response);
    final dynamic jsonResponse = json.decode(response.toString().trim());
    final AgreementResponseModel responseModel =
        AgreementResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    try {
      if (API_CALLING_STATUS == CHECK_AGREE) {
        if (responseModel.Status.contains('1')) {
          redirectToDashboard();
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return WillPopScope(
                  onWillPop: () {},
                  child: CustomAlertDialog(
                    content: LocaleUtils.getString(mContext, 'Session_warning'),
                    title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                    isShowNagativeButton: false,
                    textNagativeButton: '',
                    textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                    onPressedNegative: () {},
                    onPressedPositive: () {
                      final Route route =
                          CupertinoPageRoute(builder: (context) => Dashboard());
                      Navigator.pushAndRemoveUntil(
                          context, route, (Route<dynamic> route) => false);
                    },
                  ));
            },
          );
        } else {
          /*if (mounted) {
            setState(() {
              agreementURL = responseModel.Message.trim();
              print('====agreementURL===$agreementURL');
            });
          }*/
        }
      } else if (API_CALLING_STATUS == AGREE) {
        if (responseModel.Status.contains('1')) {
          sharedPrefs.setBool(IS_AGREEMENT_POLICY, false);
          redirectToDashboard();
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return WillPopScope(
                  onWillPop: () {},
                  child: CustomAlertDialog(
                    content: LocaleUtils.getString(mContext, 'Session_warning'),
                    title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                    isShowNagativeButton: false,
                    textNagativeButton: '',
                    textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                    onPressedNegative: () {},
                    onPressedPositive: () {
                      final Route route =
                          CupertinoPageRoute(builder: (context) => Dashboard());
                      Navigator.pushAndRemoveUntil(
                          context, route, (Route<dynamic> route) => false);
                    },
                  ));
            },
          );
        } else {
          _showErrorAlert(PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name, responseModel.Message, FAIL, '',
              LocaleUtils.getString(mContext, 'OK'), false);
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
