import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';

class KnowYourBoxModel {
  String varType;
  String dtDate;
  String varName;

  String varColor;
  String varStatus;
  String varSticker;
  String chrStatus;
  int fk_StickerGlCode;
  bool isDelete = false;

  KnowYourBoxModel(
      {this.varType,
      this.dtDate,
      this.varName,
      this.varStatus,
      this.varSticker,
      this.chrStatus,
      this.fk_StickerGlCode,
      this.varColor});

  KnowYourBoxModel.fromJson(Map<String, dynamic> json)
      : varType = json['varType'],
        dtDate = json['dtDate'],
        varName = json['varName'],
        varStatus = json.containsKey('varStatus') ? json['varStatus'] : '',
        varSticker = json.containsKey('varSticker') ? json['varSticker'] : '',
        chrStatus = json.containsKey('chrStatus') ? json['chrStatus'] : '',
        fk_StickerGlCode =
            json.containsKey('fk_StickerGlCode') ? json['fk_StickerGlCode'] : 0,
        varColor = json.containsKey('varColor') ? json['varColor'] : '#000000';
}

class KnowYourBoxScreen extends StatefulWidget {
  final String stickerNo;

  KnowYourBoxScreen({this.stickerNo});

  @override
  KnowYourBoxScreenState createState() => KnowYourBoxScreenState();
}

class KnowYourBoxScreenState extends State<KnowYourBoxScreen>
    implements WSInterface, PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false, _loading = false;
  String dropdownValue;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '';
  int receiveCount = 0;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  List<KnowYourBoxModel> scanDataList;
  TextEditingController serialNoTextController;

//  final FocusNode _serialNoFocus = FocusNode();
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false, isNotification = false, isSync = false;

  //bool isSaveClickEnable = true;
  String menufacturer = '';
  WSPresenter wsPresenter;
  String enteredSticker = '';
  String message = '';
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    wsPresenter = WSPresenter(this);

    scanDataList = List();
    _battery = EcpSyncPlugin();
    mUtils = Utils();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    serialNoTextController = TextEditingController();

    init();
  }

  void init() async {
    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullname = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullname != null ? fullname : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    String userType = await sharedPrefs.getString(PREF_USER_TYPE);
    if (userType.contains('E')) {
      isSync = false;
    } else {
      isSync = true;
    }

    String screenState = await sharedPrefs.getString(PREF_SCREEN_STATE);
    if (screenState == TAG_DISPATCH) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/dispatch_icon.png';
    } else if (screenState == TAG_STOCK_TRANSFER) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/stock_transfer_small_top.png';
    } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/edit_do_icon.png';
    } else if (screenState == TAG_ADD_DAMAGE_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_REMOVE_DAMAGE_STOCK) {
      isReceiveScreen = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_RECEIVE) {
      isReceiveScreen = true;
      topHeaderImage = 'assets/receive_icon.png';
    } else if (screenState == TAG_KNOW_YOUR_BOX) {
      isReceiveScreen = true;
      topHeaderImage = 'assets/know_your_box_icon.png';
    }

    if (subTitle.isEmpty) {
      subTitle = getTitleName(screenState);
    }

    receiveCount = await sharedPrefs.getInt(PREF_RECEIVE_COUNT);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) {
      try {
        if (state['type'] == '11') {
          var detailsData = state['Details'];
          final dynamic lists = json.decode(detailsData);
          if (lists.length > 0) {
            for (var i = 0; i < lists.length; i++) {
              if (lists[i].toString().trim().isNotEmpty) {
                List<String> code = lists[i].toString().split("/");
                if (code.length > 1) {
                  enteredSticker = code[0].toString();
                } else {
                  enteredSticker = lists[i].toString();
                }
                break;
              }
            }
            checkSticker(false);
          }
        }
      } catch (e) {
        print(e.toString());
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await insertLogDetails();

    await _battery.hideKeyboardPlugin();

    if (widget.stickerNo.isNotEmpty) {
      checkSticker(false);
    }

    //serialNoTextController.text = widget.stickerNo;

    if (mounted) {
      setState(() {});
    }
  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
        await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
        await databaseHelper.getSelectedMenuDetails('DEV_TNT_KYB');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode =
        await databaseHelper.getSyncCodeFromLoginDetails(int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  void _onTextChanged() {
    final String value = serialNoTextController.text ?? '';
    if (value.isNotEmpty) {
      if (value.length >= int.parse(globals.BARCODE_LENGTH)) {
        _battery.checkBarCode(value).then((String serialNo) {
          if (serialNo.isNotEmpty) {
            List<String> code = serialNo.split("/");
            if (code.length > 1) {
              enteredSticker = code[0].toString();
            } else {
              enteredSticker = serialNo;
            }
            //enteredSticker = serialNo;
            serialNoTextController.text = '';
            checkSticker(true);
          }
        });
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(context).requestFocus(FocusNode());

        if (serialNoTextController.text.isNotEmpty) {
          List<String> code = serialNoTextController.text.split("/");
          if (code.length > 1) {
            enteredSticker = code[0].toString();
          } else {
            enteredSticker = serialNoTextController.text;
          }
          serialNoTextController.text = '';
          checkSticker(true);
        }
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
            'true',
            'true',
            'false',
            '#004a96',
            PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
            LocaleUtils.getString(mContext, 'next'),
            PROJECT_NAME == 'BASF_HK'
                ? LocaleUtils.getString(mContext, 'scan_your_label_here')
                : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'EnterSrNumber'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final scanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'StartScan'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: startScanBtnCall,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(
                          userName, subTitle, topHeaderImage, receiveCount),
                      widget.stickerNo.isEmpty
                          ? Container(
                              margin: const EdgeInsets.only(top: 20),
                              child: Align(
                                alignment: Alignment.topCenter,
                                child: scanButton,
                              ),
                            )
                          : Container(),
                      widget.stickerNo.isEmpty
                          ? Container(
                              margin: const EdgeInsets.only(
                                  top: 20, right: 15, left: 15),
                              child: Stack(
                                alignment: Alignment.center,
                                children: <Widget>[
                                  const Divider(
                                      height: 1, color: Colors.black54),
                                  Container(
                                    height: 28,
                                    width: 50,
                                    alignment: Alignment.center,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary),
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(5))),
                                    child: Text(
                                      LocaleUtils.getString(mContext, 'OR'),
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w300,
                                        fontFamily: 'helvetica',
                                        color: Colors.white70,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Container(),
                      widget.stickerNo.isEmpty
                          ? Container(
                              margin: const EdgeInsets.only(
                                  top: 20, right: 20, left: 20),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Expanded(
                                    flex: 1,
                                    child: Form(
                                      key: _formKey,
                                      autovalidate: _autoValidate,
                                      child: Container(
                                        height: 42,
                                        width: screenSize.width,
                                        padding: const EdgeInsets.fromLTRB(
                                            15, 0, 15, 0),
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                              color: const Color(colorPrimary),
                                              width: 2),
                                          borderRadius: _getRadiusDropDown(),
                                        ),
                                        child: serialNumberTxt,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(left: 15),
                                    width: 50,
                                    child: addButton,
                                  ),
                                ],
                              ),
                            )
                          : Container(),
                      Expanded(
                        child: Container(
                          child: Card(
                            elevation: 7,
                            margin: const EdgeInsets.only(
                                top: 10, right: 15, left: 15, bottom: 10),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: <Widget>[
                                Container(
                                  padding: const EdgeInsets.only(
                                      top: 15, bottom: 15),
                                  alignment: Alignment.center,
                                  child: Column(children: <Widget>[
                                    Text(
                                      LocaleUtils.getString(
                                          mContext, 'ScannedSerialNo'),
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'helvetica',
                                        color: const Color(colorPrimary),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Visibility(
                                        child: Text(
                                          widget.stickerNo.isNotEmpty
                                              ? widget.stickerNo
                                              : enteredSticker,
                                          style: TextStyle(
                                            fontSize: 13.0,
                                            fontWeight: FontWeight.w300,
                                            fontFamily: 'helvetica',
                                            color: Colors.black,
                                          ),
                                        ),
                                        visible:
                                            //scanDataList.length > 0 ? true : false,
                                            scanDataList.isNotEmpty
                                                ? true
                                                : false,
                                      ),
                                    ),
                                  ]),
                                ),
                                Container(
                                  margin: const EdgeInsets.only(
                                      left: 20, right: 20),
                                  child: const Divider(color: Colors.black54),
                                ),
                                Expanded(
                                  child: Container(
                                    //child: scanDataList.length > 0
                                    child: scanDataList.isNotEmpty
                                        ? ListView.builder(
                                            itemCount: scanDataList.length,
                                            shrinkWrap: true,
                                            itemBuilder: (BuildContext context,
                                                int index) {
                                              return Column(
                                                children: <Widget>[
                                                  Container(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            left: 20,
                                                            right: 20,
                                                            top: 10,
                                                            bottom: 10),
                                                    width: screenSize.width,
                                                    child: Row(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                      children: <Widget>[
                                                        Container(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(10.0),
                                                          decoration:
                                                              const BoxDecoration(
                                                            shape:
                                                                BoxShape.circle,
                                                            color: Color(
                                                                colorPrimary),
                                                          ),
                                                        ),
                                                        Expanded(
                                                          child: Padding(
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .end,
                                                                children: <
                                                                    Widget>[
                                                                  Text(
                                                                    scanDataList[index].varType !=
                                                                            null
                                                                        ? scanDataList[index]
                                                                            .varType
                                                                        : "",
                                                                    style:
                                                                        TextStyle(
                                                                      fontSize:
                                                                          14.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w600,
                                                                      fontFamily:
                                                                          'helvetica',
                                                                      color: const Color(
                                                                          colorPrimary),
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        top: 5),
                                                                    child: Text(
                                                                      scanDataList[index].varName !=
                                                                              null
                                                                          ? scanDataList[index]
                                                                              .varName
                                                                          : "",
                                                                      style:
                                                                          TextStyle(
                                                                        fontSize:
                                                                            13.0,
                                                                        fontWeight:
                                                                            FontWeight.w500,
                                                                        fontFamily:
                                                                            'helvetica',
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Padding(
                                                                    padding: const EdgeInsets
                                                                            .only(
                                                                        top: 5),
                                                                    child: Text(
                                                                      scanDataList[index].dtDate !=
                                                                              null
                                                                          ? scanDataList[index]
                                                                              .dtDate
                                                                          : "",
                                                                      style:
                                                                          TextStyle(
                                                                        fontSize:
                                                                            10.0,
                                                                        fontWeight:
                                                                            FontWeight.w300,
                                                                        fontFamily:
                                                                            'helvetica',
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ]),
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    left: 15,
                                                                    right: 15),
                                                          ),
                                                          flex: 2,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              );
                                            },
                                          )
                                        : Visibility(
                                            child: Container(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Image.asset(
                                                    'assets/nodata_icon.png',
                                                    height: 100,
                                                    width: 100,
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 10),
                                                    child: Text(
                                                      message,
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            visible: _loading ? true : false,
                                          ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                          ),
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void checkSticker(bool toastStatus) {
    print('Done');
    print(_battery.checkInternet());
    _battery.checkInternet().then((String isConnection) {
      if (isConnection != null && isConnection.contains('true')) {
        /*_loading = true;
        dismissProgressHUD();*/
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                param[PARAM_API_TOKEN] = apiToken;
                param[PARAM_PERSON_ID] = loginID;
                param[PARAM_DEVICE_ID] = deviceid;
                param[PARAM_VERSION] = APP_VERSION;
                param['LoginBy'] = loginID;
                param['StickerNo'] = widget.stickerNo.isNotEmpty
                    ? widget.stickerNo
                    : enteredSticker;
                param['SubModuleName'] = Platform.isAndroid
                    ? SUB_MODULE_NAME_ANDROID
                    : SUB_MODULE_NAME_IOS;
                param[PARAM_ACTION] = "GetData";
                print(param);
                wsPresenter.callAPI(POST_METHOD, 'Know_Your_Box', param);
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void showNoInternetDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(mContext, 'no_internet_connection'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    print('Error : ' + errorTxt);
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: errorTxt,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);
    message = responseModel.Message;

    print(responseModel.Status);
    print(message);

    dismissProgressHUD();

    if (responseModel.Status.contains('1')) {
      if (mounted) {
        setState(() {
          scanDataList.clear();
          scanDataList.addAll(responseModel.getKnowYourBoxModelList());
        });
      }
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    } else {
      if (mounted) {
        setState(() {
          scanDataList.clear();
        });
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
