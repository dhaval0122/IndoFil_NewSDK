import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/track_n_trace/KnowYourBoxScreen.dart';
import 'package:flutter_basf_hk_app/track_n_trace/piv/PIVConfirmScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';
import 'package:super_tooltip/super_tooltip.dart';

class PIVScanScreen extends StatefulWidget {
  final List<KnowYourBoxModel> scanData;
  final bool isChange;
  final String displayName;

  PIVScanScreen({this.scanData, this.isChange, this.displayName});

  @override
  PIVScanScreenState createState() => PIVScanScreenState();
}

class PIVScanScreenState extends State<PIVScanScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '', topHeaderImage = 'assets/piv_icon.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController serialNoTextController;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  String menufacturer = '';
  DatabaseHelper databaseHelper;
  int apiCallType = 0;
  WSPresenter wsPresenter;
  List<KnowYourBoxModel> inwardScanList;
  bool isSelectAll = false;
  Flushbar flush;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    inwardScanList = new List();
    if (widget.isChange) {
      inwardScanList.addAll(widget.scanData);
    }

    serialNoTextController = TextEditingController();

    init();
  }

  void init() async {
    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullName = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullName != null ? fullName : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) async {
          try {
            print('=======state=======${state.toString()}');
            if (state['type'] == '11') {
              var detailsData = state['Details'];
              final dynamic lists = json.decode(detailsData);
              verifySticker(lists);
            }
          } catch (e) {
            print(e.toString());
          }
        });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await insertLogDetails();

    await _battery.hideKeyboardPlugin();

    if (mounted) {
      setState(() {});
    }
  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_TNT_PIV');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode =
    await databaseHelper.getSyncCodeFromLoginDetails(int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void verifySticker(dynamic lists) async {
    if (lists.length > 0) {
      for (var j in lists) {
        if (j.toString().trim().isNotEmpty) {
          List<String> code = j.toString().split("/");
          print('====F CODE=====${code.toString()}');
          if (code.length > 1) {
            if (code[1].toString() == '31') {
              insertStickerInList(code[0].toString().toUpperCase(), 'P');
            } else if (code[1].toString() == '21') {
              insertStickerInList(code[0].toString().toUpperCase(), 'S');
            }
          } else {
            insertStickerInList(code[0].toString().toUpperCase(), 'S');
          }
        }
      }
    }
  }

  void insertStickerInList(String sticker, String chrType) {
    bool isExist = stickerAlreadyExist(sticker);
    if (isExist) {
      int inwardScanListLength = inwardScanList.length;
      if (inwardScanListLength < globals.SCAN_LIMIT) {
//        isVerifyBtn = true;
        isLaserScanLoad = false;
        inwardScanList.insert(
            0,
            KnowYourBoxModel(
              varSticker: sticker,
              fk_StickerGlCode: 0,
            ));
        if (mounted) {
          setState(() {});
        }
      } else {
        isLaserScanLoad = false;
        _showSnackBar(LocaleUtils.getString(mContext, 'you_reached_max_limit'));
      }
    } else {
      isLaserScanLoad = false;
      _showSnackBar(LocaleUtils.getString(mContext, 'LabelAlreadyExist'));
    }
  }

  bool stickerAlreadyExist(String sticker) {
    if (inwardScanList.isNotEmpty) {
      int lengthList = inwardScanList.length;
      for (int i = 0; i < lengthList; i++) {
        KnowYourBoxModel inwardScanModel = inwardScanList[i];
        if (sticker.toUpperCase() == inwardScanModel.varSticker.toUpperCase()) {
          return false;
        }
      }
    }
    return true;
  }

  void _onTextChanged() async {
    final String value = serialNoTextController.text ?? '';
    if (value.isNotEmpty) {
      if (value.trim().length >= int.parse(globals.BARCODE_LENGTH)) {
        print('=====value=======$value');
        if (!isLaserScanLoad) {
          final List<String> scanList = List();
          isLaserScanLoad = true;
          await _battery.checkBarCode(value).then((String serialNo) async {
            if (!scanList.contains(serialNo)) {
              scanList.add(serialNo);
            }
            verifySticker(scanList);
            serialNoTextController.text = '';
          });
        } else {
          serialNoTextController.text = '';
        }
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(mContext).requestFocus(FocusNode());
        List<String> scanList = List();
        scanList.add(serialNoTextController.text);
        verifySticker(scanList);
        serialNoTextController.text = '';
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
        'false',
        'true',
        'false',
        '#004a96',
        PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
        LocaleUtils.getString(mContext, 'next'),
        PROJECT_NAME == 'BASF_HK'
            ? LocaleUtils.getString(mContext, 'scan_your_label_here')
            : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

//  void redirectInwardConfirmScreen() {
//    if (widget.isChange) {
//      Navigator.pop(context, true);
//    } else {
//      final Route route =
//      CupertinoPageRoute(builder: (context) => InwardConfirmScreen());
//      Navigator.pushReplacement(mContext, route);
//    }
//  }

  String getSticker() {
    final StringBuffer stringBuilder = StringBuffer();
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        stringBuilder.write(inwardScanList[i].varSticker);
        if (i == (inwardScanList.length - 1)) {
        } else {
          stringBuilder.write(",");
        }
      }
    }
    return stringBuilder.toString();
  }

  void apiCall(int type) async {
    String enteredSticker = getSticker();
    print('======enteredSticker====$enteredSticker');
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      _loading = true;
      dismissProgressHUD();

      Future.delayed(const Duration(milliseconds: 700), () async {
        var param = Map();
        String loginID = await sharedPrefs.getString(PREF_INIT_GI_CODE);
        String deviceid = await sharedPrefs.getString(PREF_DEVICE_ID);
        String apiToken = await sharedPrefs.getString(PREF_API_TOKEN);

        param[PARAM_SUB_MODULE_NAME] =
        Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;
        param[PARAM_VERSION] = APP_VERSION;
        param[PARAM_API_TOKEN] = apiToken;
        param[PARAM_PERSON_ID] = loginID;
        param[PARAM_DEVICE_ID] = deviceid;
        param[PARAM_VERSION] = APP_VERSION;
        param['LoginBy'] = loginID;
        param['StickerNo'] = enteredSticker;
        param['SubModuleName'] =
        Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;

        if (type == 1) {
          param[PARAM_ACTION] = "GetBulkKYBData";
        }

        print(param);
        apiCallType = type;
        wsPresenter.callAPI(POST_METHOD, 'Know_Your_Box', param);
      });
    } else {
//      await showDialog<Map>(
//        barrierDismissible: false,
//        context: mContext,
//        builder: (context) {
//          return CustomAlertDialog(
//            content: LocaleUtils.getString(mContext, 'no_internet_connection'),
//            title:
//                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
//            isShowNagativeButton: false,
//            textNagativeButton: '',
//            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//            onPressedNegative: () {},
//            onPressedPositive: () {},
//          );
//        },
//      );
      _showSnackBar(LocaleUtils.getString(mContext, 'no_internet_connection'));
    }
  }

  void removeSticker(int index) async {
    print('=========index=====$index');
    KnowYourBoxModel inwardScanModel = inwardScanList[index];
    inwardScanList[index].isDelete = false;
    inwardScanList.removeAt(index);
    if (mounted) {
      setState(() {});
    }

    flush = Flushbar<bool>(
      message:
      "${inwardScanModel.varSticker} ${LocaleUtils.getString(
          mContext, 'deleted')}",
      duration: Duration(seconds: 3),
      mainButton: FlatButton(
        onPressed: () {
          inwardScanList.insert(index, inwardScanModel);
          flush.dismiss();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    await flush.show(context);
  }

  void removeMultiSelectedSticker() async {
    List<KnowYourBoxModel> multiDeleteStickerList = new List();
    multiDeleteStickerList.addAll(inwardScanList);

    if (inwardScanList.isNotEmpty) {
      for (int i = (inwardScanList.length - 1); i >= 0; i--) {
        if (inwardScanList[i].isDelete) {
//          if (inwardScanList[i].chrValid == 'Y') {
//            isVerifyBtn = true;
//          }
          inwardScanList[i].isDelete = false;
          inwardScanList.removeAt(i);
//          multiDeleteStickerList.add(MultiDeleteStickerModel(i, inwardScanList[i]));
        }
      }
    }
//    if (multiDeleteStickerList.isNotEmpty) {
//      for (int i = 0; i < multiDeleteStickerList.length; i++) {
//
//      }
//    }
    if (mounted) {
      setState(() {});
    }

    if (multiDeleteStickerList.isNotEmpty) {
      flush = Flushbar<bool>(
        message:
        "${(multiDeleteStickerList.length) -
            (inwardScanList.length)} ${LocaleUtils.getString(
            mContext, 'deleted')}",
        duration: Duration(seconds: 3),
        mainButton: FlatButton(
          onPressed: () {
//            isVerifyBtn = false;
            inwardScanList.clear();
            inwardScanList.addAll(multiDeleteStickerList);
//            for (int i = 0; i < multiDeleteStickerList.length; i++) {
//              print('====index======${multiDeleteStickerList[i].index}');
//              InwardScanModel inwardScanModel = multiDeleteStickerList[i].inwardScanModel;
//              inwardScanModel.isDelete = false;
//              inwardScanList.insert(multiDeleteStickerList[i].index,
//                  inwardScanModel);
//            }
            flush.dismiss();
            if (mounted) {
              setState(() {});
            }
          },
          child: Text(
            "Undo",
            style: TextStyle(color: Colors.amber),
          ),
        ),
      );
      await flush.show(context);
    }
  }

  Color getColorCode(int index) {
//    if (!inwardScanList[index].isDelete) {
//      if (inwardScanList[index].fk_StickerGlCode > 0) {
//        if (inwardScanList[index].chrValid.contains('N')) {
//          return Colors.red;
//        } else {
//          return Colors.black;
//        }
//      } else {
    return const Color(colorPrimary);
//      }
//    } else {
//      return Color(colorPrimary);
//    }
  }

  Widget legendSubText(Color colorCode, String legendName) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 20),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 20,
            decoration: BoxDecoration(
                color: colorCode,
                borderRadius: BorderRadius.all(Radius.circular(10))),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: Text(legendName,
                style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'helvetica',
                    color: Colors.black)),
          )
        ],
      ),
    );
  }

  bool isStickerSelected() {
    bool isSelected = false;

    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        if (inwardScanList[i].isDelete) {
          isSelected = true;
        }
      }
    }

    return isSelected;
  }

  bool isCheckAllStickerSelected() {
    bool isSelected = true;

    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        if (!inwardScanList[i].isDelete) {
          isSelected = false;
        }
      }
    }

    return isSelected;
  }

  void selectAll() {
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        inwardScanList[i].isDelete = true;
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void unSelectAll() {
    if (inwardScanList.isNotEmpty) {
      for (int i = 0; i < inwardScanList.length; i++) {
        inwardScanList[i].isDelete = false;
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void setSelection(int index) {
    if (inwardScanList[index].isDelete) {
      inwardScanList[index].isDelete = false;
    } else {
      inwardScanList[index].isDelete = true;
    }
    if (isCheckAllStickerSelected()) {
      isSelectAll = true;
    } else {
      isSelectAll = false;
    }
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final tooltip = SuperTooltip(
        popupDirection: TooltipDirection.left,
        arrowTipDistance: 0.0,
        arrowBaseWidth: 0.0,
        arrowLength: 0.0,
        borderColor: Color(colorPrimary),
        borderWidth: 4.0,
        snapsFarAwayVertically: true,
        showCloseButton: ShowCloseButton.none,
        hasShadow: false,
        touchThroughAreaShape: ClipAreaShape.rectangle,
        content: Material(
            child: Container(
              width: screenSize.width,
              child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    physics: AlwaysScrollableScrollPhysics(),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                            '${LocaleUtils.getString(
                                mContext, 'legend_of_current_status')}',
                            style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'helvetica',
                                color: Colors.black)),
                        legendSubText(Color(colorBlocked),
                            LocaleUtils.getString(
                                mContext, 'blocked_restricted')),
                        legendSubText(Color(colorInStock),
                            LocaleUtils.getString(mContext, 'in_stock')),
                        legendSubText(Color(colorConsume),
                            LocaleUtils.getString(mContext, 'consumed')),
                        legendSubText(Color(colorDamage),
                            LocaleUtils.getString(mContext, 'damaged')),
                        legendSubText(Color(colorScraped),
                            LocaleUtils.getString(mContext, 'scraped')),
                        legendSubText(Color(colorDispatch),
                            LocaleUtils.getString(mContext, 'dispatched_foc')),
                        legendSubText(Color(colorInValid),
                            LocaleUtils.getString(mContext, 'in_valid')),
                        legendSubText(Color(colorPrinted),
                            LocaleUtils.getString(mContext, 'printed')),
                        legendSubText(Color(colorPalletBreak),
                            LocaleUtils.getString(mContext, 'pallet_break_')),
                        legendSubText(Color(colorInTransit),
                            LocaleUtils.getString(mContext, 'in_transit')),
                      ],
                    ),
                  )),
            )));

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'EnterSrNumber'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    final cameraIcon = InkWell(
      child: Padding(
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Icon(Icons.camera_alt, color: Colors.white)),
      onTap: () {
        startScanBtnCall();
      },
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'verify'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (inwardScanList.isEmpty) {
//            showDialog<Map>(
//              barrierDismissible: false,
//              context: context,
//              builder: (context) {
//                return CustomAlertDialog(
//                  content: LocaleUtils.getString(mContext, 'YouHaveNotScannedAnyLabelYet'),
//                  title: PROJECT_NAME == 'BASF_HK'
//                      ? BASF_HK_APP_Name
//                      : Zydus_APP_Name,
//                  isShowNagativeButton: false,
//                  textNagativeButton: '',
//                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//                  onPressedNegative: () {},
//                  onPressedPositive: () {},
//                );
//              },
//            );
            _showSnackBar(LocaleUtils.getString(
                mContext, 'YouHaveNotScannedAnyLabelYet'));
          } else {
            apiCall(1);
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          if (tooltip.isOpen) {
            tooltip.close();
          } else {
            Navigator.pop(context, false);
          }
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (tooltip.isOpen) {
                tooltip.close();
              } else {
                Navigator.pop(context, false);
              }
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, widget.displayName, topHeaderImage, 0),
//                    CustomTopHeaderBarForInward(stage: SUB_HEADER_INWARD_SCAN),
                        Container(
                          margin:
                          const EdgeInsets.only(top: 20, right: 20, left: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Form(
                                  key: _formKey,
                                  autovalidate: _autoValidate,
                                  child: Container(
                                    height: 42,
                                    width: screenSize.width,
                                    padding:
                                    const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: serialNumberTxt,
                                  ),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                child: addButton,
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                height: 45,
                                decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  color: const Color(colorPrimary),
                                ),
                                child: cameraIcon,
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: const Color(bgColor),
                            child: Card(
                              elevation: 7,
                              margin: const EdgeInsets.only(
                                  top: 10, right: 15, left: 15),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Container(
                                    height: 40,
                                    padding:
                                    const EdgeInsets.only(left: 10, right: 10),
                                    alignment: Alignment.centerLeft,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary)),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: <Widget>[
                                        Text(
                                          LocaleUtils.getString(
                                              mContext, 'ScannedSrNo'),
                                          style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w300,
                                            fontFamily: 'helvetica',
                                            color: Colors.white,
                                          ),
                                        ),
                                        Container(
                                          margin: const EdgeInsets.only(
                                              right: 25),
                                          child: Row(
                                            crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                            MainAxisAlignment.end,
                                            children: <Widget>[
                                              InkWell(
                                                onTap: () {
                                                  tooltip.show(context);
                                                },
                                                child: const Align(
                                                  alignment: Alignment
                                                      .centerRight,
                                                  child: Icon(
                                                    Icons.info,
                                                    size: 25.0,
                                                    color: Colors.orange,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  isStickerSelected()
                                      ? Container(
                                      color: const Color(colorAccent),
                                      height: 40,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Expanded(
                                              child: InkWell(
                                                child: Center(
                                                  child: Container(
                                                    width: 27,
                                                    height: 27,
                                                    decoration: BoxDecoration(
                                                        color: isSelectAll
                                                            ? const Color(
                                                            colorPrimary)
                                                            : const Color(
                                                            colorAccent),
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            color: const Color(
                                                                colorPrimary),
                                                            width: 1)),
                                                    child: isSelectAll
                                                        ? Icon(
                                                      Icons.done,
                                                      size: 15.0,
                                                      color: Colors.white,
                                                    )
                                                        : Container(),
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll();
                                                  }
                                                },
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                child: Text(
                                                  LocaleUtils.getString(
                                                      mContext, 'select_all'),
                                                  style: TextStyle(
                                                    fontSize: 15.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: 'helvetica',
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                  textAlign: TextAlign.left,
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll();
                                                  }
                                                },
                                              ),
                                              flex: 2,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                onTap: () {
                                                  removeMultiSelectedSticker();
                                                },
                                                child: isStickerSelected()
                                                    ? Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Icon(
                                                    Icons.delete,
                                                    size: 25.0,
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                )
                                                    : Container(),
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ))
                                      : Container(),
                                  Expanded(
                                    child: Container(
                                      child: ListView.builder(
                                        itemCount: inwardScanList.length,
                                        shrinkWrap: true,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return Material(
                                            child: InkWell(
                                              onTap: () {
                                                if (isStickerSelected()) {
                                                  setSelection(index);
                                                }
                                              },
                                              onLongPress: () {
                                                setSelection(index);
                                              },
                                              child: Container(
                                                  color: Colors.white,
                                                  child: Column(
                                                    children: <Widget>[
                                                      Container(
                                                        height: 40,
                                                        color: inwardScanList[index]
                                                            .isDelete
                                                            ? Colors.grey[200]
                                                            : Colors.white,
                                                        width: screenSize.width,
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                          mainAxisSize:
                                                          MainAxisSize.max,
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: Center(
                                                                  child: inwardScanList[
                                                                  index]
                                                                      .isDelete
                                                                      ? Container(
                                                                    width: 27,
                                                                    height:
                                                                    27,
                                                                    decoration:
                                                                    BoxDecoration(
                                                                      color: const Color(
                                                                          colorPrimary),
                                                                      shape: BoxShape
                                                                          .circle,
                                                                      //borderRadius: BorderRadius.all(Radius.circular(10))
                                                                    ),
                                                                    child:
                                                                    Icon(
                                                                      Icons
                                                                          .done,
                                                                      size:
                                                                      15.0,
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                  )
                                                                      : Text(
                                                                      '#${(index + 1)}',
                                                                      style:
                                                                      TextStyle(
                                                                        fontSize:
                                                                        14.0,
                                                                        fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                        fontFamily:
                                                                        'helvetica',
                                                                        color: getColorCode(
                                                                            index),
                                                                      ))),
                                                              flex: 1,
                                                            ),
                                                            Expanded(
                                                              child: Container(
                                                                child: Align(
                                                                  child: Text(
                                                                      '${inwardScanList[index]
                                                                          .varSticker}',
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                          14.0,
                                                                          fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                          fontFamily:
                                                                          'helvetica',
                                                                          color: getColorCode(
                                                                              index))),
                                                                  alignment: Alignment
                                                                      .centerLeft,
                                                                ),
                                                              ),
                                                              flex: 2,
                                                            ),
                                                            Expanded(
                                                              child:
                                                              !isStickerSelected()
                                                                  ? Align(
                                                                child:
                                                                GestureDetector(
                                                                  child: Icon(
                                                                      Icons
                                                                          .delete,
                                                                      color:
                                                                      getColorCode(
                                                                          index)),
                                                                  onTap:
                                                                      () {
//                                                            isFocusNodeEnable = false;
                                                                    if (!isStickerSelected()) {
                                                                      removeSticker(
                                                                          index);
                                                                    }
                                                                  },
                                                                ),
                                                                alignment:
                                                                Alignment
                                                                    .center,
                                                              )
                                                                  : Container(),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      const Divider(
                                                          height: 3,
                                                          color: Colors.black),
                                                    ],
                                                  )),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: screenSize.width,
                          height: 45,
                          child: saveButton,
                          margin: const EdgeInsets.all(15),
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  void navigatePIVConfirmScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PIVConfirmScreen(
          displayName: widget.displayName,
          scanData: inwardScanList,
        ));
    await Navigator.pushReplacement(context, route);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
    GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        inwardScanList.clear();
        inwardScanList.addAll(responseModel.getKnowYourBoxModelList());
        if (widget.isChange) {
          PIVConfirmScreenState.inwardScanList.clear();
          PIVConfirmScreenState.inwardScanList.addAll(inwardScanList);
          Navigator.pop(context, true);
        } else {
          navigatePIVConfirmScreen();
        }
      } else if (responseModel.Status.contains('2')) {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'Session_warning'),
              title: PROJECT_NAME == 'BASF_HK'
                  ? BASF_HK_APP_Name
                  : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {
                final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
                Navigator.pushAndRemoveUntil(
                    context, route, (Route<dynamic> route) => false);
              },
            );
          },
        );
      } else {
//        showDialog<Map>(
//          barrierDismissible: false,
//          context: mContext,
//          builder: (context) {
//            return CustomAlertDialog(
//              content: responseModel.Message,
//              title:
//              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
//              isShowNagativeButton: false,
//              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//              onPressedPositive: () {},
//            );
//          },
//        );
        _showSnackBar(responseModel.Message);
      }
    }
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void _showSnackBar(String text) {
    Flushbar(
      message: text,
      duration: Duration(seconds: 4),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
