import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/track_n_trace/KnowYourBoxScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';
import 'package:super_tooltip/super_tooltip.dart';

import 'PIVScanScreen.dart';

class PIVConfirmScreen extends StatefulWidget {
  final List<KnowYourBoxModel> scanData;
  final String displayName;

  PIVConfirmScreen({this.scanData, this.displayName});

  @override
  PIVConfirmScreenState createState() => PIVConfirmScreenState();
}

class PIVConfirmScreenState extends State<PIVConfirmScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false, isNotification = false, isSync = false;
  Size screenSize;
  String userName = '', topHeaderImage = 'assets/piv_icon.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  DatabaseHelper databaseHelper;

//  int apiCallType = 0;
//  WSPresenter wsPresenter;
  static List<KnowYourBoxModel> inwardScanList;
  List<KnowYourBoxModel> inwardScanListSearch;
  TextEditingController _search_controller;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
//    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    inwardScanList = new List();
    inwardScanListSearch = new List();
    if (widget.scanData != null) {
      inwardScanList.addAll(widget.scanData);
      inwardScanListSearch.addAll(widget.scanData);
    }

    _search_controller = TextEditingController();

    init();
  }

  void init() async {
//    menufacturer = await mUtils.getMenufacturer();
//    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
//      serialNoTextController.addListener(_onTextChanged);
//    }

    String fullName = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullName != null ? fullName : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await _battery.hideKeyboardPlugin();

    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    super.dispose();
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
            'false',
            'true',
            'false',
            '#004a96',
            PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
            LocaleUtils.getString(mContext, 'next'),
            PROJECT_NAME == 'BASF_HK'
                ? LocaleUtils.getString(mContext, 'scan_your_label_here')
                : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

//  void redirectInwardConfirmScreen() {
//    if (widget.isChange) {
//      Navigator.pop(context, true);
//    } else {
//      final Route route =
//      CupertinoPageRoute(builder: (context) => InwardConfirmScreen());
//      Navigator.pushReplacement(mContext, route);
//    }
//  }

  Color getColorCode(int index) {
//    if (inwardScanList[index].varColor) {
//      if (inwardScanList[index].chrValid.contains('N')) {
//        return Colors.red;
//      } else {
    return mUtils.fromHex(inwardScanList[index].varColor);
//      }
//    } else {
//      return Color(colorPrimary);
//    }
  }

  Widget legendSubText(Color colorCode, String legendName) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 20),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 20,
            decoration: BoxDecoration(
                color: colorCode,
                borderRadius: BorderRadius.all(Radius.circular(10))),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: Text(legendName,
                style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'helvetica',
                    color: Colors.black)),
          )
        ],
      ),
    );
  }

  void filterSearchResults(String query) {
    final List<KnowYourBoxModel> dummySearchList = List<KnowYourBoxModel>();
    dummySearchList.addAll(inwardScanListSearch);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<KnowYourBoxModel> dummyListData = List<KnowYourBoxModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          inwardScanList.clear();
          inwardScanList.addAll(dummyListData);
        });
      }
    } else {
      if (mounted) {
        setState(() {
          inwardScanList.clear();
          inwardScanList.addAll(inwardScanListSearch);
        });
      }
    }
  }

  void reScanBtn() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PIVScanScreen(
            isChange: true,
            displayName: widget.displayName,
            scanData: inwardScanList));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          if (mounted) {
            setState(() {});
          }
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateKnowYourBoxScreen(String stickerNo) async {
    await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_KNOW_YOUR_BOX);
    final Route route = CupertinoPageRoute(
        builder: (context) => KnowYourBoxScreen(stickerNo: stickerNo));
    await Navigator.push(context, route);
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final tooltip = SuperTooltip(
        popupDirection: TooltipDirection.left,
        arrowTipDistance: 0.0,
        arrowBaseWidth: 0.0,
        arrowLength: 0.0,
        borderColor: Color(colorPrimary),
        borderWidth: 4.0,
        snapsFarAwayVertically: true,
        showCloseButton: ShowCloseButton.none,
        hasShadow: false,
        touchThroughAreaShape: ClipAreaShape.rectangle,
        content: Material(
            child: Container(
          width: screenSize.width,
          child: Padding(
              padding: const EdgeInsets.all(10),
              child: SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  physics: AlwaysScrollableScrollPhysics(),
                  child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                      '${LocaleUtils.getString(mContext, 'legend_of_current_status')}',
                      style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'helvetica',
                          color: Colors.black)),
                  legendSubText(Color(colorBlocked),
                      LocaleUtils.getString(mContext, 'blocked_restricted')),
                  legendSubText(Color(colorInStock),
                      LocaleUtils.getString(mContext, 'in_stock')),
                  legendSubText(Color(colorConsume),
                      LocaleUtils.getString(mContext, 'consumed')),
                  legendSubText(Color(colorDamage),
                      LocaleUtils.getString(mContext, 'damaged')),
                  legendSubText(Color(colorScraped),
                      LocaleUtils.getString(mContext, 'scraped')),
                  legendSubText(Color(colorDispatch),
                      LocaleUtils.getString(mContext, 'dispatched_foc')),
                  legendSubText(Color(colorInValid),
                      LocaleUtils.getString(mContext, 'in_valid')),
                  legendSubText(Color(colorPrinted),
                      LocaleUtils.getString(mContext, 'printed')),
                  legendSubText(Color(colorPalletBreak),
                      LocaleUtils.getString(mContext, 'pallet_break_')),
                  legendSubText(Color(colorInTransit),
                      LocaleUtils.getString(mContext, 'in_transit')),
                ],
                  ))),
        )));

    final reScanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ReScan'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: reScanBtn,
      ),
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Discard'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          showDialog<Map>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(
                    mContext, 'AreYouSureUWant2DiscardTransaction'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  Navigator.pop(context, false);
                },
              );
            },
          );
        },
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          if (tooltip.isOpen) {
            tooltip.close();
          } else {
            Navigator.pop(context, true);
          }
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (tooltip.isOpen) {
                tooltip.close();
              } else {
                Navigator.pop(context, true);
              }
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    CustomTopHeaderBar(
                        userName, widget.displayName, topHeaderImage, 0),
//                    CustomTopHeaderBarForInward(stage: SUB_HEADER_INWARD_SCAN),
                    Container(
                      decoration: BoxDecoration(
                          color: const Color(colorAccent),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(3))),
                      margin:
                          const EdgeInsets.only(top: 10, left: 10, right: 10),
                      padding: const EdgeInsets.all(6),
                      child: Container(
                        height: 40,
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            color: Colors.white),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: TextField(
                                  controller: _search_controller,
                                  //enableInteractiveSelection: false,
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintStyle:
                                        TextStyle(color: Colors.grey[700]),
                                    hintText: LocaleUtils.getString(
                                        mContext, 'SearchArticleCodeOrName'),
                                    counterText: '',
                                  ),
                                  onChanged: (value) {
                                    filterSearchResults(
                                        value.trim().toLowerCase());
                                  },
                                  maxLines: 1,
                                  maxLength: EditTxtMaxLengths,
                                ),
                              ),
                              flex: 1,
                            ),
                            Flexible(
                              child: IconButton(
                                  onPressed: () {
                                    // _search_controller.clear();
                                  },
                                  icon: const Icon(
                                    Icons.search,
                                    color: Color(colorPrimary),
                                  )),
                              flex: 0,
                            )
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        color: const Color(bgColor),
                        child: Card(
                          elevation: 7,
                          margin: const EdgeInsets.only(
                              top: 10, right: 15, left: 15),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              Container(
                                height: 40,
                                padding:
                                    const EdgeInsets.only(left: 10, right: 5),
                                alignment: Alignment.centerLeft,
                                decoration: const BoxDecoration(
                                    color: Color(colorPrimary)),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Expanded(
                                      flex: 1,
                                      child: Center(
                                        child: Text(
                                          LocaleUtils.getString(mContext, 'sr'),
                                          style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w300,
                                            fontFamily: 'helvetica',
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: Text(
                                        '${LocaleUtils.getString(mContext, 'SerialNo')}',
                                        style: TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w300,
                                          fontFamily: 'helvetica',
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: InkWell(
                                        onTap: () {
                                          tooltip.show(context);
                                        },
                                        child: const Align(
                                          alignment: Alignment.centerRight,
                                          child: Padding(
                                            padding: EdgeInsets.only(right: 3),
                                            child: Icon(
                                              Icons.info,
                                              size: 25.0,
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Expanded(
                                child: Container(
                                  child: inwardScanList.isNotEmpty
                                      ? ListView.builder(
                                          itemCount: inwardScanList.length,
                                          shrinkWrap: true,
                                          itemBuilder: (BuildContext context,
                                              int index) {
                                            return InkWell(
                                              onTap: () {
                                                navigateKnowYourBoxScreen(
                                                    inwardScanList[index]
                                                        .varSticker);
                                              },
                                              child: Container(
                                                  color: Colors.white,
                                                  child: Column(
                                                    children: <Widget>[
                                                      Container(
                                                        height: 40,
                                                        color: Colors.white,
                                                        width: screenSize.width,
                                                        child: Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .center,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceAround,
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: Center(
                                                                  child: Text(
                                                                      '#${(index + 1)}',
                                                                      style:
                                                                          TextStyle(
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight.w400,
                                                                        fontFamily:
                                                                            'helvetica',
                                                                        color: getColorCode(
                                                                            index),
                                                                      ))),
                                                              flex: 1,
                                                            ),
                                                            Expanded(
                                                              child: Container(
                                                                child: Align(
                                                                  child: Text(
                                                                      '${inwardScanList[index].varSticker}',
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                              14.0,
                                                                          fontWeight: FontWeight
                                                                              .w400,
                                                                          fontFamily:
                                                                              'helvetica',
                                                                          color:
                                                                              getColorCode(index))),
                                                                  alignment:
                                                                      Alignment
                                                                          .centerLeft,
                                                                ),
                                                              ),
                                                              flex: 2,
                                                            ),
                                                            Expanded(
                                                              child: Align(
                                                                alignment: Alignment
                                                                    .centerRight,
                                                                child: Padding(
                                                                  padding:
                                                                      EdgeInsets
                                                                          .all(
                                                                              8.0),
                                                                  child: Icon(
                                                                    Icons.info,
                                                                    size: 25.0,
                                                                    color: Colors
                                                                        .orange,
                                                                  ),
                                                                ),
                                                              ),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      const Divider(
                                                          height: 3,
                                                          color: Colors.black),
                                                    ],
                                                  )),
                                            );
                                          },
                                        )
                                      : Container(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: <Widget>[
                                              Image.asset(
                                                'assets/nodata_icon.png',
                                                height: 100,
                                                width: 100,
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 10),
                                                child: Text(
                                                  LocaleUtils.getString(
                                                      mContext, 'NoDataFound'),
                                                  style: prifixTxtStyle,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      margin: const EdgeInsets.all(15),
                      child: Row(
                        children: <Widget>[
                          Expanded(
                            child: reScanButton,
                            flex: 1,
                          ),
                          Container(
                            width: 10,
                          ),
                          Expanded(
                            child: saveButton,
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
