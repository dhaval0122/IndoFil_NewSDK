import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/StockVisibilityModel.dart';
import 'package:flutter_basf_hk_app/stock_visibility/StockVisibilitySKUScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

class StockVisibilityScreen extends StatefulWidget {
  @override
  StockVisibilityScreenState createState() => StockVisibilityScreenState();
}

class StockVisibilityScreenState extends State<StockVisibilityScreen>
    implements WSInterface, PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false, isNotification = false, isSync = false;
  Size screenSize;
  String userName, subTitle, doNo, topHeaderImage = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;

  List<StockVisibilityCustomerModel> listCust = List();
  List<StockVisibilityProductModel> list = List();
  List<StockVisibilityProductModel> listDisplay = List();

  static int apiCallType = 0;

  final TextEditingController _search_controller = TextEditingController();

  WSPresenter wsPresenter;

  StockVisibilityCustomerModel selectedCustomerModel;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    Route route = CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    apiCallType = 0;

    mUtils = Utils();
    _battery = EcpSyncPlugin();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      topHeaderImage = 'assets/stock_info_icon.png';
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData(1, 0);
    _initLoading();

    insertLogDetails();

  }


  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_STV');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else {
      return '';
    }
  }

  // type : 1 = GetCustomer, 2 = GetPRD
  void getData(int type, int CustomerGlCode) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                sharedPrefs
                    .getString(PREF_INIT_GI_CODE)
                    .then((String initGlCode) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param['EmployeeGlCode'] = initGlCode;
                  param[PARAM_DEVICE_ID] = deviceid;
                  param['Filter'] = '';
                  param['Version'] = APP_VERSION;

                  param[PARAM_ACTION] = type == 1 ? 'GetCustomer' : 'GetPRD';
                  param['PRDGlCode'] = '0';
                  param['PSKUGlCode'] = '0';
                  param['StockBlockXML'] = '';
                  param['Favourite'] = '';
                  param['CustomerGlCode'] = CustomerGlCode.toString();

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
                });
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void markFavourite(int type, int PRDGlCode, String Favourite) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                sharedPrefs
                    .getString(PREF_INIT_GI_CODE)
                    .then((String initGlCode) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param['EmployeeGlCode'] = initGlCode;
                  param[PARAM_DEVICE_ID] = deviceid;
                  param['Filter'] = '';
                  param['Version'] = APP_VERSION;

                  param[PARAM_ACTION] = Favourite.toLowerCase() == 'y'
                      ? 'markFavourite'
                      : 'UnMarkFavourite';
                  param['PRDGlCode'] = PRDGlCode.toString();
                  param['PSKUGlCode'] = '0';
                  param['StockBlockXML'] = '';
                  param['Favourite'] = Favourite;
                  param['CustomerGlCode'] = selectedCustomerModel != null
                      ? selectedCustomerModel.fk_UserGlCode.toString()
                      : 0;

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Stock_Visibility', param);
                });
              });
            });
          });
        });
      } else {
        showNoInternetDialog();
      }
    });
  }

  void showNoInternetDialog() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(mContext, 'no_internet_connection'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      if (apiCallType == 1) {
        listCust.clear();

        if (mounted) {
          setState(() {
            listCust.addAll(responseModel.getStockVisibilityCustomerList());
            selectedCustomerModel = listCust[0];
          });
        }
        // For Testing Purpose
        if (selectedCustomerModel != null) {
          getData(2, selectedCustomerModel.fk_UserGlCode);
        }
        return;
      } else if (apiCallType == 2) {
        if (mounted) {
          setState(() {
            list.clear();
            listDisplay.clear();

            listDisplay.addAll(responseModel.getStockVisibilityProductList());
            list.addAll(listDisplay);
          });
        }
      } else if (apiCallType == 3) {
        getData(2, selectedCustomerModel.fk_UserGlCode);
        return;
      }
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    }
    dismissProgressHUD();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 42,
                      width: screenSize.width,
                      padding: const EdgeInsets.fromLTRB(15, 0, 15, 0),
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: const Color(colorPrimary), width: 2),
                          borderRadius: _getRadiusDropDown()),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<StockVisibilityCustomerModel>(
                          value: selectedCustomerModel,
                          onChanged: (StockVisibilityCustomerModel newValue) {
                            _search_controller.text = '';
                            if (mounted) {
                              setState(() {
                                selectedCustomerModel = newValue;
                              });
                              getData(2, selectedCustomerModel.fk_UserGlCode);
                            }
                          },
                          hint: Text(
                            LocaleUtils.getString(mContext, 'sel_customer'),
                            style: prifixTxtPrimaryStyle,
                            textAlign: TextAlign.left,
                          ),
                          isExpanded: true,
                          items: listCust != null
                              ? listCust
                                  .map((StockVisibilityCustomerModel value) {
                                  return DropdownMenuItem<
                                      StockVisibilityCustomerModel>(
                                    value: value,
                                    child: Text(
                                      value.varName,
                                      style: prifixTxtPrimaryStyle,
                                    ),
                                  );
                                }).toList()
                              : List(),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    child: Container(
                      height: 40,
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(7)),
                          color: Colors.white),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: _search_controller,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: prifixTxtPrimaryStyle,
                                  hintText: LocaleUtils.getString(
                                      mContext, 'SearchPRD'),
                                  counterText: '',
                                ),
                                onChanged: (value) {
                                  filterSearchResults(value.trimLeft());
                                },
                                style: prifixTxtPrimaryStyle,
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {
                                  // _search_controller.clear();
                                },
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    color: const Color(colorAccent),
                    padding: const EdgeInsets.all(10),
                    margin: const EdgeInsets.only(top: 10),
                    child: Container(
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                LocaleUtils.getString(mContext, 'PRD'),
                                style: prifixTxtPrimaryStyle,
                              ),
                            ),
                            flex: 2,
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                '${LocaleUtils.getString(
                                    mContext, 'Qty')}.(${globals.KG_PCS}.)',
                                style: prifixTxtPrimaryStyle,
                                textAlign: TextAlign.center,
                              ),
                            ),
                            flex: 1,
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: Text(
                                LocaleUtils.getString(mContext, 'fav'),
                                style: prifixTxtPrimaryStyle,
                                textAlign: TextAlign.right,
                              ),
                            ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    //child: listDisplay.length > 0
                    child: listDisplay.length > 0
                        ? Container(
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemBuilder: (context, position) {
                                return GestureDetector(
                                    child: Card(
                                        margin: const EdgeInsets.only(
                                            left: 7,
                                            top: 7,
                                            bottom: 7,
                                            right: 7),
                                        elevation: 3,
                                        child: Container(
                                          padding: const EdgeInsets.all(2),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 5),
                                                  child: Text(
                                                    listDisplay[position]
                                                        .varPRD_Name,
                                                  ),
                                                ),
                                                flex: 2,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 5),
                                                  child: Text(
                                                    listDisplay[position]
                                                        .decQty
                                                        .toString(),
                                                    textAlign: TextAlign.center,
                                                  ),
                                                ),
                                                flex: 1,
                                              ),
                                              Expanded(
                                                child: Padding(
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 5),
                                                  child: Align(
                                                    alignment:
                                                        Alignment.centerRight,
                                                    child: IconButton(
                                                      onPressed: () {
                                                        markFavourite(
                                                            3,
                                                            listDisplay[
                                                                    position]
                                                                .fk_PRDGlCode,
                                                            listDisplay[position]
                                                                    .Favourite
                                                                    .contains(
                                                                        'Y')
                                                                ? 'N'
                                                                : 'Y');
                                                      },
                                                      icon: Image.asset(listDisplay[
                                                                  position]
                                                              .Favourite
                                                              .contains('Y')
                                                          ? 'assets/star_yellow.png'
                                                          : 'assets/star_theme.png'),
                                                    ),
                                                  ),
                                                ),
                                                flex: 1,
                                              ),
                                            ],
                                          ),
                                        )),
                                    onTap: () {
                                      final Route route = CupertinoPageRoute(
                                          builder: (context) =>
                                              StockVisibilitySKUScreen(
                                                  listDisplay[position],
                                                  selectedCustomerModel));
                                      Navigator.push(mContext, route);
                                    });
                              },
                              itemCount: listDisplay.length,
                            ),
                          )
                        : Visibility(
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Image.asset(
                                    'assets/nodata_icon.png',
                                    height: 100,
                                    width: 100,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'NoDataFound'),
                                      style: prifixTxtStyle,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            visible: listDisplay.length == 0 ? true : false,
                          ),
                  )
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void filterSearchResults(String query) {
    print(query);

    final List<StockVisibilityProductModel> dummySearchList =
        List<StockVisibilityProductModel>();
    dummySearchList.addAll(list);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<StockVisibilityProductModel> dummyListData =
          List<StockVisibilityProductModel>();
      dummySearchList.forEach((item) {
        if (item.varPRD_Name.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(dummyListData);
        });
      }
      return;
    } else {
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(list);
        });
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
