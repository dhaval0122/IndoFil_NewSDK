import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopSubHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/consume/ConsumeStockThirdScreen.dart';
import 'package:flutter_basf_hk_app/damage/DamageStockDetailsScreen.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchThirdScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveThirdScreen.dart';
import 'package:flutter_basf_hk_app/scrap/ScrapStockDetailsScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';

class ValidStickerModel {
  int fk_StickerGlCode;
  int fk_Product_SKUGlCode;
  String varScanCode;
  int fk_Sticker_DamageGlCode;
  int fk_ReceivedFromGlCode;
  String chrPallet;
  String varBatch_No;
  int fk_PalletGlCode;

  //String fkReceiveFromGlCode;

  ValidStickerModel(
      {this.fk_StickerGlCode,
      this.fk_Product_SKUGlCode,
      this.varScanCode,
      this.fk_Sticker_DamageGlCode,
      this.fk_ReceivedFromGlCode,
      this.chrPallet,
      this.varBatch_No,
      this.fk_PalletGlCode});

  ValidStickerModel.fromMap(Map<String, dynamic> json) {
    this.fk_StickerGlCode = json['fk_StickerGlCode'];
    this.fk_Product_SKUGlCode = json['fk_Product_SKUGlCode'];
    this.varScanCode = json['varScanCode'];
    this.fk_Sticker_DamageGlCode = json.containsKey('fk_Sticker_DamageGlCode')
        ? json['fk_Sticker_DamageGlCode']
        : 0;
    this.fk_ReceivedFromGlCode = json.containsKey('fk_ReceivedFromGlCode')
        ? json['fk_ReceivedFromGlCode']
        : 0;
    this.chrPallet = json['chrPallet'];
    this.varBatch_No =
        json.containsKey('varBatch_No') ? json['varBatch_No'] : '';
    this.fk_PalletGlCode = json['fk_PalletGlCode'];
  }
}

class ScanDataModel {
  int intRows;
  int fk_Customer_DispatchProduct_GLCode;
  int fk_Customer_ReceiveProductGlCode;
  int fk_Customer_DispatchGlCode;
  int fk_Customer_ReceiveGlCode;
  int intRowNo;
  String varSticker;
  String chrValid;
  String chrValidSave;
  String chrPallet;
  int intNoOfSticker;
  bool isDeleted = false;
  bool isMultiDeleted = false;

  ScanDataModel({
    this.intRows,
    this.fk_Customer_DispatchProduct_GLCode,
    this.fk_Customer_ReceiveProductGlCode,
    this.fk_Customer_DispatchGlCode,
    this.fk_Customer_ReceiveGlCode,
    this.intRowNo,
    this.varSticker,
    this.chrValid,
    this.chrValidSave,
    this.chrPallet,
    this.intNoOfSticker,
  });

  ScanDataModel.fromMap(Map<String, dynamic> json) {
    this.fk_Customer_DispatchProduct_GLCode =
        json.containsKey('fk_Customer_DispatchProduct_GLCode')
            ? json['fk_Customer_DispatchProduct_GLCode']
            : 0;
    this.fk_Customer_ReceiveProductGlCode =
        json.containsKey('fk_Customer_ReceiveProductGlCode')
            ? json['fk_Customer_ReceiveProductGlCode']
            : 0;
    this.fk_Customer_DispatchGlCode =
    json.containsKey('fk_Customer_DispatchGlCode')
        ? json['fk_Customer_DispatchGlCode']
        : 0;
    this.fk_Customer_ReceiveGlCode =
    json.containsKey('fk_Customer_ReceiveGlCode')
        ? json['fk_Customer_ReceiveGlCode']
        : 0;
    this.intRowNo = json['intRowNo'];
    this.varSticker = json['varSticker'];
    this.chrValid = json['chrValid'];
    this.chrValidSave =
        json.containsKey('chrValidSave') ? json['chrValidSave'] : '';
    this.chrPallet = json.containsKey('chrPallet') ? json['chrPallet'] : 'N';
    this.intNoOfSticker =
        json.containsKey('intNoOfSticker') ? json['intNoOfSticker'] : 0;
  }
}

class PalletModel {
  String stickerNo;
  String palletNo;
  int fkPalletGlCode;
  String chrPallet;
  String scanType = 'P';
  String removed = 'N';

  PalletModel(
      {this.stickerNo,
      this.palletNo,
      this.fkPalletGlCode,
      this.chrPallet,
      this.scanType});

  PalletModel.fromMap(Map<String, dynamic> json) {
    this.stickerNo =
        json.containsKey('varStickerNo') ? json['varStickerNo'] : '';
    this.palletNo = json.containsKey('varPalletNo') ? json['varPalletNo'] : '';
    this.fkPalletGlCode = json['fk_PalletGlCode'];
    this.chrPallet = json['chrPallet'];
  }
}

class PalletCheckBreakModel {
  int fkPalletGlCode;
  String chrPallet;

  PalletCheckBreakModel(this.fkPalletGlCode, this.chrPallet);
}

class HalfTransactionModule {
  bool isValid;
  String tranModuleName;

  HalfTransactionModule(this.isValid, this.tranModuleName);
}

class ScanningScreen extends StatefulWidget {
  @override
  ScanningScreenState createState() => ScanningScreenState();
}

class ScanningScreenState extends State<ScanningScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;

  //isFocusNodeEnable = true,
  String dropdownValue;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '';
  int receiveCount = 0;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  List<ScanDataModel> scanDataList;
  TextEditingController serialNoTextController;

//  FocusNode _serialNoFocus;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false, isVisible = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isStickerFullLimit = true;
  bool isLaserScanLoad = false;
  Flushbar flushbar;
  String menufacturer = '';

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    //isSaveClickEnable = true;
    scanDataList = List();
    _battery = EcpSyncPlugin();
    mUtils = Utils();

    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    pushNotificationServices = PushNotificationServices(this);

    serialNoTextController = TextEditingController();

    init();
  }

  void init() async {
    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullname = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullname != null ? fullname : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    String userType = await sharedPrefs.getString(PREF_USER_TYPE);
    if (userType.contains('E')) {
      isSync = false;
    } else {
      isSync = true;
    }

    String screenState = await sharedPrefs.getString(PREF_SCREEN_STATE);
    if (screenState == TAG_DISPATCH) {
      isReceiveScreen = false;
      isVisible = true;
      topHeaderImage = 'assets/dispatch_icon.png';
    } else if (screenState == TAG_STOCK_TRANSFER) {
      isReceiveScreen = false;
      isVisible = true;
      topHeaderImage = 'assets/stock_transfer_small_top.png';
    } else if (screenState == TAG_SALES_RETURN) {
      isReceiveScreen = false;
      isVisible = true;
      topHeaderImage = 'assets/sidebar_placegoodsreturn.png';
    } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
      isReceiveScreen = false;
      isVisible = true;
      topHeaderImage = 'assets/edit_do_icon.png';
    } else if (screenState == TAG_ADD_DAMAGE_STOCK) {
      isReceiveScreen = false;
      isVisible = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_REMOVE_DAMAGE_STOCK) {
      isReceiveScreen = false;
      isVisible = false;
      topHeaderImage = 'assets/damaged_icon.png';
    } else if (screenState == TAG_RECEIVE) {
      isReceiveScreen = true;
      isVisible = true;
      topHeaderImage = 'assets/receive_icon.png';
    } else if (screenState == TAG_FOC) {
      isReceiveScreen = false;
      isVisible = false;
      topHeaderImage = 'assets/foc_icon.png';
    } else if (screenState == TAG_SCRAP_STOCK) {
      isReceiveScreen = false;
      isVisible = false;
      topHeaderImage = 'assets/scrap_big.png';
    } else if (screenState == TAG_CONSUME_STOCK) {
      isReceiveScreen = false;
      isVisible = false;
      topHeaderImage = 'assets/consume_big.png';
    }

    if (subTitle.isEmpty) {
      subTitle = getTitleName(screenState);
    }

    int fkCustomerDispatchGlCode =
    await sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE);
    await loadScanRecordList(fkCustomerDispatchGlCode);

    receiveCount = await sharedPrefs.getInt(PREF_RECEIVE_COUNT);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) async {
      try {
        print('=======state=======${state.toString()}');
        if (state['type'] == '11') {
          var detailsData = state['Details'];
          final dynamic lists = json.decode(detailsData);
          await checkPallet(lists, 0);
        }
      } catch (e) {
        print(e.toString());
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await _battery.hideKeyboardPlugin();

    if (mounted) {
      setState(() {});
    }
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_CONSUME_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_consume');
    } else if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_FOC) {
      return LocaleUtils.getString(mContext, 'tag_foc');
    } else if (tagName == TAG_SCRAP_STOCK) {
      return LocaleUtils.getString(mContext, 'Scrap');
    } else {
      return tagName;
    }
  }

  Future<bool> showPalletBreakPopup(String stickerNo) async {
    flushbar = await Flushbar<bool>(
      title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
      message:
      '${LocaleUtils.getString(
          mContext, 'pallet_break_first')} $stickerNo ${LocaleUtils.getString(
          mContext, 'pallet_break_second')}',
      icon: Icon(
        Icons.info_outline,
        color: Colors.blue,
      ),
      duration: Duration(seconds: 10),
      mainButton: FlatButton(
        onPressed: () {
          flushbar.dismiss(true);
        },
        child: Text(
          '${LocaleUtils.getString(mContext, 'yes')}',
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );

    flushbar
      ..onStatusChanged = (FlushbarStatus status) {
        switch (status) {
          case FlushbarStatus.SHOWING:
            {
              print('====SHOWING=====');
              isLaserScanLoad = true;
              break;
            }
          case FlushbarStatus.IS_APPEARING:
            {
              print('====IS_APPEARING=====');
              isLaserScanLoad = true;
              break;
            }
          case FlushbarStatus.IS_HIDING:
            {
              print('====IS_HIDING=====');
              isLaserScanLoad = false;
              break;
            }
          case FlushbarStatus.DISMISSED:
            {
              print('====DISMISSED=====');
              isLaserScanLoad = false;
              break;
            }
        }
      };
    return flushbar.show(context);
  }

  Future checkPallet(dynamic lists, int load) async {
    //print('lists========${lists.toString()}');
    List<String> _stickerList = List();
    List<String> palletList = List();
    List<PalletModel> stickerModelList = List();
    List<PalletModel> palletModelList = List();
    int isPalletBreakToast = load;
    isStickerFullLimit = true;
    if (lists.length > 0) {
      for (var j in lists) {
        if (j.toString().trim().isNotEmpty) {
          List<String> code = j.toString().split("/");
          print('====F CODE=====${code.toString()}');
          if (code.length > 1) {
            if (code[1].toString() == '31') {
              if (!palletList.contains(code[0].toString().toUpperCase())) {
                palletList.add(code[0].toString().toUpperCase());
              }
            } else if (code[1].toString() == '21') {
              if (!_stickerList.contains(code[0].toString().toUpperCase())) {
                _stickerList.add(code[0].toString().toUpperCase());
              }
            }
          } else {
            //single scan
            await databaseHelper
                .checkPalletValid(j.toString().toUpperCase())
                .then((bool isValid) {
              print('==checkPallet==isValid======$isValid');
              if (isValid) {
                if (!palletList.contains(j.toString().toUpperCase())) {
                  palletList.add(j.toString().toUpperCase());
                }
              } else {
                if (!_stickerList.contains(code[0].toString().toUpperCase())) {
                  _stickerList.add(j.toString().toUpperCase());
                }
              }
            });
          }
        }
      }
      String breakPalletGlCodes = "";

      await Future.forEach(_stickerList, (String s) async {
        print("===Sticker====$s");
        await sharedPrefs
            .getString(PREF_SCREEN_STATE)
            .then((String screen) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fkDispachGlCode) async {
            await sharedPrefs
                .getInt(PREF_FK_RECEIVE_GL_CODE)
                .then((int fkReceiveGlCode) async {
              if (screen == TAG_DISPATCH ||
                  screen.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
                  screen == TAG_STOCK_TRANSFER ||
                  screen == TAG_SALES_RETURN ||
                  screen == TAG_FOC) {
                await databaseHelper
                    .checkStickerValid_(s, fkDispachGlCode)
                    .then((bool isValid) async {
                  print('======isValid====$isValid');
                  if (isValid) {
                    int fkMainCustomerGlCode =
                    await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
                    HalfTransactionModule halfTransactionModule =
                    await databaseHelper
                        .checkHalfTransactionFromOtherModule(
                        screen, fkMainCustomerGlCode, s);
                    if (halfTransactionModule.isValid) {
                      await databaseHelper
                          .checkStickerPalletBreak(
                          s,
                          fkDispachGlCode,
                          breakPalletGlCodes.isEmpty
                              ? '0'
                              : breakPalletGlCodes)
                          .then((int isBreak) async {
                        if (isBreak > 0) {
                          bool isPalletBreak = await showPalletBreakPopup(s);
                          if (isPalletBreak != null && isPalletBreak) {
                            if (breakPalletGlCodes.isEmpty) {
                              breakPalletGlCodes = '$isBreak';
                            } else {
                              breakPalletGlCodes =
                              '$breakPalletGlCodes,$isBreak';
                            }
                            PalletModel palletModel = PalletModel(
                                stickerNo: s,
                                palletNo: '',
                                fkPalletGlCode: 0,
                                chrPallet: 'N',
                                scanType: 'S');
                            stickerModelList.add(palletModel);
                          }
                        } else {
                          PalletModel palletModel = PalletModel(
                              stickerNo: s,
                              palletNo: '',
                              fkPalletGlCode: 0,
                              chrPallet: 'N',
                              scanType: 'S');
                          stickerModelList.add(palletModel);
                        }
                      });
                    } else {
                      isLaserScanLoad = false;
                      _showSnackBar(
                          '${LocaleUtils.getString(mContext,
                              'label_already_scan_another_module_half_tran')} ${halfTransactionModule
                              .tranModuleName}');
                    }
                  } else {
                    isLaserScanLoad = false;
                    _showSnackBar(
                        LocaleUtils.getString(mContext, 'LabelAlreadyExist'));
                  }
                });
              } else if (screen == TAG_RECEIVE) {
                await databaseHelper
                    .checkStickerPalletBreak_(s, fkReceiveGlCode,
                        breakPalletGlCodes.isEmpty ? '0' : breakPalletGlCodes)
                    .then((int isBreak) async {
                  if (isBreak > 0) {
                    bool isPalletBreak = await showPalletBreakPopup(s);
                    if (isPalletBreak != null && isPalletBreak) {
                      if (breakPalletGlCodes.isEmpty) {
                        breakPalletGlCodes = '$isBreak';
                      } else {
                        breakPalletGlCodes = '$breakPalletGlCodes,$isBreak';
                      }
                      PalletModel palletModel = PalletModel(
                          stickerNo: s,
                          palletNo: '',
                          fkPalletGlCode: 0,
                          chrPallet: 'N',
                          scanType: 'S');
                      stickerModelList.add(palletModel);
                    }
                  } else {
                    PalletModel palletModel = PalletModel(
                        stickerNo: s,
                        palletNo: '',
                        fkPalletGlCode: 0,
                        chrPallet: 'N',
                        scanType: 'S');
                    stickerModelList.add(palletModel);
                  }
                });
              } else {
                if (screen == TAG_ADD_DAMAGE_STOCK) {
                  int fkMainCustomerGlCode =
                  await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
                  HalfTransactionModule halfTransactionModule =
                  await databaseHelper.checkHalfTransactionFromOtherModule(
                      screen, fkMainCustomerGlCode, s);
                  if (halfTransactionModule.isValid) {
                    await databaseHelper
                        .checkStickerPalletBreakForDamage(
                        s,
                        breakPalletGlCodes.isEmpty
                            ? '0'
                            : breakPalletGlCodes)
                        .then((int isBreak) async {
                      if (isBreak > 0) {
                        bool isPalletBreak = await showPalletBreakPopup(s);
                        if (isPalletBreak != null && isPalletBreak) {
                          if (breakPalletGlCodes.isEmpty) {
                            breakPalletGlCodes = '$isBreak';
                          } else {
                            breakPalletGlCodes = '$breakPalletGlCodes,$isBreak';
                          }
                          PalletModel palletModel = PalletModel(
                              stickerNo: s,
                              palletNo: '',
                              fkPalletGlCode: 0,
                              chrPallet: 'N',
                              scanType: 'S');
                          stickerModelList.add(palletModel);
                        }
                      } else {
                        PalletModel palletModel = PalletModel(
                            stickerNo: s,
                            palletNo: '',
                            fkPalletGlCode: 0,
                            chrPallet: 'N',
                            scanType: 'S');
                        stickerModelList.add(palletModel);
                      }
                    });
                  } else {
                    isLaserScanLoad = false;
                    _showSnackBar(
                        '${LocaleUtils.getString(mContext,
                            'label_already_scan_another_module_half_tran')} ${halfTransactionModule
                            .tranModuleName}');
                  }
                } else if (screen == TAG_SCRAP_STOCK) {
                  int fkMainCustomerGlCode =
                  await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
                  HalfTransactionModule halfTransactionModule =
                  await databaseHelper.checkHalfTransactionFromOtherModule(
                      screen, fkMainCustomerGlCode, s);
                  if (halfTransactionModule.isValid) {
                    await databaseHelper
                        .checkStickerPalletBreakForScrap(
                        s,
                        breakPalletGlCodes.isEmpty
                            ? '0'
                            : breakPalletGlCodes)
                        .then((int isBreak) async {
                      if (isBreak > 0) {
                        bool isPalletBreak = await showPalletBreakPopup(s);
                        if (isPalletBreak != null && isPalletBreak) {
                          if (breakPalletGlCodes.isEmpty) {
                            breakPalletGlCodes = '$isBreak';
                          } else {
                            breakPalletGlCodes = '$breakPalletGlCodes,$isBreak';
                          }
                          PalletModel palletModel = PalletModel(
                              stickerNo: s,
                              palletNo: '',
                              fkPalletGlCode: 0,
                              chrPallet: 'N',
                              scanType: 'S');
                          stickerModelList.add(palletModel);
                        }
                      } else {
                        PalletModel palletModel = PalletModel(
                            stickerNo: s,
                            palletNo: '',
                            fkPalletGlCode: 0,
                            chrPallet: 'N',
                            scanType: 'S');
                        stickerModelList.add(palletModel);
                      }
                    });
                  } else {
                    isLaserScanLoad = false;
                    _showSnackBar(
                        '${LocaleUtils.getString(mContext,
                            'label_already_scan_another_module_half_tran')} ${halfTransactionModule
                            .tranModuleName}');
                  }
                } else if (screen == TAG_CONSUME_STOCK) {
                  int fkMainCustomerGlCode =
                  await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
                  HalfTransactionModule halfTransactionModule =
                  await databaseHelper.checkHalfTransactionFromOtherModule(
                      screen, fkMainCustomerGlCode, s);
                  if (halfTransactionModule.isValid) {
                    await databaseHelper
                        .checkStickerPalletBreakForConsume(
                        s,
                        breakPalletGlCodes.isEmpty
                            ? '0'
                            : breakPalletGlCodes)
                        .then((int isBreak) async {
                      if (isBreak > 0) {
                        bool isPalletBreak = await showPalletBreakPopup(s);
                        if (isPalletBreak != null && isPalletBreak) {
                          if (breakPalletGlCodes.isEmpty) {
                            breakPalletGlCodes = '$isBreak';
                          } else {
                            breakPalletGlCodes = '$breakPalletGlCodes,$isBreak';
                          }
                          PalletModel palletModel = PalletModel(
                              stickerNo: s,
                              palletNo: '',
                              fkPalletGlCode: 0,
                              chrPallet: 'N',
                              scanType: 'S');
                          stickerModelList.add(palletModel);
                        }
                      } else {
                        PalletModel palletModel = PalletModel(
                            stickerNo: s,
                            palletNo: '',
                            fkPalletGlCode: 0,
                            chrPallet: 'N',
                            scanType: 'S');
                        stickerModelList.add(palletModel);
                      }
                    });
                  } else {
                    isLaserScanLoad = false;
                    _showSnackBar(
                        '${LocaleUtils.getString(mContext,
                            'label_already_scan_another_module_half_tran')} ${halfTransactionModule
                            .tranModuleName}');
                  }
                } else {
                  PalletModel palletModel = PalletModel(
                      stickerNo: s,
                      palletNo: '',
                      fkPalletGlCode: 0,
                      chrPallet: 'N',
                      scanType: 'S');
                  stickerModelList.add(palletModel);
                }
              }
            });
          });
        });
      });

      if (stickerModelList.isNotEmpty) {
        if (load == 0) {
          await checkSticker(stickerModelList, isPalletBreakToast);
        } else {
          List<PalletModel> stickerModelListTemp = List();
          await Future.forEach(stickerModelList, (PalletModel palletM) async {
            if (stickerModelListTemp.isNotEmpty) {
              await Future.forEach(stickerModelListTemp,
                  (PalletModel palletMemp) {
                if (palletMemp.stickerNo.toUpperCase() ==
                    palletM.stickerNo.toUpperCase()) {
                } else {
                  stickerModelListTemp.add(palletM);
                }
              });
            } else {
              stickerModelListTemp.add(palletM);
            }
          });

          var json = jsonEncode(
              stickerModelListTemp.map((e) => e.stickerNo.toString()).toList());
          print('*****stickerModelListTemp*****${json.toString()}');
          await checkSticker(stickerModelListTemp, isPalletBreakToast);
        }
      }

      await Future.forEach(palletList, (String p) async {
        print("===Pallet====$p");
        await sharedPrefs
            .getString(PREF_SCREEN_STATE)
            .then((String screen) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fkDispachGlCode) async {
            await sharedPrefs
                .getInt(PREF_FK_RECEIVE_GL_CODE)
                .then((int fkReceiveGlCode) async {
              if (screen == TAG_DISPATCH ||
                  screen.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
                  screen == TAG_STOCK_TRANSFER ||
                  screen == TAG_SALES_RETURN ||
                  screen == TAG_FOC) {
                int fkMainCustomerGlCode =
                await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
                HalfTransactionModule halfTransactionModule =
                await databaseHelper.checkHalfTransactionFromOtherModule(
                    screen, fkMainCustomerGlCode, p);
                if (halfTransactionModule.isValid) {
                  bool isValidInvalidPallet = await databaseHelper
                      .validInvalidPallet(p, fkDispachGlCode);
                  bool isValid =
                  await databaseHelper.validPallet(p, fkDispachGlCode);
                  print('=====isValid=$isValid=====');
                  print('=====isValidInvalidPallet=$isValidInvalidPallet=====');
                  if (isValid && isValidInvalidPallet) {
                    await databaseHelper
                        .checkPalletBreak(p.toString())
                        .then((PalletCheckBreakModel isBreak) async {
                      if (isBreak != null) {
                        if (isBreak.chrPallet == 'Y') {
                          isPalletBreakToast = 2;
                          _showSnackBar(
                              LocaleUtils.getString(mContext, 'pallet_break'));
                          isLaserScanLoad = false;
                        } else {
                          _loading = true;
                          dismissProgressHUD();
                          await databaseHelper
                              .getStickerFromPallet(isBreak.fkPalletGlCode)
                              .then((List<PalletModel> list) async {
                            print('==SIZE===${list.length}');
                            //palletModelList.addAll(list);
                            await validStickerForPallet(
                                p.toString(),
                                isBreak.fkPalletGlCode,
                                isPalletBreakToast,
                                isBreak.chrPallet,
                                list.length);
                          });
                        }
                      } else {
                        PalletModel palletModel = PalletModel(
                            stickerNo: p,
                            palletNo: '',
                            fkPalletGlCode: 0,
                            chrPallet: 'N',
                            scanType: 'S');
                        palletModelList.add(palletModel);
                      }
                    });
                  } else {
                    isPalletBreakToast = 3;
                    _showSnackBar(LocaleUtils.getString(
                        mContext, 'pallet_sticker_scan_break'));
                    isLaserScanLoad = false;
                  }
                } else {
                  isLaserScanLoad = false;
                  _showSnackBar(
                      '${LocaleUtils.getString(mContext,
                          'label_already_scan_another_module_half_tran')} ${halfTransactionModule
                          .tranModuleName}');
                }
              } else if (screen == TAG_RECEIVE) {
                bool isValidInvalidPallet = await databaseHelper
                    .validInvalidPalletForReceive(p, fkReceiveGlCode);
                bool isValid = await databaseHelper.validPalletForReceive(
                    p, fkReceiveGlCode);

                if (isValid && isValidInvalidPallet) {
                  await databaseHelper
                      .checkPalletBreak(p)
                      .then((PalletCheckBreakModel isBreak) async {
                    if (isBreak != null) {
                      if (isBreak.chrPallet == 'Y') {
                        isPalletBreakToast = 2;
                        _showSnackBar(
                            LocaleUtils.getString(mContext, 'pallet_break'));
                        isLaserScanLoad = false;
                      } else {
                        _loading = true;
                        dismissProgressHUD();
                        await databaseHelper
                            .getStickerFromPallet(isBreak.fkPalletGlCode)
                            .then((List<PalletModel> list) async {
                          print('==SIZE===${list.length}');
                          //palletModelList.addAll(list);
                          await validStickerForPallet(
                              p.toString(),
                              isBreak.fkPalletGlCode,
                              isPalletBreakToast,
                              isBreak.chrPallet,
                              list.length);
                        });
                      }
                    } else {
                      PalletModel palletModel = PalletModel(
                          stickerNo: p,
                          palletNo: '',
                          fkPalletGlCode: 0,
                          chrPallet: 'N',
                          scanType: 'S');
                      palletModelList.add(palletModel);
                    }
                  });
                } else {
                  isPalletBreakToast = 3;
                  _showSnackBar(LocaleUtils.getString(
                      mContext, 'pallet_sticker_scan_break'));
                  isLaserScanLoad = false;
                }
//                });
              } else if (screen == TAG_ADD_DAMAGE_STOCK) {
                _showSnackBar(
                    LocaleUtils.getString(mContext, 'pallet_not_allow'));
                isLaserScanLoad = false;
              } else if (screen == TAG_REMOVE_DAMAGE_STOCK) {
                _showSnackBar(
                    LocaleUtils.getString(mContext, 'pallet_not_allow'));
                isLaserScanLoad = false;
              } else if (screen == TAG_SCRAP_STOCK) {
                _showSnackBar(
                    LocaleUtils.getString(mContext, 'pallet_not_allow_scrap'));
                isLaserScanLoad = false;
              } else if (screen == TAG_CONSUME_STOCK) {
                _showSnackBar(LocaleUtils.getString(
                    mContext, 'pallet_not_allow_consume'));
                isLaserScanLoad = false;
              } else {
                PalletModel palletModel = PalletModel(
                    stickerNo: p,
                    palletNo: '',
                    fkPalletGlCode: 0,
                    chrPallet: 'N',
                    scanType: 'S');
                palletModelList.add(palletModel);
              }
            });
          });
        });
      });

      if (isPalletBreakToast == 2) {
//        _showSnackBar(LocaleUtils.getString(mContext, 'pallet_break'));
      } else if (isPalletBreakToast == 3) {
//        _showSnackBar(
//            LocaleUtils.getString(mContext, 'pallet_sticker_scan_break'));
      } else {
        if (palletModelList.isNotEmpty) {
          await checkSticker(palletModelList, isPalletBreakToast);
        }
      }
    }
  }

  void _onTextChanged() async {
//    if (isFocusNodeEnable) {
    final String value = serialNoTextController.text ?? '';
    if (value.isEmpty) {
//        if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
//          _serialNoFocus.unfocus();
//          FocusScope.of(mContext).requestFocus(_serialNoFocus);
//        }
    } else {
      if (value
          .trim()
          .length >= int.parse(globals.BARCODE_LENGTH)) {
        print('=====value=======$value');
        if (!isLaserScanLoad) {
          final List<String> scanList = List();
          isLaserScanLoad = true;
          await _battery.checkBarCode(value).then((String serialNo) async {
            if (!scanList.contains(serialNo)) {
              scanList.add(serialNo);
            }
            serialNoTextController.text = '';
          });
          await checkPallet(scanList, 1);
        } else {
          serialNoTextController.text = '';
        }
      } else {
//          if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
//            FocusScope.of(mContext).requestFocus(_serialNoFocus);
//          }
      }
    }
//    } else {
//      serialNoTextController.text = '';
//    }
  }

  @override
  void dispose() {
    super.dispose();
    _timer.cancel();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void redirectDispatchThirdScreen(bool isBackPress) {
    sharedPrefs.getBool(IS_CHANGE_SCANNING_STATE).then((bool isChange) {
      if (isChange) {
        print('=====IS_CHANGE_SCANNING_STATE======');
        sharedPrefs.setBool(IS_CHANGE_SCANNING_STATE, false);
        Navigator.pop(mContext, true);
      } else {
        if (isBackPress) {
          print('=====isBackPress==IF====');
          if (Navigator.canPop(mContext)) {
            Navigator.pop(mContext);
          } else {
            final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
            Navigator.pushAndRemoveUntil(
                mContext, route, (Route<dynamic> route) => false);
          }
        } else {
          print('=====isBackPress===ELSE===');
          sharedPrefs.getString(PREF_SCREEN_STATE).then((String screen) {
            if (screen == TAG_DISPATCH || screen == TAG_FOC) {
              final Route route = CupertinoPageRoute(
                  builder: (context) =>
                      DispatchThirdScreen(
                          isRedirectToEditScreen: false, subTitleTxt: ''));
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_RECEIVE) {
              final Route route = CupertinoPageRoute(
                  builder: (context) => ReceiveThirdScreen());
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_STOCK_TRANSFER ||
                screen == TAG_SALES_RETURN) {
              final Route route = CupertinoPageRoute(
                  builder: (context) =>
                      DispatchThirdScreen(
                          isRedirectToEditScreen: false, subTitleTxt: ''));
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_ADD_DAMAGE_STOCK) {
              final Route route = CupertinoPageRoute(
                  builder: (context) => DamageStockDetailsScreen());
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_REMOVE_DAMAGE_STOCK) {
              final Route route = CupertinoPageRoute(
                  builder: (context) => DamageStockDetailsScreen());
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_SCRAP_STOCK) {
              final Route route = CupertinoPageRoute(
                  builder: (context) => ScrapStockDetailsScreen());
              Navigator.pushReplacement(mContext, route);
            } else if (screen == TAG_CONSUME_STOCK) {
              final Route route = CupertinoPageRoute(
                  builder: (context) => ConsumeStockThirdScreen());
              Navigator.pushReplacement(mContext, route);
            }
          });
        }
      }
    });
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(mContext).requestFocus(FocusNode());
        List<String> scanList = List();
        scanList.add(serialNoTextController.text);
        serialNoTextController.text = '';
        //checkSticker(scanList, true);
        checkPallet(scanList, 1);
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void saveBtnCall() {
    redirectDispatchThirdScreen(false);
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
        'false',
        'true',
        'false',
        '#004a96',
        PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
        LocaleUtils.getString(mContext, 'next'),
        PROJECT_NAME == 'BASF_HK'
            ? LocaleUtils.getString(mContext, 'scan_your_label_here')
            : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {
      //_showSnackBar(result.toString());
//      isSaveClickEnable = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    print('*****************isFocusNodeEnable*******');

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'EnterSrNumber'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    final cameraIcon = InkWell(
      child: Padding(
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Icon(Icons.camera_alt, color: Colors.white)),
      onTap: () {
        startScanBtnCall();
      },
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Save'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: saveBtnCall,
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          FocusScope.of(mContext).requestFocus(FocusNode());
          redirectDispatchThirdScreen(true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              FocusScope.of(mContext).requestFocus(FocusNode());
              redirectDispatchThirdScreen(true);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, subTitle, topHeaderImage, receiveCount),
                        Visibility(
                          child: CustomTopSubHeaderBar(
                              SUB_HEADER_SCANNING, isReceiveScreen),
                          visible: isVisible,
                        ),
                        Container(
                          margin:
                          const EdgeInsets.only(top: 20, right: 20, left: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Form(
                                  key: _formKey,
                                  autovalidate: _autoValidate,
                                  child: Container(
                                    height: 42,
                                    width: screenSize.width,
                                    padding:
                                    const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: serialNumberTxt,
                                  ),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                child: addButton,
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                height: 45,
                                decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  color: const Color(colorPrimary),
                                ),
                                child: cameraIcon,
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: const Color(bgColor),
                            child: Card(
                              elevation: 7,
                              margin: const EdgeInsets.only(
                                  top: 10, right: 15, left: 15),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Container(
                                    height: 40,
                                    padding: const EdgeInsets.only(left: 10),
                                    alignment: Alignment.centerLeft,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary)),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'ScannedSrNo'),
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w300,
                                        fontFamily: 'helvetica',
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                  isStickerSelected()
                                      ? Container(
                                      color: const Color(colorAccent),
                                      height: 40,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Expanded(
                                              child: InkWell(
                                                child: Center(
                                                  child: Container(
                                                    width: 27,
                                                    height: 27,
                                                    decoration: BoxDecoration(
                                                        color: isSelectAll
                                                            ? const Color(
                                                            colorPrimary)
                                                            : const Color(
                                                            colorAccent),
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            color: const Color(
                                                                colorPrimary),
                                                            width: 1)),
                                                    child: isSelectAll
                                                        ? Icon(
                                                      Icons.done,
                                                      size: 15.0,
                                                      color: Colors.white,
                                                    )
                                                        : Container(),
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll(false);
                                                  }
                                                },
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                child: Text(
                                                  LocaleUtils.getString(
                                                      mContext, 'select_all'),
                                                  style: TextStyle(
                                                    fontSize: 15.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: 'helvetica',
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                  textAlign: TextAlign.left,
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll(false);
                                                  }
                                                },
                                              ),
                                              flex: 2,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                onTap: () {
                                                  removeMultiSelectedSticker();
                                                },
                                                child: isStickerSelected()
                                                    ? Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Icon(
                                                    Icons.delete,
                                                    size: 25.0,
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                )
                                                    : Container(),
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ))
                                      : Container(),
                                  Expanded(
                                    child: Container(
                                      child: ListView.builder(
                                        itemCount: scanDataList.length,
                                        shrinkWrap: true,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return !scanDataList[index].isDeleted
                                              ? InkWell(
                                              onTap: () {
                                                if (isStickerSelected()) {
                                                  setSelection(index);
                                                }
                                              },
                                              onLongPress: () {
                                                setSelection(index);
                                              },
                                              child: Container(
                                                color: Colors.white,
                                                child: Column(
                                                  children: <Widget>[
                                                    Container(
                                                      height: 40,
                                                      width: screenSize.width,
                                                      color: scanDataList[index]
                                                          .isMultiDeleted
                                                          ? Colors.grey[200]
                                                          : Colors.white,
                                                      child: Row(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                        children: <Widget>[
                                                          Expanded(
                                                            child: Center(
                                                                child: scanDataList[index]
                                                                    .isMultiDeleted
                                                                    ? Container(
                                                                  width:
                                                                  27,
                                                                  height:
                                                                  27,
                                                                  decoration:
                                                                  BoxDecoration(
                                                                    color: const Color(
                                                                        colorPrimary),
                                                                    shape: BoxShape
                                                                        .circle,
                                                                    //borderRadius: BorderRadius.all(Radius.circular(10))
                                                                  ),
                                                                  child:
                                                                  Icon(
                                                                    Icons
                                                                        .done,
                                                                    size: 15.0,
                                                                    color: Colors
                                                                        .white,
                                                                  ),
                                                                ) : Text(
                                                                    '#${scanDataList[index]
                                                                        .intRows
                                                                        .toString()}',
                                                                    style: TextStyle(
                                                                        fontSize:
                                                                        14.0,
                                                                        fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                        fontFamily:
                                                                        'helvetica',
                                                                        color: scanDataList[index]
                                                                            .chrValid
                                                                            .contains(
                                                                            'N')
                                                                            ? Colors
                                                                            .red
                                                                            : Colors
                                                                            .black))),
                                                            flex: 1,
                                                          ),
                                                          Expanded(
                                                            child: Align(
                                                              child: Text(
                                                                  scanDataList[index]
                                                                      .chrPallet ==
                                                                      'Y'
                                                                      ? '${scanDataList[index]
                                                                      .varSticker} - (${scanDataList[index]
                                                                      .intNoOfSticker})'
                                                                      : scanDataList[
                                                                  index]
                                                                      .varSticker,
                                                                  style: TextStyle(
                                                                      fontSize:
                                                                      14.0,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                      fontFamily:
                                                                      'helvetica',
                                                                      color: scanDataList[index]
                                                                          .chrValid
                                                                          .contains(
                                                                          'N')
                                                                          ? Colors
                                                                          .red
                                                                          : Colors
                                                                          .black)),
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                            ),
                                                            flex: 2,
                                                          ),
                                                          Expanded(
                                                            child:
                                                            !isStickerSelected()
                                                                ? Align(
                                                              child:
                                                              GestureDetector(
                                                                child: Icon(
                                                                    Icons
                                                                        .delete,
                                                                    color: scanDataList[index]
                                                                        .chrValid
                                                                        .contains(
                                                                        'N')
                                                                        ? Colors
                                                                        .red
                                                                        : Colors
                                                                        .black),
                                                                onTap:
                                                                    () {
//                                                        isFocusNodeEnable = false;
                                                                  removeSticker(
                                                                      scanDataList[index]
                                                                          .fk_Customer_DispatchProduct_GLCode,
                                                                      scanDataList[index]
                                                                          .fk_Customer_DispatchGlCode,
                                                                      scanDataList[index]
                                                                          .fk_Customer_ReceiveGlCode,
                                                                      scanDataList[index]
                                                                          .chrPallet,
                                                                      scanDataList[index]
                                                                          .varSticker,
                                                                      index);
                                                                },
                                                              ),
                                                              alignment:
                                                              Alignment
                                                                  .center,
                                                            )
                                                                : Container(),
                                                            flex: 1,
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(
                                                        height: 3,
                                                        color: Colors.black),
                                                  ],
                                                ),
                                              ))
                                              : Container();
                                        },
                                      ),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: screenSize.width,
                          height: 45,
                          child: saveButton,
                          margin: const EdgeInsets.all(15),
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void checkSticker(List<PalletModel> sticker, int toastStatus) async {
    _loading = true;
    dismissProgressHUD();

    String query = '';

    final StringBuffer stringBuilder = StringBuffer();
    for (int i = 0; i < sticker.length; i++) {
      stringBuilder.write("'");
      stringBuilder.write(sticker[i].stickerNo);
      if (i == (sticker.length - 1)) {
        stringBuilder.write("'");
      } else {
        stringBuilder.write("',");
      }
    }

    //if (sticker.length > 0) {}
    if (sticker.isNotEmpty) {
      await sharedPrefs.getString(PREF_SCREEN_STATE).then((String state) async {
        await sharedPrefs
            .getInt(PREF_FK_DISPATCH_GL_CODE)
            .then((int fk_Customer_DispatchGlCode) async {
          if (state == TAG_DISPATCH ||
              state.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
              state == TAG_STOCK_TRANSFER ||
              state == TAG_SALES_RETURN ||
              state == TAG_FOC) {
            query = "SELECT  CCDPD.varSticker AS varSticker,CCDPD.chrPallet,CCDPD.fk_PalletGlCode FROM CPM_Customer_Dispatch_Product_Details as CCDPD\n" +
                "WHERE CCDPD.fk_Customer_DispatchGlCode='${fk_Customer_DispatchGlCode.toString()}'\n" +
                "      AND CCDPD.varSticker IN (${stringBuilder.toString()})\n" +
                "      AND ifnull( CCDPD.chrActive, 'N' ) IN ('I','Y')";

            await validStickerCheck(
                query, toastStatus, sticker, fk_Customer_DispatchGlCode);
          } else if (state == TAG_RECEIVE) {
            await sharedPrefs
                .getInt(PREF_FK_RECEIVE_GL_CODE)
                .then((int fkReceiveGlCode) async {
              query = "SELECT CCRPD.intGlCode, CCRPD.varSticker AS varSticker,CCRPD.chrPallet,CCRPD.fk_PalletGlCode FROM CPM_Customer_Receive_Product_Details as CCRPD\n" +
                  "WHERE CCRPD.fk_Customer_ReceiveGlCode='$fkReceiveGlCode'\n" +
                  "      AND CCRPD.varSticker IN (${stringBuilder.toString()})\n" +
                  "      AND ifnull( CCRPD.chrActive, 'N' ) = 'Y'";

              await validStickerCheck(
                  query, toastStatus, sticker, fk_Customer_DispatchGlCode);
            });
          } else if (state == TAG_ADD_DAMAGE_STOCK) {
            await sharedPrefs
                .getString(PREF_DAMAGE_TRANS_CODE)
                .then((String damageTransCode) async {
              query = "SELECT CCSD.intGlCode, CCSD.varSticker AS varSticker,'N' as chrPallet,0 as fk_PalletGlCode FROM CPM_Customer_Sticker_Damage as CCSD\n" +
                  "WHERE CCSD.varTransactionCode='$damageTransCode'\n" +
                  "      AND CCSD.varSticker IN (${stringBuilder.toString()})\n" +
                  "      AND ifnull(CCSD.chrActive, 'N' ) = 'Y'\n" +
                  "      AND ifnull(CCSD.chrRemove, 'N' ) = 'N'";

              await validStickerCheck(
                  query, toastStatus, sticker, fk_Customer_DispatchGlCode);
            });
          } else if (state == TAG_REMOVE_DAMAGE_STOCK) {
            await sharedPrefs
                .getString(PREF_DAMAGE_TRANS_CODE)
                .then((String damageTransCode) async {
              query = "SELECT CCSD.intGlCode, CCSD.varSticker AS varSticker,'N' as chrPallet,0 as fk_PalletGlCode FROM CPM_Customer_Sticker_Damage_Remove as CCSD\n" +
                  "WHERE CCSD.varTransactionCode='$damageTransCode'\n" +
                  "      AND CCSD.varSticker IN (${stringBuilder.toString()})\n" +
                  "      AND ifnull(CCSD.chrActive, 'N' ) = 'Y'";
              await validStickerCheck(
                  query, toastStatus, sticker, fk_Customer_DispatchGlCode);
            });
          } else if (state == TAG_SCRAP_STOCK) {
            await sharedPrefs
                .getString(PREF_SCRAP_TRANS_CODE)
                .then((String scrapTransCode) async {
              query = "SELECT CCSS.intGlCode, CCSS.varSticker AS varSticker,'N' as chrPallet,0 as fk_PalletGlCode FROM CPM_Customer_Sticker_Scrap as CCSS\n" +
                  " WHERE CCSS.varTransactionCode='$scrapTransCode'\n" +
                  "      AND CCSS.varSticker IN (${stringBuilder.toString()})\n" +
                  "      AND ifnull(CCSS.chrActive, 'N' ) = 'Y'";

              await validStickerCheck(
                  query, toastStatus, sticker, fk_Customer_DispatchGlCode);
            });
          } else if (state == TAG_CONSUME_STOCK) {
            await sharedPrefs
                .getString(PREF_CONSUME_TRANS_CODE)
                .then((String scrapTransCode) async {
              query = "SELECT CCSC.intGlCode," +
                  "      CCSC.varSticker AS varSticker," +
                  "      'N' as chrPallet," +
                  "      0 as fk_PalletGlCode" +
                  "      FROM CPM_Customer_Sticker_Consume as CCSC\n" +
                  "      WHERE CCSC.varTransactionCode='$scrapTransCode'\n" +
                  "      AND CCSC.varSticker IN (${stringBuilder.toString()})\n" +
                  "      AND ifnull(CCSC.chrActive, 'N' ) = 'Y'";

              await validStickerCheck(
                  query, toastStatus, sticker, fk_Customer_DispatchGlCode);
            });
          }
        });
      });
    }
  }

  void validStickerCheck(String QUERY, int toastStatus,
      List<PalletModel> sticker, int fk_Customer_DispatchGlCode) async {
    List<String> checkStickerList = List();

    await databaseHelper
        .checkSticker(QUERY)
        .then((List<String> checkList) async {
      checkStickerList.addAll(checkList);

      if (checkStickerList.isNotEmpty) {
        if (toastStatus == 0) {
          _showSnackBar(LocaleUtils.getString(mContext, 'LabelAlreadyExist'));
        } else if (toastStatus == 1) {
          _showSnackBar(
              LocaleUtils.getString(mContext, 'SomeLabelAlreadyExist'));
        } else if (toastStatus == 2) {
          _showSnackBar(LocaleUtils.getString(mContext, 'pallet_break'));
        } else if (toastStatus == 3) {
          _showSnackBar(
              LocaleUtils.getString(mContext, 'pallet_sticker_scan_break'));
        }

        await Future.forEach(sticker, (PalletModel palletM) async {
          await Future.forEach(checkStickerList, (String palletString) {
            if (palletM.stickerNo.toUpperCase() == palletString.toUpperCase()) {
              //sticker.remove(palletM);
              palletM.removed = 'Y';
            }
          });
        });
      }
    });

    if (sticker.isNotEmpty) {
      await Future.forEach(sticker, (PalletModel palletM) async {
        if (palletM.removed == 'N') {
          await validSticker(palletM, toastStatus, "N");
        }
      });
      await loadScanRecordList(fk_Customer_DispatchGlCode);
    } else {
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
    }
  }

  void _showSnackBar(String text) {
    //_key.currentState.showSnackBar(SnackBar(content: Text(text)));
    Flushbar(
      //title:  "Hey Ninja",
      message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  String strPallet = "";
  int count = 0;

  void validSticker(
      PalletModel palletModel, int isLoad, String chrPallet) async {
    await sharedPrefs.getString(PREF_SCREEN_STATE).then((String state) async {
      if (state == TAG_DISPATCH ||
          state == TAG_STOCK_TRANSFER ||
          state == TAG_SALES_RETURN ||
          state == TAG_FOC) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validStickerDispatch(fk_Customer_DispatchGlCode,
                        fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel == null) {
                    await databaseHelper
                        .validSticker_Dispatch(fk_Customer_DispatchGlCode,
                            fkMainCustomerGLCode, palletModel.stickerNo)
                        .then((ValidStickerModel valStickerModel) async {
                      if (valStickerModel != null) {
                        int isAutoDispatchDOConfirmValid = 0;
                        /*
                        * For Auto Dispatch Confirm
                        * @globals.AUTO_DISPATCH_DO_CONFIRM
                        * */
                        if (state == TAG_DISPATCH &&
                            globals.AUTO_DISPATCH_DO_CONFIRM == 'N') {
                          await sharedPrefs
                              .getInt(PREF_FK_SOLD_TO_PARTY_GL_CODE)
                              .then((int fkSoldToPartyGlCode) async {
                            await sharedPrefs
                                .getInt(PREF_FK_LAST_DISPATCHED_TO)
                                .then((int fkShipToPartyGlCode) async {
                              await sharedPrefs
                                  .getString(PREF_DO_NO)
                                  .then((String doNo) async {
                                await databaseHelper
                                    .checkAutoDispatchDOConfirmValid(
                                        fk_Customer_DispatchGlCode,
                                        fkMainCustomerGLCode,
                                        fkSoldToPartyGlCode,
                                        fkShipToPartyGlCode,
                                        valStickerModel.fk_Product_SKUGlCode,
                                        doNo,
                                        valStickerModel.varBatch_No)
                                    .then((int ischeck) {
                                  print(
                                      '===checkAutoDispatchDOConfirmValid==return==$ischeck');
                                  isAutoDispatchDOConfirmValid = ischeck;
                                });
                              });
                            });
                          });
                        }

                        if (isAutoDispatchDOConfirmValid == 0) {
                          /*
                          * For Batch Validation
                          * @globals.BATCH_VALIDATION
                          * */
                          bool isBatchValid = true;

                          if (globals.BATCH_VALIDATION == 'Y' &&
                              (state == TAG_DISPATCH ||
                                  state == TAG_STOCK_TRANSFER ||
                                  state == TAG_FOC)) {
                            await databaseHelper
                                .batchValidation(
                                    valStickerModel.varBatch_No,
                                    fkMainCustomerGLCode,
                                    valStickerModel.fk_Product_SKUGlCode)
                                .then((bool isBatchValid1) {
                              isBatchValid = isBatchValid1;
                            });
                          }

                          if (isBatchValid) {
                            await databaseHelper
                                .getCountQueryDispatch(
                                    fk_Customer_DispatchGlCode)
                                .then((int countTemp) async {
                              print(
                                  '====chrPallet======${palletModel.chrPallet}');
                              if (palletModel.chrPallet == 'Y') {
                                if (strPallet != palletModel.palletNo) {
                                  count = countTemp + 1;
                                  strPallet = palletModel.palletNo;
                                }
                              } else {
                                count = countTemp + 1;
                              }

                              print('====strPallet==after===$strPallet');
                              print('====count==after===$count');

                              //await databaseHelper.

                              await databaseHelper
                                  .insertSticker(
                                      fk_Customer_DispatchGlCode,
                                      valStickerModel.fk_Product_SKUGlCode,
                                      palletModel.chrPallet,
                                      palletModel.fkPalletGlCode,
                                      valStickerModel.fk_StickerGlCode,
                                      palletModel.stickerNo,
                                      int.parse(initGlCode),
                                      'Y',
                                      'Y',
                                      syncCode,
                                      fkMainCustomerGLCode,
                                      count,
                                      palletModel.scanType)
                                  .then((int id) {
                                if (isLoad == 1) {
                                  loadScanRecordList(
                                      fk_Customer_DispatchGlCode);
                                }
                              });
                            });
                          } else {
                            if (isStickerFullLimit) {
                              _showSnackBar(LocaleUtils.getString(
                                  mContext, 'label_not_found_current_stock'));
                              isStickerFullLimit = false;
                            }
                          }
                        } else if (isAutoDispatchDOConfirmValid == 1) {
                          if (isStickerFullLimit) {
                            _showSnackBar(LocaleUtils.getString(
                                mContext, 'label_limit_exceeded'));
                            isStickerFullLimit = false;
                          }
                        } else if (isAutoDispatchDOConfirmValid == 2) {
                          if (isStickerFullLimit) {
                            _showSnackBar(LocaleUtils.getString(mContext,
                                'label_belong_to_current_dispatch_planning'));
                            isStickerFullLimit = false;
                          }
                        }
                      } else {
                        await databaseHelper
                            .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                            .then((int countTemp) async {
                          int count = countTemp + 1;
                          await databaseHelper
                              .insertSticker(
                                  fk_Customer_DispatchGlCode,
                                  0,
                                  palletModel.chrPallet,
                                  palletModel.fkPalletGlCode,
                                  0,
                                  palletModel.stickerNo,
                                  int.parse(initGlCode),
                                  'N',
                                  'Y',
                                  syncCode,
                                  fkMainCustomerGLCode,
                                  count,
                                  palletModel.scanType)
                              .then((int id) {
                            if (isLoad == 1) {
                              loadScanRecordList(fk_Customer_DispatchGlCode);
                            }
                          });
                        });
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                        .then((int countTemp) async {
                      int count = countTemp + 1;
                      await databaseHelper
                          .insertSticker(
                              fk_Customer_DispatchGlCode,
                              0,
                              palletModel.chrPallet,
                              palletModel.fkPalletGlCode,
                              0,
                              palletModel.stickerNo,
                              int.parse(initGlCode),
                              'N',
                              'Y',
                              syncCode,
                              fkMainCustomerGLCode,
                              count,
                              palletModel.scanType)
                          .then((int id) {
                        if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                        }
                      });
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validStickerDispatchForEditDO(fk_Customer_DispatchGlCode,
                        fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel == null) {
                    await databaseHelper
                        .validSticker_EditDO(fkMainCustomerGLCode,
                            fk_Customer_DispatchGlCode, palletModel.stickerNo)
                        .then((ValidStickerModel valStickerModel) async {
                      if (valStickerModel != null) {
                        int isAutoDispatchDOConfirmValid = 0;
                        if (state == TAG_DISPATCH &&
                            globals.AUTO_DISPATCH_DO_CONFIRM == 'N') {
                          await sharedPrefs
                              .getInt(PREF_FK_SOLD_TO_PARTY_GL_CODE)
                              .then((int fkSoldToPartyGlCode) async {
                            await sharedPrefs
                                .getInt(PREF_FK_LAST_DISPATCHED_TO)
                                .then((int fkShipToPartyGlCode) async {
                              await sharedPrefs
                                  .getString(PREF_DO_NO)
                                  .then((String doNo) async {
                                await databaseHelper
                                    .checkAutoDispatchDOConfirmValid(
                                        fk_Customer_DispatchGlCode,
                                        fkMainCustomerGLCode,
                                        fkSoldToPartyGlCode,
                                        fkShipToPartyGlCode,
                                        valStickerModel.fk_Product_SKUGlCode,
                                        doNo,
                                        valStickerModel.varBatch_No)
                                    .then((int ischeck) {
                                  isAutoDispatchDOConfirmValid = ischeck;
                                });
                              });
                            });
                          });
                        }
                        if (isAutoDispatchDOConfirmValid == 0) {
                          /*
                          * For Batch Validation
                          * @globals.BATCH_VALIDATION
                          * */
                          /*bool isBatchValid = true;
                          if (globals.BATCH_VALIDATION == 'Y') {
                            await databaseHelper
                                .batchValidation(
                                    valStickerModel.varBatch_No,
                                    fkMainCustomerGLCode,
                                    valStickerModel.fk_Product_SKUGlCode)
                                .then((bool isBatchValid1) {
                              isBatchValid = isBatchValid1;
                            });
                          }

                          if (isBatchValid) {*/

                          String maxDeletedSticker =
                          await databaseHelper.getMaxStickerIDForEditDO(
                              valStickerModel.fk_StickerGlCode,
                              fk_Customer_DispatchGlCode);
                          print('===maxDeletedSticker====$maxDeletedSticker');
                          if (maxDeletedSticker.isNotEmpty) {
                            await databaseHelper.releaseDeletedStickerForEditDO(
                                valStickerModel.fk_StickerGlCode,
                                fk_Customer_DispatchGlCode,
                                maxDeletedSticker,
                                false);
                          }

                          await databaseHelper
                              .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                              .then((int countTemp) async {
                            final int count = countTemp + 1;
                            await databaseHelper
                                .insertSticker(
                                fk_Customer_DispatchGlCode,
                                valStickerModel.fk_Product_SKUGlCode,
                                palletModel.chrPallet,
                                palletModel.fkPalletGlCode,
                                valStickerModel.fk_StickerGlCode,
                                palletModel.stickerNo,
                                int.parse(initGlCode),
                                'Y',
                                'I',
                                syncCode,
                                fkMainCustomerGLCode,
                                count,
                                palletModel.scanType)
                                .then((int id) {
                              if (isLoad == 1) {
                                loadScanRecordList(fk_Customer_DispatchGlCode);
                              }
                            });
                          });
                          /*} else {
                            if (isStickerFullLimit) {
                              _showSnackBar(LocaleUtils.getString(
                                  mContext, 'label_not_found_current_stock'));
                              isStickerFullLimit = false;
                            }
                          }*/
                        } else if (isAutoDispatchDOConfirmValid == 1) {
                          if (isStickerFullLimit) {
                            _showSnackBar(LocaleUtils.getString(
                                mContext, 'label_limit_exceeded'));
                            isStickerFullLimit = false;
                          }
                        } else if (isAutoDispatchDOConfirmValid == 2) {
                          if (isStickerFullLimit) {
                            _showSnackBar(LocaleUtils.getString(mContext,
                                'label_belong_to_current_dispatch_planning'));
                            isStickerFullLimit = false;
                          }
                        }
                      } else {
                        await databaseHelper
                            .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                            .then((int countTemp) async {
                          final int count = countTemp + 1;
                          await databaseHelper
                              .insertSticker(
                                  fk_Customer_DispatchGlCode,
                                  0,
                                  palletModel.chrPallet,
                                  palletModel.fkPalletGlCode,
                                  0,
                                  palletModel.stickerNo,
                                  int.parse(initGlCode),
                                  'N',
                                  'I',
                                  syncCode,
                                  fkMainCustomerGLCode,
                                  count,
                                  palletModel.scanType)
                              .then((int id) {
                            if (isLoad == 1) {
                              loadScanRecordList(fk_Customer_DispatchGlCode);
                            }
                          });
                        });
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                        .then((int countTemp) async {
                      final int count = countTemp + 1;
                      await databaseHelper
                          .insertSticker(
                              fk_Customer_DispatchGlCode,
                              0,
                              palletModel.chrPallet,
                              palletModel.fkPalletGlCode,
                              0,
                              palletModel.stickerNo,
                              int.parse(initGlCode),
                              'N',
                              'Y',
                              syncCode,
                              fkMainCustomerGLCode,
                              count,
                              palletModel.scanType)
                          .then((int id) {
                        if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                        }
                      });
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state == TAG_RECEIVE) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await sharedPrefs
                  .getInt(PREF_FK_RECEIVE_GL_CODE)
                  .then((int fkReceiveGlCode) async {
                await _battery.getUniqueNumber().then((String syncCode) async {
                  await databaseHelper
                      .validStickerReceive(fk_Customer_DispatchGlCode,
                          fkMainCustomerGLCode, palletModel.stickerNo)
                      .then((ValidStickerModel validStickerModel) async {
                    if (validStickerModel != null) {
                      await databaseHelper
                          .insertReceiveSticker(
                              fkReceiveGlCode,
                              validStickerModel.fk_Product_SKUGlCode,
                              palletModel.chrPallet,
                              palletModel.fkPalletGlCode,
                              validStickerModel.fk_StickerGlCode,
                              palletModel.stickerNo,
                              int.parse(initGlCode),
                              syncCode,
                              'Y')
                          .then((int id) {
                        if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                        }
                      });
                    } else {
                      //insert
                      await databaseHelper
                          .insertReceiveSticker(
                              fkReceiveGlCode,
                              0,
                              palletModel.chrPallet,
                              palletModel.fkPalletGlCode,
                              0,
                              palletModel.stickerNo,
                              int.parse(initGlCode),
                              syncCode,
                              'N')
                          .then((int id) {
                        if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                        }
                      });
                    }
                  });
                });
              });
            });
          });
        });
      } else if (state == TAG_ADD_DAMAGE_STOCK) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int fkMainCustomerGLCode) async {
            await sharedPrefs
                .getString(PREF_DAMAGE_TRANS_CODE)
                .then((String damageTransCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validDamageSticker(
                        fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel != null) {
                    await databaseHelper
                        .insertDamageSticker(
                            int.parse(initGlCode),
                            fkMainCustomerGLCode,
                            validStickerModel.fk_StickerGlCode,
                            palletModel.stickerNo,
                            syncCode,
                            'Y',
                            damageTransCode,
                            validStickerModel.fk_ReceivedFromGlCode)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .insertDamageSticker(
                            int.parse(initGlCode),
                            fkMainCustomerGLCode,
                            0,
                            palletModel.stickerNo,
                            syncCode,
                            'N',
                            damageTransCode,
                            0)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state == TAG_REMOVE_DAMAGE_STOCK) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int fkMainCustomerGLCode) async {
            await sharedPrefs
                .getString(PREF_DAMAGE_TRANS_CODE)
                .then((String damageTransCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validDamageStickerForRemove(
                        fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel != null) {
                    await databaseHelper
                        .insertDamageStickerForRemove(
                            int.parse(initGlCode),
                            fkMainCustomerGLCode,
                            validStickerModel.fk_StickerGlCode,
                            palletModel.stickerNo,
                            syncCode,
                            'Y',
                            damageTransCode,
                            validStickerModel.fk_Sticker_DamageGlCode)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .insertDamageStickerForRemove(
                            int.parse(initGlCode),
                            fkMainCustomerGLCode,
                            0,
                            palletModel.stickerNo,
                            syncCode,
                            'N',
                            damageTransCode,
                            0)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state == TAG_SCRAP_STOCK) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int fkMainCustomerGLCode) async {
            await sharedPrefs
                .getString(PREF_SCRAP_TRANS_CODE)
                .then((String scrapTransCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validDamageSticker(
                    fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel != null) {
                    await databaseHelper
                        .insertScrapSticker(
                        int.parse(initGlCode),
                        fkMainCustomerGLCode,
                        validStickerModel.fk_StickerGlCode,
                        palletModel.stickerNo,
                        syncCode,
                        'Y',
                        scrapTransCode,
                        validStickerModel.fk_ReceivedFromGlCode)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .insertScrapSticker(
                        int.parse(initGlCode),
                        fkMainCustomerGLCode,
                        0,
                        palletModel.stickerNo,
                        syncCode,
                        'N',
                        scrapTransCode,
                        0)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state == TAG_CONSUME_STOCK) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
              .then((int fkMainCustomerGLCode) async {
            await sharedPrefs
                .getString(PREF_CONSUME_TRANS_CODE)
                .then((String scrapTransCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validDamageSticker(
                    fkMainCustomerGLCode, palletModel.stickerNo)
                    .then((ValidStickerModel validStickerModel) async {
                  if (validStickerModel != null) {
                    await databaseHelper
                        .insertConsumeSticker(
                        int.parse(initGlCode),
                        fkMainCustomerGLCode,
                        validStickerModel.fk_StickerGlCode,
                        palletModel.stickerNo,
                        syncCode,
                        'Y',
                        scrapTransCode,
                        validStickerModel.fk_Sticker_DamageGlCode)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .insertConsumeSticker(
                        int.parse(initGlCode),
                        fkMainCustomerGLCode,
                        0,
                        palletModel.stickerNo,
                        syncCode,
                        'N',
                        scrapTransCode,
                        0)
                        .then((int id) {
                      if (isLoad == 1) {
                        loadScanRecordList(0);
                      }
                    });
                  }
                });
              });
            });
          });
        });
      }
    });
    /*} catch (e) {
      print(e.toString());
    }*/
  }

  void validStickerForPallet(String palletNo, int fkPalletGlCode, int isLoad,
      String chrPallet, int totalNoOfSticker) async {
    //try {
    await sharedPrefs.getString(PREF_SCREEN_STATE).then((String state) async {
      if (state == TAG_DISPATCH ||
          state == TAG_STOCK_TRANSFER ||
          state == TAG_SALES_RETURN ||
          state == TAG_FOC) {
        //Dispatch
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validStickerDispatchForPallet(fk_Customer_DispatchGlCode,
                        fkMainCustomerGLCode, fkPalletGlCode)
                    .then((int intNoOfStickerForDispatchPallet) async {
                  print(
                      '===intNoOfStickerForDispatchPallet=======$intNoOfStickerForDispatchPallet');
                  if (intNoOfStickerForDispatchPallet == 0) {
                    await databaseHelper
                        .validSticker_DispatchForPallet(
                            fk_Customer_DispatchGlCode,
                            fkMainCustomerGLCode,
                            fkPalletGlCode)
                        .then((int intNoOfStickerForDispatch_Pallet) async {
                      print(
                          '===intNoOfStickerForDispatch_Pallet=======$intNoOfStickerForDispatch_Pallet');
                      print('===totalNoOfSticker=======$totalNoOfSticker');
                      if (intNoOfStickerForDispatch_Pallet > 0) {
                        if (totalNoOfSticker > 0 &&
                            totalNoOfSticker ==
                                intNoOfStickerForDispatch_Pallet) {
                          /*
                          * For Batch Validation
                          * @globals.BATCH_VALIDATION
                          * */
                          bool isBatchValid = true;
                          if (globals.BATCH_VALIDATION == 'Y' &&
                              (state == TAG_DISPATCH ||
                                  state == TAG_STOCK_TRANSFER ||
                                  state == TAG_FOC)) {
                            await databaseHelper
                                .batchValidationForPallet(fkPalletGlCode)
                                .then((bool isBatchValid1) {
                              isBatchValid = isBatchValid1;
                            });
                          }

                          if (isBatchValid) {
                            await databaseHelper
                                .getCountQueryDispatch(
                                    fk_Customer_DispatchGlCode)
                                .then((int countTemp) async {
                              await databaseHelper
                                  .insertStickerForPallet(
                                      fk_Customer_DispatchGlCode,
                                      int.parse(initGlCode),
                                      'Y',
                                      'Y',
                                      syncCode,
                                      fkMainCustomerGLCode,
                                      countTemp,
                                      fkPalletGlCode)
                                  .then((int id) {
                                // if (isLoad == 1) {
                                loadScanRecordList(fk_Customer_DispatchGlCode);
                                //}
                              });
                            });
                          } else {
                            _loading = false;
                            dismissProgressHUD();
                            _showSnackBar(LocaleUtils.getString(
                                mContext, 'label_not_found_current_stock'));
                          }
                        } else {
                          await databaseHelper
                              .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                              .then((int countTemp) async {
                            int count = countTemp + 1;
                            await databaseHelper
                                .insertSticker(
                                    fk_Customer_DispatchGlCode,
                                    0,
                                    'N',
                                    0,
                                    0,
                                    palletNo,
                                    int.parse(initGlCode),
                                    'N',
                                    'Y',
                                    syncCode,
                                    fkMainCustomerGLCode,
                                    count,
                                    '')
                                .then((int id) {
                              //if (isLoad == 1) {
                              loadScanRecordList(fk_Customer_DispatchGlCode);
                              //}
                            });
                          });
                        }
                      } else {
                        await databaseHelper
                            .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                            .then((int countTemp) async {
                          int count = countTemp + 1;
                          await databaseHelper
                              .insertSticker(
                                  fk_Customer_DispatchGlCode,
                                  0,
                                  'N',
                                  0,
                                  0,
                                  palletNo,
                                  int.parse(initGlCode),
                                  'N',
                                  'Y',
                                  syncCode,
                                  fkMainCustomerGLCode,
                                  count,
                                  '')
                              .then((int id) {
                            //if (isLoad == 1) {
                            loadScanRecordList(fk_Customer_DispatchGlCode);
                            //}
                          });
                        });
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                        .then((int countTemp) async {
                      int count = countTemp + 1;
                      await databaseHelper
                          .insertSticker(
                              fk_Customer_DispatchGlCode,
                              0,
                              'N',
                              0,
                              0,
                              palletNo,
                              int.parse(initGlCode),
                              'N',
                              'Y',
                              syncCode,
                              fkMainCustomerGLCode,
                              count,
                              '')
                          .then((int id) {
                        //if (isLoad == 1) {
                        loadScanRecordList(fk_Customer_DispatchGlCode);
                        //}
                      });
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await _battery.getUniqueNumber().then((String syncCode) async {
                await databaseHelper
                    .validStickerDispatchForPalletForEditDO(
                    fk_Customer_DispatchGlCode,
                    fkMainCustomerGLCode,
                    fkPalletGlCode)
                    .then((int intNoOfStickerForDispatchPallet) async {
                  if (intNoOfStickerForDispatchPallet == 0) {
                    await databaseHelper
                        .validSticker_EditDOForPallet(fkMainCustomerGLCode,
                            fk_Customer_DispatchGlCode, fkPalletGlCode)
                        .then((int intNoOfStickerForDispatch_Pallet) async {
                      if (intNoOfStickerForDispatch_Pallet > 0) {
                        await databaseHelper
                            .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                            .then((int countTemp) async {
                          if (totalNoOfSticker > 0 &&
                              totalNoOfSticker ==
                                  intNoOfStickerForDispatch_Pallet) {
                            /*
                          * For Batch Validation
                          * @globals.BATCH_VALIDATION
                          * */
                            /*bool isBatchValid = true;
                            if (globals.BATCH_VALIDATION == 'Y') {
                              await databaseHelper
                                  .batchValidationForPallet(fkPalletGlCode)
                                  .then((bool isBatchValid1) {
                                isBatchValid = isBatchValid1;
                              });
                            }

                            if (isBatchValid) {*/

                            String maxDeletedSticker = await databaseHelper
                                .getMaxStickerIDForEditDOPallet(
                                fkPalletGlCode, fk_Customer_DispatchGlCode);
                            print('===maxDeletedSticker====$maxDeletedSticker');
                            if (maxDeletedSticker.isNotEmpty) {
                              await databaseHelper
                                  .releaseDeletedStickerForEditDO(
                                  fkPalletGlCode,
                                  fk_Customer_DispatchGlCode,
                                  maxDeletedSticker,
                                  true);
                            }

//                            await databaseHelper.releaseDeletedStickerForEditDO(
//                                fkPalletGlCode,
//                                fk_Customer_DispatchGlCode,maxDeletedSticker.toString(),true);

                            await databaseHelper
                                .getCountQueryDispatch(
                                fk_Customer_DispatchGlCode)
                                .then((int countTemp) async {
                              await databaseHelper
                                  .insertStickerForPallet(
                                  fk_Customer_DispatchGlCode,
                                  int.parse(initGlCode),
                                  'Y',
                                  'I',
                                  syncCode,
                                  fkMainCustomerGLCode,
                                  countTemp,
                                  fkPalletGlCode)
                                  .then((int id) {
                                //if (isLoad == 1) {
                                loadScanRecordList(fk_Customer_DispatchGlCode);
                                //}
                              });
                            });
                            /*} else {
                              _loading = false;
                              dismissProgressHUD();
                              _showSnackBar(LocaleUtils.getString(
                                  mContext, 'label_not_found_current_stock'));
                            }*/
                          } else {
                            await databaseHelper
                                .getCountQueryDispatch(
                                    fk_Customer_DispatchGlCode)
                                .then((int countTemp) async {
                              final int count = countTemp + 1;
                              await databaseHelper
                                  .insertSticker(
                                      fk_Customer_DispatchGlCode,
                                      0,
                                      'N',
                                      0,
                                      0,
                                      palletNo,
                                      int.parse(initGlCode),
                                      'N',
                                      'I',
                                      syncCode,
                                      fkMainCustomerGLCode,
                                      count,
                                      '')
                                  .then((int id) {
                                //if (isLoad == 1) {
                                loadScanRecordList(fk_Customer_DispatchGlCode);
                                //}
                              });
                            });
                          }
                        });
                      } else {
                        await databaseHelper
                            .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                            .then((int countTemp) async {
                          final int count = countTemp + 1;
                          await databaseHelper
                              .insertSticker(
                                  fk_Customer_DispatchGlCode,
                                  0,
                                  'N',
                                  0,
                                  0,
                                  palletNo,
                                  int.parse(initGlCode),
                                  'N',
                                  'I',
                                  syncCode,
                                  fkMainCustomerGLCode,
                                  count,
                                  '')
                              .then((int id) {
                            //if (isLoad == 1) {
                            loadScanRecordList(fk_Customer_DispatchGlCode);
                            //}
                          });
                        });
                      }
                    });
                  } else {
                    //insert
                    await databaseHelper
                        .getCountQueryDispatch(fk_Customer_DispatchGlCode)
                        .then((int countTemp) async {
                      final int count = countTemp + 1;
                      await databaseHelper
                          .insertSticker(
                              fk_Customer_DispatchGlCode,
                              0,
                              'N',
                              0,
                              0,
                              palletNo,
                              int.parse(initGlCode),
                              'N',
                              'Y',
                              syncCode,
                              fkMainCustomerGLCode,
                              count,
                              '')
                          .then((int id) {
                        //if (isLoad == 1) {
                        loadScanRecordList(fk_Customer_DispatchGlCode);
                        //}
                      });
                    });
                  }
                });
              });
            });
          });
        });
      } else if (state == TAG_RECEIVE) {
//          print('===========TAG_RECEIVE=========LOAD DATA=======');
        await sharedPrefs
            .getString(PREF_INIT_GI_CODE)
            .then((String initGlCode) async {
          await sharedPrefs
              .getInt(PREF_FK_DISPATCH_GL_CODE)
              .then((int fk_Customer_DispatchGlCode) async {
            await sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGLCode) async {
              await sharedPrefs
                  .getInt(PREF_FK_RECEIVE_GL_CODE)
                  .then((int fkReceiveGlCode) async {
                await _battery.getUniqueNumber().then((String syncCode) async {
                  await databaseHelper
                      .validStickerReceiveForPallet(fk_Customer_DispatchGlCode,
                          fkMainCustomerGLCode, fkPalletGlCode)
                      .then((int intNoOfStickerForReceive_Pallet) async {
                    if (intNoOfStickerForReceive_Pallet > 0) {
                      if (totalNoOfSticker > 0 &&
                          totalNoOfSticker == intNoOfStickerForReceive_Pallet) {
                        await databaseHelper
                            .insertReceiveStickerForPallet(
                                fkReceiveGlCode,
                                int.parse(initGlCode),
                                syncCode,
                                'Y',
                                fkPalletGlCode)
                            .then((int id) {
                          //if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                          //}
                        });
                      } else {
                        await databaseHelper
                            .insertReceiveSticker(fkReceiveGlCode, 0, 'N', 0, 0,
                                palletNo, int.parse(initGlCode), syncCode, 'N')
                            .then((int id) {
                          //if (isLoad == 1) {
                          loadScanRecordList(fk_Customer_DispatchGlCode);
                          //}
                        });
                      }
                    } else {
                      //insert
                      await databaseHelper
                          .insertReceiveSticker(fkReceiveGlCode, 0, 'N', 0, 0,
                              palletNo, int.parse(initGlCode), syncCode, 'N')
                          .then((int id) {
                        //if (isLoad == 1) {
                        loadScanRecordList(fk_Customer_DispatchGlCode);
                        //}
                      });
                    }
                  });
                });
              });
            });
          });
        });
      }
    });
    /*} catch (e) {
      print(e.toString());
    }*/
  }

  void loadScanRecordList(int fk_Customer_DispatchGlCode) async {
    _loading = true;
    dismissProgressHUD();
    String screenState = await sharedPrefs.getString(PREF_SCREEN_STATE);
    if (screenState == TAG_DISPATCH ||
        screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase() ||
        screenState == TAG_STOCK_TRANSFER ||
        screenState == TAG_FOC ||
        screenState == TAG_SALES_RETURN) {
      List<ScanDataModel> sDataList = await databaseHelper.getScanDataList(
          fk_Customer_DispatchGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    } else if (screenState == TAG_RECEIVE) {
      int fkReceiveGlCode = await sharedPrefs.getInt(PREF_FK_RECEIVE_GL_CODE);
      print('fkReceiveGlCode====$fkReceiveGlCode');
      List<ScanDataModel> sDataList =
      await databaseHelper.getScanDataList(fkReceiveGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    } else if (screenState == TAG_ADD_DAMAGE_STOCK) {
      int fkCustomerGlCode =
      await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      List<ScanDataModel> sDataList =
      await databaseHelper.getScanDataList(fkCustomerGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    } else if (screenState == TAG_REMOVE_DAMAGE_STOCK) {
      int fkCustomerGlCode =
      await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      List<ScanDataModel> sDataList =
      await databaseHelper.getScanDataList(fkCustomerGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    } else if (screenState == TAG_SCRAP_STOCK) {
      int fkCustomerGlCode =
      await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      List<ScanDataModel> sDataList =
      await databaseHelper.getScanDataList(fkCustomerGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    } else if (screenState == TAG_CONSUME_STOCK) {
      int fkCustomerGlCode =
      await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      List<ScanDataModel> sDataList =
      await databaseHelper.getScanDataList(fkCustomerGlCode, screenState);
      _loading = false;
      dismissProgressHUD();
      isLaserScanLoad = false;
      scanDataList.clear();
      if (mounted) {
        setState(() {
          scanDataList.addAll(sDataList);
        });
      }
    }
  }

  void unSelectAll(bool flag) {
    if (scanDataList.isNotEmpty) {
      for (int i = 0; i < scanDataList.length; i++) {
        scanDataList[i].isMultiDeleted = false;
        if (flag) {
          scanDataList[i].isDeleted = false;
        }
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void selectAll() {
    if (scanDataList.isNotEmpty) {
      for (int i = 0; i < scanDataList.length; i++) {
        scanDataList[i].isMultiDeleted = true;
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  bool isStickerSelected() {
    bool isSelected = false;

    if (scanDataList.isNotEmpty) {
      for (int i = 0; i < scanDataList.length; i++) {
        if (scanDataList[i].isMultiDeleted) {
          isSelected = true;
        }
      }
    }

    return isSelected;
  }

  void setSelection(int index) {
    if (scanDataList[index].isMultiDeleted) {
      scanDataList[index].isMultiDeleted = false;
    } else {
      scanDataList[index].isMultiDeleted = true;
    }
    if (isCheckAllStickerSelected()) {
      isSelectAll = true;
    } else {
      isSelectAll = false;
    }
    if (mounted) {
      setState(() {});
    }
  }

  bool isCheckAllStickerSelected() {
    bool isSelected = true;

    if (scanDataList.isNotEmpty) {
      for (int i = 0; i < scanDataList.length; i++) {
        if (!scanDataList[i].isMultiDeleted) {
          isSelected = false;
        }
      }
    }

    return isSelected;
  }

  Timer _timer;
  bool isSelectAll = false;

  void removeMultiSelectedSticker() {
    isLaserScanLoad = true;
    int deleteCount = 0;
    for (int i = 0; i < scanDataList.length; i++) {
      if (scanDataList[i].isMultiDeleted) {
        scanDataList[i].isMultiDeleted = false;
        scanDataList[i].isDeleted = true;
        deleteCount = deleteCount + 1;
      }
    }
    if (mounted) {
      setState(() {});
    }

    flushbar = Flushbar<bool>(
      message: "$deleteCount ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
          isLaserScanLoad = false;
          unSelectAll(true);
          _timer.cancel();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    flushbar.show(context);

    _timer = new Timer(const Duration(seconds: 4), () async {
      isLaserScanLoad = false;
      await Future.forEach(scanDataList, (ScanDataModel scanDataModel) async {
        if (scanDataModel.isDeleted) {
          deleteFromDB(
              scanDataModel.fk_Customer_DispatchProduct_GLCode,
              scanDataModel.fk_Customer_DispatchGlCode,
              scanDataModel.fk_Customer_ReceiveGlCode,
              scanDataModel.chrPallet,
              scanDataModel.varSticker,
              false);
        }
      });
      int fk_Customer_DispatchGlCode = await sharedPrefs.getInt(
          PREF_FK_DISPATCH_GL_CODE);
      await loadScanRecordList(fk_Customer_DispatchGlCode);
    });
  }

  void removeSticker(int fk_Customer_DispatchProduct_GLCode,
      int fkCustomerDispatchGlCode,
      int fkCustomerReceiveGlCode,
      String chrPallet,
      String varSticker,
      int index) {
    isLaserScanLoad = true;
    scanDataList[index].isDeleted = true;
    if (mounted) {
      setState(() {});
    }
    flushbar = Flushbar<bool>(
      message: "$varSticker ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
          isLaserScanLoad = false;
          scanDataList[index].isDeleted = false;
          _timer.cancel();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    flushbar.show(context);

    _timer = new Timer(const Duration(seconds: 4), () async {
      print('=========DELETED========');
      isLaserScanLoad = false;
      deleteFromDB(fk_Customer_DispatchProduct_GLCode, fkCustomerDispatchGlCode,
          fkCustomerReceiveGlCode, chrPallet, varSticker, true);
    });
  }

  void deleteFromDB(int fk_Customer_DispatchProduct_GLCode,
      int fkCustomerDispatchGlCode,
      int fkCustomerReceiveGlCode,
      String chrPallet,
      String varSticker,
      bool isSingleDelete) async {
    String initGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    int fk_Customer_DispatchGlCode =
    await sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE);
    String state = await sharedPrefs.getString(PREF_SCREEN_STATE);
    if (state == TAG_DISPATCH ||
        state == TAG_STOCK_TRANSFER ||
        state == TAG_SALES_RETURN ||
        state == TAG_FOC) {
      await databaseHelper.updateStickerForDelete(
          fk_Customer_DispatchProduct_GLCode,
          fkCustomerDispatchGlCode,
          'N',
          chrPallet);

      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state == TAG_RECEIVE) {
      await databaseHelper.updateStickerForDeleteReceive(
          fk_Customer_DispatchProduct_GLCode,
          fkCustomerReceiveGlCode,
          chrPallet);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state == TAG_ADD_DAMAGE_STOCK) {
      await databaseHelper.updateStickerForDeleteAddDamage(
          int.parse(initGlCode), fk_Customer_DispatchProduct_GLCode);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state == TAG_REMOVE_DAMAGE_STOCK) {
      await databaseHelper.updateStickerForDeleteRemoveDamage(
          int.parse(initGlCode), fk_Customer_DispatchProduct_GLCode);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
      await databaseHelper.updateStickerForDeleteForEditDO(
          fk_Customer_DispatchProduct_GLCode,
          fkCustomerDispatchGlCode,
          'E',
          chrPallet);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state == TAG_CONSUME_STOCK) {
      await databaseHelper.updateStickerForDeleteForConsume(
          int.parse(initGlCode), fk_Customer_DispatchProduct_GLCode);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    } else if (state == TAG_SCRAP_STOCK) {
      await databaseHelper.updateStickerForDeleteScrap(
          int.parse(initGlCode), fk_Customer_DispatchProduct_GLCode);
      if (isSingleDelete) {
        await loadScanRecordList(fk_Customer_DispatchGlCode);
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
