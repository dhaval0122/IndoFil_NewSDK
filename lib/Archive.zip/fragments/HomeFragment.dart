import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/available_to_promise/AvailableToPromise.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchThirdScreen.dart';
import 'package:flutter_basf_hk_app/dispatch/InvoiceDispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/mystockinfo/MyStockInfoScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/PlaceOrderScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/order_history/OrderHistoryScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderScreen.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveFirstScreen.dart';
import 'package:flutter_basf_hk_app/receive/ReceiveThirdScreen.dart';
import 'package:flutter_basf_hk_app/sales_summary/ReportsScreen.dart';
import 'package:flutter_basf_hk_app/sales_summary/SalesSummaryScreen.dart';
import 'package:flutter_basf_hk_app/stock_visibility/StockVisibilityScreen.dart';
import 'package:flutter_basf_hk_app/stocktransfer/StockTransferScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';

class DispatchHalfTransactionModel {
  int fk_DispatchGlCode;
  int fk_Customer_To_GlCode;
  String chrTransType;

  DispatchHalfTransactionModel({this.fk_DispatchGlCode, this.fk_Customer_To_GlCode, this.chrTransType});

  factory DispatchHalfTransactionModel.fromJson(Map<String, dynamic> json) {
    return DispatchHalfTransactionModel(
      fk_DispatchGlCode: json['fk_DispatchGlCode'],
      fk_Customer_To_GlCode: json['fk_Customer_To_GlCode'],
      chrTransType: json['chrTransType'],
    );
  }

  DispatchHalfTransactionModel.fromMap(Map<String, dynamic> json) {
    this.fk_DispatchGlCode = json['fk_DispatchGlCode'];
    this.fk_Customer_To_GlCode = json['fk_Customer_To_GlCode'];
    this.chrTransType = json['chrTransType'];
  }
}

class DispatchHalfReceiveTransactionModel {
  int fk_ReceiveGlCode;
  int fk_DispatchGlCode;

  DispatchHalfReceiveTransactionModel({this.fk_ReceiveGlCode, this.fk_DispatchGlCode});

  DispatchHalfReceiveTransactionModel.fromMap(Map<String, dynamic> json) {
    this.fk_ReceiveGlCode = json['fk_ReceiveGlCode'];
    this.fk_DispatchGlCode = json['fk_DispatchGlCode'];
  }
}

class HomeFragment extends StatelessWidget {
  final String userName;
  final String lastSyncDate;
  final List<MenuMasterModel> menuMasterList;
  final int receiveCount;
  final bool isShowLastSyncDate;
  final String subTitle;
  final bool isLoading;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  DatabaseHelper databaseHelper;
  DashboardState mDashboard;
  final AnimationController mainScreenAnimationController;
  final Animation mainScreenAnimation;
  final EcpSyncPlugin syncPlugin;

  HomeFragment(this.mContext,
      this.sharedPrefs,
      this.databaseHelper,
      this.userName,
      this.lastSyncDate,
      this.menuMasterList,
      this.receiveCount,
      this.isShowLastSyncDate,
      this.subTitle,
      this.isLoading, {
        this.mDashboard,
        this.mainScreenAnimationController,
        this.mainScreenAnimation,
        this.syncPlugin});

//  @override
//  Widget build(BuildContext context) {
//    return Container(
//      color: const Color(colorPrimary),
//      child: Column(
//        children: <Widget>[
//          isShowLastSyncDate
//              ? CustomTopHeaderBar(userName, lastSyncDate, '', 0)
//              : CustomTopHeaderBar(
//              userName, subTitle, 'assets/ic_insight_white.png', 0),
//          Expanded(
//            child: !isLoading
//                ? _buildList(context)
//                : Center(
//              child: const CircularProgressIndicator(
//                  valueColor:
//                  AlwaysStoppedAnimation<Color>(Color(whiteColor))),
//            ),
//            flex: 1,
//          )
//        ],
//      ),
//    );
//  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(colorPrimary),
      child: Column(
        children: <Widget>[
          isShowLastSyncDate
              ? CustomTopHeaderBar(userName, lastSyncDate, '', 0)
              : CustomTopHeaderBar(
              userName, subTitle, 'assets/ic_insight_white.png', 0),
          Expanded(
            child: !isLoading
                ? _buildList(context)
                : Center(
              child: const CircularProgressIndicator(
                  valueColor:
                  AlwaysStoppedAnimation<Color>(Color(whiteColor))),
            ),
            flex: 1,
          )
        ],
      ),
    );
  }

  void navigateDispatchFirstScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => DispatchFirstScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateInvoiceDispatchFirstScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => InvoiceDispatchFirstScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateDispatchThirdScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) =>
            DispatchThirdScreen(
                isRedirectToEditScreen: false, subTitleTxt: ''));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateMyStockInfoScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => MyStockInfoScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateReceiveThirdScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => ReceiveThirdScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateReceiveFirstScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => ReceiveFirstScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateStockTransferScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => StockTransferScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateStockVisibilityScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => StockVisibilityScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateReportsScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => ReportsScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigatePlaceOrderScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PlaceOrderScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
//          mDashboard?.showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateOrderHistoryScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => OrderHistoryScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateSalesSummaryScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => SalesSummaryScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateAvailableToPromiseScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => AvailableToPromiseScreen());
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigatePlaceNewOrderScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) =>
            PlaceNewOrderScreen(
              dataOrderSummary: null,
            ));
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_DIS');
    String syncCode = await syncPlugin.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void redirectToNextScreen(BuildContext context, String code) {
    if (code == 'DEV_DIS') {
      sharedPrefs.setString(PREF_SCREEN_STATE, TAG_DISPATCH).then((bool isDis) {
        sharedPrefs
            .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
            .then((int mainCustomerGlCode) {
          databaseHelper
              .checkDispatchHalfTransaction(mainCustomerGlCode, 'D')
              .then((DispatchHalfTransactionModel dispatchModel) {
            print('----dispatchModel-------$dispatchModel');
            if (dispatchModel != null) {
              sharedPrefs
                  .setInt(
                  PREF_FK_DISPATCH_GL_CODE, dispatchModel.fk_DispatchGlCode)
                  .then((bool isDisGlCode) {
                sharedPrefs
                    .setInt(PREF_FK_LAST_DISPATCHED_TO,
                    dispatchModel.fk_Customer_To_GlCode)
                    .then((bool isCustGlCode) {
                  insertLogDetails();
                  navigateDispatchThirdScreen();
                });
              });
            } else {
              sharedPrefs
                  .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, false)
                  .then((bool isTransType) {
                insertLogDetails();
                if (globals.AUTO_DISPATCH_DO_CONFIRM == 'N') {
                  navigateInvoiceDispatchFirstScreen();
                } else {
                  navigateDispatchFirstScreen();
                }
              });
            }
          });
        });
      });
    } else if (code == 'DEV_MSI') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_MY_STOCK_INFO)
          .then((bool isDis) {
        navigateMyStockInfoScreen();
      });
    } else if (code == 'DEV_REC') {
      sharedPrefs.setString(PREF_SCREEN_STATE, TAG_RECEIVE).then((bool isDis) {
        sharedPrefs
            .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
            .then((int mainCustomerGlCode) {
          databaseHelper
              .checkDispatchHalfTransactionReceive(mainCustomerGlCode)
              .then((DispatchHalfReceiveTransactionModel dispatchModel) {
            print(
                '----checkDispatchHalfTransactionReceive-------$dispatchModel');
            if (dispatchModel != null) {
              sharedPrefs
                  .setInt(
                  PREF_FK_DISPATCH_GL_CODE, dispatchModel.fk_DispatchGlCode)
                  .then((bool isDisGlCode) {
                sharedPrefs
                    .setInt(
                    PREF_FK_RECEIVE_GL_CODE, dispatchModel.fk_ReceiveGlCode)
                    .then((bool isCustGlCode) {
                  insertLogDetails();
                  navigateReceiveThirdScreen();
                });
              });
            } else {
              insertLogDetails();
              navigateReceiveFirstScreen();
            }
          });
        });
      });
    } else if (code == 'DEV_STF') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_STOCK_TRANSFER)
          .then((bool isDis) {
        sharedPrefs
            .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
            .then((int mainCustomerGlCode) {
          databaseHelper
              .checkDispatchHalfTransaction(mainCustomerGlCode, 'S')
              .then((DispatchHalfTransactionModel dispatchModel) {
            print('----dispatchModel-------$dispatchModel');
            if (dispatchModel != null) {
              sharedPrefs
                  .setInt(
                  PREF_FK_DISPATCH_GL_CODE, dispatchModel.fk_DispatchGlCode)
                  .then((bool isDisGlCode) {
                sharedPrefs
                    .setInt(PREF_FK_LAST_DISPATCHED_TO,
                    dispatchModel.fk_Customer_To_GlCode)
                    .then((bool isCustGlCode) {
                  insertLogDetails();
                  navigateDispatchThirdScreen();
                });
              });
            } else {
              sharedPrefs
                  .setBool(PREF_CHANGE_DETAILS_STATE_BOOL, false)
                  .then((bool isTransType) {
                insertLogDetails();
                navigateStockTransferScreen();
              });
            }
          });
        });
      });
    } else if (code == 'DEV_STV') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_STOCK_VISIBILITY)
          .then((isBool) {
        navigateStockVisibilityScreen();
      });
    } else if (code == 'DEV_REP') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_STOCK_VISIBILITY)
          .then((isBool) {
        navigateReportsScreen();
      });
    } else if (code == 'DEV_PLO') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_STOCK_VISIBILITY)
          .then((isBool) {
        navigatePlaceOrderScreen();
      });
    } else if (code == 'DEV_PLO_ORH') {
      navigateOrderHistoryScreen();
    } else if (code == 'DEV_PLO_PNO') {
      navigatePlaceNewOrderScreen();
    } else if (code == 'DEV_REP_SALES') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_SALES_SUMMARY)
          .then((isBool) {
        navigateSalesSummaryScreen();
      });
    } else if (code == 'DEV_REP_ATP') {
      sharedPrefs
          .setString(PREF_SCREEN_STATE, TAG_AVAILABLE_TO_PROMISE)
          .then((isBool) {
        navigateAvailableToPromiseScreen();
      });
    }
  }

  Widget getListRowForReceive(int index) {
    if (menuMasterList[index].varTransactionCode == 'DEV_REC') {
      return Row(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: getIcon(menuMasterList[index].varTransactionCode),
          ),
          Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text(menuMasterList[index].varDisplayName,
                  style: TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'helvetica',
                      color: Colors.white))),
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Container(
                decoration: const BoxDecoration(
                    color: Colors.red, shape: BoxShape.circle),
                child: Padding(
                  padding: const EdgeInsets.all(7),
                  child: Center(
                    child: Text(
                        receiveCount != null ? receiveCount.toString() : '0',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'helvetica',
                            color: Colors.white)),
                  ),
                )),
          )
        ],
      );
    } else {
      return Row(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: getIcon(menuMasterList[index].varTransactionCode),
          ),
          Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text(menuMasterList[index].varDisplayName,
                  style: TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.w400,
                      fontFamily: 'helvetica',
                      color: Colors.white))),
        ],
      );
    }
  }

  ListView _buildList(BuildContext context) {
    return ListView.builder(
      itemCount: menuMasterList.length,
      shrinkWrap: true,
      itemBuilder: (BuildContext context, int index) {
        var count =
        menuMasterList.length > 10 ? 10 : menuMasterList.length;
        var animation = Tween(begin: 0.0, end: 1.0).animate(
            CurvedAnimation(
                parent: mainScreenAnimationController,
                curve: Interval((1 / count) * index, 1.0,
                    curve: Curves.fastOutSlowIn)));
        mainScreenAnimationController.forward();

        return InkWell(
            onTap: () {
              print('===========TAP=============');
              redirectToNextScreen(
                  mContext, menuMasterList[index].varTransactionCode);
            },
            child: AnimatedBuilder(
              animation: mainScreenAnimationController,
              builder: (BuildContext context, Widget child) {
                return FadeTransition(
                  opacity: animation,
                  child: new Transform(
                    transform: new Matrix4.translationValues(
                        100 * (1.0 - animation.value), 0.0, 0.0),
                    child: Column(
                      children: <Widget>[
                        Container(
                          height: 45,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[getListRowForReceive(index)],
                          ),
                        ),
                        Divider(color: Colors.white70),
                      ],
                    ),
                  ),
                );
              },
            )
        );
      },
    );
  }

  Image getIcon(String code) {
    if (code == 'DEV_DIS') {
      return Image.asset(
        'assets/dispatch_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_MSI') {
      return Image.asset(
        'assets/stock_info_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_REC') {
      return Image.asset(
        'assets/receive_icon.png',
        color: Colors.white,
        fit: BoxFit.contain,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_STF') {
      return Image.asset(
        'assets/stock_transfer.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_STV') {
      return Image.asset(
        'assets/stock_info_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_REP') {
      return Image.asset(
        'assets/ic_insight_white.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_REP_SALES') {
      return Image.asset(
        'assets/receive_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_REP_ATP') {
      return Image.asset(
        'assets/promise_one.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_SSR') {
      return Image.asset(
        'assets/placegoodsreturn.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_PLO') {
      return Image.asset(
        'assets/place_order_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_PLO_ORH') {
      return Image.asset(
        'assets/orderhistory_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else if (code == 'DEV_PLO_PNO') {
      return Image.asset(
        'assets/neworder_icon.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    } else {
      return Image.asset(
        'assets/promise_one.png',
        color: Colors.white,
        height: 25,
        width: 25,
      );
    }
  }
}

