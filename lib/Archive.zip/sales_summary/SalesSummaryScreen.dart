import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/DatePicker.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/SalesSummaryModel.dart';
import 'package:flutter_basf_hk_app/sales_summary/SalesSummarySKUScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

class SalesSummaryScreen extends StatefulWidget {
  @override
  SalesSummaryScreenState createState() => SalesSummaryScreenState();
}

class SalesSummaryScreenState extends State<SalesSummaryScreen>
    implements WSInterface, PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false, isNotification = false, isSync = false;
  Size screenSize;
  String userName, subTitle, doNo, dateFormatAPI = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;

  List<SalesSummaryModel> list = List();
  List<SalesSummaryModel> listDisplay = List();

  final TextEditingController searchcontroller = TextEditingController();

  WSPresenter wsPresenter;

  DateTime selectedFromDate, selectedToDate;
  DateTime currentDateTime = DateTime.now();
  TextEditingController fromDateController, toDateController;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    fromDateController = TextEditingController();
    toDateController = TextEditingController();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    setUpDate();
    _initLoading();

    insertLogDetails();

  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_REP_SALES');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_SALES_SUMMARY) {
      return LocaleUtils.getString(mContext, 'tag_stock_summary');
    } else {
      return '';
    }
  }

  void getData() {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            param[PARAM_PERSON_ID] = loginID;
            param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                ? SUB_MODULE_NAME_ANDROID
                : SUB_MODULE_NAME_IOS;
            param[PARAM_VERSION] = APP_VERSION;

            sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                sharedPrefs
                    .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                    .then((int mainCustomerGlCode) {
                  sharedPrefs
                      .getString(PREF_DATE_FORMAT)
                      .then((String dateformat) {
                    param[PARAM_API_TOKEN] = apiToken;
                    param[PARAM_DEVICE_ID] = deviceid;
                    param[PARAM_ACTION] = 'GetSalesSummary';
                    param[PARAM_PERSON_ID] = loginID;
                    param['Filter'] = '';
                    /*param['ToDate'] = '2019-02-28';
                param['FromDate'] = '2019-02-01';*/

                    //if (fromDateController.text.length > 0) {
                    if (fromDateController.text.isNotEmpty) {
                      param['FromDate'] = mUtils.convertDateTime(
                          fromDateController.text, dateformat);
                    } else {
                      param['FromDate'] = '';
                    }

                    // if (toDateController.text.length > 0) {
                    if (toDateController.text.isNotEmpty) {
                      param['ToDate'] = mUtils.convertDateTime(
                          toDateController.text, dateformat);
                    } else {
                      param['ToDate'] = '';
                    }

                    param['Product_SKU_GlCode'] = '0';
                    param['Version'] = APP_VERSION;
                    param['DispatchId'] = '0';
                    param['Batch_No'] = '';
                    param['CustomerId'] = mainCustomerGlCode.toString();

                    print(param);
                    wsPresenter.callAPI(
                        POST_METHOD, 'SalesSummary_Device_Report', param);
                  });
                });
              });
            });
          });
        });
      } else {
        //_showSnackBar('No Internet Connection');
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    dismissProgressHUD();
    //print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    //print('Response : ' + response);
    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      listDisplay.clear();
      list.clear();
      /*if (responseModel.getSalesSummaryList() != null &&
          responseModel.getSalesSummaryList().length > 0) {*/
      if (responseModel.getSalesSummaryList() != null &&
          responseModel.getSalesSummaryList().isNotEmpty) {
        if (mounted) {
          setState(() {
            listDisplay.addAll(responseModel.getSalesSummaryList());
            list.addAll(listDisplay);
          });
        }
      }
    } else if (responseModel.Status.contains('2')) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    }

    print(_loading);
    dismissProgressHUD();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  void _setDate(bool isFromDate) {
    final DateTime minDate = DateTime(1970, 1, 1);
    DatePicker.showDatePicker(context,
        showTitleActions: true,
        minTime: isFromDate ? minDate : selectedFromDate,
        maxTime: currentDateTime, onConfirm: (newDateTime) {
      print('confirm $newDateTime');
      final String monthValues = newDateTime.month.toString().length > 1
          ? newDateTime.month.toString()
          : '0${newDateTime.month}';

      final String dayValues = newDateTime.day.toString().length > 1
          ? newDateTime.day.toString()
          : '0${newDateTime.day}';

      if (isFromDate) {
        final String dateValues =
            '$monthValues' + '/$dayValues' + '/${newDateTime.year}';
        selectedFromDate = newDateTime;
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          fromDateController.text =
              mUtils.convertDateTimeDisplay(dateValues, dateFormat);
        });

        selectedToDate = mUtils.getActualMaxDate(selectedFromDate);
        final String monthValues1 = selectedToDate.month.toString().length > 1
            ? selectedToDate.month.toString()
            : '0${selectedToDate.month}';
        final String dayValues1 = selectedToDate.day.toString().length > 1
            ? selectedToDate.day.toString()
            : '0${selectedToDate.day}';

        final String dateToValues =
            '$monthValues1' + '/$dayValues1' + '/${selectedToDate.year}';
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          toDateController.text =
              mUtils.convertDateTimeDisplay(dateToValues, dateFormat);
          getData();
        });
      } else {
        final String dateValues =
            '$monthValues' + '/$dayValues' + '/${newDateTime.year}';
        selectedToDate = newDateTime;
        sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
          toDateController.text =
              mUtils.convertDateTimeDisplay(dateValues, dateFormat);
          getData();
        });
      }
    },
        currentTime: isFromDate ? selectedFromDate : selectedToDate,
        locale: LocaleType.en);
  }

  void setUpDate() {
    selectedToDate = DateTime.now();
    //print('===calendarToDate====${selectedToDate.toString()}');
    selectedFromDate = DateTime(selectedToDate.year, selectedToDate.month, 1);
    //print('===calendarFromDate====${selectedFromDate.toString()}');

    sharedPrefs.getString(PREF_DATE_FORMAT).then((String dateFormat) {
      dateFormatAPI = dateFormat;
      final String fromDateValues =
          mUtils.convertDateFormat(selectedFromDate, dateFormat);
      final String toDateValues =
          mUtils.convertDateFormat(selectedToDate, dateFormat);
      if (mounted) {
        setState(() {
          fromDateController.text = fromDateValues;
          toDateController.text = toDateValues;
        });

        getData();
      }
    });
  }

  String getLabelTitle(int index) {
    String mChrType = listDisplay[index].chrTransType;
    if (mChrType == 'S') {
      return LocaleUtils.getString(mContext, 'transfer_to');
    } else if (mChrType == 'D') {
      return LocaleUtils.getString(mContext, 'DispatchTo_');
    } else if (mChrType == 'R') {
      return LocaleUtils.getString(mContext, 'return_to');
    } else if (mChrType == 'F') {
      return LocaleUtils.getString(mContext, 'FocTo_');
    } else {
      return LocaleUtils.getString(mContext, 'DispatchTo_');
    }
  }

  String getLabelDate(int index) {
    String mChrType = listDisplay[index].chrTransType;
    if (mChrType == 'S') {
      return LocaleUtils.getString(mContext, 'transferDt');
    } else if (mChrType == 'D') {
      return LocaleUtils.getString(mContext, 'DispatchDt');
    } else if (mChrType == 'R') {
      return LocaleUtils.getString(mContext, 'returnDt');
    } else if (mChrType == 'F') {
      return LocaleUtils.getString(mContext, 'FocDt');
    } else {
      return LocaleUtils.getString(mContext, 'DispatchDt');
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: Colors.white,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle,
                      'assets/ic_sales_summary_white.png', 0),
                  Container(
                    padding: const EdgeInsets.only(
                        left: 10, top: 10, right: 10, bottom: 10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Container(
                                    padding: const EdgeInsets.only(bottom: 3),
                                    child: Text(
                                      LocaleUtils.getString(mContext, 'FromDt'),
                                      style: prifixTxtStyle,
                                    ),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    height: 45,
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                        borderRadius: const BorderRadius.all(
                                            Radius.circular(7)),
                                        border: Border.all(
                                            color: const Color(colorPrimary),
                                            width: 2)),
                                    child: InkWell(
                                      child: TextField(
                                        controller: fromDateController,
                                        //enableInteractiveSelection: false,
                                        decoration: InputDecoration(
                                          border: InputBorder.none,
                                          hintStyle: prifixTxtPrimaryStyle,
                                          labelStyle: prifixTxtPrimaryStyle,
                                          hintText: LocaleUtils.getString(
                                              mContext, 'FromDt'),
                                          counterText: '',
                                          //labelText: defaultFromDate
                                        ),
                                        style: prifixTxtPrimaryStyle,
                                        onChanged: (value) {
                                          print('====FROM DATE=====$value');
                                        },
                                        autofocus: false,
                                        enabled: false,
                                        maxLines: 1,
                                        maxLength: EditTxtMaxLengths,
                                      ),
                                      onTap: () {
                                        print('====FROM DATE===TAP==');
                                        _setDate(true);
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              flex: 1,
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(left: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: <Widget>[
                                    Container(
                                      padding: const EdgeInsets.only(bottom: 3),
                                      child: Text(
                                        LocaleUtils.getString(mContext, 'ToDt'),
                                        style: prifixTxtStyle,
                                      ),
                                    ),
                                    Container(
                                        padding: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        height: 45,
                                        width: double.infinity,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                const BorderRadius.all(
                                                    Radius.circular(7)),
                                            border: Border.all(
                                                color:
                                                    const Color(colorPrimary),
                                                width: 2)),
                                        child: InkWell(
                                          child: TextField(
                                            controller: toDateController,
                                            //enableInteractiveSelection: false,
                                            decoration: InputDecoration(
                                              border: InputBorder.none,
                                              hintStyle: prifixTxtPrimaryStyle,
                                              labelStyle: prifixTxtPrimaryStyle,
                                              hintText: LocaleUtils.getString(
                                                  mContext, 'ToDt'),
                                              counterText: '',
                                            ),
                                            style: prifixTxtPrimaryStyle,
                                            onChanged: (value) {
                                              print('====TO DATE=====$value');
                                              _setDate(false);
                                            },
                                            autofocus: false,
                                            enabled: false,
                                            maxLines: 1,
                                            maxLength: EditTxtMaxLengths,
                                          ),
                                          onTap: () {
                                            print('====TO DATE==TAP===');
                                            _setDate(false);
                                          },
                                        )),
                                  ],
                                ),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    //color: Color(colorAccent),
                    padding: const EdgeInsets.all(10),

                    child: Container(
                      height: 45,
                      decoration: BoxDecoration(
                          borderRadius:
                              const BorderRadius.all(Radius.circular(7)),
                          border: Border.all(
                              color: const Color(colorPrimary), width: 2)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Flexible(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 10),
                              child: TextField(
                                controller: searchcontroller,
                                //enableInteractiveSelection: false,
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  hintStyle: prifixTxtPrimaryStyle,
                                  hintText: '${LocaleUtils.getString(
                                      mContext, 'search_by_name')}${globals
                                      .DO_NO}.',
                                  counterText: '',
                                ),
                                style: prifixTxtPrimaryStyle,
                                onChanged: (value) {
                                  filterSearchResults(value);
                                },
                                maxLines: 1,
                                maxLength: EditTxtMaxLengths,
                              ),
                            ),
                            flex: 1,
                          ),
                          Flexible(
                            child: IconButton(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.search,
                                  color: Color(colorPrimary),
                                )),
                            flex: 0,
                          )
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: _loading
                        //? listDisplay.length > 0
                        ? listDisplay.length > 0
                            ? Container(
                                child: ListView.builder(
                                  shrinkWrap: true,
                                  itemBuilder: (context, position) {
                                    return GestureDetector(
                                        child: Card(
                                            margin: const EdgeInsets.only(
                                                left: 10,
                                                top: 7,
                                                bottom: 7,
                                                right: 10),
                                            elevation: 3,
                                            child: Container(
                                              padding: const EdgeInsets.all(10),
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                children: <Widget>[
                                                  Row(
                                                    children: <Widget>[
                                                      Expanded(
                                                        child: Wrap(
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Text(
                                                              getLabelTitle(
                                                                  position),
                                                              style:
                                                                  prifixTxtStyle,
                                                            ),
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                      Expanded(
                                                        child: Wrap(
                                                          direction:
                                                              Axis.horizontal,
                                                          runAlignment:
                                                              WrapAlignment
                                                                  .start,
                                                          children: <Widget>[
                                                            Text(
                                                              listDisplay[position]
                                                                          .DispatchTo !=
                                                                      null
                                                                  ? listDisplay[
                                                                          position]
                                                                      .DispatchTo
                                                                  : '',
                                                              style: textStyle,
                                                            ),
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                '${listDisplay[position]
                                                                    .varEntityName}:',
                                                                style:
                                                                    prifixTxtStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                listDisplay[
                                                                        position]
                                                                    .varDONO,
                                                                style:
                                                                    textStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                LocaleUtils
                                                                    .getString(
                                                                        mContext,
                                                                        'TotUnits_'),
                                                                style:
                                                                    prifixTxtStyle,
                                                              ),
                                                              Text(
                                                                listDisplay[position]
                                                                            .TotalUnits !=
                                                                        null
                                                                    ? listDisplay[
                                                                            position]
                                                                        .TotalUnits
                                                                        .toString()
                                                                    : '',
                                                                style:
                                                                    textStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                LocaleUtils
                                                                    .getString(
                                                                        mContext,
                                                                        'TotArticle_'),
                                                                style:
                                                                    prifixTxtStyle,
                                                              ),
                                                              Text(
                                                                listDisplay[position]
                                                                            .TotalArticle !=
                                                                        null
                                                                    ? listDisplay[
                                                                            position]
                                                                        .TotalArticle
                                                                        .toString()
                                                                    : '',
                                                                style:
                                                                    textStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 5),
                                                    child: Row(
                                                      children: <Widget>[
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                getLabelDate(
                                                                    position),
                                                                style:
                                                                    prifixTxtStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                        Expanded(
                                                          child: Wrap(
                                                            direction:
                                                                Axis.horizontal,
                                                            runAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            children: <Widget>[
                                                              Text(
                                                                listDisplay[position]
                                                                            .dtDispatchDate !=
                                                                        null
                                                                    ? listDisplay[
                                                                            position]
                                                                        .dtDispatchDate
                                                                    : '',
                                                                style:
                                                                    textStyle,
                                                              ),
                                                            ],
                                                          ),
                                                          flex: 1,
                                                        ),
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            )),
                                        onTap: () {
                                          final Route route =
                                              CupertinoPageRoute(
                                                  builder: (context) =>
                                                      SalesSummarySKUScreen(
                                                          listDisplay[
                                                              position]));
                                          Navigator.push(mContext, route);
                                        });
                                  },
                                  itemCount: listDisplay.length,
                                ),
                              )
                            : Container(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Image.asset(
                                      'assets/nodata_icon.png',
                                      height: 100,
                                      width: 100,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 10),
                                      child: Text(
                                        LocaleUtils.getString(
                                            mContext, 'NoDataFound'),
                                        style: prifixTxtStyle,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                        : const Text(''),
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  void filterSearchResults(String query) {
    print(query);

    final List<SalesSummaryModel> dummySearchList = List<SalesSummaryModel>();
    dummySearchList.addAll(list);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<SalesSummaryModel> dummyListData = List<SalesSummaryModel>();
      dummySearchList.forEach((item) {
        if (item.DispatchTo.toLowerCase().contains(query) ||
            item.varDONO.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(dummyListData);
        });
      }
      return;
    } else {
      if (mounted) {
        setState(() {
          listDisplay.clear();
          listDisplay.addAll(list);
        });
      }
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
