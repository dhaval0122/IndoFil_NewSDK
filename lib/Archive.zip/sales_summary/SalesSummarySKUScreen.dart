import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/SalesSummaryModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

class SalesSummarySKUScreen extends StatefulWidget {
  SalesSummaryModel data;

  SalesSummarySKUScreen(SalesSummaryModel data) {
    this.data = data;
  }

  @override
  SalesSummarySKUScreenState createState() => SalesSummarySKUScreenState();
}

class SalesSummarySKUScreenState extends State<SalesSummarySKUScreen>
    implements WSInterface, PushNotificationListener {

  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _loading = false,
      isNotification = false,
      isSync = false,
      isNoData = false;
  Size screenSize;
  String userName, subTitle, doNo;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;

  List<SalesSummarySKUModel> list = List();
  List<SalesSummarySKUModel> listDisplay = List();

  List<SalesSummarySKUStickerModel> listSticker = List();
  List<SalesSummarySKUStickerModel> listStickerDisplay = List();

  final TextEditingController searchcontroller = TextEditingController();

  WSPresenter wsPresenter;
  EcpSyncPlugin _battery;

  static int apiCallType = 0;
  static String batchNo = '';
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    Route route = CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
        });
      }
    });
    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
      if (mounted) {
        setState(() {
          subTitle = getTitleName(screenState);
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData(1, 0);
    _initLoading();
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_EDIT_DO) {
      return LocaleUtils.getString(mContext, 'tag_edit_do');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_SALES_SUMMARY) {
      return LocaleUtils.getString(mContext, 'tag_stock_summary');
    } else {
      return '';
    }
  }

  void getData(int type, int Product_SKU_GlCode) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGlCode) {
              param[PARAM_PERSON_ID] = loginID;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param[PARAM_DEVICE_ID] = deviceid;
                  param[PARAM_ACTION] = type == 1 ? 'GetSKU' : 'GetLabel';
                  param['Filter'] = '';
                  param['ToDate'] = '0';
                  param['FromDate'] = '0';
                  param['Product_SKU_GlCode'] = Product_SKU_GlCode.toString();
                  param['DispatchId'] =
                      widget.data.fk_DispatchGlCode.toString();
                  param['CustomerId'] = mainCustomerGlCode.toString();
                  param['Batch_No'] = type == 2 ? batchNo : '';
                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(
                      POST_METHOD, 'SalesSummary_Device_Report', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (mounted) {
          if (apiCallType == 1) {
            if (mounted) {
              setState(() {
                list.clear();
                listDisplay.clear();

                listDisplay.addAll(responseModel.getSalesSummarySKUList());
                list.addAll(listDisplay);
                if (listDisplay.length > 0) {
                  isNoData = false;
                } else {
                  isNoData = true;
                }
              });
            }
          } else {
            if (mounted) {
              setState(() {
                listSticker.clear();
                listStickerDisplay.clear();

                listStickerDisplay
                    .addAll(responseModel.getSalesSummarySKUStickerList());
                listSticker.addAll(listStickerDisplay);

                showDialog<Map>(
                    context: context,
                    builder: (context) => MyForm(
                          screenSize: screenSize,
                          listSticker: listSticker,
                          listStickerDisplay: listStickerDisplay,
                        ));
              });
            }
          }
        }
      } else if (responseModel.Status.contains('2')) {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'Session_warning'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {
                final Route route =
                    CupertinoPageRoute(builder: (context) => Dashboard());
                Navigator.pushAndRemoveUntil(
                    context, route, (Route<dynamic> route) => false);
              },
            );
          },
        );
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: Colors.white,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle,
                      'assets/ic_sales_summary_white.png', 0),
                  Card(
                    margin: const EdgeInsets.only(
                        left: 10, top: 10, bottom: 7, right: 10),
                    elevation: 3,
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: <Widget>[
                          Wrap(
                            direction: Axis.horizontal,
                            runAlignment: WrapAlignment.start,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'Date_'),
                                style: prifixTxtStyle,
                              ),
                              Text(
                                widget.data.dtDispatchDate,
                                style: textStyle,
                              ),
                            ],
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(left: 7),
                              child: Wrap(
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                children: <Widget>[
                                  Text(
                                    '${widget.data.varEntityName}:',
                                    style: prifixTxtStyle,
                                  ),
                                  Text(
                                    widget.data.varDONO,
                                    style: textStyle,
                                  ),
                                ],
                              ),
                            ),
                            flex: 1,
                          )
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    color: const Color(colorAccent),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotUnits_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Text(
                                widget.data.TotalUnits.toString(),
                                style: textPrimaryStyle,
                              ),
                            ],
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: 1,
                          color: Colors.white70,
                        ),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotArticle_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Text(
                                widget.data.TotalArticle.toString(),
                                style: textPrimaryStyle,
                              ),
                            ],
                          ),
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 1,
                    child: listDisplay.length > 0
                        //child: listDisplay.length > 0
                        ? Container(
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemBuilder: (context, position) {
                                return GestureDetector(
                                    child: Card(
                                        margin: const EdgeInsets.only(
                                            left: 10,
                                            top: 7,
                                            bottom: 7,
                                            right: 10),
                                        elevation: 3,
                                        child: Container(
                                          padding: const EdgeInsets.all(10),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.start,
                                            children: <Widget>[
                                              Row(
                                                children: <Widget>[
//                                                  Container(
//                                                    child: Text(
//                                                      LocaleUtils.getString(
//                                                          mContext,
//                                                          'ArticleName'),
//                                                      style: prifixTxtStyle,
//                                                      textAlign:
//                                                          TextAlign.start,
//                                                    ),
//                                                    alignment:
//                                                        Alignment.topLeft,
//                                                  ),
                                                  Expanded(
                                                    child: Container(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 0),
                                                      child: Text(
                                                        listDisplay[position]
                                                            .varProduct_SKU_Name
                                                            .toString(),
                                                        style: TextStyle(
                                                          fontSize: 15.0,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          color: Colors.black,
                                                        ),
                                                      ),
                                                    ),
                                                    flex: 1,
                                                  ),
                                                ],
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                mainAxisSize: MainAxisSize.max,
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 5),
                                                child: Row(
                                                  children: <Widget>[
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 10),
                                                      child: Wrap(
                                                        direction:
                                                            Axis.horizontal,
                                                        runAlignment:
                                                            WrapAlignment.start,
                                                        crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Text(
                                                            LocaleUtils
                                                                .getString(
                                                                    mContext,
                                                                    'Batch_'),
                                                            style:
                                                                prifixTxtStyle,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 3),
                                                            child: Text(
                                                              listDisplay[
                                                                      position]
                                                                  .varBatch_No
                                                                  .toString(),
                                                              style: textStyle,
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
//                                                    Expanded(
//                                                      child: Wrap(
//                                                        direction:
//                                                            Axis.horizontal,
//                                                        crossAxisAlignment:
//                                                            WrapCrossAlignment
//                                                                .center,
//                                                        alignment:
//                                                            WrapAlignment.end,
//                                                        children: <Widget>[
//                                                          Text(
//                                                            LocaleUtils.getString(
//                                                                mContext,
//                                                                'ArticleCode_'),
//                                                            style:
//                                                                prifixTxtStyle,
//                                                          ),
//                                                          Padding(
//                                                            padding:
//                                                                const EdgeInsets
//                                                                        .only(
//                                                                    top: 3),
//                                                            child: Text(
//                                                              listDisplay[
//                                                                      position]
//                                                                  .varProduct_SKU_Code
//                                                                  .toString(),
//                                                              style: textStyle,
//                                                            ),
//                                                          )
//                                                        ],
//                                                      ),
//                                                      flex: 1,
//                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 5),
                                                child: Row(
                                                  children: <Widget>[
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              right: 10),
                                                      child: Wrap(
                                                        direction:
                                                            Axis.horizontal,
                                                        crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                        children: <Widget>[
                                                          Text(
                                                            LocaleUtils
                                                                .getString(
                                                                    mContext,
                                                                    'Units_'),
                                                            style:
                                                                prifixTxtStyle,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 3),
                                                            child: Text(
                                                              listDisplay[
                                                                      position]
                                                                  .TotalUnti
                                                                  .toStringAsFixed(
                                                                      2),
                                                              style: textStyle,
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                    Expanded(
                                                      child: Wrap(
                                                        direction:
                                                            Axis.horizontal,
                                                        crossAxisAlignment:
                                                            WrapCrossAlignment
                                                                .center,
                                                        alignment:
                                                            WrapAlignment.end,
                                                        children: <Widget>[
                                                          Text(
                                                            '${LocaleUtils
                                                                .getString(
                                                                mContext,
                                                                'Qty')}.(${globals
                                                                .KG_PCS}.)',
                                                            style:
                                                                prifixTxtStyle,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 3),
                                                            child: Text(
                                                              listDisplay[position]
                                                                          .QtyKG >
                                                                      0
                                                                  ? listDisplay[
                                                                          position]
                                                                      .QtyKG
                                                                      .toStringAsFixed(
                                                                          2)
                                                                  : '0.00',
                                                              style: textStyle,
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                      flex: 1,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        )),
                                    onTap: () {
                                      batchNo =
                                          listDisplay[position].varBatch_No;
                                      getData(2,
                                          listDisplay[position].fk_SKU_GlCode);
                                    });
                              },
                              itemCount: listDisplay.length,
                            ),
                          )
                        : Visibility(
                            child: Container(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Image.asset(
                                    'assets/nodata_icon.png',
                                    height: 100,
                                    width: 100,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      LocaleUtils.getString(
                                          mContext, 'NoDataFound'),
                                      style: prifixTxtStyle,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            visible: isNoData,
                          ),
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  AlertDialog scanRecordShowDialog() {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: screenSize.width * 0.9,
          height: screenSize.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(
                      LocaleUtils.getString(mContext, 'ScannedSerialNo'),
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.centerLeft,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: searchcontroller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey),
                              hintText: LocaleUtils.getString(
                                  mContext, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                // child: listStickerDisplay.length > 0
                child: listStickerDisplay.length > 0
                    ? Container(
                        child: ListView.builder(
                          itemCount: listStickerDisplay.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return Column(
                              children: <Widget>[
                                Container(
                                  height: 35,
                                  width: screenSize.width,
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                        '#' +
                                            listStickerDisplay[index]
                                                .intRowNo
                                                .toString() +
                                            '     ' +
                                            listStickerDisplay[index]
                                                .varSticker,
                                        style: TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'helvetica',
                                        )),
                                  ),
                                ),
                                Container(
                                  width: screenSize.width,
                                  color: Colors.black12,
                                  height: 1,
                                ),
                              ],
                            );
                          },
                        ),
                      )
                    : Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              'assets/nodata_icon.png',
                              height: 100,
                              width: 100,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                LocaleUtils.getString(mContext, 'NoDataFound'),
                                style: prifixTxtStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                flex: 1,
              ),
              Container(
                width: screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(mContext, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  void filterSearchResults(String query) {
    print(query);
    final List<SalesSummarySKUStickerModel> dummySearchList =
        List<SalesSummarySKUStickerModel>();
    dummySearchList.addAll(listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<SalesSummarySKUStickerModel> dummyListData =
          List<SalesSummarySKUStickerModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          listStickerDisplay.clear();
          listStickerDisplay.addAll(dummyListData);
        });
      }
    } else {
      if (mounted) {
        setState(() {
          listStickerDisplay.clear();
          listStickerDisplay.addAll(listSticker);
        });
      }
    }

    print(listStickerDisplay.length);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class MyForm extends StatefulWidget {
  Size screenSize;
  List<SalesSummarySKUStickerModel> listSticker = List();
  List<SalesSummarySKUStickerModel> listStickerDisplay = List();
  final TextEditingController searchcontroller = TextEditingController();

  MyForm({this.screenSize, this.listSticker, this.listStickerDisplay});

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: widget.screenSize.width * 0.9,
          height: widget.screenSize.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: widget.screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(LocaleUtils.getString(context, 'ScannedSerialNo'),
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.centerLeft,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: widget.searchcontroller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey),
                              hintText:
                                  LocaleUtils.getString(context, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: const Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                //child: widget.listStickerDisplay.length > 0
                child: widget.listStickerDisplay.length > 0
                    ? Container(
                        child: ListView.builder(
                          itemCount: widget.listStickerDisplay.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return Column(
                              children: <Widget>[
                                Container(
                                  height: 35,
                                  width: widget.screenSize.width,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                              '#' +
                                                  widget
                                                      .listStickerDisplay[index]
                                                      .intRowNo
                                                      .toString(),
                                              style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: 'helvetica',
                                              )),
                                        ),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: Align(
                                          alignment: Alignment.centerLeft,
                                          child: Text(
                                              widget.listStickerDisplay[index]
                                                  .varSticker,
                                              style: TextStyle(
                                                fontSize: 14.0,
                                                fontWeight: FontWeight.w400,
                                                fontFamily: 'helvetica',
                                              )),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                /*Container(
                                  height: 35,
                                  width: widget.screenSize.width,
                                  child: Align(
                                    alignment: Alignment.center,
                                    child: Text(
                                        '#' +
                                            widget.listStickerDisplay[index]
                                                .intRowNo
                                                .toString() +
                                            '     ' +
                                            widget.listStickerDisplay[index]
                                                .varSticker,
                                        style: TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'helvetica',
                                        )),
                                  ),
                                ),*/
                                Container(
                                  width: widget.screenSize.width,
                                  color: Colors.black12,
                                  height: 1,
                                ),
                              ],
                            );
                          },
                        ),
                      )
                    : Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              'assets/nodata_icon.png',
                              height: 100,
                              width: 100,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                LocaleUtils.getString(context, 'NoDataFound'),
                                style: prifixTxtStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                flex: 1,
              ),
              Container(
                width: widget.screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(context, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  void filterSearchResults(String query) {
    print(query);
    final List<SalesSummarySKUStickerModel> dummySearchList =
        List<SalesSummarySKUStickerModel>();
    dummySearchList.addAll(widget.listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<SalesSummarySKUStickerModel> dummyListData =
          List<SalesSummarySKUStickerModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(widget.listSticker);
        });
    }

    //print(widget.listStickerDisplay.length);
  }
}
