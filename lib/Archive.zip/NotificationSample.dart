//NotificationSample

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';

final Map<String, Item> _items = <String, Item>{};

Item _itemForMessage(Map<String, dynamic> message) {
  /*final String itemId = message['data']['id'];
  final Item item = _items.putIfAbsent(itemId, () => Item(itemId: itemId))
    ..status = message['data']['status'];
  return item;*/

  //Map<String, Item> _items = <String, Item>{};

  return null;
}

class Item {
  Item({this.itemId});

  final String itemId;

  StreamController<Item> _controller = StreamController<Item>.broadcast();

  Stream<Item> get onChanged => _controller.stream;

  String _status;

  String get status => _status;

  set status(String value) {
    _status = value;
    _controller.add(this);
  }

  static final Map<String, Route<void>> routes = <String, Route<void>>{};

  Route<void> get route {
    final String routeName = '/detail/$itemId';
    return routes.putIfAbsent(
      routeName,
      () => CupertinoPageRoute<void>(
        settings: RouteSettings(name: routeName),
        builder: (BuildContext context) => DetailPage(itemId),
      ),
    );
  }
}

class DetailPage extends StatefulWidget {
  DetailPage(this.itemId);

  final String itemId;

  @override
  _DetailPageState createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  Item _item;
  StreamSubscription<Item> _subscription;

  @override
  void initState() {
    super.initState();
    _item = _items[widget.itemId];
    _subscription = _item.onChanged.listen((Item item) {
      if (!mounted) {
        _subscription.cancel();
      } else {
        setState(() {
          _item = item;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:
            Text(LocaleUtils.getString(context, "Item") + " ${_item.itemId}"),
      ),
      body: Material(
        child: Center(
            child: Text(LocaleUtils.getString(context, "Item_status") +
                ": ${_item.status}")),
      ),
    );
  }
}

class PushMessagingExample extends StatefulWidget {
  @override
  _PushMessagingExampleState createState() => _PushMessagingExampleState();
}

class _PushMessagingExampleState extends State<PushMessagingExample> {
  String _homeScreenText = "Waiting for token...";
  bool _topicButtonsDisabled = false;


  final TextEditingController _topicController =
      TextEditingController(text: 'topic');

  Widget _buildDialog(BuildContext context, Item item) {
    return AlertDialog(
      content: Text("Item 0 has been updated"),
      actions: <Widget>[
        FlatButton(
          child: const Text('CLOSE'),
          onPressed: () {
            Navigator.pop(context, false);
          },
        ),
        FlatButton(
          child: const Text('SHOW'),
          onPressed: () {
            Navigator.pop(context, true);
          },
        ),
      ],
    );
  }

  void _showItemDialog(Map<String, dynamic> message) {
    showDialog<bool>(
      context: context,
      builder: (_) => _buildDialog(context, _itemForMessage(message)),
    ).then((bool shouldNavigate) {
      if (shouldNavigate == true) {
        _navigateToItemDetail(message);
      }
    });
  }

  void _navigateToItemDetail(Map<String, dynamic> message) {
    final Item item = _itemForMessage(message);
    // Clear away dialogs
    Navigator.popUntil(context, (Route<dynamic> route) => route is PageRoute);
    if (!item.route.isCurrent) {
      Navigator.push(context, item.route);
    }
  }

  @override
  void initState() {
    super.initState();

//    try {
//      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
//        final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
//        _firebaseMessaging.configure(
//          onMessage: (Map<String, dynamic> message) async {
//            print("onMessage: $message");
//            _showItemDialog(message);
//          },
//          onLaunch: (Map<String, dynamic> message) async {
//            print("onLaunch: $message");
//            _navigateToItemDetail(message);
//          },
//          onResume: (Map<String, dynamic> message) async {
//            print("onResume: $message");
//            _navigateToItemDetail(message);
//          },
//        );
//
//        _firebaseMessaging.requestNotificationPermissions(
//            const IosNotificationSettings(
//                sound: true, badge: true, alert: true));
//        _firebaseMessaging.onIosSettingsRegistered
//            .listen((IosNotificationSettings settings) {
//          print("Settings registered: $settings");
//        });
//
//        _firebaseMessaging.getToken().then((String token) {
//          assert(token != null);
//          setState(() {
//            print(token);
//            _homeScreenText = "Push Messaging token: $token";
//          });
//          print(_homeScreenText);
//        });
//      }
//    } catch (e) {
//      print(e);
//    }
    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        //BaseClassChina().initilizeFirebase(pus)
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Push Messaging Demo'),
        ),
        // For testing -- simulate a message being received
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showItemDialog(<String, dynamic>{
            "data": <String, String>{
              "id": "2",
              "status": "out of stock",
            },
          }),
          tooltip: 'Simulate Message',
          child: const Icon(Icons.message),
        ),
        body: Material(
          child: Column(
            children: <Widget>[
              Center(
                child: Text(_homeScreenText),
              ),
              Row(children: <Widget>[
                Expanded(
                  child: TextField(
                      controller: _topicController,
                      //enableInteractiveSelection: false,
                      onChanged: (String v) {
                        setState(() {
                          _topicButtonsDisabled = v.isEmpty;
                        });
                      }),
                ),
                FlatButton(
                  child: const Text("subscribe"),
                  onPressed: _topicButtonsDisabled
                      ? null
                      : () {
//                          _firebaseMessaging
//                              .subscribeToTopic(_topicController.text);
                          _clearTopicText();
                        },
                ),
                FlatButton(
                  child: const Text("unsubscribe"),
                  onPressed: _topicButtonsDisabled
                      ? null
                      : () {
//                          _firebaseMessaging
//                              .unsubscribeFromTopic(_topicController.text);
                          _clearTopicText();
                        },
                ),
              ])
            ],
          ),
        ));
  }

  void _clearTopicText() {
    setState(() {
      _topicController.text = "";
      _topicButtonsDisabled = true;
    });
  }
}

/*void main() {
  runApp(
    MaterialApp(
      home: PushMessagingExample(),
    ),
  );
}*/

//{notification: {title: test notification flutter, body: this is test notification flutter }, data: {}}
//{"notification": {"body": "this is a body","title": "this is a title"}, "priority": "high",
// "data": {"click_action": "FLUTTER_NOTIFICATION_CLICK", "id": "1", "status": "done"}, "to": "<FCM TOKEN>"}
//{title: test notification flutter 1, body: this is test notification flutter 1}, data: {status: done, id: 1, click_action: FLUTTER_NOTIFICATION_CLICK}}

//{status: done, google.c.a.c_l: flutt5k, google.c.a.e: 1, id: 1, aps:
// {alert: {title: test notification flutter 5k, body: this is test notification flutter 5k}},
// gcm.n.e: 1, google.c.a.c_id: 808089316255572420, google.c.a.udt: 0, gcm.message_id: 0:1555666357183156%debf4539debf4539,
// google.c.a.ts: 1555666357, click_action: FLUTTER_NOTIFICATION_CLICK}
