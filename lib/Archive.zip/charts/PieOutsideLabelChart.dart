import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/model/LinearSales.dart';

class PieOutsideLabelChart extends StatelessWidget {
  final List<charts.Series> seriesList;
  final bool animate;

  PieOutsideLabelChart(this.seriesList, {this.animate});

  /// Creates a [PieChart] with sample data and no transition.
  factory PieOutsideLabelChart.withSampleData(List<LinearSales> data) {
    return new PieOutsideLabelChart(
      _createSampleData(data),
      // Disable animations for image tests.
      animate: true,
    );
  }


  @override
  Widget build(BuildContext context) {
    return new charts.PieChart(seriesList,
        animate: animate,
        animationDuration: Duration(seconds: 1),
        /*defaultRenderer: new charts.ArcRendererConfig(arcRendererDecorators: [
          new charts.ArcLabelDecorator(
              labelPosition: charts.ArcLabelPosition.outside)
        ])*/
        /*defaultRenderer: new charts.ArcRendererConfig(
            arcWidth: 60,
            arcRendererDecorators: [new charts.ArcLabelDecorator()])*/
        defaultRenderer: new charts.ArcRendererConfig(
            arcWidth: 150,
            arcRendererDecorators: [new charts.ArcLabelDecorator(labelPosition: charts.ArcLabelPosition.inside)]));


  }

  /// Create one series with sample hard coded data.
  static List<charts.Series<LinearSales, int>> _createSampleData(List<LinearSales> data) {
    /*final data = [
      new LinearSales(0, 100,charts.Color.fromHex(code: '#5e9bd4')),
      new LinearSales(1, 75,charts.Color.fromHex(code: '#ee7e32')),
      new LinearSales(2, 25,charts.Color.fromHex(code: '#a5a5a5')),
      new LinearSales(3, 65,charts.Color.fromHex(code: '#11a6be')),
      new LinearSales(4, 97,charts.Color.fromHex(code: '#114b95')),
      new LinearSales(5, 39,charts.Color.fromHex(code: '#91c66a')),
      new LinearSales(6, 51,charts.Color.fromHex(code: '#ed4799')),
      new LinearSales(7, 88,charts.Color.fromHex(code: '#5b2d90')),
    ];*/

    return [
      new charts.Series<LinearSales, int>(
        id: 'Sales',
        domainFn: (LinearSales sales, _) => sales.year,
        measureFn: (LinearSales sales, _) => sales.sales,
        data: data,
        colorFn: (LinearSales sales, _) => sales.color,
        labelAccessorFn: (LinearSales sales, _) => '${sales.sales}',
      )
    ];
  }
}

