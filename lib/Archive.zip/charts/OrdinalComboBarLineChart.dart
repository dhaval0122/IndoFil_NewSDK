import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter_basf_hk_app/model/OrdinalSales.dart';

class OrdinalComboBarLineChart extends StatelessWidget {
  final List<charts.Series> seriesList;
  final bool animate;

  OrdinalComboBarLineChart(this.seriesList, {this.animate});

  factory OrdinalComboBarLineChart.withSampleData(
      List<OrdinalSales> currentYearList,
      List<OrdinalSales> previousYearList,
      List<OrdinalSales> growthList) {
    return new OrdinalComboBarLineChart(
      _createSampleData(currentYearList, previousYearList, growthList),
      // Disable animations for image tests.
      animate: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return new charts.OrdinalComboChart(seriesList,
        animate: animate,
        animationDuration: Duration(seconds: 1),
//        behaviors: [new charts.PanAndZoomBehavior()],
        // Configure the default renderer as a bar renderer.
        /*defaultRenderer: new charts.BarRendererConfig(
            groupingType: charts.BarGroupingType.grouped),*/
        // Custom renderer configuration for the line series. This will be used for
        // any series that does not define a rendererIdKey.
        customSeriesRenderers: [
          new charts.LineRendererConfig(
              // ID used to link series to this renderer.
              customRendererId: 'customLine')
        ]);
  }

  /// Create series list with multiple series
  static List<charts.Series<OrdinalSales, String>> _createSampleData(
    List<OrdinalSales> currentYearList,
    List<OrdinalSales> previousYearList,
    List<OrdinalSales> growthList,
  ) {
    /*final desktopSalesData = [
      new OrdinalSales('1', 50),
      new OrdinalSales('2', 25),
      new OrdinalSales('3', 100),
      new OrdinalSales('4', 75),
      new OrdinalSales('5', 53),
      new OrdinalSales('6', 48),
      new OrdinalSales('7', 68),
      new OrdinalSales('8', 84),
      new OrdinalSales('9', 73),
      new OrdinalSales('10', 67),
      new OrdinalSales('11', 38),
      new OrdinalSales('12', 48),
    ];

    final tableSalesData = [
      new OrdinalSales('1', 65),
      new OrdinalSales('2', 35),
      new OrdinalSales('3', 58),
      new OrdinalSales('4', 98),
      new OrdinalSales('5', 100),
      new OrdinalSales('6', 68),
      new OrdinalSales('7', 78),
      new OrdinalSales('8', 65),
      new OrdinalSales('9', 48),
      new OrdinalSales('10', 39),
      new OrdinalSales('11', 58),
      new OrdinalSales('12', 96),
    ];

    final mobileSalesData = [
      new OrdinalSales('1', 78),
      new OrdinalSales('2', 98),
      new OrdinalSales('3', 85),
      new OrdinalSales('4', 45),
      new OrdinalSales('5', 54),
      new OrdinalSales('6', 65),
      new OrdinalSales('7', 21),
      new OrdinalSales('8', 83),
      new OrdinalSales('9', 100),
      new OrdinalSales('10', 69),
      new OrdinalSales('11', 78),
      new OrdinalSales('12', 69),
    ];*/
//charts.MaterialPalette.blue.shadeDefault
    return [
      new charts.Series<OrdinalSales, String>(
          id: 'Current',
          colorFn: (_, __) => charts.Color.fromHex(code: '#58c8e3'),
          domainFn: (OrdinalSales sales, _) => sales.year,
          measureFn: (OrdinalSales sales, _) => sales.sales,
          data: currentYearList,
          labelAccessorFn: (OrdinalSales sales, _) =>
              '${sales.year}: \$${sales.sales.toString()}'),
      new charts.Series<OrdinalSales, String>(
          id: 'Previous',
          colorFn: (_, __) => charts.Color.fromHex(code: '#ee57a2'),
          domainFn: (OrdinalSales sales, _) => sales.year,
          measureFn: (OrdinalSales sales, _) => sales.sales,
          data: previousYearList,
          labelAccessorFn: (OrdinalSales sales, _) =>
              '${sales.year}: \$${sales.sales.toString()}'),
      new charts.Series<OrdinalSales, String>(
          id: 'Growth ',
          colorFn: (_, __) => charts.Color.fromHex(code: '#b6b6b4'),
          domainFn: (OrdinalSales sales, _) => sales.year,
          measureFn: (OrdinalSales sales, _) => sales.sales,
          data: growthList,
          labelAccessorFn: (OrdinalSales sales, _) =>
              '${sales.year}: \$${sales.sales.toString()}')
        // Configure our custom line renderer for this series.
        ..setAttribute(charts.rendererIdKey, 'customLine'),
    ];
  }
}
