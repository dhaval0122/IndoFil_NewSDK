import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/model/OrdinalSales.dart';

class HorizontalBarChart extends StatelessWidget {
  final List<charts.Series> seriesList;
  final bool animate;

  HorizontalBarChart(this.seriesList, {this.animate});

  /// Creates a [BarChart] with sample data and no transition.
  factory HorizontalBarChart.withSampleData(
      List<OrdinalSales> data, List<OrdinalSales> data1,
      List<OrdinalSales> data2,List<OrdinalSales> data3) {
    return new HorizontalBarChart(
      _createSampleData(data,data1,data2,data3),
      // Disable animations for image tests.
      animate: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    // For horizontal bar charts, set the [vertical] flag to false.
    return new charts.BarChart(
      seriesList,
      animate: animate,
      animationDuration: Duration(seconds: 1),
      vertical: false,
    );
  }

  /// Create one series with sample hard coded data.
  static List<charts.Series<OrdinalSales, String>> _createSampleData(
      List<OrdinalSales> data, List<OrdinalSales> data1,
      List<OrdinalSales> data2,List<OrdinalSales> data3) {
    /*final data = [
      new OrdinalSales('JF', 5),
      new OrdinalSales('JT', 25),
      new OrdinalSales('BA', 100),
      new OrdinalSales('JW', 45),
      new OrdinalSales('JV', 75),
      new OrdinalSales('JU', 68),
      new OrdinalSales('6D', 97),
      new OrdinalSales('6C', 36),
    ];
    final data1 = [
      new OrdinalSales('JF', 25),
      new OrdinalSales('JT', 85),
      new OrdinalSales('BA', 45),
      new OrdinalSales('JW', 59),
      new OrdinalSales('JV', 28),
      new OrdinalSales('JU', 100),
      new OrdinalSales('6D', 67),
      new OrdinalSales('6C', 88),
    ];
    final data2 = [
      new OrdinalSales('JF', 36),
      new OrdinalSales('JT', 45),
      new OrdinalSales('BA', 69),
      new OrdinalSales('JW', 99),
      new OrdinalSales('JV', 69),
      new OrdinalSales('JU', 77),
      new OrdinalSales('6D', 78),
      new OrdinalSales('6C', 100),
    ];
    final data3 = [
      new OrdinalSales('JF', 88),
      new OrdinalSales('JT', 77),
      new OrdinalSales('BA', 100),
      new OrdinalSales('JW', 66),
      new OrdinalSales('JV', 78),
      new OrdinalSales('JU', 55),
      new OrdinalSales('6D', 33),
      new OrdinalSales('6C', 11),
    ];*/

    return [
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#ffc000'),
        data: data,
      ),
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#a4a4a4'),
        data: data1,
      ),
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#ed7d31'),
        data: data2,
      ),
      new charts.Series<OrdinalSales, String>(
        id: 'Sales',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#5a9bd5'),
        data: data3,
      )
    ];
  }
}
