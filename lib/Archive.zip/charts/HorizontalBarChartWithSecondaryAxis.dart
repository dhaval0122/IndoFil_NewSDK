/// Bar chart example
import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter_basf_hk_app/model/OrdinalSales.dart';

/// Example of using a primary and secondary axis (left & right respectively)
/// for a set of grouped bars. This is useful for comparing Series that have
/// different units (revenue vs clicks by region), or different magnitudes (2017
/// revenue vs 1/1/2017 revenue by region).
///
/// The first series plots using the primary axis to position its measure
/// values (bar height). This is the default axis used if the measureAxisId is
/// not set.
///
/// The second series plots using the secondary axis due to the measureAxisId of
/// secondaryMeasureAxisId.
///
/// Note: primary and secondary may flip left and right positioning when
/// RTL.flipAxisLocations is set.
class HorizontalBarChartWithSecondaryAxis extends StatelessWidget {
  static const secondaryMeasureAxisId = 'secondaryMeasureAxisId';
  final List<charts.Series> seriesList;
  final bool animate;

  HorizontalBarChartWithSecondaryAxis(this.seriesList, {this.animate});

  factory HorizontalBarChartWithSecondaryAxis.withSampleData(List<OrdinalSales> globalSalesData,List<OrdinalSales> losAngelesSalesData) {
    return new HorizontalBarChartWithSecondaryAxis(
      _createSampleData(globalSalesData,losAngelesSalesData),
      // Disable animations for image tests.
      animate: true,
    );
  }


  @override
  Widget build(BuildContext context) {
    // For horizontal bar charts, set the [vertical] flag to false.
    return new charts.BarChart(
      seriesList,
      animate: animate,
      animationDuration: Duration(seconds: 1),
      barGroupingType: charts.BarGroupingType.grouped,
      vertical: false,
      // It is important when using both primary and secondary axes to choose
      // the same number of ticks for both sides to get the gridlines to line
      // up.
      primaryMeasureAxis: new charts.NumericAxisSpec(
          tickProviderSpec:
          new charts.BasicNumericTickProviderSpec(desiredTickCount: 3)),
      secondaryMeasureAxis: new charts.NumericAxisSpec(
          tickProviderSpec:
          new charts.BasicNumericTickProviderSpec(desiredTickCount: 3)),
    );
  }

  /// Create series list with multiple series
  static List<charts.Series<OrdinalSales, String>> _createSampleData(List<OrdinalSales> globalSalesData,List<OrdinalSales> losAngelesSalesData) {
    /*final globalSalesData = [
      new OrdinalSales('Malaysia', 450000),
      new OrdinalSales('Philippines', 25000),
      new OrdinalSales('Thailand', 100000),
      new OrdinalSales('Japan', 750000),
      new OrdinalSales('India', 350000),
      new OrdinalSales('South korea', 650000),
      new OrdinalSales('Sudan', 850000),
      new OrdinalSales('Indonesia', 650000),
      new OrdinalSales('China', 470000),
      new OrdinalSales('Taiwan', 960000),
    ];

    final losAngelesSalesData = [
      new OrdinalSales('Malaysia', 150000),
      new OrdinalSales('Philippines', 85000),
      new OrdinalSales('Thailand', 58000),
      new OrdinalSales('Japan', 1000000),
      new OrdinalSales('India', 650000),
      new OrdinalSales('South korea', 350000),
      new OrdinalSales('Sudan', 960000),
      new OrdinalSales('Indonesia', 480000),
      new OrdinalSales('China', 270000),
      new OrdinalSales('Taiwan', 190000),
    ];*/

    return [
      new charts.Series<OrdinalSales, String>(
        id: 'Global Revenue',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#53c6e1'),
        data: globalSalesData,
      ),
      new charts.Series<OrdinalSales, String>(
        id: 'Los Angeles Revenue',
        domainFn: (OrdinalSales sales, _) => sales.year,
        measureFn: (OrdinalSales sales, _) => sales.sales,
        colorFn: (OrdinalSales sales, _) => charts.Color.fromHex(code: '#ed4799'),
        data: losAngelesSalesData,
      )..setAttribute(charts.measureAxisIdKey, secondaryMeasureAxisId)
      // Set the 'Los Angeles Revenue' series to use the secondary measure axis.
      // All series that have this set will use the secondary measure axis.
      // All other series will use the primary measure axis.
    ];
  }
}