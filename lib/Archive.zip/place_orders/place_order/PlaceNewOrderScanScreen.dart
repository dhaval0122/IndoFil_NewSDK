import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/components/SearchableSpinner.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/PlaceOrderModel.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderConfirmScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';

// ignore: must_be_immutable
class PlaceNewOrderScanScreen extends StatefulWidget {
  int fk_OrderGlCode;
  bool isUpdate;

  PlaceNewOrderScanScreen({this.fk_OrderGlCode, this.isUpdate});

  @override
  PlaceNewOrderScanScreenState createState() =>
      PlaceNewOrderScanScreenState(fk_OrderGlCode: fk_OrderGlCode);
}

class PlaceNewOrderScanScreenState extends State<PlaceNewOrderScanScreen>
    implements
        PushNotificationListener,
        ItemClickSearchableSpinner,
        WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isEditable = false,
      isSync = false;
  String dropdownValue;
  Size screenSize;
  String userName = '',
      subTitle,
      topHeaderImage = 'assets/neworder_icon.png';
  int receiveCount = 0;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController serialNoTextController;
  WSPresenter wsPresenter;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  int intEditIndex = -1;
  int fk_OrderGlCode;
  static int apiCallType = 0;

  List<Product_Sku_Mst_Model> listSKU;
  Product_Sku_Mst_Model selectedSKU;
  List<Order_Product_Details> listQty;
  List<Scanning_Details> listScanningDetails;

  PlaceNewOrderScanScreenState({this.fk_OrderGlCode});

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();
    mUtils = Utils();

    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    pushNotificationServices = PushNotificationServices(this);

    serialNoTextController = TextEditingController();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
            subTitle = LocaleUtils.getString(mContext, 'tag_place_new_order');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_RECEIVE_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          receiveCount = count;
        });
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    listSKU = List();
    listQty = List();
    listScanningDetails = List();
    apiCall(1, '');
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void apiCall(int type, String JSONData) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGlCode) {
              param[PARAM_PERSON_ID] = loginID;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param[PARAM_DEVICE_ID] = deviceid;
                  if (type == 1) {
                    param[PARAM_ACTION] = "GetMasters";
                  } else if (type == 2) {
                    param[PARAM_ACTION] = "InsertProductDetail";
                  } else if (type == 3) {
                    param[PARAM_ACTION] = "ScanningDetail";
                  }

                  param['OrderId'] = '$fk_OrderGlCode';
                  param['OrderProductId'] = '';
                  param['ToCustomerId'] = mainCustomerGlCode.toString();
                  param['ProductSkuId'] = '';
                  param['JSONData'] = JSONData;
                  param['Remarks'] = '';

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Order_Information', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
              LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedPositive: () {
                if (apiCallType == 1) {
                  Navigator.pop(mContext, false);
                }
              },
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: errorTxt,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {
            if (apiCallType == 1) {
              Navigator.pop(mContext, false);
            }
          },
        );
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;

    if (apiCallType != 1) {
      dismissProgressHUD();
    }

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
    GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (mounted) {
          if (apiCallType == 1) {
            listSKU.clear();
            listSKU.addAll(responseModel.getProductSkuMstList_PlaceOrder());
            apiCall(3, '');
          } else if (apiCallType == 2) {
            redirectPlaceNewOrderConfirmScreen();
          } else if (apiCallType == 3) {
            listScanningDetails.clear();
            listScanningDetails
                .addAll(responseModel.getScanning_Details_PlaceOrder());
          }
        }
      } else {
        if (apiCallType == 2) {
          _showSnackBar(responseModel.Message);
        }
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                        LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                        LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                        LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
              // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void redirectPlaceNewOrderConfirmScreen() {
    if (widget.isUpdate) {
      Navigator.pop(mContext, true);
    } else {
      final Route route = CupertinoPageRoute(
          builder: (context) =>
              PlaceNewOrderConfirmScreen(fk_OrderGlCode: fk_OrderGlCode));
      Navigator.pushReplacement(mContext, route);
    }
  }

  void editRecord(int index) {
    isEditable = true;
    intEditIndex = index;
    Scanning_Details scanning_details = listScanningDetails[index];
    if (scanning_details != null) {
      selectedSKU = null;
      for (Product_Sku_Mst_Model data in listSKU) {
        if (data.intGlCode == scanning_details.fk_Product_SKUGlCode) {
          setState(() {
            selectedSKU = data;
          });
          break;
        }
      }

      serialNoTextController.text = scanning_details.decQuantityInKG.toString();

      if (mounted) {
        setState(() {});
      }
    }
  }

  void deleteRecord(int index) {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'del_conform'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'no'),
              textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
              onPressedNegative: () {},
              onPressedPositive: () {
                if (mounted) {
                  setState(() {
                    listScanningDetails.removeAt(index);
                  });
                }
              },
            ));
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      //enableInteractiveSelection: false,
      keyboardType:
      TextInputType.numberWithOptions(decimal: false, signed: false),
      textInputAction: TextInputAction.done,
      onFieldSubmitted: (value) {},
      autovalidate: false,
      autofocus: false,
      style: textStyle,
      maxLines: 1,
      maxLength: 6,
      decoration: InputDecoration(
          hintText: LocaleUtils.getString(mContext, 'Qty'),
          border: InputBorder.none,
          //contentPadding: EdgeInsets.fromLTRB(0, p_15, 0, 0),
          errorStyle: errorStyle,
          hintStyle: hintStyle,
          counterText: ""),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (selectedSKU == null) {
            _showSnackBar(
                LocaleUtils.getString(mContext, 'plz_select_article'));
          } else if (serialNoTextController.text.trim().isEmpty) {
            _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterQty'));
          } else if (double.parse(serialNoTextController.text) <= 0) {
            _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterQty_'));
          } else {
            bool isInsert = true;
            if (listScanningDetails.length > 0) {
              for (int i = 0; i < listScanningDetails.length; i++) {
                Scanning_Details scanning_details = listScanningDetails[i];
                if (scanning_details.fk_Product_SKUGlCode ==
                    selectedSKU.intGlCode) {
                  isInsert = false;
                  break;
                }
              }
            }

            if (isInsert) {
              FocusScope.of(mContext).requestFocus(FocusNode());
              Scanning_Details d2 = new Scanning_Details(
                  fk_OrderGlCode: fk_OrderGlCode,
                  fk_Product_SKUGlCode: selectedSKU.intGlCode,
                  varProduct_SKU_Code: selectedSKU.varProduct_SKU_Code,
                  varProduct_SKU_Name: selectedSKU.varProduct_SKU_Name,
                  decQuantityInKG:
                  double.parse(serialNoTextController.text.trim()));

              if (mounted) {
                setState(() {
                  listScanningDetails.add(d2);
                  serialNoTextController.text = '';
                  selectedSKU = null;
                  isEditable = false;
                  intEditIndex = -1;
                });
              }
            } else {
              if (isEditable) {
                FocusScope.of(mContext).requestFocus(FocusNode());
                Scanning_Details d2 = new Scanning_Details(
                    fk_OrderGlCode: fk_OrderGlCode,
                    fk_Product_SKUGlCode: selectedSKU.intGlCode,
                    varProduct_SKU_Code: selectedSKU.varProduct_SKU_Code,
                    varProduct_SKU_Name: selectedSKU.varProduct_SKU_Name,
                    decQuantityInKG:
                    double.parse(serialNoTextController.text.trim()));

                if (mounted) {
                  setState(() {
                    listScanningDetails.removeAt(intEditIndex);
                    listScanningDetails.insert(intEditIndex, d2);
                    serialNoTextController.text = '';
                    selectedSKU = null;
                    isEditable = false;
                    intEditIndex = -1;
                  });
                }
              } else {
                _showSnackBar(
                    LocaleUtils.getString(mContext, 'article_al_ext'));
              }
            }
          }
        },
      ),
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Save'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (listScanningDetails.isEmpty) {
            String jsonFull = '{"Order_Product_Details":{}}';
            print(jsonFull);
            apiCall(2, jsonFull);
            //_showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterQty'));
          } else {
            listQty.clear();
            for (Scanning_Details data in listScanningDetails) {
              Order_Product_Details tmp = new Order_Product_Details(
                  fk_OrderGlCode: data.fk_OrderGlCode,
                  fk_Product_SKU_GlCode: data.fk_Product_SKUGlCode,
                  decQty: data.decQuantityInKG);
              listQty.add(tmp);
            }

            var json = jsonEncode(listQty.map((e) => e.toJson()).toList());
            String jsonFull = '{"Order_Product_Details":$json}';
            print(jsonFull);
            apiCall(2, jsonFull);
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          FocusScope.of(mContext).requestFocus(FocusNode());
          Navigator.pop(mContext, false);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              FocusScope.of(mContext).requestFocus(FocusNode());
              Navigator.pop(mContext, false);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    CustomTopHeaderBar(
                        userName, subTitle, topHeaderImage, receiveCount),
                    Container(
                      margin:
                      const EdgeInsets.only(top: 20, right: 20, left: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: <Widget>[
                          Expanded(
                            flex: 2,
                            child: InkWell(
                              child: Container(
                                  height: 42,
                                  width: screenSize.width,
                                  margin: const EdgeInsets.only(right: 5),
                                  alignment: Alignment.centerLeft,
                                  padding:
                                  const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: isEditable
                                              ? Colors.grey
                                              : const Color(0xFF000000)),
                                      borderRadius: _getRadiusDropDown()),
                                  child: Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Padding(
                                          padding: EdgeInsets.only(left: 0),
                                          child: Text(
                                            selectedSKU != null
                                                ? selectedSKU
                                                .varProduct_SKU_Name
                                                : LocaleUtils.getString(
                                                mContext, 'select_article'),
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 1,
                                            style: selectedSKU != null ||
                                                !isEditable
                                                ? textStyle
                                                : hintStyle,
                                          ),
                                        ),
                                      ),
                                      Icon(
                                        Icons.arrow_drop_down,
                                        color: isEditable
                                            ? Colors.grey
                                            : Colors.black,
                                      )
                                    ],
                                  )),
                              onTap: () {
                                if (!isEditable) {
                                  List<SpinnerModel> customertemp = listSKU
                                      .map((customerTypeModel) =>
                                      SpinnerModel(
                                          customerTypeModel.intGlCode,
                                          '${customerTypeModel
                                              .varProduct_SKU_Code} - ${customerTypeModel
                                              .varProduct_SKU_Name}',
                                          1))
                                      .toList();
                                  print(
                                      '===customertemp===${customertemp
                                          .length}');
                                  showDialog<Map>(
                                    barrierDismissible: true,
                                    context: context,
                                    builder: (context) {
                                      return SearchableSpinner(
                                        screenSize: screenSize,
                                        listSticker: customertemp,
                                        itemClickSearchableSpinner: this,
                                      );
                                    },
                                  );
                                }
                              },
                            ),
                          ),
                          Expanded(
                            flex: 1,
                            child: Form(
                              key: _formKey,
                              autovalidate: _autoValidate,
                              child: Container(
                                height: 42,
                                width: screenSize.width,
                                padding:
                                const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color(0xFF000000)),
                                    borderRadius: _getRadiusDropDown()),
                                child: serialNumberTxt,
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(left: 10),
                            width: 50,
                            child: addButton,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      child: Container(
                        color: const Color(bgColor),
                        child: Card(
                          elevation: 7,
                          margin: const EdgeInsets.only(
                              top: 10, right: 15, left: 15),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: <Widget>[
                              Container(
                                height: 40,
                                padding: const EdgeInsets.only(left: 10),
                                alignment: Alignment.centerLeft,
                                decoration: const BoxDecoration(
                                    color: Color(colorPrimary)),
                                child: Text(
                                  LocaleUtils.getString(
                                      mContext, 'article_details'),
                                  style: TextStyle(
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w300,
                                    fontFamily: 'helvetica',
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              Expanded(
                                //child: widget.listStickerDisplay.length > 0
                                child: listScanningDetails.isNotEmpty
                                    ? Container(
                                  child: ListView.builder(
                                    itemCount: listScanningDetails.length,
                                    shrinkWrap: true,
                                    itemBuilder: (BuildContext context,
                                        int index) {
                                      return Slidable(
                                        actionPane:
                                        SlidableDrawerActionPane(),
                                        actionExtentRatio: 0.25,
                                        child: Container(
                                          color: Colors.white,
                                          child: Column(
                                            children: <Widget>[
                                              Padding(
                                                padding:
                                                const EdgeInsets.only(
                                                  left: 0,
                                                ),
                                                child: Container(
                                                  child: Row(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment
                                                        .center,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .start,
                                                    children: <Widget>[
                                                      Expanded(
                                                        flex: 1,
                                                        child: Container(
                                                          padding:
                                                          const EdgeInsets
                                                              .only(
                                                              left:
                                                              10,
                                                              right:
                                                              10,
                                                              top: 5,
                                                              bottom:
                                                              5),
                                                          child: Column(
                                                              mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .start,
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              children: <
                                                                  Widget>[
                                                                Text(
                                                                    '${listScanningDetails[index]
                                                                        .varProduct_SKU_Code} - ${listScanningDetails[index]
                                                                        .varProduct_SKU_Name}',
                                                                    style: TextStyle(
                                                                        fontSize: 14.0,
                                                                        fontWeight: FontWeight
                                                                            .w600,
                                                                        fontFamily: 'helvetica',
                                                                        color: Colors
                                                                            .black)),
                                                                Padding(
                                                                  padding:
                                                                  EdgeInsets
                                                                      .only(
                                                                      top: 5),
                                                                  child:
                                                                  Wrap(
                                                                    direction:
                                                                    Axis
                                                                        .horizontal,
                                                                    alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                    crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                    children: <
                                                                        Widget>[
                                                                      Text(
                                                                        '${LocaleUtils
                                                                            .getString(
                                                                            context,
                                                                            'Qty')}: ',
                                                                        style: titleBoldStyle,
                                                                      ),
                                                                      Padding(
                                                                          padding: EdgeInsets
                                                                              .only(
                                                                              top: 2),
                                                                          child: Text(
                                                                            '${listScanningDetails[index]
                                                                                .decQuantityInKG
                                                                                .toStringAsFixed(
                                                                                2)}',
                                                                            style: textNormalStyle,
                                                                          ))
                                                                    ],
                                                                  ),
                                                                ),
                                                              ]),
                                                        ),
                                                      ),
//                                                    Padding(
//                                                      child: Align(
//                                                        child: GestureDetector(
//                                                          child: Icon(
//                                                              Icons.delete,
//                                                              color:
//                                                              Colors.black),
//                                                          onTap: () {
//                                                          },
//                                                        ),
//                                                        alignment:
//                                                        Alignment.center,
//                                                      ),
//                                                      padding: EdgeInsets.only(
//                                                          left: 5),
//                                                    )
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                width: screenSize.width,
                                                color: Colors.black12,
                                                height: 1,
                                              ),
                                            ],
                                          ),
                                        ),
                                        secondaryActions: <Widget>[
                                          IconSlideAction(
                                              caption: 'Edit',
                                              color: Colors.green,
                                              icon: Icons.edit,
                                              onTap: () {
                                                editRecord(index);
                                              }),
                                          IconSlideAction(
                                              caption: 'Delete',
                                              color: Colors.red,
                                              icon: Icons.delete,
                                              onTap: () {
                                                deleteRecord(index);
                                              }),
                                        ],
                                      );
                                    },
                                  ),
                                )
                                    : Container(
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment:
                                    MainAxisAlignment.center,
                                    children: <Widget>[
                                      Image.asset(
                                        'assets/nodata_icon.png',
                                        height: 100,
                                        width: 100,
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(
                                            top: 10),
                                        child: Text(
                                          LocaleUtils.getString(
                                              context, 'NoDataFound'),
                                          style: prifixTxtStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                      ),
                      flex: 1,
                    ),
                    Container(
                      width: screenSize.width,
                      height: 45,
                      child: saveButton,
                      margin: const EdgeInsets.all(15),
                    ),
                  ],
                )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void _showSnackBar(String text) {
    //_key.currentState.showSnackBar(SnackBar(content: Text(text)));
    Flushbar(
      //title:  "Hey Ninja",
      message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    print('===initcode====${model.initcode}');
    if (model.spinnerID == 1) {
      selectedSKU = null;
      serialNoTextController.text = '';
      isEditable = false;
      intEditIndex = -1;

      for (Product_Sku_Mst_Model data in listSKU) {
        if (data.intGlCode == model.initcode) {
          setState(() {
            selectedSKU = data;
          });
          break;
        }
      }
    }
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
