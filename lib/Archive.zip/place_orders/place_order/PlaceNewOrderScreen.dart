import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/components/SearchableSpinner.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/model/PlaceOrderModel.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderConfirmScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderScanScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

// ignore: must_be_immutable
class PlaceNewOrderScreen extends StatefulWidget {
  Order_Summary_Model dataOrderSummary;

  PlaceNewOrderScreen({this.dataOrderSummary});

  @override
  PlaceNewOrderScreenState createState() =>
      PlaceNewOrderScreenState(dataOrderSummary: dataOrderSummary);
}

class PlaceNewOrderScreenState extends State<PlaceNewOrderScreen>
    implements
        PushNotificationListener,
        ItemClickSearchableSpinner,
        WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '',
      subTitle,
      topHeaderImage = 'assets/neworder_icon.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  WSPresenter wsPresenter;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  static int apiCallType = 0;

  List<Country_MstModel> countryList;
  Country_MstModel selectedCountryModel;

  List<Person_Mst_Model> personList;
  List<Person_Mst_Model> personListFilter;
  Person_Mst_Model selectedPersonModel;

  Order_Summary_Model dataOrderSummary;

  PlaceNewOrderScreenState({this.dataOrderSummary});

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
//    Navigator.popAndPushNamed(mContext, SCANNING_SCREEN);
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.pushReplacement(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
            subTitle = LocaleUtils.getString(mContext, 'tag_place_new_order');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    countryList = List();
    personList = List();
    personListFilter = List();

    if (dataOrderSummary == null) {
      apiCall(1);
    } else {
      apiCall(2);
    }

    _initLoading();

    insertLogDetails();

  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_PLO_PNO');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void apiCall(int type) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGlCode) {
              param[PARAM_PERSON_ID] = loginID;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param[PARAM_DEVICE_ID] = deviceid;
                  if (type == 1) {
                    param[PARAM_ACTION] = "CheckPendingOrder";
                  } else if (type == 2) {
                    param[PARAM_ACTION] = "GetMasters";
                  } else if (type == 3) {
                    param[PARAM_ACTION] = "InsertOrder";
                  } else if (type == 4) {
                    param[PARAM_ACTION] = "UpdateOrder";
                  }

                  param['OrderId'] =
                  '${dataOrderSummary == null ? '' : dataOrderSummary
                      .fk_OrderGlCode}';
                  param['OrderProductId'] = '';
                  //param['ToCustomerId'] = mainCustomerGlCode.toString();
                  param['ToCustomerId'] = type == 3 || type == 4
                      ? selectedPersonModel.intGlCode.toString()
                      : '';
                  param['ProductSkuId'] = '';
                  param['JSONData'] = '';
                  param['Remarks'] = '';

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Order_Information', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedPositive: () {
                if (apiCallType != 3) {
                  Navigator.pop(mContext, false);
                }
              },
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: errorTxt,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {
            Navigator.pop(mContext, false);
          },
        );
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    if (apiCallType != 1) {
      dismissProgressHUD();
    }

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (mounted) {
          if (apiCallType == 1) {
            int fk_OrderGlCode =
                responseModel.getCheckPendingOrder(); // 0 = No Pending Order
            print("XXXX $fk_OrderGlCode");

            if (fk_OrderGlCode == 0) {
              apiCall(2);
            } else {
              // GOTO 3rd Screen
              dismissProgressHUD();
              redirectPlaceNewOrderConfirmScreen(fk_OrderGlCode);
            }
          } else if (apiCallType == 2) {
            setState(() {
              countryList.clear();
              countryList.addAll(responseModel.getCountryList_PlaceOrder());

              personListFilter.clear();
              personList.clear();
              personList.addAll(responseModel.getPerson_Mst_PlaceOrder());

              if (dataOrderSummary != null) {
                for (Country_MstModel data in countryList) {
                  if (data.varCode == dataOrderSummary.varCountry_Code) {
                    selectedCountryModel = data;
                    break;
                  }
                }

                setUpPersonType();

                for (Person_Mst_Model data in personList) {
                  if (data.varSAPCode ==
                      dataOrderSummary.varTo_Customer_SAP_Code) {
                    selectedPersonModel = data;
                    break;
                  }
                }
              }
            });
          } else if (apiCallType == 3) {
            redirectPlaceNewOrderScanScreen(responseModel.getInsertOrderId());
          } else if (apiCallType == 4) {
            redirectPlaceNewOrderConfirmScreen(dataOrderSummary.fk_OrderGlCode);
          }
        }
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void redirectPlaceNewOrderScanScreen(int fk_OrderGlCode) {
    final Route route = CupertinoPageRoute(
        builder: (context) =>
            PlaceNewOrderScanScreen(
              fk_OrderGlCode: fk_OrderGlCode,
              isUpdate: false,
            ));
    Navigator.pushReplacement(mContext, route);
  }

  void redirectPlaceNewOrderConfirmScreen(int fk_OrderGlCode) {
    if (dataOrderSummary != null) {
      Navigator.pop(mContext, true);
    } else {
      final Route route = CupertinoPageRoute(
          builder: (context) =>
              PlaceNewOrderConfirmScreen(fk_OrderGlCode: fk_OrderGlCode));
      Navigator.pushReplacement(mContext, route);
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final loginButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'proceed'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (selectedCountryModel != null) {
            if (selectedPersonModel != null) {
              apiCall(dataOrderSummary == null ? 3 : 4);
            } else {
              _showSnackBar(LocaleUtils.getString(mContext, 'plz_sel_cust'));
            }
          } else {
            _showSnackBar(LocaleUtils.getString(mContext, 'plz_sel_country'));
          }
        },
      ),
    );

    return MyCustomScaffold(
      //resizeToAvoidBottomPadding: false,
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(mContext, false);
        },
      ).appBar(),
      key: _key,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
                  Expanded(
                    child: Form(
                      child: Container(
                        color: const Color(bgColor),
                        child: Column(
                          children: <Widget>[
                            Expanded(
                              child: Card(
                                elevation: 7,
                                margin: const EdgeInsets.all(15),
                                child: Container(
                                  padding: const EdgeInsets.all(15),
                                  child: ListView(
                                    shrinkWrap: true,
                                    children: <Widget>[
                                      InkWell(
                                        child: Container(
                                            height: 42,
                                            width: screenSize.width,
                                            alignment: Alignment.centerLeft,
                                            margin:
                                                const EdgeInsets.only(top: 12),
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 0, 15, 0),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xFF000000)),
                                                borderRadius:
                                                    _getRadiusDropDown()),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Text(
                                                  selectedCountryModel != null
                                                      ? selectedCountryModel
                                                          .varName
                                                      : LocaleUtils.getString(
                                                          mContext,
                                                          'sel_country'),
                                                  style: selectedCountryModel !=
                                                          null
                                                      ? textStyle
                                                      : hintStyle,
                                                ),
                                                Icon(Icons.arrow_drop_down)
                                              ],
                                            )),
                                        onTap: () {
                                          List<SpinnerModel> countrytemp =
                                              countryList
                                                  .map((countryMasterModel) =>
                                                      SpinnerModel(
                                                          countryMasterModel
                                                              .intGlCode,
                                                          countryMasterModel
                                                              .varName,
                                                          1))
                                                  .toList();
                                          showDialog<Map>(
                                            barrierDismissible: true,
                                            context: context,
                                            builder: (context) {
                                              return SearchableSpinner(
                                                screenSize: screenSize,
                                                listSticker: countrytemp,
                                                itemClickSearchableSpinner:
                                                    this,
                                              );
                                            },
                                          );
                                        },
                                      ),
                                      InkWell(
                                        child: Container(
                                            height: 42,
                                            width: screenSize.width,
                                            margin:
                                                const EdgeInsets.only(top: 20),
                                            alignment: Alignment.centerLeft,
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 0, 15, 0),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xFF000000)),
                                                borderRadius:
                                                    _getRadiusDropDown()),
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: <Widget>[
                                                Expanded(
                                                  flex: 1,
                                                  child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 0),
                                                    child: Text(
                                                      selectedPersonModel !=
                                                              null
                                                          ? selectedPersonModel
                                                              .varOrganisationName
                                                          : LocaleUtils
                                                          .getString(
                                                          mContext,
                                                          'sel_customer'),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                      style:
                                                          selectedPersonModel !=
                                                                  null
                                                              ? textStyle
                                                              : hintStyle,
                                                    ),
                                                  ),
                                                ),
                                                Icon(Icons.arrow_drop_down)
                                              ],
                                            )),
                                        onTap: () {
                                          List<SpinnerModel> customertemp =
                                              personListFilter
                                                  .map((customerTypeModel) =>
                                                      SpinnerModel(
                                                          customerTypeModel
                                                              .intGlCode,
                                                          customerTypeModel
                                                              .varOrganisationName,
                                                          2))
                                                  .toList();
                                          print(
                                              '===customertemp===${customertemp.length}');
                                          showDialog<Map>(
                                            barrierDismissible: true,
                                            context: context,
                                            builder: (context) {
                                              return SearchableSpinner(
                                                screenSize: screenSize,
                                                listSticker: customertemp,
                                                itemClickSearchableSpinner:
                                                    this,
                                              );
                                            },
                                          );
                                        },
                                      ),
                                      Container(
                                          height: 42,
                                          width: screenSize.width,
                                          margin:
                                              const EdgeInsets.only(top: 20),
                                          padding: const EdgeInsets.fromLTRB(
                                              15, 0, 15, 0),
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color:
                                                      const Color(0xFF000000)),
                                              borderRadius:
                                                  _getRadiusDropDown()),
                                          child: Align(
                                            alignment: Alignment.centerLeft,
                                            child: Text(
                                              selectedPersonModel != null
                                                  ? selectedPersonModel
                                                      .varCustomer_Type_Name
                                                  : LocaleUtils.getString(
                                                      mContext,
                                                  'Select_Customer_type'),
                                              style: selectedPersonModel != null
                                                  ? textStyle
                                                  : hintStyle,
                                            ),
                                          )),
                                      Container(
                                        width: screenSize.width,
                                        height: 45,
                                        child: loginButton,
                                        margin: const EdgeInsets.only(top: 30),
                                        //margin: EdgeInsets.all(15),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              flex: 1,
                            ),
                          ],
                        ),
                      ),
                      autovalidate: _autoValidate,
                      key: _formKey,
                    ),
                    flex: 1,
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    print('===initcode====${model.initcode}');
    if (model.spinnerID == 1) {
      setSelectedCountryValues(model.initcode);
    } else if (model.spinnerID == 2) {
      setSelectedPersonValues(model.initcode);
    }
  }

  void setSelectedCountryValues(int initId) {
    for (int i = 0; i < countryList.length; i++) {
      if (countryList[i].intGlCode == initId) {
        if (mounted) {
          setState(() {
            selectedCountryModel = countryList[i];
            setUpPersonType();
          });
        }
      }
    }
  }

  void setSelectedPersonValues(int initId) {
    for (int i = 0; i < personListFilter.length; i++) {
      if (personListFilter[i].intGlCode == initId) {
        if (mounted) {
          setState(() {
            selectedPersonModel = personListFilter[i];
            print(selectedPersonModel.toString());
            //setUpCustomerType(true);
          });
        }
        break;
      }
    }
  }

  void setUpPersonType() {
    personListFilter.clear();
    selectedPersonModel = null;
    List<Person_Mst_Model> tmpList = new List();

    if (selectedCountryModel != null) {
      final int fkCountryGlCode = selectedCountryModel.intGlCode;

      for (Person_Mst_Model data in personList) {
        if (data.fk_CountryGlCode == fkCountryGlCode) {
          tmpList.add(data);
        }
      }
    }

    if (mounted) {
      setState(() {
        personListFilter.addAll(tmpList);
      });
    }
  }
}
