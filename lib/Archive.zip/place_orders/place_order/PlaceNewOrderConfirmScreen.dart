import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonEditDOWidgets.dart';
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/PlaceOrderModel.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderScanScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderScreen.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceOrderCongratulationScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

abstract class DialogLoadListener {
  void onLoad();

  void onCancel();
}

// ignore: must_be_immutable
class PlaceNewOrderConfirmScreen extends StatefulWidget {
  int fk_OrderGlCode;

  PlaceNewOrderConfirmScreen({this.fk_OrderGlCode});

  @override
  PlaceNewOrderConfirmScreenState createState() =>
      PlaceNewOrderConfirmScreenState(fk_OrderGlCode: fk_OrderGlCode);
}

class PlaceNewOrderConfirmScreenState extends State<PlaceNewOrderConfirmScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false, isNotification = false, isSync = false;
  String dropdownValue;
  Size screenSize;
  String userName = '',
      subTitle,
      topHeaderImage = 'assets/neworder_icon.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  WSPresenter wsPresenter;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  int fk_OrderGlCode;
  int apiCallType = 0;
  Order_Summary_Model dataOrderSummary;
  Order_Product_Summary_Model dataOrderPrdSummary;

  PlaceNewOrderConfirmScreenState({this.fk_OrderGlCode});

  List<Scanning_Details> listScanningDetails;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PlaceNewOrderScanScreen(
              fk_OrderGlCode: dataOrderSummary.fk_OrderGlCode,
          isUpdate: true,
            ));
    //Navigator.push(mContext, route);
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          //if (mounted) {
          //getScanRecordFromDB();
          //}
          apiCall(1, "");
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void redirectDetailScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PlaceNewOrderScreen(
              dataOrderSummary: dataOrderSummary,
            ));
    //Navigator.push(mContext, route);
    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          //if (mounted) {
          //getScanRecordFromDB();
          //}
          apiCall(1, "");
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    pushNotificationServices = PushNotificationServices(this);
    wsPresenter = WSPresenter(this);
    _battery = EcpSyncPlugin();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
            subTitle = LocaleUtils.getString(mContext, 'tag_place_new_order');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    listScanningDetails = new List();
    apiCall(1, "");
  }

  void apiCall(int type, String remarks) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();

          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String loginID) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int mainCustomerGlCode) {
              param[PARAM_PERSON_ID] = loginID;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                  param[PARAM_API_TOKEN] = apiToken;
                  param[PARAM_DEVICE_ID] = deviceid;
                  if (type == 1) {
                    param[PARAM_ACTION] = "CustomerOrderSummary";
                  } else if (type == 2) {
                    param[PARAM_ACTION] = "ScanningDetail";
                  } else if (type == 3) {
                    param[PARAM_ACTION] = "Close";
                  } else if (type == 4) {
                    param[PARAM_ACTION] = "Confirm";
                  }

                  param['OrderId'] = '$fk_OrderGlCode';
                  param['OrderProductId'] = '';
                  param['ToCustomerId'] = mainCustomerGlCode.toString();
                  param['ProductSkuId'] = '';
                  param['JSONData'] = '';
                  param['Remarks'] = remarks;

                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Order_Information', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    if (apiCallType != 1) {
      dismissProgressHUD();
    }

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (mounted) {
          if (apiCallType == 1) {
            dataOrderSummary = responseModel.getOrder_Summary_PlaceOrder();
            dataOrderPrdSummary =
                responseModel.getOrder_Product_Summary_PlaceOrder();

            apiCall(2, "");
          } else if (apiCallType == 2) {
            listScanningDetails.clear();
            listScanningDetails
                .addAll(responseModel.getScanning_Details_PlaceOrder());
          } else if (apiCallType == 3) {
            showDialog<Map>(
              barrierDismissible: false,
              context: mContext,
              builder: (context) {
                return CustomAlertDialog(
                  content: responseModel.Message,
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedPositive: () {
                    Navigator.pop(mContext);
                  },
                );
              },
            );
          }else if (apiCallType == 4) {
            final Route route = CupertinoPageRoute(
                builder: (context) =>
                    PlaceOrderCongratulationScreen(
                      orderNo: responseModel.getOrderNo(),));
            Navigator.pushReplacement(mContext, route);
          }
        }
      } else {
        if (apiCallType == 3) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final changeDetailsButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'ChangeDetails'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          redirectDetailScreen();
        },
      ),
    );

    final reScanButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'update'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          redirectScanScreen();
        },
      ),
    );

    final closeButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonEditDOWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Discard'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        textSize: 16.0,
        onTap: () {
          closeOrder();
        },
      ),
    );

    final dispatchButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Confirm'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          dispatchOrder();
        },
      ),
    );

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      resizeToAvoidBottomPadding: false,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
//                  CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_THIRD, false),
                  Container(
                    child: Card(
                      elevation: 7,
                      margin: const EdgeInsets.only(
                          top: 10, left: 15, right: 15, bottom: 10),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Row(
                              children: <Widget>[
                                Expanded(
                                  child: Wrap(
                                    direction: Axis.horizontal,
                                    runAlignment: WrapAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        LocaleUtils.getString(
                                            mContext, 'Country_'),
                                        style: prifixTxtStyle,
                                      ),
                                      Text(
                                        dataOrderSummary != null
                                            ? dataOrderSummary.varCountry_Name
                                            : '',
                                        style: textStyle,
                                      ),
                                    ],
                                  ),
                                  flex: 1,
                                ),
                                Expanded(
                                  child: Wrap(
                                    direction: Axis.horizontal,
                                    runAlignment: WrapAlignment.start,
                                    children: <Widget>[
                                      Text(
                                        LocaleUtils.getString(
                                            mContext, 'CustType_'),
                                        style: prifixTxtStyle,
                                      ),
                                      Text(
                                        dataOrderSummary != null
                                            ? dataOrderSummary
                                                .varCustomer_Type_Name
                                            : '',
                                        style: textStyle,
                                      ),
                                    ],
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 5),
                              child: Wrap(
                                direction: Axis.horizontal,
                                runAlignment: WrapAlignment.start,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'CustName_'),
                                    style: prifixTxtStyle,
                                  ),
                                  Text(
                                    dataOrderSummary != null
                                        ? dataOrderSummary.varTo_Customer_Name
                                        : '',
                                    style: textStyle,
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 0),
                              child: Row(
                                children: <Widget>[
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisSize: MainAxisSize.max,
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceEvenly,
                                      children: <Widget>[
//                                        Wrap(
//                                          direction: Axis.horizontal,
//                                          crossAxisAlignment:
//                                              WrapCrossAlignment.center,
//                                          alignment: WrapAlignment.start,
//                                          children: <Widget>[
//                                            Text(
//                                              '',
//                                              style: prifixTxtStyle,
//                                            ),
//                                            Padding(
//                                                padding: const EdgeInsets.only(
//                                                    top: 1),
//                                                child: Text(
//                                                  '',
//                                                  style: textStyle,
//                                                ))
//                                          ],
//                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 4),
                                          child: Wrap(
                                            direction: Axis.horizontal,
                                            runAlignment: WrapAlignment.start,
                                            children: <Widget>[
                                              Text(
                                                LocaleUtils.getString(
                                                    mContext, 'SAPCode_'),
                                                style: prifixTxtStyle,
                                              ),
                                              Text(
                                                dataOrderSummary != null
                                                    ? dataOrderSummary
                                                        .varTo_Customer_SAP_Code
                                                    : '',
                                                style: textStyle,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                    flex: 2,
                                  ),
//                                  globals.AUTO_DISPATCH_DO_CONFIRM == 'N'
//                                      ? globals.AUTO_DISPATCH_STO_CONFIRM == 'N'
//                                          ? Container()
//                                          : changeDetailsButton
//                                      : changeDetailsButton,
                                  changeDetailsButton,
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    color: const Color(colorAccent),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotUnits_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                  padding: const EdgeInsets.only(top: 2),
                                  child: Text(
                                    dataOrderPrdSummary != null
                                        ? '${dataOrderPrdSummary.decTotalQuantity}'
                                        : '0',
                                    style: textPrimaryStyle,
                                  ))
                            ],
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: 1,
                          color: Colors.white70,
                        ),
                        Expanded(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                LocaleUtils.getString(mContext, 'TotArticle_'),
                                style: prifixTxtPrimaryStyle,
                              ),
                              Padding(
                                  padding: const EdgeInsets.only(top: 2),
                                  child: Text(
                                    dataOrderPrdSummary != null
                                        ? '${dataOrderPrdSummary.intTotalArticle}'
                                        : '0',
                                    style: textPrimaryStyle,
                                  ))
                            ],
                          ),
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      alignment: Alignment.topLeft,
                      margin: const EdgeInsets.only(
                          top: 10, left: 15, right: 15, bottom: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 5, left: 0, bottom: 10),
                            child: Text(
                                LocaleUtils.getString(
                                    mContext, 'article_details'),
                                style: prifixTxtStyle),
                          ),
                          Expanded(
                            child: listScanningDetails.isNotEmpty
                                ? Container(
                                    child: ListView.builder(
                                      itemCount: listScanningDetails.length,
                                      shrinkWrap: true,
                                      itemBuilder:
                                          (BuildContext context, int index) {
                                        return Card(
                                          margin: const EdgeInsets.only(
                                              left: 0,
                                              top: 7,
                                              bottom: 7,
                                              right: 0),
                                          elevation: 3,
                                          child: Container(
                                            padding: const EdgeInsets.all(10),
                                            width: screenSize.width,
                                            child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: <Widget>[
                                                  Text(
                                                      '${listScanningDetails[index].varProduct_SKU_Code} - ${listScanningDetails[index].varProduct_SKU_Name}',
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          fontFamily:
                                                              'helvetica',
                                                          color: Colors.black)),
                                                  Text(
                                                      '${LocaleUtils.getString(context, 'Qty')} : ${listScanningDetails[index].decQuantityInKG.toString()}',
                                                      style: TextStyle(
                                                          fontSize: 14.0,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontFamily:
                                                              'helvetica',
                                                          color: Colors.black)),
                                                ]),
                                          ),
                                        );
                                      },
                                    ),
                                  )
                                : Container(
                                    width: screenSize.width,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/nodata_icon.png',
                                          height: 100,
                                          width: 100,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10),
                                          child: Text(
                                            LocaleUtils.getString(
                                                context, 'NoDataFound'),
                                            style: prifixTxtStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Container(
                    width: screenSize.width,
                    height: 45,
                    margin: const EdgeInsets.all(15),
                    child: Row(
                      children: <Widget>[
                        Expanded(
                          child: reScanButton,
                          flex: 1,
                        ),
                        Container(
                          width: 10,
                        ),
                        Expanded(
                          child: closeButton,
                          flex: 1,
                        ),
                        Container(
                          width: 10,
                        ),
                        Expanded(
                          child: dispatchButton,
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  closeOrder() {
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: LocaleUtils.getString(
              mContext, 'AreYouSureUWant2DiscardTransaction'),
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: true,
          textNagativeButton: LocaleUtils.getString(mContext, 'no'),
          textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
          onPressedNegative: () {},
          onPressedPositive: () {
            apiCall(3, '');
          },
        );
      },
    );
  }

  dispatchOrder() async {
    if (listScanningDetails.isNotEmpty) {
     /* _loading = true;
      dismissProgressHUD();*/

      final TextEditingController _textFieldController = TextEditingController();

      await showDialog<Map>(
          barrierDismissible: false,
          context: context,
          builder: (context) {
            return AlertDialog(
              contentPadding: const EdgeInsets.all(16.0),
              content: Row(
                children: <Widget>[
                  Expanded(
                      child: TextField(
                        autofocus: true,
                        //enableInteractiveSelection: false,
                        keyboardType: TextInputType.multiline,
                        maxLines: 3,
                        controller: _textFieldController,
                        decoration: InputDecoration(
                          //labelText: 'Please enter reason for settle order.',
                          hintText: LocaleUtils.getString(
                              mContext, 'enter_remarks'),
                          hintStyle: TextStyle(
                            fontSize: 15.0,
                            fontWeight: FontWeight.w400,
                            fontFamily: 'helvetica',
                            color: Colors.black54,
                          ),
                        ),
                      ))
                ],
              ),
              actions: <Widget>[
                FlatButton(
                    child: Text(LocaleUtils.getString(mContext, 'no'),
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'helvetica',
                          color: Colors.black,
                        )),
                    onPressed: () {
                      Navigator.pop(context);
                    }),
                FlatButton(
                    child: Text(LocaleUtils.getString(mContext, 'yes'),
                        style: TextStyle(
                          fontSize: 15.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.black,
                        )),
                    onPressed: () {
                      Navigator.pop(context);
//                      if (_textFieldController.text.trim().isEmpty) {
//                        _showSnackBar(LocaleUtils.getString(
//                            mContext, 'plz_enter_remarks'));
//                      } else {
                         apiCall(4, _textFieldController.text.trim());
//                      }
                    })
              ],
              title: Text(
                LocaleUtils.getString(mContext, 'enter_remarks'),
                style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'helvetica',
                    color: Colors.black),
                textAlign: TextAlign.left,
              ),
              titlePadding:
              const EdgeInsets.only(left: 16.0, top: 16.0, right: 16.0),
            );
          });

    } else {
      await showDialog<Map>(
        barrierDismissible: false,
        context: context,
        builder: (context) {
          return CustomAlertDialog(
            content:
            LocaleUtils.getString(mContext, 'YouHaveNotScannedAnyLabelYet'),
            title:
            PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  void _showSnackBar(String text) {
     Flushbar(
       message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

// ignore: must_be_immutable
class MyForm extends StatefulWidget {
  Size screenSize;
  List<ScanDataModel> listSticker = List();
  List<ScanDataModel> listStickerDisplay = List();

  //final TextEditingController _search_controller =  TextEditingController();
  PlaceNewOrderConfirmScreenState dispatchThirdScreen;

  MyForm(
      {this.screenSize,
      this.listSticker,
      this.listStickerDisplay,
      this.dispatchThirdScreen});

  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final TextEditingController searchcontroller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        contentPadding: const EdgeInsets.all(0.0),
        shape: RoundedRectangleBorder(
            borderRadius: const BorderRadius.all(Radius.circular(5.0))),
        //title:  Text('Alert Dialog title'),
        content: Container(
          width: widget.screenSize.width * 0.9,
          height: widget.screenSize.height * 0.5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                width: widget.screenSize.width,
                height: 40,
                padding: const EdgeInsets.only(left: 10, right: 10),
                color: const Color(colorPrimary),
                child: Align(
                  child: Text(LocaleUtils.getString(context, 'ScannedSerialNo'),
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'helvetica',
                          color: Colors.white)),
                  alignment: Alignment.centerLeft,
                ),
              ),
              Container(
                color: const Color(colorAccent),
                padding: const EdgeInsets.all(10),
                child: Container(
                  height: 40,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(7)),
                      color: Colors.white),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Padding(
                          padding: const EdgeInsets.only(left: 10),
                          child: TextField(
                            controller: searchcontroller,
                            //enableInteractiveSelection: false,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(color: Colors.grey[700]),
                              hintText:
                                  LocaleUtils.getString(context, 'SearchLabel'),
                              counterText: '',
                            ),
                            onChanged: (value) {
                              filterSearchResults(value);
                            },
                            maxLines: 1,
                            maxLength: EditTxtMaxLengths,
                          ),
                        ),
                        flex: 1,
                      ),
                      Flexible(
                        child: IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.search,
                              color: Color(colorPrimary),
                            )),
                        flex: 0,
                      )
                    ],
                  ),
                ),
              ),
              Expanded(
                //child: widget.listStickerDisplay.length > 0
                child: widget.listStickerDisplay.isNotEmpty
                    ? Container(
                        child: ListView.builder(
                          itemCount: widget.listStickerDisplay.length,
                          shrinkWrap: true,
                          itemBuilder: (BuildContext context, int index) {
                            return Column(
                              children: <Widget>[
                                Container(
                                  height: 35,
                                  width: widget.screenSize.width,
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: <Widget>[
                                      Expanded(
                                        flex: 1,
                                        child: Center(
                                            child: Text(
                                                '#' +
                                                    widget
                                                        .listStickerDisplay[
                                                            index]
                                                        .intRows
                                                        .toString(),
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'helvetica',
                                                    color: widget
                                                            .listStickerDisplay[
                                                                index]
                                                            .chrValid
                                                            .contains('N')
                                                        ? Colors.red
                                                        : Colors.black))),
                                      ),
                                      Expanded(
                                        child: Padding(
                                            padding:
                                                const EdgeInsets.only(left: 0),
                                            child: Text(
                                                widget.listStickerDisplay[index]
                                                            .intNoOfSticker >
                                                        0
                                                    ? '${widget.listStickerDisplay[index].varSticker} - (${widget.listStickerDisplay[index].intNoOfSticker})'
                                                    : '${widget.listStickerDisplay[index].varSticker}',
                                                style: TextStyle(
                                                    fontSize: 14.0,
                                                    fontWeight: FontWeight.w400,
                                                    fontFamily: 'helvetica',
                                                    color: widget
                                                            .listStickerDisplay[
                                                                index]
                                                            .chrValid
                                                            .contains('N')
                                                        ? Colors.red
                                                        : Colors.black))),
                                        flex: 3,
                                      ),
                                      Expanded(
                                        child: Align(
                                          child: GestureDetector(
                                            child: Icon(Icons.delete,
                                                color: widget
                                                        .listStickerDisplay[
                                                            index]
                                                        .chrValid
                                                        .contains('N')
                                                    ? Colors.red
                                                    : Colors.black),
                                            onTap: () {},
                                          ),
                                          alignment: Alignment.center,
                                        ),
                                        flex: 1,
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  width: widget.screenSize.width,
                                  color: Colors.black12,
                                  height: 1,
                                ),
                              ],
                            );
                          },
                        ),
                      )
                    : Container(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.asset(
                              'assets/nodata_icon.png',
                              height: 100,
                              width: 100,
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 10),
                              child: Text(
                                LocaleUtils.getString(context, 'NoDataFound'),
                                style: prifixTxtStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                flex: 1,
              ),
              Container(
                width: widget.screenSize.width,
                height: 45,
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: ButtonDialogWidgets(
                        buttonName: LocaleUtils.getString(context, 'Close'),
                        buttonColor: const Color(colorPrimary),
                        textColor: Colors.white,
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                      ),
                      flex: 1,
                    ),
                  ],
                ),
              ),
            ],
          ),
        )
        //actions: _actionButton()
        );
  }

  void filterSearchResults(String query) {
    print(query);
    final List<ScanDataModel> dummySearchList = List<ScanDataModel>();
    dummySearchList.addAll(widget.listSticker);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<ScanDataModel> dummyListData = List<ScanDataModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });

      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(dummyListData);
        });
    } else {
      if (mounted)
        // ignore: curly_braces_in_flow_control_structures
        setState(() {
          widget.listStickerDisplay.clear();
          widget.listStickerDisplay.addAll(widget.listSticker);
        });
    }

    print(widget.listStickerDisplay.length);
  }
}
