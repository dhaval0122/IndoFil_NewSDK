import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/FooterWidgets.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/HomeFragment.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/dimens.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';

class PlaceOrderScreen extends StatefulWidget {
  @override
  PlaceOrderScreenState createState() => PlaceOrderScreenState();
}

class PlaceOrderScreenState extends State<PlaceOrderScreen>
    with TickerProviderStateMixin implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Size screenSize;
  String userName, subTitle, lastLoginDate;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  bool loadingFlag = false, isNotification = false, isSync = false;
  String displayDateFormat = '';
  List<MenuMasterModel> menuMasterList;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  AnimationController animationController;

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  StatelessWidget _getDrawerItemWidget(int pos) {
    switch (pos) {
      case 0:
        print('=========_getDrawerItemWidget=======$pos');
        return HomeFragment(mContext, sharedPrefs, databaseHelper, userName,
            lastLoginDate,
            menuMasterList,
            0,
            false,
            subTitle,
            false,
          mainScreenAnimation: Tween(begin: 0.0, end: 1.0).animate(
              CurvedAnimation(
                  parent: animationController,
                  curve: Interval((1 / 9) * 3, 1.0,
                      curve: Curves.fastOutSlowIn))),
          mainScreenAnimationController: animationController,
          syncPlugin: _battery,);
      default:
        return Text(LocaleUtils.getString(mContext, 'Err'));
    }
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 800), vsync: this);
    super.initState();

    menuMasterList = List();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (mounted) {
        setState(() {
          userName = fullname != null ? fullname : '';
          subTitle = LocaleUtils.getString(mContext, 'tag_place_order');
        });
      }
    });

    sharedPrefs.getString(PREF_LAST_SYNC_DATE).then((String lSyncDate) {
      if (mounted) {
        setState(() {
          //print('======lSyncDate======$lSyncDate');
          if (lSyncDate.isEmpty) {
            lastLoginDate = '';
          } else {
            lastLoginDate =
                LocaleUtils.getString(mContext, 'LastSync') + ' : $lSyncDate';
          }
        });
      }
    });

    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_WITH_TIME_DEFAULT_FORMAT;
          }
        });
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    getData();

    insertLogDetails();

  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_PLO');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getData() {
    databaseHelper
        .getMenuMasterForPlaceOrder()
        .then((List<MenuMasterModel> menuList) {
      print('====menuMasterList====${menuMasterList.length}');
      if (mounted) {
        setState(() {
          menuMasterList.addAll(menuList);
          _getDrawerItemWidget(0);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return WillPopScope(
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
      key: _key,
      body: Stack(
        children: <Widget>[
          _getDrawerItemWidget(0),
        ],
      ),
      bottomNavigationBar: Container(
        height: p_45,
        child: FooterWidgets(),
      ),
        ));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
