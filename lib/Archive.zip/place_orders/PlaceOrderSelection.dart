import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/place_orders/place_order/PlaceNewOrderScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

import 'order_history/OrderHistoryScreen.dart';

//this is svn check

class PlaceOrderSelection extends StatefulWidget {
  @override
  PlaceOrderSelectionState createState() => PlaceOrderSelectionState();
}

class PlaceOrderSelectionState extends State<PlaceOrderSelection>
    implements PushNotificationListener, ItemClickSearchableSpinner {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '',
      subTitle = 'Place Order',
      topHeaderImage = 'assets/place_order_icon.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectPlaceNewOrderScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => PlaceNewOrderScreen());
    Navigator.push(mContext, route);
  }

  void redirectPlaceOrderHistoryScreen() {
    final Route route =
    CupertinoPageRoute(builder: (context) => OrderHistoryScreen());
    Navigator.push(mContext, route);
  }

  @override
  void initState() {
    super.initState();
    _battery = EcpSyncPlugin();

    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
          });
        }
      }
    });
//    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
//      if (screenState == TAG_DISPATCH) {
//        topHeaderImage = 'assets/dispatch_icon.png';
//      } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
//        topHeaderImage = 'assets/edit_do_icon.png';
//      }
//
//      if (subTitle.isEmpty) {
//        if (mounted) {
//          setState(() {
//            subTitle = screenState != null ? screenState : '';
//          });
//        }
//      }
//    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    _initLoading();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _key,
      body: SafeArea(
        child: Container(
          width: screenSize.width,
          color: const Color(bgColor),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: <Widget>[
              CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
              Expanded(
                child: Container(
                  width: screenSize.width,
                  child: Card(
                    margin: EdgeInsets.only(
                        top: 10, right: 10, left: 10, bottom: 5),
                    elevation: 7,
                    color: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Image.asset(
                          'assets/neworder_icon.png',
                          height: 100,
                          width: 100,
                          color: const Color(colorPrimary),
                        ),
                        Padding(
                            padding: const EdgeInsets.only(top: 30),
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              splashColor: Colors.grey,
                              onPressed: () {
                                redirectPlaceNewOrderScreen();
                              },
                              elevation: 7,
                              padding: const EdgeInsets.only(
                                  left: 30, right: 30, top: 12, bottom: 12),
                              color: const Color(colorPrimary),
                              child: Text('Place New Order',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: 'helvetica')),
                            )),
                      ],
                    ),
                  ),
                ),
                flex: 1,
              ),
              Expanded(
                child: Container(
                  width: screenSize.width,
                  child: Card(
                    margin: EdgeInsets.only(
                        top: 5, right: 10, left: 10, bottom: 10),
                    elevation: 7,
                    color: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Image.asset(
                          'assets/orderhistory_icon.png',
                          height: 100,
                          width: 100,
                          color: const Color(colorPrimary),
                        ),
                        Padding(
                            padding: const EdgeInsets.only(top: 30),
                            child: RaisedButton(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(25),
                              ),
                              splashColor: Colors.grey,
                              onPressed: () {
                                redirectPlaceOrderHistoryScreen();
                              },
                              elevation: 7,
                              padding: const EdgeInsets.only(
                                  left: 30, right: 30, top: 12, bottom: 12),
                              color: const Color(colorPrimary),
                              child: Text('Order History',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: 'helvetica')),
                            )),
                      ],
                    ),
                  ),
                ),
                flex: 1,
              ),
            ],
          ),
        ),
      ),
    );
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    print('===initcode====${model.initcode}');
    if (model.spinnerID == 1) {
    } else if (model.spinnerID == 2) {}
  }
}
