import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/OrderHistoryModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

// ignore: must_be_immutable
class OrderHistoryDetailsScreen extends StatefulWidget {
  String displayName;
  OrderHistorySummaryModel data;

  OrderHistoryDetailsScreen({this.displayName, this.data});

  @override
  OrderHistoryDetailsScreenState createState() =>
      OrderHistoryDetailsScreenState();
}

class OrderHistoryDetailsScreenState extends State<OrderHistoryDetailsScreen>
    implements WSInterface, PushNotificationListener {
  OrderHistoryDetailsScreenState() {
    wsPresenter = WSPresenter(this);
  }

  //GlobalKey<ScaffoldState> _key = GlobalKey();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  bool _loading = false,
      loadingFlag = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  ProgressHUD _progressHUD;
  BuildContext mContext;
  String userName = '',
      subTitle;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  String dateFormatAPI = '', noDataTitle = '';
  WSPresenter wsPresenter;
  List<OrderHistoryDetailModel> listDetails;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  int apiCallType = 0;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    _initLoading();

    listDetails = List();
    _battery = EcpSyncPlugin();
    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
            subTitle = LocaleUtils.getString(mContext, 'tag_order_history');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    apiCall(1);
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
          //_isLoginButtonDisable = true;
        } else {
          _progressHUD.state.dismiss();
          //_isLoginButtonDisable = false;
        }
        _loading = !_loading;
      });
    }
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK'
                            ? BASF_HK_APP_Name
                            : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                // ignore: missing_return
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK'
                      ? BASF_HK_APP_Name
                      : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void apiCall(int type) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        setState(() {
          loadingFlag = true;
        });

        Future.delayed(const Duration(milliseconds: 700), () {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initGlCode) {
            sharedPrefs
                .getInt(PREF_MAIN_CUSTOMER_GI_CODE)
                .then((int fkMainCustomerGlCode) {
              sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
                var param = Map();
                param['OrderId'] = '${widget.data.fk_OrderGlCode}';
                param['StatusCodes'] = '';
                param['dtFromDate'] = '';
                param['dtToDate'] = '';
                param[PARAM_PERSON_ID] = fkMainCustomerGlCode.toString();
                param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                    ? SUB_MODULE_NAME_ANDROID
                    : SUB_MODULE_NAME_IOS;
                param[PARAM_VERSION] = APP_VERSION;
                param[PARAM_API_TOKEN] = apiToken;

                sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                  param[PARAM_DEVICE_ID] = deviceid;
                  if (type == 1) {
                    param['Action'] = 'Detail';
                  }
                  print(param);
                  apiCallType = type;
                  wsPresenter.callAPI(POST_METHOD, 'Order_History', param);
                });
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: 'Ok',
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
        /*_showErrorAlert(
            APP_Name, 'No Internet Connection', FAIL, '', 'OK', false);*/
      }
    });
  }

  void clear() {
    if (mounted) {
      setState(() {
        listDetails.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Close'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          Navigator.pop(context, false);
        },
      ),
    );

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: isNotification,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: notificationCount,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, false);
        },
      ).appBar(),
      key: _scaffoldKey,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              color: const Color(bgColor),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  CustomTopHeaderBar(userName, subTitle,
                      'assets/orderhistory_icon.png', 0),
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.all(10),
                      child: Column(
                        children: <Widget>[
                          Card(
                              margin: const EdgeInsets.only(
                                  left: 0, top: 7, bottom: 7, right: 0),
                              elevation: 3,
                              child: Container(
                                color: Colors.white,
                                padding: const EdgeInsets.all(10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: <Widget>[
                                    Padding(
                                      padding:
                                      const EdgeInsets
                                          .only(
                                          top: 5),
                                      child: Row(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .center,
                                        children: <
                                            Widget>[
                                          Wrap(
                                            direction: Axis
                                                .horizontal,
                                            alignment:
                                            WrapAlignment
                                                .start,
                                            crossAxisAlignment:
                                            WrapCrossAlignment
                                                .center,
                                            children: <
                                                Widget>[
                                              Text(
                                                LocaleUtils.getString(
                                                    mContext,
                                                    'CustName_'),
                                                style:
                                                prifixTxtStyle,
                                              ),
                                            ],
                                          ),
                                          Expanded(
                                            flex: 1,
                                            child: Wrap(
                                              direction: Axis
                                                  .horizontal,
                                              alignment:
                                              WrapAlignment
                                                  .start,
                                              crossAxisAlignment:
                                              WrapCrossAlignment
                                                  .center,
                                              children: <
                                                  Widget>[
                                                Padding(
                                                  padding: const EdgeInsets
                                                      .only(
                                                      top:
                                                      2),
                                                  child:
                                                  Text(
                                                    widget.data
                                                        .varTo_Customer_Name !=
                                                        null
                                                        ? widget.data
                                                        .varTo_Customer_Name
                                                        : '',
                                                    style:
                                                    textStyle,
                                                    overflow: TextOverflow
                                                        .ellipsis,
                                                    maxLines: 1,
                                                  ),
                                                )
                                              ],
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Row(
                                        //crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        children: <Widget>[
                                          Expanded(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.max,
                                              children: <Widget>[
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      LocaleUtils.getString(
                                                          mContext, 'po_'),
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ],
                                                ),
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              top: 2),
                                                      child: Text(
                                                        widget.data.varOrder_No !=
                                                                null
                                                            ? widget.data
                                                                .varOrder_No
                                                            : '',
                                                        style: textStyle,
                                                      ),
                                                    )
                                                  ],
                                                ),
                                              ],
                                            ),
                                            flex: 2,
                                          ),
                                          Expanded(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.max,
                                              children: <Widget>[
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      LocaleUtils.getString(
                                                          mContext, 'status_'),
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ],
                                                ),
                                                Expanded(
                                                  child: Wrap(
                                                    direction: Axis.horizontal,
                                                    runAlignment:
                                                        WrapAlignment.start,
                                                    children: <Widget>[
                                                      Text(
                                                        '${widget.data.varStatus}',
                                                        style: TextStyle(
                                                          fontSize: 15.0,
                                                          fontWeight:
                                                              FontWeight.w400,
                                                          fontFamily:
                                                              'helvetica',
                                                          color: getStatusColor(
                                                              widget.data
                                                                  .varStatus),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            flex: 3,
                                          )
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: <Widget>[
                                          Wrap(
                                            direction: Axis.horizontal,
                                            alignment: WrapAlignment.start,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.center,
                                            children: <Widget>[
                                              Text(
                                                LocaleUtils.getString(
                                                    mContext, 'Date_'),
                                                style: prifixTxtStyle,
                                              ),
                                            ],
                                          ),
                                          Wrap(
                                            direction: Axis.horizontal,
                                            alignment: WrapAlignment.start,
                                            crossAxisAlignment:
                                                WrapCrossAlignment.center,
                                            children: <Widget>[
                                              Padding(
                                                padding: const EdgeInsets.only(
                                                    top: 2),
                                                child: Text(
                                                  widget.data.dtOrderDate !=
                                                          null
                                                      ? widget.data.dtOrderDate
                                                      : '',
                                                  style: textStyle,
                                                ),
                                              )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Row(
                                        //crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        children: <Widget>[
                                          Expanded(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.max,
                                              children: <Widget>[
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      LocaleUtils.getString(
                                                          mContext,
                                                          'TotArticle_'),
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ],
                                                ),
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Padding(
                                                        padding:
                                                            const EdgeInsets
                                                                .only(top: 2),
                                                        child: Text(
                                                          '${widget.data.intTotalArticle}',
                                                          style: textStyle,
                                                        ))
                                                  ],
                                                ),
                                              ],
                                            ),
                                            flex: 2,
                                          ),
                                          Expanded(
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.max,
                                              children: <Widget>[
                                                Wrap(
                                                  direction: Axis.horizontal,
                                                  runAlignment:
                                                      WrapAlignment.start,
                                                  children: <Widget>[
                                                    Text(
                                                      LocaleUtils.getString(
                                                          mContext, 'tot_qty_'),
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ],
                                                ),
                                                Expanded(
                                                  child: Wrap(
                                                    direction: Axis.horizontal,
                                                    runAlignment:
                                                        WrapAlignment.start,
                                                    children: <Widget>[
                                                      Text(
                                                        '${widget.data.decQuantityInKG}',
                                                        style: textStyle,
                                                      ),
                                                    ],
                                                  ),
                                                  flex: 1,
                                                )
                                              ],
                                            ),
                                            flex: 3,
                                          )
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Row(
                                        //crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        children: <Widget>[
                                          Wrap(
                                            direction: Axis.horizontal,
                                            runAlignment:
                                            WrapAlignment.start,
                                            children: <Widget>[
                                              Text(
                                                LocaleUtils.getString(
                                                    mContext,
                                                    'last_status_update_on'),
                                                style: prifixTxtStyle,
                                              ),
                                            ],
                                          ),
                                          Expanded(
                                            child: Wrap(
                                              direction: Axis.horizontal,
                                              runAlignment:
                                              WrapAlignment.start,
                                              children: <Widget>[
                                                Padding(
                                                    padding:
                                                    const EdgeInsets
                                                        .only(top: 2),
                                                    child: Text(
                                                      '${widget.data
                                                          .dtLastStatusUpdatedON}',
                                                      style: textStyle,
                                                    ))
                                              ],
                                            ),
                                            flex: 1,
                                          ),
                                        ],
                                      ),
                                    )
                                  ],
                                ),
                              )),
                          Container(
                            color: const Color(colorAccent),
                            padding: EdgeInsets.only(top: 7, bottom: 7),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: <Widget>[
                                Expanded(
                                  flex: 1,
                                  child: Padding(
                                    padding: EdgeInsets.only(left: 10),
                                    child: Text(LocaleUtils.getString(
                                        mContext, 'article_details'),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: TextStyle(
                                            fontSize: 14.0,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'helvetica',
                                            color: Colors.black)),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: !loadingFlag
                                ? listDetails.isNotEmpty
                                    ? Container(
                                        child: ListView.builder(
                                          itemCount: listDetails.length,
                                          shrinkWrap: true,
                                          itemBuilder: (BuildContext context,
                                              int index) {
                                            return InkWell(
                                                child: Card(
                                                    margin:
                                                        const EdgeInsets.only(
                                                            left: 0,
                                                            top: 7,
                                                            bottom: 7,
                                                            right: 0),
                                                    elevation: 3,
                                                    child: Container(
                                                      color: Colors.white,
                                                      padding:
                                                          const EdgeInsets.all(
                                                              10),
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisAlignment:
                                                            MainAxisAlignment
                                                                .start,
                                                        children: <Widget>[
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 5),
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              mainAxisSize: MainAxisSize
                                                                  .max,
                                                              children: <
                                                                  Widget>[
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Wrap(
                                                                    direction: Axis
                                                                        .horizontal,
                                                                    alignment:
                                                                    WrapAlignment
                                                                        .start,
                                                                    crossAxisAlignment:
                                                                    WrapCrossAlignment
                                                                        .center,
                                                                    children: <
                                                                        Widget>[
                                                                      Text(
                                                                        '${listDetails[index]
                                                                            .varProduct_SKU_Code}-${listDetails[index]
                                                                            .varProduct_SKU_Name}',
                                                                        style:
                                                                        prifixTxtStyle,
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                        .only(
                                                                    top: 5),
                                                            child: Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .center,
                                                              children: <
                                                                  Widget>[
                                                                Wrap(
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      WrapCrossAlignment
                                                                          .center,
                                                                  children: <
                                                                      Widget>[
                                                                    Text(
                                                                      '${LocaleUtils.getString(mContext, 'Qty')}: ',
                                                                      style:
                                                                          prifixTxtStyle,
                                                                    ),
                                                                  ],
                                                                ),
                                                                Wrap(
                                                                  direction: Axis
                                                                      .horizontal,
                                                                  alignment:
                                                                      WrapAlignment
                                                                          .start,
                                                                  crossAxisAlignment:
                                                                      WrapCrossAlignment
                                                                          .center,
                                                                  children: <
                                                                      Widget>[
                                                                    Padding(
                                                                      padding: const EdgeInsets
                                                                              .only(
                                                                          top:
                                                                              2),
                                                                      child:
                                                                          Text(
                                                                        '${listDetails[index].decQuantityInKG}',
                                                                        style:
                                                                            textStyle,
                                                                      ),
                                                                    )
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    )));
                                          },
                                        ),
                                      )
                                    : Container(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: <Widget>[
                                            Image.asset(
                                              'assets/nodata_icon.png',
                                              height: 100,
                                              width: 100,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 10),
                                              child: Text(
                                                noDataTitle,
                                                style: prifixTxtStyle,
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                : Center(
                                    child: const CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Color(colorPrimary))),
                                  ),
                            flex: 1,
                          ),
                        ],
                      ),
                    ),
                    flex: 1,
                  ),
                  Container(
                    width: screenSize.width,
                    height: 45,
                    child: saveButton,
                    margin: const EdgeInsets.all(15),
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  Color getStatusColor(String status) {
    if (status.toLowerCase() == 'pending') {
      return Colors.orange;
    } else if (status.toLowerCase() == 'accept') {
      return Colors.green;
    } else if (status.toLowerCase() == 'reject') {
      return Colors.red;
    } else {
      return Colors.black;
    }
  }

  @override
  void onLoginError(String errorTxt) {
    setState(() {
      loadingFlag = false;
    });

    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return CustomAlertDialog(
          content: errorTxt,
          title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
          isShowNagativeButton: false,
          textNagativeButton: '',
          textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
          onPressedNegative: () {},
          onPressedPositive: () {},
        );
      },
    );
  }

  @override
  void onLoginSuccess(String response) {
    print(response);

    setState(() {
      loadingFlag = false;
    });

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (apiCallType == 1 && responseModel.Status == '1') {
      listDetails.clear();
      if (mounted) {
        setState(() {
          listDetails.addAll(responseModel.getDetails_OrderHistory());
        });
      }
    } else if (responseModel.Status == '2') {
      //API Token
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'Session_warning'),
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {
              final Route route =
                  CupertinoPageRoute(builder: (context) => Dashboard());
              Navigator.pushAndRemoveUntil(
                  context, route, (Route<dynamic> route) => false);
            },
          );
        },
      );
    } else if (responseModel.Status == '0') {
      if (mounted) {
        setState(() {
          listDetails.clear();
          noDataTitle = responseModel.Message;
        });
      }
    } else {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: responseModel.Message,
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
