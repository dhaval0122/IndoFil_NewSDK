import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/FooterWidgets.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/ForgotResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/dimens.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

const String SUCCESS = 'Success', FAIL = 'Fail';

class Forgot extends StatefulWidget {
  @override
  _ForgotState createState() => _ForgotState();
}

class _ForgotState extends State<Forgot> implements WSInterface {

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _autoValidate = false;
  Size screenSize;
  String _email;
  Utils mUtils;
  SharedPrefs sharedPrefs;
  WSPresenter wsPresenter;
  ProgressHUD _progressHUD;
  bool _loading = false;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  EcpSyncPlugin _battery;

  _ForgotState() {
    wsPresenter = WSPresenter(this);
  }

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(context, 'loading_dot'),
      loading: _loading,
    );
  }

  void _forgotAPICall() async {
    FocusScope.of(context).requestFocus(FocusNode());
    int fkLanguageCode = await sharedPrefs.getInt(PREF_FK_LANGUAGE_GL_CODE);

    await _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          var param = Map();
          param[PARAM_USERNAME] = _email;
          param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
              ? SUB_MODULE_NAME_ANDROID
              : SUB_MODULE_NAME_IOS;
          param[PARAM_VERSION] = APP_VERSION;
          param[PARAM_LANGUAGE_ID] = fkLanguageCode.toString() != null
              ? fkLanguageCode.toString()
              : '0';
          sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
            param[PARAM_DEVICE_ID] = deviceid;
            print(param);
            wsPresenter.callAPI(POST_METHOD, FORGOT, param);
          });
        });
      } else {
        //_showSnackBar('No Internet Connection');
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(context, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(context, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
        //_showErrorAlert(APP_Name, 'No Internet Connection', FAIL, '', 'OK', false);
      }
    });
  }

  /*void _showSnackBar(String text) {
    scaffoldKey.currentState.showSnackBar(SnackBar(
      content: Text(text),
      duration: Duration(seconds: 1),
    ));
  }*/

  void navigationPage() {
    Navigator.of(context).pop();
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _forgotAPICall();
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }

        _loading = !_loading;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    _battery = EcpSyncPlugin();

//    try {
//      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
//        final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
//        _firebaseMessaging.configure(
//          onMessage: (Map<String, dynamic> message) async {
//            print('onMessage: $message');
//            //_showItemDialog(message);
//
//            if (message.containsKey('notification')) {
//              /*PushNotificationModel items = PushNotificationModel.fromMap(message);
//          print('======notification======={$items}');*/
//              //_showNotification(items.title, items.body);
//            }
//          },
//          onLaunch: (Map<String, dynamic> message) async {
//            print('onLaunch: $message');
//            //_navigateToItemDetail(message);
//          },
//          onResume: (Map<String, dynamic> message) async {
//            print('onResume: $message');
//            //_navigateToItemDetail(message);
//          },
//        );
//        _firebaseMessaging.requestNotificationPermissions(
//            const IosNotificationSettings(
//                sound: true, badge: true, alert: true));
//        _firebaseMessaging.onIosSettingsRegistered
//            .listen((IosNotificationSettings settings) {
//          print('Settings registered: $settings');
//        });
//        _firebaseMessaging.getToken().then((String token) {
//          assert(token != null);
//          /*setState(() {
//        String _homeScreenText = 'Push Messaging token: $token';
//        print(_homeScreenText);
//      });*/
//          //print(_homeScreenText);
//        });
//      }
//    } catch (e) {
//      print(e);
//    }

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        //BaseClassChina().initilizeFirebase(pus)
      }
    } catch (e) {
      print(e);
    }

    _initLoading();
  }

  String validateEmail(String value) {
    if (value.trim().isEmpty) {
      return LocaleUtils.getString(context, 'please_enter_your_email');
    } else {
      return null;
    }
//    Pattern pattern =
//        r'^(([^<>()[\]\\.,;:\s@\']+(\.[^<>()[\]\\.,;:\s@\']+)*)|(\'.+\'))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
//    RegExp regex =  RegExp(pattern);
//    if (!regex.hasMatch(value))
//      return 'Please enter your valid Email';
//    else
//      return null;
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final email = TextFormField(
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
      //enableInteractiveSelection: false,
      autofocus: false,
      autocorrect: false,
      validator: validateEmail,
      onSaved: (String val) {
        _email = val;
      },
      style: inputTextStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(context, 'email'),
        contentPadding: const EdgeInsets.fromLTRB(0, p_15, 0, 0),
        errorStyle: errorStyle,
        hintStyle: TextStyle(color: Colors.grey[400]),
        prefixIcon: const Icon(Icons.email, color: Colors.white),
        focusedBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Colors.grey[100])),
        enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: const Color(colorAccent))),
      ),
    );

    final forgotText = Padding(
      padding: const EdgeInsets.only(top: p_40),
      child: Text(
        LocaleUtils.getString(context, 'Forgot_Password'),
        style: TextStyle(
          fontSize: 24.0,
          fontWeight: FontWeight.w400,
          fontFamily: 'helvetica',
          color: Colors.white,
        ),
        textAlign: TextAlign.left,
      ),
    );

    final sendPasswordButton = Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(context, 'send_password'),
        buttonColor: const Color(colorAccent),
        textColor: Colors.black,
        onTap: _validateInputs,
      ),
    );

    return Scaffold(
      key: scaffoldKey,
      bottomNavigationBar: Container(
        height: p_45,
        child: FooterWidgets(),
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              width: screenSize.width,
              height: screenSize.height,
              decoration: BoxDecoration(color: const Color(colorPrimary)),
              child: Column(
                children: <Widget>[
                  Expanded(
                    child: SingleChildScrollView(
                      child: Form(
                        child: Container(
                          child: Column(
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.only(bottom: 50),
                                child: GestureDetector(
                                  child: const Icon(Icons.arrow_back,
                                      color: Colors.white, size: 30),
                                  onTap: navigationPage,
                                ),
                              ),
                              Image.asset(
                                  PROJECT_NAME == 'BASF_HK'
                                      ? 'assets/basf_appicon.png'
                                      : 'assets/zydus_appicon.png',
                                  width: p_100,
                                  height: p_100),
                              Padding(
                                padding: const EdgeInsets.only(top: 50),
                                child: forgotText,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: p_20),
                                child: email,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: p_20),
                                child: sendPasswordButton,
                              ),
                            ],
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                          ),
                          padding:
                              const EdgeInsets.fromLTRB(p_25, p_40, p_25, p_40),
                          alignment: Alignment.topLeft,
                        ),
                        autovalidate: _autoValidate,
                        key: _formKey,
                      ),
                      scrollDirection: Axis.vertical,
                      controller: ScrollController(),
                    ),
                    flex: 1,
                  ),
                ],
              ),
            ),
            _progressHUD,
          ],
        ),
      ),
    );
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print(errorTxt);
    //_showSnackBar(errorTxt);
    showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
            onWillPop: () {},
            child: CustomAlertDialog(
              content: errorTxt,
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(context, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            ));
      },
    );
    //_showErrorAlert(APP_Name, errorTxt, '','OK',FAIL,false);
  }

  @override
  void onLoginSuccess(String response) {
    _loading = false;
    dismissProgressHUD();
    print(response);
    //_showSnackBar(response);

    final dynamic jsonResponse = json.decode(response.toString().trim());
    final ForgotResponseModel responseModel =
        ForgotResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status.contains('1')) {
      //Success Response
      final List<ForgotResponseDataModel> forgotList = responseModel.Response;
      String newPassword = '';
      //if (forgotList?.length > 0) {
      if (forgotList.isNotEmpty) {
        newPassword = forgotList[0].varPassword;
      }
      updatePasswordPersonMaster(newPassword, responseModel.Message);
    } else {
      //Show error dialog
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {},
              ));
        },
      );
    }
  }

  void updatePasswordPersonMaster(String password, String message) {
    databaseHelper
        .updatePasswordPersonMaster(password, _email.trim())
        .then((int id) {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content: message,
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(context, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  navigationPage();
                },
              ));
        },
      );
    });
  }
}
