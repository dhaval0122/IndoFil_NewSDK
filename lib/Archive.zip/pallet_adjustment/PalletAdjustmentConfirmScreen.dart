import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentCongratulationScreen.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentScanScreen.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';
import 'package:super_tooltip/super_tooltip.dart';

class PalletAdjustmentConfirmScreen extends StatefulWidget {
  final List<PalletAdjustmentModel> scanData;
  final PalletSummary palletSummary;
  final String displayName;

  PalletAdjustmentConfirmScreen(
      {this.scanData, this.displayName, this.palletSummary});

  @override
  _PalletAdjustmentConfirmScreenState createState() =>
      _PalletAdjustmentConfirmScreenState();
}

class _PalletAdjustmentConfirmScreenState
    extends State<PalletAdjustmentConfirmScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool _loading = false, isNotification = false, isSync = false;
  Size screenSize;
  String userName = '', topHeaderImage = 'assets/pallet_adjustment.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  DatabaseHelper databaseHelper;
  List<PalletAdjustmentModel> _palletAdjustmentList;
  List<PalletAdjustmentModel> _palletAdjustmentListSearch;
  TextEditingController _search_controller;
  PalletSummary palletSummary;
  WSPresenter wsPresenter;
  int apiCallType = 0;
  Flushbar flush;
  bool isVerifyBtn = false;
  bool isReturnResultCall = false;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    _palletAdjustmentList = new List();
    _palletAdjustmentListSearch = new List();

    _search_controller = TextEditingController();

    init();
  }

  void init() async {
    String fullName = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullName != null ? fullName : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await _battery.hideKeyboardPlugin();

    isReturnResultCall = false;
    if (widget.scanData.isEmpty && widget.palletSummary == null) {
      apiCall(1, '');
    } else {
      _palletAdjustmentList.addAll(widget.scanData);
      _palletAdjustmentListSearch.addAll(widget.scanData);
      palletSummary = widget.palletSummary;
    }

    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    super.dispose();
    _battery = null;
  }

  void isVerifySaveBtnTitle() {
    if (_palletAdjustmentList.isNotEmpty) {
      isVerifyBtn = false;
      for (int i = 0; i < _palletAdjustmentList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentList[i];
        if (palletAdjustmentModel.chrStatus == 'D' ||
            palletAdjustmentModel.chrStatus == 'I') {
          isVerifyBtn = true;
        }
      }
      if (mounted) {
        setState(() {});
      }
    }
  }

  bool isVerifySaveBtnValue() {
    bool flag = false;
    if (_palletAdjustmentList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentList[i];
        if (palletAdjustmentModel.chrStatus == 'E' ||
            palletAdjustmentModel.chrStatus == 'I') {
          flag = true;
        }
      }
    }
    return flag;
  }


  int isTotalLabelLength() {
    final List<PalletAdjustmentModel> dummySearchList = List<
        PalletAdjustmentModel>();
    if (_palletAdjustmentList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentList[i];
        if (palletAdjustmentModel.chrStatus != 'D') {
          dummySearchList.add(palletAdjustmentModel);
        }
      }
    }
    return dummySearchList.length;
  }

  void apiCall(int type, String jsonData) async {
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      _loading = true;
      dismissProgressHUD();

      Future.delayed(const Duration(milliseconds: 500), () async {
        var param = Map();
        String loginID = await sharedPrefs.getString(PREF_INIT_GI_CODE);
        String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
        String apiToken = await sharedPrefs.getString(PREF_API_TOKEN);

        param[PARAM_SUB_MODULE_NAME] =
            Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;
        param[PARAM_API_TOKEN] = apiToken;
        param[PARAM_PERSON_ID] = loginID;
        param[PARAM_DEVICE_ID] = deviceID;
        param[PARAM_VERSION] = APP_VERSION;
        param['PalletNo'] =
        palletSummary != null ? palletSummary.varPalletNo : '';
        param['PalletGlCode'] =
        palletSummary != null ? palletSummary.fk_PalletGlCode.toString() : '';
        param['JsonData'] = jsonData;

        if (type == 1) {
          param[PARAM_ACTION] = "PalletAdjustmentDetail";
        } else if (type == 2) {
          param[PARAM_ACTION] = "Close";
        } else if (type == 3) {
          param[PARAM_ACTION] = "Verify";
        } else if (type == 4) {
          param[PARAM_ACTION] = "Save";
        }

        print(param);
        apiCallType = type;
        wsPresenter.callAPI(POST_METHOD, 'Pallet_Adjustment', param);
      });
    } else {
      await showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'no_internet_connection'),
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
            'false',
            'true',
            'false',
            '#004a96',
            PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
            LocaleUtils.getString(mContext, 'next'),
            PROJECT_NAME == 'BASF_HK'
                ? LocaleUtils.getString(mContext, 'scan_your_label_here')
                : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

  Color getColorCode(int index) {
    return mUtils.fromHex(_palletAdjustmentList[index].varColor);
  }

  Widget legendSubText(Color colorCode, String legendName) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 20),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 20,
            decoration: BoxDecoration(
                color: colorCode,
                borderRadius: BorderRadius.all(Radius.circular(10))),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: Text(legendName,
                style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'helvetica',
                    color: Colors.black)),
          )
        ],
      ),
    );
  }

  void filterSearchResults(String query) {
    final List<PalletAdjustmentModel> dummySearchList =
        List<PalletAdjustmentModel>();
    dummySearchList.addAll(_palletAdjustmentListSearch);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<PalletAdjustmentModel> dummyListData =
          List<PalletAdjustmentModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          _palletAdjustmentList.clear();
          _palletAdjustmentList.addAll(dummyListData);
        });
      }
    } else {
      if (mounted) {
        setState(() {
          _palletAdjustmentList.clear();
          _palletAdjustmentList.addAll(_palletAdjustmentListSearch);
        });
      }
    }
  }

//  void reScanBtn() async {
//    final Route route = CupertinoPageRoute(
//        builder: (context) => PIVScanScreen(
//            isChange: true,
//            displayName: widget.displayName,
//            scanData: inwardScanList));
//    final result = await Navigator.push(mContext, route);
//    try {
//      if (result != null) {
//        if (result) {
//          if (mounted) {
//            setState(() {});
//          }
//        }
//      }
//    } catch (e) {
//      print(e.toString());
//    }
//  }

  void navigatePalletAdjustmentScanScreen(String displayName) async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PalletAdjustmentScanScreen(
              displayName: displayName,
          scanData: _palletAdjustmentList,
          palletSummary: palletSummary,
            ));

    final result = await Navigator.push(mContext, route);
    try {
      if (result != null) {
        if (result) {
          isReturnResultCall = true;
          apiCall(1, '');
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final tooltip = SuperTooltip(
        popupDirection: TooltipDirection.left,
        arrowTipDistance: 0.0,
        arrowBaseWidth: 0.0,
        arrowLength: 0.0,
        borderColor: Color(colorPrimary),
        borderWidth: 4.0,
        snapsFarAwayVertically: true,
        showCloseButton: ShowCloseButton.none,
        hasShadow: false,
        touchThroughAreaShape: ClipAreaShape.rectangle,
        content: Material(
            child: Container(
          width: screenSize.width,
          child: Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                      '${LocaleUtils.getString(mContext, 'legend_of_current_status')}',
                      style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'helvetica',
                          color: Colors.black)),
                  legendSubText(Color(colorLabelPresentInOtherPallet),
                      LocaleUtils.getString(mContext, 'label_other_pallet')),
                  legendSubText(Color(colorLabelExistingPallet),
                      LocaleUtils.getString(mContext, 'label_existing_pallet')),
                  legendSubText(Color(colorInValid),
                      LocaleUtils.getString(mContext, 'invalid_pallet')),
                ],
              )),
        )));

    final addLabelButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'add_label'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          navigatePalletAdjustmentScanScreen(widget.displayName);
        },
      ),
    );

    final updateButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Save'),
        buttonColor: isVerifyBtn ? const Color(colorPrimary) : Colors.grey,
        textColor: isVerifyBtn ? Colors.white : Colors.white54,
        onTap: () {
          if (isVerifySaveBtnValue()) {
            var json = jsonEncode(
                _palletAdjustmentList.map((e) => e.toJson()).toList());
            String jsonFull = '{"Pallet_Details":$json}';
            print(jsonFull);
            apiCall(3, jsonFull);
          } else {
            showDialog<Map>(
              barrierDismissible: false,
              context: context,
              builder: (context) {
                return CustomAlertDialog(
                  content:
                  LocaleUtils.getString(
                      mContext, 'YouHaveNotScannedAnyLabelYet'),
                  title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                );
              },
            );
          }
        },
      ),
    );

    final discardButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Discard'),
        buttonColor: const Color(colorInValid),
        textColor: Colors.white,
        onTap: () {
          showDialog<Map>(
            barrierDismissible: false,
            context: context,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(
                    mContext, 'by_discarding_pallet_adjustment'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  apiCall(2, '');
                },
              );
            },
          );
        },
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          if (tooltip.isOpen) {
            tooltip.close();
          } else {
            Navigator.pop(context, true);
          }
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (tooltip.isOpen) {
                tooltip.close();
              } else {
                Navigator.pop(context, true);
              }
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    color: const Color(bgColor),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, widget.displayName, topHeaderImage, 0),
//                    CustomTopHeaderBarForInward(stage: SUB_HEADER_INWARD_SCAN),
                        Container(
                          color: const Color(bgColor),
                          padding: const EdgeInsets.only(
                              top: 5, left: 15, right: 15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    LocaleUtils.getString(
                                        mContext, 'pallet_label'),
                                    style: prifixTxtStyle,
                                  ),
                                  Text(
                                    palletSummary != null
                                        ? palletSummary.varPalletNo
                                        : '',
                                    style: textStyle,
                                  ),
                                ],
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 5),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                      LocaleUtils.getString(
                                          mContext, 'total_label'),
                                      style: prifixTxtStyle,
                                    ),
                                    Text(isTotalLabelLength().toString(),
                                      style: textStyle,
                                    ),
                                  ],
                                ),
                              ),
//                          Padding(
//                            padding: const EdgeInsets.only(top: 5),
//                            child: Wrap(
//                              direction: Axis.horizontal,
//                              runAlignment: WrapAlignment.start,
//                              children: <Widget>[
//                                Text(
//                                  LocaleUtils.getString(
//                                      mContext, 'ref_id'),
//                                  style: prifixTxtStyle,
//                                ),
//                                Text(
//                                  palletSummary != null
//                                      ? palletSummary.varPalletNo
//                                      : '',
//                                  style: textStyle,
//                                ),
//                              ],
//                            ),
//                          ),
                            ],
                          ),
                        ),
                        Container(
                          height: 40,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(width: 1, color: Colors.black),
                              borderRadius: const BorderRadius.all(
                                  Radius.circular(3))),
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15),
                          //padding: const EdgeInsets.all(5),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: TextField(
                                    controller: _search_controller,
                                    //enableInteractiveSelection: false,
                                    keyboardType: TextInputType.text,
                                    textInputAction: TextInputAction.done,
                                    autofocus: false,
                                    style: textStyle,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintStyle:
                                      TextStyle(color: Colors.grey[700]),
                                      hintText: LocaleUtils.getString(
                                          mContext, 'search_serial_no'),
                                      counterText: '',
                                    ),
                                    textAlign: TextAlign.left,
                                    onChanged: (value) {
                                      filterSearchResults(
                                          value.trim().toLowerCase());
                                    },
                                    maxLines: 1,
                                    maxLength: EditTxtMaxLengths,
                                  ),
                                ),
                                flex: 1,
                              ),
                              IconButton(
                                  onPressed: () {
                                    // _search_controller.clear();
                                  },
                                  icon: const Icon(
                                    Icons.search,
                                    size: 20,
                                    color: Color(colorPrimary),
                                  ))
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: const Color(bgColor),
                            child: Card(
                              elevation: 7,
                              margin: const EdgeInsets.only(
                                  top: 10, right: 15, left: 15),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Container(
                                    height: 40,
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 5),
                                    alignment: Alignment.centerLeft,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary)),
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: <Widget>[
                                        Expanded(
                                          flex: 4,
                                          child: Text(
                                            LocaleUtils.getString(
                                                mContext, 'ScannedSrNo'),
                                            style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w300,
                                              fontFamily: 'helvetica',
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: InkWell(
                                            onTap: () {
                                              tooltip.show(context);
                                            },
                                            child: const Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding:
                                                    EdgeInsets.only(right: 10),
                                                child: Icon(
                                                  Icons.info,
                                                  size: 25.0,
                                                  color: Colors.orange,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      child: _palletAdjustmentList.isNotEmpty
                                          ? ListView.builder(
                                              itemCount:
                                              _palletAdjustmentList.length,
                                              shrinkWrap: true,
                                              itemBuilder:
                                                  (BuildContext context,
                                                      int index) {
                                                return _palletAdjustmentList[
                                                                index]
                                                            .chrStatus ==
                                                        'D'
                                                    ? Container()
                                                    : Container(
                                                        color: Colors.white,
                                                        child: Column(
                                                          children: <Widget>[
                                                            Container(
                                                              height: 40,
                                                              color:
                                                                  Colors.white,
                                                              width: screenSize
                                                                  .width,
                                                              child: Row(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .center,
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceAround,
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .max,
                                                                children: <
                                                                    Widget>[
                                                                  Expanded(
                                                                    child: Center(
                                                                        child: Text('#${(index + 1)}',
                                                                            style: TextStyle(
                                                                              fontSize: 14.0,
                                                                              fontWeight: FontWeight.w400,
                                                                              fontFamily: 'helvetica',
                                                                              color: getColorCode(index),
                                                                            ))),
                                                                    flex: 1,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Container(
                                                                      child:
                                                                          Align(
                                                                        child: Text(
                                                                            '${_palletAdjustmentList[index]
                                                                                .varSticker}',
                                                                            style: TextStyle(
                                                                                fontSize: 14.0,
                                                                                fontWeight: FontWeight.w400,
                                                                                fontFamily: 'helvetica',
                                                                                color: getColorCode(index))),
                                                                        alignment:
                                                                            Alignment.centerLeft,
                                                                      ),
                                                                    ),
                                                                    flex: 2,
                                                                  ),
                                                                  Expanded(
                                                                    child:
                                                                        Align(
                                                                      child:
                                                                          GestureDetector(
                                                                        child: Icon(
                                                                            Icons
                                                                                .delete,
                                                                            color:
                                                                                getColorCode(index)),
                                                                        onTap:
                                                                            () {
                                                                          removeSticker(
                                                                              index);
                                                                        },
                                                                      ),
                                                                      alignment:
                                                                          Alignment
                                                                              .center,
                                                                    ),
                                                                    flex: 1,
                                                                  )
                                                                ],
                                                              ),
                                                            ),
                                                            const Divider(
                                                                height: 3,
                                                                color: Colors
                                                                    .black),
                                                          ],
                                                        ));
                                              },
                                            )
                                          : Container(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.center,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: <Widget>[
                                                  Image.asset(
                                                    'assets/nodata_icon.png',
                                                    height: 100,
                                                    width: 100,
                                                  ),
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            top: 10),
                                                    child: Text(
                                                      LocaleUtils.getString(
                                                          mContext,
                                                          'NoDataFound'),
                                                      style: prifixTxtStyle,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: screenSize.width,
                          height: 45,
                          margin: const EdgeInsets.all(15),
                          child: Row(
                            children: <Widget>[
                              Expanded(
                                child: addLabelButton,
                                flex: 1,
                              ),
                              Container(
                                width: 10,
                              ),
                              Expanded(
                                child: discardButton,
                                flex: 1,
                              ),
                              Container(
                                width: 10,
                              ),
                              Expanded(
                                child: updateButton,
                                flex: 1,
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  void removeSticker(int index) async {
    print('=========index=====$index');
    PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentList[index];
    palletAdjustmentModel.chrStatus = 'D';
    palletAdjustmentModel.chrProcess = 'N';
    _palletAdjustmentList.removeAt(index);
    _palletAdjustmentList.insert(index, palletAdjustmentModel);

    isVerifySaveBtnTitle();
    if (mounted) {
      setState(() {});
    }

    flush = Flushbar<bool>(
      message:
          "${palletAdjustmentModel.varSticker} ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
//          PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentListSearch[index];
          palletAdjustmentModel.chrStatus = 'E';
          palletAdjustmentModel.chrProcess = 'Y';
          _palletAdjustmentList.removeAt(index);
          _palletAdjustmentList.insert(index, palletAdjustmentModel);
          flush.dismiss();
          isVerifySaveBtnTitle();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    await flush.show(context);
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    if (apiCallType != 3) {
      _loading = false;
      dismissProgressHUD();
    }

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (apiCallType == 1) {
        if (responseModel.Status.contains('1')) {
          List<PalletAdjustmentModel> tempList = new List();
          tempList.addAll(_palletAdjustmentList);
          _palletAdjustmentList.clear();
          _palletAdjustmentListSearch.clear();
          _palletAdjustmentList.addAll(responseModel.getPalletAdjustmentList());
          _palletAdjustmentListSearch
              .addAll(responseModel.getPalletAdjustmentList());
          palletSummary = responseModel.getPalletSummary();
          print('=====aaaaaaaaa==========');
          if (isReturnResultCall) {
            print('=====bbbbbbbbbb==========');
            if (tempList.length != _palletAdjustmentList.length) {
              print('=====cccccccccc==========');
              isVerifyBtn = true;
            } else {
              isVerifySaveBtnTitle();
            }
          }
          if (mounted) {
            setState(() {});
          }
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  final Route route =
                      CupertinoPageRoute(builder: (context) => Dashboard());
                  Navigator.pushAndRemoveUntil(
                      context, route, (Route<dynamic> route) => false);
                },
              );
            },
          );
        }
      } else if (apiCallType == 2) {
        if (responseModel.Status.contains('1')) {
          final Route route = CupertinoPageRoute(
              builder: (context) => PalletAdjustmentScreen(
                    displayName: widget.displayName,
                  ));
          Navigator.pushReplacement(mContext, route);
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  final Route route =
                      CupertinoPageRoute(builder: (context) => Dashboard());
                  Navigator.pushAndRemoveUntil(
                      context, route, (Route<dynamic> route) => false);
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      } else if (apiCallType == 3) {
        if (responseModel.Status.contains('1')) {
          var json = jsonEncode(
              _palletAdjustmentList.map((e) => e.toJson()).toList());
          String jsonFull = '{"Pallet_Details":$json}';
          print(jsonFull);
          apiCall(4, jsonFull);
        } else if (responseModel.Status.contains('2')) {
          navigatePalletAdjustmentScanScreen(widget.displayName);
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      } else if (apiCallType == 4) {
        if (responseModel.Status.contains('1')) {
          final Route route = CupertinoPageRoute(
              builder: (context) =>
                  PalletAdjustmentCongratulationScreen(
                    displayName: widget.displayName,
                  ));
          Navigator.pushReplacement(mContext, route);
        } else if (responseModel.Status.contains('2')) {
          navigatePalletAdjustmentScanScreen(widget.displayName);
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: responseModel.Message,
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedPositive: () {},
              );
            },
          );
        }
      }
    } else {
      showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: responseModel.Message,
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
