import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';
import 'package:super_tooltip/super_tooltip.dart';

class MultiDeleteModel {
  int index;
  bool isRemoveIndex;
  PalletAdjustmentModel palletAdjustmentModel;

  MultiDeleteModel(this.index, this.isRemoveIndex, this.palletAdjustmentModel);
}

class PalletAdjustmentScanScreen extends StatefulWidget {
  final List<PalletAdjustmentModel> scanData;
  final String displayName;
  final PalletSummary palletSummary;

  PalletAdjustmentScanScreen(
      {this.scanData, this.displayName, this.palletSummary});

  @override
  _PalletAdjustmentScanScreenState createState() =>
      _PalletAdjustmentScanScreenState();
}

class _PalletAdjustmentScanScreenState extends State<PalletAdjustmentScanScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '', topHeaderImage = 'assets/pallet_adjustment.png';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController serialNoTextController;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  String menufacturer = '';
  DatabaseHelper databaseHelper;
  int apiCallType = 0;
  WSPresenter wsPresenter;
  List<PalletAdjustmentModel> _palletAdjustmentScanList;
  List<PalletAdjustmentModel> _palletAdjustmentScanListSearch;
  bool isSelectAll = false;
  PalletSummary palletSummary;
  Flushbar flush;
  TextEditingController _search_controller;
  bool isVerifyBtn = false;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    _palletAdjustmentScanList = new List();
    _palletAdjustmentScanListSearch = new List();
    if (widget.scanData.isNotEmpty) {
      _palletAdjustmentScanList.addAll(widget.scanData);
      _palletAdjustmentScanListSearch.addAll(widget.scanData);
      this.palletSummary = widget.palletSummary;
    } else {
      apiCall(1, '');
    }

    serialNoTextController = TextEditingController();
    _search_controller = TextEditingController();

    init();
  }

  void init() async {
    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullName = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullName != null ? fullName : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) async {
          try {
            print('=======state=======${state.toString()}');
            if (state['type'] == '11') {
              var detailsData = state['Details'];
              final dynamic lists = json.decode(detailsData);
              verifySticker(lists);
            }
          } catch (e) {
            print(e.toString());
          }
        });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await _battery.hideKeyboardPlugin();

    isVerifySaveBtnTitle();

    if (mounted) {
      setState(() {});
    }
  }

  void verifySticker(dynamic lists) async {
    if (lists.length > 0) {
      for (var j in lists) {
        if (j.toString().trim().isNotEmpty) {
          List<String> code = j.toString().split("/");
          print('====F CODE=====${code.toString()}');
          if (code.length > 1) {
            if (code[1].toString() == '31') {
//              insertStickerInList(code[0].toString().toUpperCase(), 'P');
            } else if (code[1].toString() == '21') {
              insertStickerInList(code[0].toString().toUpperCase(), 'S');
            }
          } else {
            insertStickerInList(code[0].toString().toUpperCase(), 'S');
          }
        }
      }
    }
  }

  void insertStickerInList(String sticker, String chrType) async {
    int isExist = await stickerAlreadyExist(sticker);
    if (isExist > 0) {
      isLaserScanLoad = false;

      if (isExist == 1) {
        _palletAdjustmentScanList.insert(
            0,
            PalletAdjustmentModel(
                intGlCode: 0,
                fk_CustomerGlCode: 0,
                fk_PalletGlCode: 0,
                fk_StickerGlCode: 0,
                varSticker: sticker,
                chrStatus: 'I',
                varRefNo: '',
                varColor: '#004a96',
                chrValid: 'N',
                chrValidSave: 'N',
                chrProcess: 'N',
                varRemarks: ''));

        _palletAdjustmentScanListSearch.insert(
            0,
            PalletAdjustmentModel(
                intGlCode: 0,
                fk_CustomerGlCode: 0,
                fk_PalletGlCode: 0,
                fk_StickerGlCode: 0,
                varSticker: sticker,
                chrStatus: 'I',
                varRefNo: '',
                varColor: '#004a96',
                chrValid: 'N',
                chrValidSave: 'N',
                chrProcess: 'N',
                varRemarks: ''));

        isVerifySaveBtnTitle();

        if (mounted) {
          setState(() {});
        }
      } else if (isExist == 2) {
        changeStickerStatus(sticker);

        isVerifySaveBtnTitle();

        if (mounted) {
          setState(() {});
        }
      }
    } else {
      isLaserScanLoad = false;
      _showSnackBar(LocaleUtils.getString(mContext, 'LabelAlreadyExist'));
    }
  }

  void changeStickerStatus(String sticker) {
    if (_palletAdjustmentScanList.isNotEmpty) {
      int lengthList = _palletAdjustmentScanList.length;
      for (int i = 0; i < lengthList; i++) {
        PalletAdjustmentModel inwardScanModel = _palletAdjustmentScanList[i];
        if (sticker.toUpperCase() == inwardScanModel.varSticker.toUpperCase()) {
          if (inwardScanModel.chrStatus == 'D') {
            inwardScanModel.chrStatus = 'E';
            inwardScanModel.chrProcess = 'Y';
            _palletAdjustmentScanList.removeAt(i);
            _palletAdjustmentScanList.insert(i, inwardScanModel);
            //return true;
          }
        }
      }
    }
    //return false;
  }

  Future<int> stickerAlreadyExist(String sticker) async {
    int stickerReturn = 1;
    if (_palletAdjustmentScanList.isNotEmpty) {
//      int lengthList = _palletAdjustmentScanList.length;
//      for (int i = 0; i < lengthList; i++) {
      await Future.forEach(_palletAdjustmentScanList,
              (PalletAdjustmentModel inwardScanModel) {
//        PalletAdjustmentModel inwardScanModel = _palletAdjustmentScanList[i];
        if (sticker.toUpperCase() == inwardScanModel.varSticker.toUpperCase()) {
          if (inwardScanModel.chrStatus == 'D') {
            stickerReturn = 2;
          } else {
            stickerReturn = 0;
          }
        }
      });
    }
    return stickerReturn;
  }

  void _onTextChanged() async {
    final String value = serialNoTextController.text ?? '';
    if (value.isNotEmpty) {
      if (value.trim().length >= int.parse(globals.BARCODE_LENGTH)) {
        print('=====value=======$value');
        if (!isLaserScanLoad) {
          final List<String> scanList = List();
          isLaserScanLoad = true;
          await _battery.checkBarCode(value).then((String serialNo) async {
            if (!scanList.contains(serialNo)) {
              scanList.add(serialNo);
            }
            verifySticker(scanList);
            serialNoTextController.text = '';
          });
        } else {
          serialNoTextController.text = '';
        }
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(mContext).requestFocus(FocusNode());
        List<String> scanList = List();
        scanList.add(serialNoTextController.text);
        verifySticker(scanList);
        serialNoTextController.text = '';
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
        'false',
        'true',
        'false',
        '#004a96',
        PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
        LocaleUtils.getString(mContext, 'next'),
        PROJECT_NAME == 'BASF_HK'
            ? LocaleUtils.getString(mContext, 'scan_your_label_here')
            : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

//  void redirectInwardConfirmScreen() {
//    if (widget.isChange) {
//      Navigator.pop(context, true);
//    } else {
//      final Route route =
//      CupertinoPageRoute(builder: (context) => InwardConfirmScreen());
//      Navigator.pushReplacement(mContext, route);
//    }
//  }

  void apiCall(int type, String jsonData) async {
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      _loading = true;
      dismissProgressHUD();

      Future.delayed(const Duration(milliseconds: 500), () async {
        var param = Map();
        String loginID = await sharedPrefs.getString(PREF_INIT_GI_CODE);
        String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
        String apiToken = await sharedPrefs.getString(PREF_API_TOKEN);

        param[PARAM_SUB_MODULE_NAME] =
        Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;
        param[PARAM_API_TOKEN] = apiToken;
        param[PARAM_PERSON_ID] = loginID;
        param[PARAM_DEVICE_ID] = deviceID;
        param[PARAM_VERSION] = APP_VERSION;
        param['PalletNo'] =
        palletSummary != null ? palletSummary.varPalletNo : '';
        param['JsonData'] = jsonData;
        param['PalletGlCode'] = palletSummary != null
            ? palletSummary.fk_PalletGlCode.toString()
            : '';

        if (type == 1) {
          param[PARAM_ACTION] = "PalletAdjustmentDetail";
        } else if (type == 2) {
          param[PARAM_ACTION] = "Verify";
        }

        print(param);
        apiCallType = type;
        wsPresenter.callAPI(POST_METHOD, 'Pallet_Adjustment', param);
      });
    } else {
      _showSnackBar(LocaleUtils.getString(mContext, 'no_internet_connection'));
    }
  }

  void removeSticker(int index) {
    PalletAdjustmentModel palletAdjustmentModel1 =
    _palletAdjustmentScanList[index];
    print('=======IFIFIFIFIFIF===3====${palletAdjustmentModel1.chrStatus}');
    if (palletAdjustmentModel1.intGlCode > 0) {
      print('=========index=====$index');
      palletAdjustmentModel1.chrStatus = 'D';
      palletAdjustmentModel1.chrProcess = 'N';
      _palletAdjustmentScanList.removeAt(index);
      _palletAdjustmentScanList.insert(index, palletAdjustmentModel1);
    } else {
      _palletAdjustmentScanList.removeAt(index);
    }
    isVerifySaveBtnTitle();

    if (mounted) {
      setState(() {});
    }

    flush = Flushbar<bool>(
      message:
      "${palletAdjustmentModel1.varSticker} ${LocaleUtils.getString(
          mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
          if (palletAdjustmentModel1.intGlCode > 0) {
            palletAdjustmentModel1.chrStatus = 'E';
            palletAdjustmentModel1.chrProcess = 'Y';
            _palletAdjustmentScanList.removeAt(index);
            _palletAdjustmentScanList.insert(index, palletAdjustmentModel1);
          } else {
            _palletAdjustmentScanList.insert(index, palletAdjustmentModel1);
          }

          flush.dismiss();
          isVerifySaveBtnTitle();

          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    flush.show(context);
  }

  void removeMultiSelectedSticker() async {
    List<MultiDeleteModel> deletedIndex = List();
    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel2 =
        _palletAdjustmentScanList[i];
        if (palletAdjustmentModel2.isDelete) {
          palletAdjustmentModel2.isDelete = false;
          if (palletAdjustmentModel2.chrStatus != 'D') {
            if (palletAdjustmentModel2.intGlCode > 0) {
              palletAdjustmentModel2.chrStatus = 'D';
              palletAdjustmentModel2.chrProcess = 'N';
              deletedIndex
                  .add(MultiDeleteModel(i, true, palletAdjustmentModel2));
            } else {
              print('=======ELSEEEEEEEEEe=========$i');
              deletedIndex
                  .add(MultiDeleteModel(i, false, palletAdjustmentModel2));
              //_palletAdjustmentScanList.removeAt(i);
            }
          }
        }
      }
    }

    if (deletedIndex.isNotEmpty) {
      for (int i = 0; i < deletedIndex.length; i++) {
        if (!deletedIndex[i].isRemoveIndex) {
          _palletAdjustmentScanList.removeAt(deletedIndex[i].index);
        }
      }
    }
    isVerifySaveBtnTitle();
    if (mounted) {
      setState(() {});
    }

    flush = Flushbar<bool>(
      message:
      "${deletedIndex.length} ${LocaleUtils.getString(mContext, 'deleted')}",
      duration: Duration(seconds: 4),
      mainButton: FlatButton(
        onPressed: () {
//          _search_controller.clear();
          if (deletedIndex.isNotEmpty) {
            for (int i = 0; i < deletedIndex.length; i++) {
              int indexTemp = deletedIndex[i].index;
              print('==isRemoveIndex===${deletedIndex[i].isRemoveIndex}');
              if (deletedIndex[i].isRemoveIndex) {
                PalletAdjustmentModel palletAdjustmentModel3 =
                    deletedIndex[i].palletAdjustmentModel;
                palletAdjustmentModel3.chrStatus = 'E';
                palletAdjustmentModel3.chrProcess = 'Y';
                _palletAdjustmentScanList.removeAt(indexTemp);
                _palletAdjustmentScanList.insert(
                    indexTemp, palletAdjustmentModel3);
              } else {
                print('=======ELSEEEEEEEEE=========');
                _palletAdjustmentScanList.insert(
                    indexTemp, deletedIndex[i].palletAdjustmentModel);
              }
            }
          }
          flush.dismiss();
          isVerifySaveBtnTitle();
          if (mounted) {
            setState(() {});
          }
        },
        child: Text(
          "Undo",
          style: TextStyle(color: Colors.amber),
        ),
      ),
    );
    await flush.show(context);
  }

  Color getColorCode(int index) {
    return mUtils.fromHex(_palletAdjustmentScanList[index].varColor);
  }

  Widget legendSubText(Color colorCode, String legendName) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 20),
      child: Row(
        children: <Widget>[
          Container(
            width: 50,
            height: 20,
            decoration: BoxDecoration(
                color: colorCode,
                borderRadius: BorderRadius.all(Radius.circular(10))),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: Text(legendName,
                style: TextStyle(
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500,
                    fontFamily: 'helvetica',
                    color: Colors.black)),
          )
        ],
      ),
    );
  }

  bool isStickerSelected() {
    bool isSelected = false;

    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        if (_palletAdjustmentScanList[i].isDelete) {
          isSelected = true;
        }
      }
    }

    return isSelected;
  }

  bool isCheckAllStickerSelected() {
    bool isSelected = true;

    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        if (!_palletAdjustmentScanList[i].isDelete) {
          isSelected = false;
        }
      }
    }

    return isSelected;
  }

  void selectAll() {
    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        if (_palletAdjustmentScanList[i].chrStatus != 'D') {
          _palletAdjustmentScanList[i].isDelete = true;
        }
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void isVerifySaveBtnTitle() {
    if (_palletAdjustmentScanList.isNotEmpty) {
      isVerifyBtn = false;
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel =
        _palletAdjustmentScanList[i];
        if (palletAdjustmentModel.chrStatus == 'D' ||
            palletAdjustmentModel.chrStatus == 'I') {
          isVerifyBtn = true;
        }
      }
      if (mounted) {
        setState(() {});
      }
    }
  }

  bool isVerifySaveBtnValue() {
    bool flag = false;
    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        PalletAdjustmentModel palletAdjustmentModel = _palletAdjustmentScanList[i];
        if (palletAdjustmentModel.chrStatus == 'E' ||
            palletAdjustmentModel.chrStatus == 'I') {
          flag = true;
        }
      }
    }
    return flag;
  }

  void unSelectAll() {
    if (_palletAdjustmentScanList.isNotEmpty) {
      for (int i = 0; i < _palletAdjustmentScanList.length; i++) {
        _palletAdjustmentScanList[i].isDelete = false;
      }
    }

    if (mounted) {
      setState(() {});
    }
  }

  void setSelection(int index) {
    if (_palletAdjustmentScanList[index].isDelete) {
      _palletAdjustmentScanList[index].isDelete = false;
    } else {
      _palletAdjustmentScanList[index].isDelete = true;
    }
    if (isCheckAllStickerSelected()) {
      isSelectAll = true;
    } else {
      isSelectAll = false;
    }
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    print('======Build=======');

    final tooltip = SuperTooltip(
        popupDirection: TooltipDirection.left,
        arrowTipDistance: 0.0,
        arrowBaseWidth: 0.0,
        arrowLength: 0.0,
        borderColor: Color(colorPrimary),
        borderWidth: 4.0,
        snapsFarAwayVertically: true,
        showCloseButton: ShowCloseButton.none,
        hasShadow: false,
        touchThroughAreaShape: ClipAreaShape.rectangle,
        content: Material(
            child: Container(
              width: screenSize.width,
              child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      physics: AlwaysScrollableScrollPhysics(),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                              '${LocaleUtils.getString(
                                  mContext, 'legend_of_current_status')}',
                              style: TextStyle(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'helvetica',
                                  color: Colors.black)),
                          legendSubText(
                              Color(colorLabelPresentInOtherPallet),
                              LocaleUtils.getString(
                                  mContext, 'label_other_pallet')),
                          legendSubText(
                              Color(colorLabelExistingPallet),
                              LocaleUtils.getString(
                                  mContext, 'label_existing_pallet')),
                          legendSubText(Color(colorInValid),
                              LocaleUtils.getString(
                                  mContext, 'invalid_pallet')),
                        ],
                      ))),
            )));

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'EnterSrNumber'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    final cameraIcon = InkWell(
      child: Padding(
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Icon(Icons.camera_alt, color: Colors.white)),
      onTap: () {
        startScanBtnCall();
      },
    );

    final saveButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: isVerifyBtn
            ? LocaleUtils.getString(mContext, 'verify')
            : LocaleUtils.getString(mContext, 'Save'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (isVerifySaveBtnValue()) {
            if (isVerifyBtn) {
              var json = jsonEncode(
                  _palletAdjustmentScanList.map((e) => e.toJson()).toList());
              String jsonFull = '{"Pallet_Details":$json}';
              print(jsonFull);
              apiCall(2, jsonFull);
            } else {
              Navigator.pop(context, true);
            }
          } else {
            _showSnackBar(LocaleUtils.getString(
                mContext, 'YouHaveNotScannedAnyLabelYet'));
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          if (tooltip.isOpen) {
            tooltip.close();
          } else {
            Navigator.pop(context, false);
          }
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              if (tooltip.isOpen) {
                tooltip.close();
              } else {
                Navigator.pop(context, false);
              }
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, widget.displayName, topHeaderImage, 0),
//                    CustomTopHeaderBarForInward(stage: SUB_HEADER_INWARD_SCAN),
                        Container(
                          margin:
                          const EdgeInsets.only(top: 10, right: 15, left: 15),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Form(
                                  key: _formKey,
                                  autovalidate: _autoValidate,
                                  child: Container(
                                    height: 42,
                                    width: screenSize.width,
                                    padding:
                                    const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: serialNumberTxt,
                                  ),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                child: addButton,
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                height: 45,
                                decoration: BoxDecoration(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(5)),
                                  color: const Color(colorPrimary),
                                ),
                                child: cameraIcon,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 40,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(width: 1, color: Colors.black),
                              borderRadius:
                              const BorderRadius.all(Radius.circular(3))),
                          margin:
                          const EdgeInsets.only(top: 10, left: 15, right: 15),
                          //padding: const EdgeInsets.all(5),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: TextField(
                                    controller: _search_controller,
                                    //enableInteractiveSelection: false,
                                    keyboardType: TextInputType.text,
                                    textInputAction: TextInputAction.done,
                                    autofocus: false,
                                    style: textStyle,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      hintStyle: TextStyle(
                                          color: Colors.grey[700]),
                                      hintText: LocaleUtils.getString(
                                          mContext, 'search_serial_no'),
                                      counterText: '',
                                    ),
                                    textAlign: TextAlign.left,
                                    onChanged: (value) {
                                      filterSearchResults(
                                          value.trim().toLowerCase());
                                    },
                                    maxLines: 1,
                                    maxLength: EditTxtMaxLengths,
                                  ),
                                ),
                                flex: 1,
                              ),
                              IconButton(
                                  onPressed: () {
                                    // _search_controller.clear();
                                  },
                                  icon: const Icon(
                                    Icons.search,
                                    size: 20,
                                    color: Color(colorPrimary),
                                  ))
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: const Color(bgColor),
                            child: Card(
                              elevation: 7,
                              margin: const EdgeInsets.only(
                                  top: 10, right: 15, left: 15),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Container(
                                    height: 40,
                                    padding:
                                    const EdgeInsets.only(left: 10, right: 5),
                                    alignment: Alignment.centerLeft,
                                    decoration: const BoxDecoration(
                                        color: Color(colorPrimary)),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment
                                          .center,
                                      mainAxisAlignment: MainAxisAlignment
                                          .start,
                                      children: <Widget>[
                                        Expanded(
                                          flex: 4,
                                          child: Text(
                                            LocaleUtils.getString(
                                                mContext, 'ScannedSrNo'),
                                            style: TextStyle(
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.w300,
                                              fontFamily: 'helvetica',
                                              color: Colors.white,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: InkWell(
                                            onTap: () {
                                              tooltip.show(context);
                                            },
                                            child: const Align(
                                              alignment: Alignment.center,
                                              child: Padding(
                                                padding: EdgeInsets.only(
                                                    right: 10),
                                                child: Icon(
                                                  Icons.info,
                                                  size: 25.0,
                                                  color: Colors.orange,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  isStickerSelected()
                                      ? Container(
                                      color: const Color(colorAccent),
                                      height: 40,
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 0),
                                        child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: <Widget>[
                                            Expanded(
                                              child: InkWell(
                                                child: Center(
                                                  child: Container(
                                                    width: 27,
                                                    height: 27,
                                                    decoration: BoxDecoration(
                                                        color: isSelectAll
                                                            ? const Color(
                                                            colorPrimary)
                                                            : const Color(
                                                            colorAccent),
                                                        shape: BoxShape.circle,
                                                        border: Border.all(
                                                            color: const Color(
                                                                colorPrimary),
                                                            width: 1)),
                                                    child: isSelectAll
                                                        ? Icon(
                                                      Icons.done,
                                                      size: 15.0,
                                                      color: Colors.white,
                                                    )
                                                        : Container(),
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll();
                                                  }
                                                },
                                              ),
                                              flex: 1,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                child: Text(
                                                  LocaleUtils.getString(
                                                      mContext, 'select_all'),
                                                  style: TextStyle(
                                                    fontSize: 15.0,
                                                    fontWeight: FontWeight.w600,
                                                    fontFamily: 'helvetica',
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                  textAlign: TextAlign.left,
                                                ),
                                                onTap: () {
                                                  if (!isSelectAll) {
                                                    isSelectAll = true;
                                                    selectAll();
                                                  } else {
                                                    isSelectAll = false;
                                                    unSelectAll();
                                                  }
                                                },
                                              ),
                                              flex: 2,
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                onTap: () {
                                                  removeMultiSelectedSticker();
                                                },
                                                child: isStickerSelected()
                                                    ? Align(
                                                  alignment:
                                                  Alignment.center,
                                                  child: Icon(
                                                    Icons.delete,
                                                    size: 25.0,
                                                    color: const Color(
                                                        colorPrimary),
                                                  ),
                                                )
                                                    : Container(),
                                              ),
                                              flex: 1,
                                            ),
                                          ],
                                        ),
                                      ))
                                      : Container(),
                                  Expanded(
                                    child: Container(
                                      child: ListView.builder(
                                        itemCount: _palletAdjustmentScanList
                                            .length,
                                        shrinkWrap: true,
                                        scrollDirection: Axis.vertical,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return _palletAdjustmentScanList[index]
                                              .chrStatus ==
                                              'D'
                                              ? Container()
                                              : Material(
                                            child: InkWell(
                                              onTap: () {
                                                if (isStickerSelected()) {
                                                  setSelection(index);
                                                }
                                              },
                                              onLongPress: () {
                                                setSelection(index);
                                              },
                                              child: Container(
                                                  color: Colors.white,
                                                  child: Column(
                                                    children: <Widget>[
                                                      Container(
                                                        height: 40,
                                                        color: _palletAdjustmentScanList[index]
                                                            .isDelete ? Colors
                                                            .grey[200] : Colors
                                                            .white,
                                                        width:
                                                        screenSize.width,
                                                        child: Row(
                                                          crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                          mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .spaceAround,
                                                          mainAxisSize:
                                                          MainAxisSize
                                                              .max,
                                                          children: <Widget>[
                                                            Expanded(
                                                              child: Center(
                                                                  child: _palletAdjustmentScanList[index]
                                                                      .isDelete
                                                                      ? Container(
                                                                    width:
                                                                    27,
                                                                    height:
                                                                    27,
                                                                    decoration:
                                                                    BoxDecoration(
                                                                      color: const Color(
                                                                          colorPrimary),
                                                                      shape: BoxShape
                                                                          .circle,
                                                                      //borderRadius: BorderRadius.all(Radius.circular(10))
                                                                    ),
                                                                    child:
                                                                    Icon(
                                                                      Icons
                                                                          .done,
                                                                      size: 15.0,
                                                                      color: Colors
                                                                          .white,
                                                                    ),
                                                                  )
                                                                      : Text(
                                                                      '#${(index +
                                                                          1)}',
                                                                      style:
                                                                      TextStyle(
                                                                        fontSize: 14.0,
                                                                        fontWeight: FontWeight
                                                                            .w500,
                                                                        fontFamily: 'helvetica',
                                                                        color: getColorCode(
                                                                            index),
                                                                      ))),
                                                              flex: 1,
                                                            ),
                                                            Expanded(
                                                              child:
                                                              Container(
                                                                child: Align(
                                                                  child: Text(
                                                                      '${_palletAdjustmentScanList[index]
                                                                          .varSticker}',
                                                                      style: TextStyle(
                                                                          fontSize:
                                                                          14.0,
                                                                          fontWeight: FontWeight
                                                                              .w500,
                                                                          fontFamily:
                                                                          'helvetica',
                                                                          color:
                                                                          getColorCode(
                                                                              index))),
                                                                  alignment:
                                                                  Alignment
                                                                      .centerLeft,
                                                                ),
                                                              ),
                                                              flex: 2,
                                                            ),
                                                            Expanded(
                                                              child: !isStickerSelected()
                                                                  ? Align(
                                                                child:
                                                                GestureDetector(
                                                                  child: Icon(
                                                                      Icons
                                                                          .delete,
                                                                      color: getColorCode(
                                                                          index)),
                                                                  onTap:
                                                                      () {
//                                                            isFocusNodeEnable = false;
                                                                    if (!isStickerSelected()) {
                                                                      removeSticker(
                                                                          index);
                                                                    }
                                                                  },
                                                                ),
                                                                alignment:
                                                                Alignment
                                                                    .center,
                                                              )
                                                                  : Container(),
                                                              flex: 1,
                                                            )
                                                          ],
                                                        ),
                                                      ),
                                                      const Divider(
                                                          height: 3,
                                                          color: Colors.black),
                                                    ],
                                                  )),
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                                    flex: 1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          flex: 1,
                        ),
                        Container(
                          width: screenSize.width,
                          height: 45,
                          child: saveButton,
                          margin: const EdgeInsets.all(15),
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  void filterSearchResults(String query) {
    final List<PalletAdjustmentModel> dummySearchList =
    List<PalletAdjustmentModel>();
    dummySearchList.addAll(_palletAdjustmentScanListSearch);

    if (query.isNotEmpty) {
      query = query.toLowerCase();
      final List<PalletAdjustmentModel> dummyListData =
      List<PalletAdjustmentModel>();
      dummySearchList.forEach((item) {
        if (item.varSticker.toLowerCase().contains(query)) {
          dummyListData.add(item);
        }
      });
      if (mounted) {
        setState(() {
          _palletAdjustmentScanList.clear();
          _palletAdjustmentScanList.addAll(dummyListData);
        });
      }
    } else {
      if (mounted) {
        setState(() {
          _palletAdjustmentScanList.clear();
          _palletAdjustmentScanList.addAll(_palletAdjustmentScanListSearch);
        });
      }
    }
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
    GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (responseModel.Status.contains('1')) {
        if (apiCallType == 1) {
          _palletAdjustmentScanList.clear();
          _palletAdjustmentScanListSearch.clear();
          _palletAdjustmentScanList
              .addAll(responseModel.getPalletAdjustmentList());
          _palletAdjustmentScanListSearch
              .addAll(responseModel.getPalletAdjustmentList());
          palletSummary = responseModel.getPalletSummary();
          if (mounted) {
            setState(() {});
          }
        } else if (apiCallType == 2) {
          Navigator.pop(context, true);
        }
      } else if (responseModel.Status.contains('2')) {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'Session_warning'),
              title:
              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {
                final Route route =
                CupertinoPageRoute(builder: (context) => Dashboard());
                Navigator.pushAndRemoveUntil(
                    context, route, (Route<dynamic> route) => false);
              },
            );
          },
        );
      } else {
//        showDialog<Map>(
//          barrierDismissible: false,
//          context: mContext,
//          builder: (context) {
//            return CustomAlertDialog(
//              content: responseModel.Message,
//              title:
//              PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
//              isShowNagativeButton: false,
//              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//              onPressedPositive: () {},
//            );
//          },
//        );
        _showSnackBar(responseModel.Message);
      }
    }
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  void _showSnackBar(String text) {
    Flushbar(
      message: text,
      duration: Duration(seconds: 2),
    )..show(mContext);
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
