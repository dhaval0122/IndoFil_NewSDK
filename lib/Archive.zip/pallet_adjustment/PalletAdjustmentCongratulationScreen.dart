import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonDialogWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';

class PalletAdjustmentCongratulationScreen extends StatefulWidget {
  final String displayName;

  PalletAdjustmentCongratulationScreen({this.displayName});

  @override
  PalletAdjustmentCongratulationScreenState createState() =>
      PalletAdjustmentCongratulationScreenState();
}

class PalletAdjustmentCongratulationScreenState
    extends State<PalletAdjustmentCongratulationScreen>
    implements PushNotificationListener {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  Size screenSize;
  BuildContext mContext;
  String userName = '';
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  bool isNotification = false, isSync = false;
  EcpSyncPlugin _battery;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;

  @override
  void initState() {
    super.initState();
    _battery = EcpSyncPlugin();
    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    pushNotificationServices = PushNotificationServices(this);

    sharedPrefs.getString(PREF_FULL_NAME).then((String fullname) {
      if (userName.isEmpty) {
        if (mounted) {
          setState(() {
            userName = fullname != null ? fullname : '';
//            subTitle = LocaleUtils.getString(mContext, 'tag_sales_inward');
          });
        }
      }
    });

    sharedPrefs.getBool(IS_NOTIFICATION).then((bool isNoti) {
      if (isNoti) {
        if (mounted) {
          setState(() {
            isNotification = true;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isNotification = false;
          });
        }
      }
    });

    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }
  }

//  void dismissProgressHUD() {
//    if (mounted) {
//      setState(() {
//        if (_loading) {
//          _progressHUD.state.show();
//          //_isLoginButtonDisable = true;
//        } else {
//          _progressHUD.state.dismiss();
//          //_isLoginButtonDisable = false;
//        }
//        _loading = !_loading;
//      });
//    }
//  }

  void doneBtnCall() {
//    sharedPrefs.getString(PREF_SCREEN_STATE).then((String screenState) {
//      if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
//        _clickSync(false);
//      } else {
    //if(screenState == TAG_RECEIVE){
    final Route route = CupertinoPageRoute(builder: (mContext) => Dashboard());
    Navigator.pushAndRemoveUntil(
        context, route, (Route<dynamic> route) => false);
    //} else {
    // Navigator.pop(context);
    //}
//      }
//    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final doneBtn = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonDialogWidgets(
        buttonName: LocaleUtils.getString(mContext, 'Done'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          doneBtnCall();
        },
      ),
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          doneBtnCall();
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              doneBtnCall();
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  color: const Color(bgColor),
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(userName, widget.displayName,
                          'assets/pallet_adjustment.png', -1),
//                      CustomTopHeaderBarForInward(
//                          stage: SUB_HEADER_INWARD_CONGRATULATION),
//                  CustomTopSubHeaderBar(
//                      SUB_HEADER_CONGRATULATION, isReceiveScreen),
                      Expanded(
                        child: Container(
                          margin: const EdgeInsets.only(
                              top: 10, left: 15, right: 15, bottom: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Image.asset(
                                'assets/congratulations_icon.png',
                                height: 80,
                                width: 80,
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Text(
                                    LocaleUtils.getString(
                                        mContext, 'Congratulation'),
                                    style: TextStyle(
                                        fontSize: 25.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'helvetica',
                                        color: const Color(0xFF669900))),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(top: 20),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: <Widget>[
                                    Text(
                                        LocaleUtils.getString(
                                            mContext, 'URDoingGood'),
                                        style: TextStyle(
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'helvetica',
                                            color: const Color(0xFF669900))),
                                    Image.asset(
                                      'assets/congratulations_smiley_icon.png',
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        flex: 1,
                      ),
                      Container(
                        width: screenSize.width,
                        height: 45,
                        //margin: EdgeInsets.all(15),
                        child: doneBtn,
                      ),
                    ],
                  ),
                ),
//                _progressHUD,
              ],
            ),
          ),
        ));
  }

  /*_getRadiusDropDown() {
    return BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }*/

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}
