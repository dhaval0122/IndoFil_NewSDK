import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flushbar/flushbar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Dashboard.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/GeneralResponseModel.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentConfirmScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';
import 'package:screen/screen.dart';

class PalletAdjustmentModel {
  int intGlCode;
  int fk_CustomerGlCode;
  int fk_PalletGlCode;
  int fk_StickerGlCode;
  String varSticker;
  String chrStatus;
  String varRefNo;
  String varColor;
  String chrValid;
  String chrValidSave;
  String chrProcess;
  String varRemarks;
  bool isDelete = false;

  PalletAdjustmentModel(
      {this.intGlCode,
      this.fk_CustomerGlCode,
      this.fk_PalletGlCode,
      this.fk_StickerGlCode,
      this.varSticker,
      this.chrStatus,
      this.varRefNo,
      this.varColor,
      this.chrValid,
      this.chrValidSave,
      this.chrProcess,
      this.varRemarks});

  PalletAdjustmentModel.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        fk_CustomerGlCode = json['fk_CustomerGlCode'],
        fk_PalletGlCode = json['fk_PalletGlCode'],
        fk_StickerGlCode = json['fk_StickerGlCode'],
        varSticker = json['varSticker'],
        chrStatus = json['chrStatus'],
        varRefNo = json['varRefNo'],
        varColor = json['varColor'],
        chrValid = json['chrValid'],
        chrValidSave = json['chrValidSave'],
        chrProcess = json['chrProcess'],
        varRemarks = json['varRemarks'];

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['intGlCode'] = this.intGlCode;
    data['fk_CustomerGlCode'] = this.fk_CustomerGlCode;
    data['fk_PalletGlCode'] = this.fk_PalletGlCode;
    data['fk_StickerGlCode'] = this.fk_StickerGlCode;
    data['varSticker'] = this.varSticker;
    data['chrStatus'] = this.chrStatus;
    data['varRefNo'] = this.varRefNo;
    data['varColor'] = this.varColor;
    data['chrValid'] = this.chrValid;
    data['chrValidSave'] = this.chrValidSave;
    data['chrProcess'] = this.chrProcess;
    data['varRemarks'] = this.varRemarks;
    return data;
  }
}

class PalletSummary {
  int intTotalStickers;
  int fk_PalletGlCode;
  String varPalletNo;

  PalletSummary({
    this.intTotalStickers,
    this.fk_PalletGlCode,
    this.varPalletNo,
  });

  PalletSummary.fromJson(Map<String, dynamic> json)
      : intTotalStickers = json['intTotalStickers'],
        fk_PalletGlCode = json['fk_PalletGlCode'],
        varPalletNo = json['varPalletNo'];
}

class PalletAdjustmentScreen extends StatefulWidget {
  final String displayName;

  PalletAdjustmentScreen({this.displayName});

  @override
  _PalletAdjustmentScreenState createState() => _PalletAdjustmentScreenState();
}

class _PalletAdjustmentScreenState extends State<PalletAdjustmentScreen>
    implements PushNotificationListener, WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false;
  Size screenSize;
  String userName = '',
      topHeaderImage = 'assets/pallet_adjustment.png',
      lastLoginDate = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  TextEditingController serialNoTextController;
  EcpSyncPlugin _battery;
  StreamSubscription<Map> _batteryStateSubscription;
  bool isReceiveScreen = false;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  bool isLaserScanLoad = false;
  String menufacturer = '';
  DatabaseHelper databaseHelper;
  int apiCallType = 0;
  WSPresenter wsPresenter;
  List<PalletAdjustmentModel> palletAdjustmentList;
  bool isSelectAll = false;
  Flushbar flush;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void checkScreenLock() async {
    bool isKeptOn = await Screen.isKeptOn;
    if (!isKeptOn) {
      await Screen.keepOn(true);
    }
  }

  @override
  void initState() {
    super.initState();
    _initLoading();

    checkScreenLock();

    _battery = EcpSyncPlugin();
    wsPresenter = WSPresenter(this);
    mUtils = Utils();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();
    sharedPrefs = SharedPrefs();
    pushNotificationServices = PushNotificationServices(this);

    palletAdjustmentList = new List();

    serialNoTextController = TextEditingController();

    init();
  }

  void init() async {
    lastLoginDate = await sharedPrefs.getString(PREF_LAST_SYNC_DATE);

    menufacturer = await mUtils.getMenufacturer();
    if (Platform.isAndroid && menufacturer.contains(CHIPhER_LAB)) {
      serialNoTextController.addListener(_onTextChanged);
    }

    String fullName = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullName != null ? fullName : '';
    }

    isNotification = await sharedPrefs.getBool(IS_NOTIFICATION);

    notificationCount = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);

    _batteryStateSubscription =
        _battery.onBatteryStateChanged.listen((Map state) async {
          try {
            print('=======state=======${state.toString()}');
            if (state['type'] == '11') {
              var detailsData = state['Details'];
              final dynamic lists = json.decode(detailsData);
              verifySticker(lists);
            }
          } catch (e) {
            print(e.toString());
          }
        });

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    await checkTransaction();

    await insertLogDetails();

    await _battery.hideKeyboardPlugin();

    apiCall(2, '');

    if (mounted) {
      setState(() {});
    }
  }

  void checkTransaction() async {
    String moduleName = await databaseHelper.checkHalfTransactionInAllModule();
    String moduleName1 = await databaseHelper.checkSyncAllTransaction();
    if (moduleName.isNotEmpty && moduleName1.isNotEmpty) {
      await syncDialog(moduleName);
    }
  }

  void syncDialog(String moduleName) async {
    final StringBuffer strMsg = StringBuffer();
    strMsg.write(LocaleUtils.getString(mContext, 'you_have_active_internet'));
    strMsg.write('\n');
    strMsg.write('${LocaleUtils.getString(
        mContext, 'application_must_be_sync')} ($lastLoginDate)');
    strMsg.write('\n');
    strMsg.write(
        '${LocaleUtils.getString(
            mContext, 'no_pending_partial_transaction')} ($moduleName)');
    strMsg.write('\n');

    await showDialog<Map>(
      barrierDismissible: false,
      context: mContext,
      builder: (context) {
        return WillPopScope(
          // ignore: missing_return
            onWillPop: () {},
            child: CustomAlertDialog(
              content: strMsg.toString(),
              title: LocaleUtils.getString(mContext, 'before_you_proceed'),
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'Close'),
              textPositiveButton: LocaleUtils.getString(mContext, 'sync_now'),
              onPressedNegative: () {
                Navigator.pop(context, true);
              },
              onPressedPositive: () {
                databaseHelper.close();
                final Route route = CupertinoPageRoute(
                    builder: (context) =>
                        SyncScreen(isDbSync: true, isDashboard: false));
                Navigator.pushReplacement(mContext, route);
              },
            ));
      },
    );
  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
        await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
        await databaseHelper.getSelectedMenuDetails('DEV_PADJ');
    String syncCode = await _battery.getUniqueNumber();
    String loginSyncCode =
        await databaseHelper.getSyncCodeFromLoginDetails(int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void verifySticker(dynamic lists) async {
    if (lists.length > 0) {
      for (var j in lists) {
        if (j.toString().trim().isNotEmpty) {
          List<String> code = j.toString().split("/");
          print('====F CODE=====${code.toString()}');
          if (code.length > 1) {
            if (code[1].toString() == '31') {
              //insertStickerInList(code[0].toString().toUpperCase(), 'P');
              apiCall(1, code[0].toString().toUpperCase());
            } else if (code[1].toString() == '21') {
              isLaserScanLoad = false;
              _showSnackBar(
                  LocaleUtils.getString(mContext, 'sticker_scan_not_allow'));
            }
          } else {
            apiCall(1, code[0].toString().toUpperCase());
          }
        }
      }
    }
  }

  void _showSnackBar(String text) {
    Flushbar(
      message: text,
      duration: Duration(seconds: 4),
    )..show(mContext);
  }

  void _onTextChanged() async {
    final String value = serialNoTextController.text ?? '';
    if (value.isNotEmpty) {
      if (value.trim().length >= int.parse(globals.BARCODE_LENGTH)) {
        print('=====value=======$value');
        if (!isLaserScanLoad) {
          final List<String> scanList = List();
          isLaserScanLoad = true;
          await _battery.checkBarCode(value).then((String serialNo) async {
            if (!scanList.contains(serialNo)) {
              scanList.add(serialNo);
            }
            verifySticker(scanList);
            serialNoTextController.text = '';
          });
        } else {
          serialNoTextController.text = '';
        }
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
    if (_batteryStateSubscription != null) {
      _batteryStateSubscription.cancel();
    }
    _battery = null;
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _validateInputs() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      if (serialNoTextController.text.trim().isEmpty) {
        _showSnackBar(LocaleUtils.getString(mContext, 'PlzEnterSrNumber'));
      } else {
        FocusScope.of(mContext).requestFocus(FocusNode());
        List<String> scanList = List();
        scanList.add(serialNoTextController.text);
        verifySticker(scanList);
        serialNoTextController.text = '';
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void startScanBtnCall() {
    _battery
        .scanBarCodes(
            'false',
            'true',
            'false',
            '#004a96',
            PROJECT_NAME == 'BASF_HK' ? 'false' : 'true',
            LocaleUtils.getString(mContext, 'next'),
            PROJECT_NAME == 'BASF_HK'
                ? LocaleUtils.getString(mContext, 'scan_your_label_here')
                : LocaleUtils.getString(mContext, 'scan_your_label'))
        .then((String result) {});
  }

  void apiCall(int type, String palletNo) async {
    print('====apiCall==palletNo====$palletNo');
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      _loading = true;
      dismissProgressHUD();

      Future.delayed(const Duration(milliseconds: 500), () async {
        var param = Map();
        String loginID = await sharedPrefs.getString(PREF_INIT_GI_CODE);
        String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
        String apiToken = await sharedPrefs.getString(PREF_API_TOKEN);

        param[PARAM_SUB_MODULE_NAME] =
            Platform.isAndroid ? SUB_MODULE_NAME_ANDROID : SUB_MODULE_NAME_IOS;
        param[PARAM_API_TOKEN] = apiToken;
        param[PARAM_PERSON_ID] = loginID;
        param[PARAM_DEVICE_ID] = deviceID;
        param[PARAM_VERSION] = APP_VERSION;
        param['PalletNo'] = palletNo;
        param['JsonData'] = '';
        param['PalletGlCode'] = '';

        if (type == 1) {
          param[PARAM_ACTION] = "CheckPallet";
        } else if (type == 2) {
          param[PARAM_ACTION] = "CheckPendingPalletAdjustment";
        }

        print(param);
        apiCallType = type;
        wsPresenter.callAPI(POST_METHOD, 'Pallet_Adjustment', param);
      });
    } else {
      await showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return CustomAlertDialog(
            content: LocaleUtils.getString(mContext, 'no_internet_connection'),
            title:
                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
            isShowNagativeButton: false,
            textNagativeButton: '',
            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
            onPressedNegative: () {},
            onPressedPositive: () {},
          );
        },
      );
    }
  }

  void navigatePalletAdjustmentScreen(
      bool isHalfTran,
      String displayName,
      List<PalletAdjustmentModel> palletAdjustList,
      PalletSummary palletSummary) async {
    final Route route = CupertinoPageRoute(
        builder: (context) => PalletAdjustmentConfirmScreen(
              displayName: displayName,
              scanData: palletAdjustList,
              palletSummary: palletSummary,
            ));
//    if (isHalfTran) {
    await Navigator.pushReplacement(mContext, route);
//    } else {
//      await Navigator.pushReplacement(mContext, route);
//    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final serialNumberTxt = TextFormField(
      controller: serialNoTextController,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.done,
      textCapitalization: TextCapitalization.words,
      autovalidate: false,
      autofocus: true,
      style: textStyle,
      maxLines: 1,
      decoration: InputDecoration(
        hintText: LocaleUtils.getString(mContext, 'enter_pallet_serial_no'),
        border: InputBorder.none,
        errorStyle: errorStyle,
        hintStyle: hintStyle,
      ),
    );

    final addButton = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: '+',
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: _validateInputs,
      ),
    );

    final cameraIcon = InkWell(
      child: Padding(
          padding: const EdgeInsets.only(top: 5, bottom: 5),
          child: Icon(Icons.camera_alt, color: Colors.white)),
      onTap: () {
        startScanBtnCall();
      },
    );

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          resizeToAvoidBottomPadding: false,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                    color: Colors.white,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: <Widget>[
                        CustomTopHeaderBar(
                            userName, widget.displayName, topHeaderImage, 0),
                        Container(
                          color: Colors.white,
                          margin: const EdgeInsets.only(
                              top: 20, right: 20, left: 20),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Form(
                                  key: _formKey,
                                  autovalidate: _autoValidate,
                                  child: Container(
                                    height: 42,
                                    width: screenSize.width,
                                    padding:
                                        const EdgeInsets.fromLTRB(15, 0, 15, 0),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: const Color(0xFF000000)),
                                        borderRadius: _getRadiusDropDown()),
                                    child: serialNumberTxt,
                                  ),
                                ),
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                child: addButton,
                              ),
                              Container(
                                margin: const EdgeInsets.only(left: 10),
                                width: 50,
                                height: 45,
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(5)),
                                  color: const Color(colorPrimary),
                                ),
                                child: cameraIcon,
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: Container(
                            color: Colors.white,
                            padding: const EdgeInsets.all(30),
                            child: Column(
                              mainAxisSize: MainAxisSize.max,
                              children: <Widget>[
                                Expanded(
                                  child: Stack(
                                    alignment: Alignment.center,
                                    children: <Widget>[
                                      Image.asset(
                                        'assets/pallet_adjustment_watermark.png',
                                      ),
                                    ],
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                          ),
                          flex: 1,
                        ),
                      ],
                    )),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  @override
  void onLoginError(String errorTxt) {
    _loading = false;
    dismissProgressHUD();
    print('Error : ' + errorTxt);
  }

  @override
  void onLoginSuccess(String response) {
    print('Response : ' + response);
    _loading = false;
    dismissProgressHUD();

    final dynamic jsonResponse = json.decode(response.toString().trim());

    final GeneralResponseModel responseModel =
        GeneralResponseModel.fromJsonStatus(jsonResponse);

    print(responseModel.Status);
    print(responseModel.Message);

    if (responseModel.Status != null) {
      if (apiCallType == 1) {
        if (responseModel.Status.contains('1')) {
          palletAdjustmentList.clear();
          palletAdjustmentList.addAll(responseModel.getPalletAdjustmentList());
          navigatePalletAdjustmentScreen(false, widget.displayName,
              palletAdjustmentList, responseModel.getPalletSummary());
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  final Route route =
                      CupertinoPageRoute(builder: (context) => Dashboard());
                  Navigator.pushAndRemoveUntil(
                      context, route, (Route<dynamic> route) => false);
                },
              );
            },
          );
        } else {
//          showDialog<Map>(
//            barrierDismissible: false,
//            context: mContext,
//            builder: (context) {
//              return CustomAlertDialog(
//                content: responseModel.Message,
//                title: PROJECT_NAME == 'BASF_HK'
//                    ? BASF_HK_APP_Name
//                    : Zydus_APP_Name,
//                isShowNagativeButton: false,
//                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//                onPressedPositive: () {},
//              );
//            },
//          );
          _showSnackBar(responseModel.Message);
        }
      } else if (apiCallType == 2) {
        if (responseModel.Status.contains('1')) {
          navigatePalletAdjustmentScreen(true, widget.displayName,
              palletAdjustmentList, responseModel.getPalletSummary());
        } else if (responseModel.Status.contains('2')) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'Session_warning'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  final Route route =
                      CupertinoPageRoute(builder: (context) => Dashboard());
                  Navigator.pushAndRemoveUntil(
                      context, route, (Route<dynamic> route) => false);
                },
              );
            },
          );
        }
      }
    } else {
//      showDialog<Map>(
//        barrierDismissible: false,
//        context: mContext,
//        builder: (context) {
//          return CustomAlertDialog(
//            content: responseModel.Message,
//            title:
//                PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
//            isShowNagativeButton: false,
//            textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
//            onPressedPositive: () {},
//          );
//        },
//      );
      _showSnackBar(responseModel.Message);
    }
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }
}

class AlwaysDisabledFocusNode extends FocusNode {
  @override
  bool get hasFocus => false;
}
