import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/BaseClassChina.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/PushNotificationServices.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;
import 'package:flutter_basf_hk_app/components/ButtonWidgets.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/CustomTopHeaderBar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/components/SearchableSpinner.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchFirstScreen.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:progress_hud/progress_hud.dart';

//this is svn check

class FOCScreen extends StatefulWidget {
  @override
  FOCScreenState createState() => FOCScreenState();
}

class FOCScreenState extends State<FOCScreen>
    implements PushNotificationListener, ItemClickSearchableSpinner {
  final GlobalKey<ScaffoldState> _key = GlobalKey();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _autoValidate = false,
      _loading = false,
      isNotification = false,
      isSync = false,
      _otherShipToShowHideState = false;

  //String dropdownValue;
  CountryMasterModel selectedCountryModel;
  CustomerTypeModel selectedCustomerTypeModel;
  Size screenSize;
  String userName = '', subTitle = '', topHeaderImage = '';
  ProgressHUD _progressHUD;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  List<CountryMasterModel> countryList;
  List<CustomerTypeModel> customerTypeList;
  TextEditingController controllerShipToName,
      controllerSAPRefNo,
      controllerAuthorisedBy,
      controllerRemarks;
  EcpSyncPlugin _battery;
  FocusNode _focusShipToName, _focusSAPRefNo, _focusAuthorisedBy, _focusRemarks;
  int notificationCount = 0;
  PushNotificationServices pushNotificationServices;
  String shipToNameValue, sapRefNoValue, authorisedByValue, remarksValue;

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.pushReplacement(mContext, route);
  }

  @override
  void initState() {
    super.initState();

    countryList = List();
    customerTypeList = List();
    _battery = EcpSyncPlugin();

    pushNotificationServices = PushNotificationServices(this);

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    databaseHelper.removeLogs();

    controllerShipToName = new TextEditingController();
    controllerSAPRefNo = new TextEditingController();
    controllerAuthorisedBy = new TextEditingController();
    controllerRemarks = new TextEditingController();

    _focusShipToName = new FocusNode();
    _focusSAPRefNo = new FocusNode();
    _focusAuthorisedBy = new FocusNode();
    _focusRemarks = new FocusNode();

    init();

    try {
      if (globals.PUSH_NOTIFICATION_CUST == 'Y') {
        BaseClassChina().initilizeFirebase(pushNotificationServices);
      }
    } catch (e) {
      print(e);
    }

    _initLoading();

  }

  void init() async {
    String fullname = await sharedPrefs.getString(PREF_FULL_NAME);
    if (userName.isEmpty) {
      userName = fullname != null ? fullname : '';
    }

    String screenState = await sharedPrefs.getString(PREF_SCREEN_STATE);
    if (screenState == TAG_DISPATCH) {
      topHeaderImage = 'assets/dispatch_icon.png';
    } else if (screenState.toLowerCase() == TAG_EDIT_DO.toLowerCase()) {
      topHeaderImage = 'assets/edit_do_icon.png';
    } else if (screenState == TAG_FOC) {
      topHeaderImage = 'assets/foc_icon.png';
    }

    if (subTitle.isEmpty) {
      subTitle = getTitleName(screenState);
    }

    bool isNoti = await sharedPrefs.getBool(IS_NOTIFICATION);
    isNotification = isNoti;

    String userType = await sharedPrefs.getString(PREF_USER_TYPE);
    if (userType.contains('E')) {
      isSync = false;
    } else {
      isSync = true;
    }

    int count = await sharedPrefs.getInt(PREF_NOTIFICATION_COUNT);
    notificationCount = count;

    var couList = await databaseHelper.getCountryAllRecords();
    print('=====countryList=====SIZE====${couList.length}');
    countryList.addAll(couList);

    bool isChangeState =
        await sharedPrefs.getBool(PREF_CHANGE_DETAILS_STATE_BOOL);
    if (isChangeState) {
      await getChangeDetailsRecord();
    }

    if (mounted) {
      setState(() {});
    }
  }

  String getTitleName(String tagName) {
    if (tagName == TAG_DISPATCH) {
      return LocaleUtils.getString(mContext, 'tag_dispatch');
    } else if (tagName == TAG_SALES_RETURN) {
      return LocaleUtils.getString(mContext, 'tag_sales_return');
    } else if (tagName == TAG_STOCK_TRANSFER) {
      return LocaleUtils.getString(mContext, 'tag_stock_transfer');
    } else if (tagName == TAG_ADD_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_add_damage_stock');
    } else if (tagName == TAG_REMOVE_DAMAGE_STOCK) {
      return LocaleUtils.getString(mContext, 'tag_remove_damage_stock');
    } else if (tagName == TAG_RECEIVE) {
      return LocaleUtils.getString(mContext, 'tag_receive');
    } else if (tagName == TAG_MY_STOCK_INFO) {
      return LocaleUtils.getString(mContext, 'tag_my_stock_info');
    } else if (tagName == TAG_KNOW_YOUR_BOX) {
      return LocaleUtils.getString(mContext, 'tag_know_your_box');
    } else if (tagName == TAG_STOCK_VISIBILITY) {
      return LocaleUtils.getString(mContext, 'tag_stock_visibility');
    } else if (tagName == TAG_SETTINGS) {
      return LocaleUtils.getString(mContext, 'tag_settings');
    } else if (tagName == TAG_AVAILABLE_TO_PROMISE) {
      return LocaleUtils.getString(mContext, 'tag_available_to_promise');
    } else if (tagName == TAG_FOC) {
      return LocaleUtils.getString(mContext, 'tag_foc');
    } else {
      return '';
    }
  }

  void getChangeDetailsRecord() async {
    int fkDispatchGlCode = await sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE);

    CustomerChangeDetailsModel customerDetailsChangeModel =
        await databaseHelper.getCustomerDetailsForChange(fkDispatchGlCode);

    if (countryList.isNotEmpty && customerDetailsChangeModel != null) {
      await Future.forEach(countryList,
          (CountryMasterModel countryMasterModel) async {
        //final CountryMasterModel countryMasterModel = countryList[i];
        if (countryMasterModel.intGlCode ==
            customerDetailsChangeModel.fk_CountryGLCode) {
          selectedCountryModel = countryMasterModel;
        }
      });
    }
    await setUpCustomerTypeForChangeDetails(customerDetailsChangeModel);
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  void _showSnackBar(String text) {
    _key.currentState.showSnackBar(SnackBar(content: Text(text)));
  }

  void _validateInputs() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();

      int customerGlCode = await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      int fkCustomerTypeCountryGlCode =
          await sharedPrefs.getInt(PREF_FK_CUSTOMER_TYPE_COUNTRY_GI_CODE);
      String initGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
      bool isChangeDetails =
          await sharedPrefs.getBool(PREF_CHANGE_DETAILS_STATE_BOOL);
      print(
          'fk_Customer_TypeGlCode:${selectedCustomerTypeModel.fk_Customer_TypeGlCode}');
      print(
          'fk_Customer_Type_CountryGlCode:${selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode}');

      if (isChangeDetails) {
        int fkDispatchGlCode =
            await sharedPrefs.getInt(PREF_FK_DISPATCH_GL_CODE);
        int id = await databaseHelper.updateChangeDetails(
            fkDispatchGlCode,
            selectedCustomerTypeModel.fk_Customer_TypeGlCode,
            selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode,
            selectedCustomerTypeModel.fk_Customer_TypeGlCode,
            selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode,
            sapRefNoValue != null ? sapRefNoValue : '',
            0,
            remarksValue != null ? remarksValue : '',
            authorisedByValue != null ? authorisedByValue : '',
            shipToNameValue != null ? shipToNameValue : '');
        if (id > 0) {
          await sharedPrefs.setInt(PREF_FK_LAST_DISPATCHED_TO,
              selectedCustomerTypeModel.fk_Customer_TypeGlCode);
          await sharedPrefs.setBool(PREF_CHANGE_DETAILS_STATE_BOOL, false);
          Navigator.pop(context, true);
        }
      } else {
        String syncCode = await _battery.getUniqueNumber();
        int id = await databaseHelper.insertCustomerDispatch(
            customerGlCode,
            fkCustomerTypeCountryGlCode,
            selectedCustomerTypeModel.fk_Customer_TypeGlCode,
            selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode,
            selectedCustomerTypeModel.fk_Customer_TypeGlCode,
            selectedCustomerTypeModel.fk_Customer_Type_CountryGlCode,
            sapRefNoValue != null ? sapRefNoValue : '',
            syncCode,
            int.parse(initGlCode),
            'F',
            0,
            remarksValue != null ? remarksValue : '',
            authorisedByValue != null ? authorisedByValue : '',
            shipToNameValue != null ? shipToNameValue : '');
        if (id > 0) {
          await sharedPrefs.setInt(PREF_FK_DISPATCH_GL_CODE, id);
          await sharedPrefs.setInt(PREF_FK_LAST_DISPATCHED_TO,
              selectedCustomerTypeModel.fk_Customer_TypeGlCode);
          redirectScanScreen();
        }
      }
    } else {
      if (mounted) {
        setState(() {
          _autoValidate = true;
        });
      }
    }
  }

  void setUpCustomerTypeForChangeDetails(
      CustomerChangeDetailsModel customerDetailsChangeModel) async {
    customerTypeList.clear();
    selectedCustomerTypeModel = null;
    if (selectedCountryModel != null) {
      final int fkCountryGlCode = selectedCountryModel.intGlCode;
      String initCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
      var customerLevel =
          await databaseHelper.getCustomerLevelForDispatch(int.parse(initCode));
      int customerGlCode = await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      var custTypeList = await databaseHelper.getSoldToPartyRecord(
          fkCountryGlCode, customerGlCode, 'SOLDTO', customerLevel);

      if (custTypeList.isNotEmpty) {
        customerTypeList.addAll(custTypeList);
        await Future.forEach(customerTypeList,
            (CustomerTypeModel customerTypeModel) async {
          if (customerTypeModel.fk_Customer_TypeGlCode ==
              customerDetailsChangeModel.fk_Sold_To_Party_GlCode) {
            selectedCustomerTypeModel = customerTypeModel;
          }
        });
      }

      controllerSAPRefNo.text = customerDetailsChangeModel.varDONo;
      controllerAuthorisedBy.text = customerDetailsChangeModel.varAuthorizedBy;
      controllerRemarks.text = customerDetailsChangeModel.varRemarks;

      if (selectedCustomerTypeModel.varCustomer_Type_Name.contains('Other')) {
        _otherShipToShowHideState = true;
      } else {
        _otherShipToShowHideState = false;
      }
      controllerShipToName.text = customerDetailsChangeModel.varCustomer_Name;

      if (mounted) {
        setState(() {});
      }
    }
  }

  void setUpCustomerType(bool isLoad) async {
    customerTypeList.clear();
    if (isLoad) {
      selectedCustomerTypeModel = null;
    }
    if (selectedCountryModel != null) {
      final int fkCountryGlCode = selectedCountryModel.intGlCode;
      String initCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
      var customerLevel =
          await databaseHelper.getCustomerLevelForDispatch(int.parse(initCode));
      int customerGlCode = await sharedPrefs.getInt(PREF_MAIN_CUSTOMER_GI_CODE);
      var custTypeList = await databaseHelper.getSoldToPartyRecord(
          fkCountryGlCode, customerGlCode, 'SOLDTO', customerLevel);
      print('------custTypeList--------${custTypeList.length}');
      if (custTypeList.isNotEmpty) {
        customerTypeList.addAll(custTypeList);
        await setDefaultSelectedOtherCustomer();
      }
    }
  }

  void setDefaultSelectedOtherCustomer() async {
//    for (int i = 0; i < customerTypeList.length; i++) {
//      if (customerTypeList[i].varCustomer_Type_Name.contains('Other')) {
//        selectedCustomerTypeModel = customerTypeList[i];
//      }
//    }
    await Future.forEach(customerTypeList,
        (CustomerTypeModel customerTypeModel) async {
      if (customerTypeModel.varCustomer_Type_Name.contains('Other')) {
        selectedCustomerTypeModel = customerTypeModel;
      }
    });

    if (selectedCustomerTypeModel.varCustomer_Type_Name.contains('Other')) {
      _otherShipToShowHideState = true;
    } else {
      _otherShipToShowHideState = false;
      controllerShipToName.text = '';
    }

    if (mounted) {
      setState(() {});
    }
  }

  void _clickSync(bool isLongPress) async {
    String isConnection = await _battery.checkInternet();
    if (isConnection.contains('true')) {
      if (isLongPress) {
        await showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'no'),
              textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
              onPressedNegative: () {},
              onPressedPositive: () {
                showDialog<Map>(
                  barrierDismissible: false,
                  context: mContext,
                  builder: (context) {
                    return CustomAlertDialog(
                      content:
                          LocaleUtils.getString(mContext, 'SyncConformMsg'),
                      title: PROJECT_NAME == 'BASF_HK'
                          ? BASF_HK_APP_Name
                          : Zydus_APP_Name,
                      isShowNagativeButton: true,
                      textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                      textPositiveButton:
                          LocaleUtils.getString(mContext, 'yes'),
                      onPressedNegative: () {},
                      onPressedPositive: () {
                        databaseHelper.close();
                        final Route route = CupertinoPageRoute(
                            builder: (context) =>
                                SyncScreen(isDbSync: true, isDashboard: false));
                        Navigator.pushReplacement(mContext, route);
                      },
                    );
                  },
                );
              },
            );
          },
        );
      } else {
        await showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
              title:
                  PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: true,
              textNagativeButton: LocaleUtils.getString(mContext, 'no'),
              textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
              onPressedNegative: () {},
              onPressedPositive: () {
                databaseHelper.close();
                final Route route = CupertinoPageRoute(
                    builder: (context) =>
                        SyncScreen(isDbSync: false, isDashboard: false));
                Navigator.pushReplacement(mContext, route);
              },
            );
          },
        );
      }
    } else {
      await showDialog<Map>(
        barrierDismissible: false,
        context: mContext,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {},
              child: CustomAlertDialog(
                content:
                    LocaleUtils.getString(mContext, 'no_internet_connection'),
                title: PROJECT_NAME == 'BASF_HK'
                    ? BASF_HK_APP_Name
                    : Zydus_APP_Name,
                isShowNagativeButton: false,
                textNagativeButton: '',
                textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                onPressedNegative: () {},
                onPressedPositive: () {},
              ));
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    final txtShipToName = TextFormField(
      controller: controllerShipToName,
      keyboardType: TextInputType.text,
      autofocus: false,
      autocorrect: false,
      textInputAction: TextInputAction.next,
      focusNode: _focusShipToName,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_focusSAPRefNo);
      },
      onSaved: (String val) {
        shipToNameValue = val;
      },
      style: textStyle,
      maxLines: 1,
      maxLength: RemarksMaxLengths,
      decoration: InputDecoration(
          hintText:
              '${LocaleUtils.getString(mContext, 'enter_other_ship_to_name')}',
          border: InputBorder.none,
          errorStyle: errorStyle,
          hintStyle: hintStyle,
          counterText: ''),
    );

    final txtSAPRefNo = TextFormField(
      controller: controllerSAPRefNo,
      keyboardType: TextInputType.text,
      autofocus: false,
      autocorrect: false,
      textInputAction: TextInputAction.next,
      focusNode: _focusSAPRefNo,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_focusAuthorisedBy);
      },
      onSaved: (String val) {
        sapRefNoValue = val;
      },
      style: textStyle,
      maxLines: 1,
      maxLength: EditTxtMaxLengths,
      decoration: InputDecoration(
          hintText: '${LocaleUtils.getString(mContext, 'sap_ref_no')}',
          border: InputBorder.none,
          errorStyle: errorStyle,
          hintStyle: hintStyle,
          counterText: ''),
    );

    final txtAuthorisedBy = TextFormField(
      controller: controllerAuthorisedBy,
      keyboardType: TextInputType.text,
      autofocus: false,
      autocorrect: false,
      textInputAction: TextInputAction.next,
      focusNode: _focusAuthorisedBy,
      onFieldSubmitted: (value) {
        FocusScope.of(context).requestFocus(_focusRemarks);
      },
      onSaved: (String val) {
        authorisedByValue = val;
      },
      style: textStyle,
      maxLines: 1,
      maxLength: EditTxtMaxLengths,
      decoration: InputDecoration(
          hintText: '${LocaleUtils.getString(mContext, 'authorised_by')}',
          border: InputBorder.none,
          errorStyle: errorStyle,
          hintStyle: hintStyle,
          counterText: ''),
    );

    final txtRemarks = TextFormField(
      controller: controllerRemarks,
      keyboardType: TextInputType.multiline,
      autofocus: false,
      autocorrect: false,
      textInputAction: TextInputAction.done,
      focusNode: _focusRemarks,
      onFieldSubmitted: (value) {
        _focusRemarks.unfocus();
      },
      onSaved: (String val) {
        remarksValue = val;
      },
      style: textStyle,
      maxLines: 3,
      maxLength: RemarksMaxLengths,
      decoration: InputDecoration(
          hintText: '${LocaleUtils.getString(mContext, 'remarks')}',
          border: InputBorder.none,
          errorStyle: errorStyle,
          hintStyle: hintStyle,
          counterText: ''),
    );

    final btnProceed = Padding(
      padding: const EdgeInsets.only(left: 0),
      child: ButtonWidgets(
        buttonName: LocaleUtils.getString(mContext, 'proceed'),
        buttonColor: const Color(colorPrimary),
        textColor: Colors.white,
        onTap: () {
          if (selectedCountryModel != null) {
            if (selectedCustomerTypeModel != null) {
              if ((_otherShipToShowHideState &&
                      controllerShipToName.text.isNotEmpty) ||
                  !_otherShipToShowHideState) {
                if (controllerSAPRefNo.text.isNotEmpty) {
                  if (controllerAuthorisedBy.text.isNotEmpty) {
                    _validateInputs();
                  } else {
                    _showSnackBar(
                        '${LocaleUtils.getString(mContext, 'please_enter_authorised_by')}');
                  }
                } else {
                  _showSnackBar(
                      '${LocaleUtils.getString(mContext, 'please_enter_SAP_Ref_No')}');
                }
              } else {
                _showSnackBar(
                    '${LocaleUtils.getString(mContext, 'please_enter_other_ship_to_name')}');
              }
            } else {
              _showSnackBar(
                  LocaleUtils.getString(mContext, 'plz_sel_ship2party_cust'));
            }
          } else {
            _showSnackBar(LocaleUtils.getString(mContext, 'plz_sel_country'));
          }
        },
      ),
    );

    return WillPopScope(
      // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
          appBar: CustomAppbar(
            isShowNotification: isNotification,
            isShowSync: isSync,
            isShowHomeIcon: true,
            mContext: context,
            notificationCount: notificationCount,
            databaseHelper: databaseHelper,
            syncPlugin: _battery,
            onBackPress: () {
              Navigator.pop(context, true);
            },
          ).appBar(),
          key: _key,
          body: SafeArea(
            child: Stack(
              children: <Widget>[
                Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      CustomTopHeaderBar(userName, subTitle, topHeaderImage, 0),
//                      CustomTopSubHeaderBar(SUB_HEADER_DISPATCH_FIRST, false),
                      Expanded(
                        child: Form(
                          child: Container(
                            color: const Color(bgColor),
                            child: Column(
                              children: <Widget>[
                                Expanded(
                                  child: Card(
                                    elevation: 7,
                                    margin: const EdgeInsets.all(15),
                                    child: Container(
                                      padding: const EdgeInsets.all(15),
                                      child: ListView(
                                        shrinkWrap: true,
                                        children: <Widget>[
                                          InkWell(
                                            child: Container(
                                                height: 42,
                                                width: screenSize.width,
                                                alignment: Alignment.centerLeft,
                                                margin: const EdgeInsets.only(
                                                    top: 12),
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        15, 0, 15, 0),
                                                decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: const Color(
                                                            0xFF000000)),
                                                    borderRadius:
                                                        _getRadiusDropDown()),
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                    Text(
                                                      selectedCountryModel !=
                                                              null
                                                          ? selectedCountryModel
                                                              .name
                                                          : LocaleUtils
                                                              .getString(
                                                                  mContext,
                                                                  'sel_country'),
                                                      style:
                                                          selectedCountryModel !=
                                                                  null
                                                              ? textStyle
                                                              : hintStyle,
                                                    ),
                                                    Icon(Icons.arrow_drop_down)
                                                  ],
                                                )),
                                            onTap: () {
                                              List<SpinnerModel> countrytemp =
                                                  countryList
                                                      .map((countryMasterModel) =>
                                                          SpinnerModel(
                                                              countryMasterModel
                                                                  .intGlCode,
                                                              countryMasterModel
                                                                  .name,
                                                              1))
                                                      .toList();
                                              showDialog<Map>(
                                                barrierDismissible: true,
                                                context: context,
                                                builder: (context) {
                                                  return SearchableSpinner(
                                                    screenSize: screenSize,
                                                    listSticker: countrytemp,
                                                    itemClickSearchableSpinner:
                                                        this,
                                                  );
                                                },
                                              );
                                            },
                                          ),
                                          InkWell(
                                            child: Container(
                                                height: 42,
                                                width: screenSize.width,
                                                margin: const EdgeInsets.only(
                                                    top: 20),
                                                alignment: Alignment.centerLeft,
                                                padding:
                                                    const EdgeInsets.fromLTRB(
                                                        15, 0, 15, 0),
                                                decoration: BoxDecoration(
                                                    border: Border.all(
                                                        color: const Color(
                                                            0xFF000000)),
                                                    borderRadius:
                                                        _getRadiusDropDown()),
                                                child: Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: <Widget>[
                                                    Expanded(
                                                      flex: 1,
                                                      child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 0),
                                                        child: Text(
                                                          selectedCustomerTypeModel !=
                                                                  null
                                                              ? selectedCustomerTypeModel
                                                                  .varCustomer_Type_Name
                                                              : LocaleUtils
                                                                  .getString(
                                                                      mContext,
                                                                      'ship2party'),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 1,
                                                          style:
                                                              selectedCustomerTypeModel !=
                                                                      null
                                                                  ? textStyle
                                                                  : hintStyle,
                                                        ),
                                                      ),
                                                    ),
                                                    Icon(Icons.arrow_drop_down)
                                                  ],
                                                )),
                                            onTap: () {
                                              List<SpinnerModel> customertemp =
                                                  customerTypeList
                                                      .map((customerTypeModel) =>
                                                          SpinnerModel(
                                                              customerTypeModel
                                                                  .fk_Customer_TypeGlCode,
                                                              customerTypeModel
                                                                  .varCustomer_Type_Name,
                                                              2))
                                                      .toList();
                                              print(
                                                  '===customertemp===${customertemp.length}');
//                                              customertemp.add(SpinnerModel(
//                                                  000, 'Other', 2));
                                              showDialog<Map>(
                                                barrierDismissible: true,
                                                context: context,
                                                builder: (context) {
                                                  return SearchableSpinner(
                                                    screenSize: screenSize,
                                                    listSticker: customertemp,
                                                    itemClickSearchableSpinner:
                                                        this,
                                                  );
                                                },
                                              );
                                            },
                                          ),
                                          Visibility(
                                            visible: _otherShipToShowHideState,
                                            child: Container(
                                              height: 42,
                                              width: screenSize.width,
                                              margin: const EdgeInsets.only(
                                                  top: 20),
                                              padding:
                                                  const EdgeInsets.fromLTRB(
                                                      15, 0, 15, 0),
                                              decoration: BoxDecoration(
                                                  border: Border.all(
                                                      color: const Color(
                                                          0xFF000000)),
                                                  borderRadius:
                                                      _getRadiusDropDown()),
                                              child: txtShipToName,
                                            ),
                                          ),
                                          Container(
                                            height: 42,
                                            width: screenSize.width,
                                            margin:
                                                const EdgeInsets.only(top: 20),
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 0, 15, 0),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xFF000000)),
                                                borderRadius:
                                                    _getRadiusDropDown()),
                                            child: txtSAPRefNo,
                                          ),
                                          Container(
                                            height: 42,
                                            width: screenSize.width,
                                            margin:
                                                const EdgeInsets.only(top: 20),
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 0, 15, 0),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xFF000000)),
                                                borderRadius:
                                                    _getRadiusDropDown()),
                                            child: txtAuthorisedBy,
                                          ),
                                          Container(
                                            height: 90,
                                            width: screenSize.width,
                                            margin:
                                                const EdgeInsets.only(top: 20),
                                            padding: const EdgeInsets.fromLTRB(
                                                15, 0, 15, 0),
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    color: const Color(
                                                        0xFF000000)),
                                                borderRadius:
                                                    _getRadiusDropDown()),
                                            child: txtRemarks,
                                          ),
                                          Container(
                                            width: screenSize.width,
                                            height: 45,
                                            child: btnProceed,
                                            margin:
                                                const EdgeInsets.only(top: 30),
                                            //margin: EdgeInsets.all(15),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  flex: 1,
                                ),
                              ],
                            ),
                          ),
                          autovalidate: _autoValidate,
                          key: _formKey,
                        ),
                        flex: 1,
                      ),
                    ],
                  ),
                ),
                _progressHUD,
              ],
            ),
          ),
        ));
  }

  BorderRadius _getRadiusDropDown() {
    return const BorderRadius.only(
        topLeft: Radius.circular(4.0),
        topRight: Radius.circular(4.0),
        bottomLeft: Radius.circular(4.0),
        bottomRight: Radius.circular(4.0));
  }

  @override
  void onLoadNotificationCount(String response) {
    sharedPrefs.getInt(PREF_NOTIFICATION_COUNT).then((int count) {
      if (mounted) {
        setState(() {
          notificationCount = count;
        });
      }
    });
  }

  @override
  void onItemClickSearchableSpinner(SpinnerModel model) {
    print('===name====${model.name}');
    print('===initcode====${model.initcode}');
    if (model.spinnerID == 1) {
      setSelectedCountryValues(model.initcode);
    } else if (model.spinnerID == 2) {
      setSelectedCustomerValues(model.initcode);
    }
  }

  void setSelectedCountryValues(int initId) {
    for (int i = 0; i < countryList.length; i++) {
      if (countryList[i].intGlCode == initId) {
        if (mounted) {
          setState(() {
            selectedCountryModel = countryList[i];
            setUpCustomerType(true);
          });
        }
      }
    }
  }

  void setSelectedCustomerValues(int initId) {
    for (int i = 0; i < customerTypeList.length; i++) {
      if (customerTypeList[i].fk_Customer_TypeGlCode == initId) {
        selectedCustomerTypeModel = customerTypeList[i];
      }
    }

    if (selectedCustomerTypeModel.varCustomer_Type_Name.contains('Other')) {
      _otherShipToShowHideState = true;
    } else {
      _otherShipToShowHideState = false;
      controllerShipToName.text = '';
    }

    if (mounted) {
      setState(() {});
    }
  }
}
