import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/designCourseAppTheme.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/consume/ConsumeStockScreen.dart';
import 'package:flutter_basf_hk_app/consume/ConsumeStockThirdScreen.dart';
import 'package:flutter_basf_hk_app/damage/DamageStockDetailsScreen.dart';
import 'package:flutter_basf_hk_app/damage/DamageStockScreen.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/dispatch/DispatchThirdScreen.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/scrap/ScrapStockDetailsScreen.dart';
import 'package:flutter_basf_hk_app/scrap/ScrapStockScreen.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';

Image getIcon(String code) {
  if (code == 'DEV_UTL_CSM') {
    return Image.asset(
      'assets/consume_big.png',
      height: 50,
      width: 50,
    );
  } else if (code == 'DEV_UTL_SCP') {
    return Image.asset(
      'assets/scrap_big.png',
      height: 50,
      width: 50,
    );
  } else if (code == 'DEV_UTL_DMG') {
    return Image.asset(
      'assets/damage_big.png',
      fit: BoxFit.contain,
      height: 50,
      width: 50,
    );
  } else {
    return Image.asset(
      'assets/consume_big.png',
      height: 50,
      width: 50,
    );
  }
}

class HexColor extends Color {
  static int _getColorFromHex(String hexColor) {
    hexColor = hexColor.toUpperCase().replaceAll("#", "");
    if (hexColor.length == 6) {
      hexColor = "FF" + hexColor;
    }
    return int.parse(hexColor, radix: 16);
  }

  HexColor(final String hexColor) : super(_getColorFromHex(hexColor));
}

class UtilityScreen extends StatefulWidget {
//  final Function callBack;
  final String displayName;

  UtilityScreen({this.displayName});

//  const UtilityScreen({Key key, this.callBack}) : super(key: key);

  @override
  _UtilityScreenState createState() => _UtilityScreenState();
}

class _UtilityScreenState extends State<UtilityScreen>
    with TickerProviderStateMixin {
  AnimationController animationController;

  final GlobalKey<ScaffoldState> _key = GlobalKey();
  bool isNotification = false, isSync = false;
  int notificationCount = 0;
  SharedPrefs sharedPrefs;
  EcpSyncPlugin _ecpSyncPlugin;
  DatabaseHelper databaseHelper;
  List<MenuMasterModel> menuMasterList;
  String userName;

  @override
  void initState() {
    animationController = AnimationController(
        duration: Duration(milliseconds: 800), vsync: this);
    super.initState();

    sharedPrefs = SharedPrefs();
    _ecpSyncPlugin = EcpSyncPlugin();
    databaseHelper = DatabaseHelper.get();
    menuMasterList = List();
    _init();

    insertLogDetails();

  }

  void insertLogDetails() async {
    String deviceID = await sharedPrefs.getString(PREF_DEVICE_ID);
    int fk_SubModuleGlCode =
    await sharedPrefs.getInt(PREF_FK_SUB_MODULE_GL_CODE);
    String intGlCode = await sharedPrefs.getString(PREF_INIT_GI_CODE);
    MenuMasterModel menuMaster =
    await databaseHelper.getSelectedMenuDetails('DEV_UTL');
    String syncCode = await _ecpSyncPlugin.getUniqueNumber();
    String loginSyncCode = await databaseHelper.getSyncCodeFromLoginDetails(
        int.parse(intGlCode));
    int fkLogFormGlCode = await sharedPrefs.getInt(PREF_FK_LOG_FROM_GL_CODE);
    if (fkLogFormGlCode > 0) {
      await databaseHelper.updateLogFormDetails(fkLogFormGlCode);
    }
    int id = await databaseHelper.insertLogDetails(
        deviceID,
        APP_VERSION,
        int.parse(intGlCode),
        syncCode,
        loginSyncCode,
        fk_SubModuleGlCode,
        menuMaster?.intGlCode,
        menuMaster?.varDisplayName);
    await sharedPrefs.setInt(PREF_FK_LOG_FROM_GL_CODE, id);
  }

  void _init() async {
    bool isNoti = await sharedPrefs.getBool(IS_NOTIFICATION);
    if (mounted) {
      setState(() {
        isNotification = isNoti;
      });
    }

    String userType = await sharedPrefs.getString(PREF_USER_TYPE);
    if (userType.contains('E')) {
      isSync = false;
    } else {
      isSync = true;
    }

    userName = await sharedPrefs.getString(PREF_FULL_NAME);

    List<MenuMasterModel> menuList =
    await databaseHelper.getMenuMasterForUtility();
    print('====menuMasterList====${menuMasterList.length}');
    if (mounted) {
      setState(() {
        menuMasterList.addAll(menuList);
      });
    }
  }

  Future<bool> getData() async {
    await Future.delayed(const Duration(milliseconds: 100));
    return true;
  }

  void navigateDamageStockScreen() async {
    final Route route =
        CupertinoPageRoute(builder: (context) => DamageStockScreen());
    final result = await Navigator.push(context, route);
    try {
      if (result != null) {
        if (result) {
          //showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateScrapStockScreen() async {

    await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_SCRAP_STOCK);

    String dispatchModel = await databaseHelper
        .checkDispatchHalfTransactionForScrap();

    await insertLogDetails();

    if (dispatchModel != null) {
      await sharedPrefs.setString(
          PREF_SCRAP_TRANS_CODE, dispatchModel);
      final Route route =
      CupertinoPageRoute(builder: (context) => ScrapStockDetailsScreen());
      await Navigator.push(context, route);
    } else {
      String uniqueNumber=await _ecpSyncPlugin.getUniqueNumber();
      await sharedPrefs.setString(PREF_SCRAP_TRANS_CODE,uniqueNumber);

      final Route route =
      CupertinoPageRoute(builder: (context) => ScrapStockScreen());
      await Navigator.push(context, route);
    }
  }

  void navigateConsumeStockScreen() async {

    String uniqueNumber=await _ecpSyncPlugin.getUniqueNumber();
    print("uniqueNumber=="+uniqueNumber);
    await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_CONSUME_STOCK);
    await sharedPrefs.setString(PREF_CONSUME_TRANS_CODE,uniqueNumber );

    final Route route =
    CupertinoPageRoute(builder: (context) => ConsumeStockScreen());
    final result = await Navigator.push(context, route);
    try {
      if (result != null) {
        if (result) {
          //showInAppSyncDialogCall();
        }
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateDispatchThirdScreen() async {
    final Route route = CupertinoPageRoute(
        builder: (context) => DispatchThirdScreen(
            isRedirectToEditScreen: false, subTitleTxt: ''));
    await Navigator.push(context, route);
  }

  void navigateDamageStockDetailsScreen() async {
    final Route route =
        CupertinoPageRoute(builder: (context) => DamageStockDetailsScreen());
    final result = await Navigator.push(context, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void navigateConsumeStockThirdScreen() async {
    final Route route =
        CupertinoPageRoute(builder: (context) => ConsumeStockThirdScreen());
    final result = await Navigator.push(context, route);
    try {
      if (result != null) {
        if (result) {}
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void moveTo() async {
    String isAdd = await databaseHelper.checkHalfTransactionForAddDamage();
    await insertLogDetails();
    if (isAdd != null) {
      await sharedPrefs.setString(PREF_DAMAGE_TRANS_CODE, isAdd);
      await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_ADD_DAMAGE_STOCK);
      navigateDamageStockDetailsScreen();
    } else {
      String isRemove =
          await databaseHelper.checkHalfTransactionForRemoveDamage();
      if (isRemove != null) {
        await sharedPrefs.setString(PREF_DAMAGE_TRANS_CODE, isRemove);
        await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_REMOVE_DAMAGE_STOCK);
        navigateDamageStockDetailsScreen();
      } else {
        navigateDamageStockScreen();
      }
    }
  }

  void moveToConsumeScreen() async{
   String isAdd = await databaseHelper.checkHalfTransactionForAddConsume();
   await insertLogDetails();
    if (isAdd != null) {
      await sharedPrefs.setString(PREF_CONSUME_TRANS_CODE, isAdd);
      await sharedPrefs.setString(PREF_SCREEN_STATE, TAG_CONSUME_STOCK);
      navigateConsumeStockThirdScreen();
    } else {
      navigateConsumeStockScreen();
    }
  }

  redirectToNextScreen(MenuMasterModel menuMasterModel) {
    if (menuMasterModel.varTransactionCode == 'DEV_UTL_CSM') {
      moveToConsumeScreen();
    } else if (menuMasterModel.varTransactionCode == 'DEV_UTL_SCP') {
      navigateScrapStockScreen();
    } else if (menuMasterModel.varTransactionCode == 'DEV_UTL_DMG') {
      moveTo();
    }
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    final double itemHeight = (size.height - kToolbarHeight - 24) / 4;
    final double itemWidth = size.width / 2;

    return WillPopScope(
        // ignore: missing_return
        onWillPop: () {
          Navigator.pop(context, true);
        },
        child: MyCustomScaffold(
            key: _key,
            appBar: CustomAppbar(
              isShowNotification: isNotification,
              isShowSync: isSync,
              isShowHomeIcon: true,
              mContext: context,
              notificationCount: notificationCount,
              databaseHelper: databaseHelper,
              syncPlugin: _ecpSyncPlugin,
              onBackPress: () {
                Navigator.pop(context, true);
              },
            ).appBar(),
            resizeToAvoidBottomPadding: false,
            body: Container(
              height: size.height,
              width: size.width,
              color: DesignCourseAppTheme.utility_bg,
              margin: EdgeInsets.only(top: 5),
              child: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: FutureBuilder(
                  future: getData(),
                  builder: (context, snapshot) {
                    if (!snapshot.hasData) {
                      return SizedBox();
                    } else {
                      return Column(mainAxisSize: MainAxisSize.max, children: <
                          Widget>[
                        Container(
                          padding: EdgeInsets.only(top: 7, bottom: 7),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Expanded(
                                flex: 1,
                                child: Padding(
                                  padding: EdgeInsets.only(left: 20),
                                  child: Text(userName != null ? userName : "",
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                      style: TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w500,
                                          fontFamily: 'helvetica',
                                          color: Colors.black)),
                                ),
                              ),
                              Container(
                                  child: Padding(
                                      padding: EdgeInsets.only(right: 15),
                                      child: Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.end,
                                          crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                          children: [
                                            Image.asset(
                                              'assets/utility_small.png',
                                              height: 20,
                                              width: 20,
                                              color: const Color(colorPrimary),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(left: 5),
                                              child: Text(
                                                  widget.displayName != null
                                                      ? widget.displayName
                                                      : "",
                                                  style: TextStyle(
                                                      fontSize: 14.0,
                                                      fontWeight:
                                                      FontWeight.w500,
                                                      fontFamily: 'helvetica',
                                                      color: Colors.black)),
                                            ),
                                          ]))),
                            ],
                          ),
                        ),
                        GridView(
                          padding: EdgeInsets.all(8),
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          children: List.generate(
                            menuMasterList.length,
                                (index) {
                              var count = menuMasterList.length;
                              var animation =
                              Tween(begin: 0.0, end: 1.0).animate(
                                CurvedAnimation(
                                  parent: animationController,
                                  curve: Interval((1 / count) * index, 1.0,
                                      curve: Curves.fastOutSlowIn),
                                ),
                              );
                              animationController.forward();
                              return InkWell(
                                onTap: () {
                                  redirectToNextScreen(menuMasterList[index]);
                                },
                                child: CategoryView(
                                  category: menuMasterList[index],
                                  animation: animation,
                                  animationController: animationController,
                                ),
                              );
                            },
                          ),
                          gridDelegate:
                          SliverGridDelegateWithFixedCrossAxisCount(
                            mainAxisSpacing: 16.0,
                            crossAxisCount: 2,
                            childAspectRatio: (itemWidth / itemHeight),
                          ),
                        )
                      ]);
                    }
                  },
                ),
              ),
            )));
  }
}

class CategoryView extends StatelessWidget {
  final MenuMasterModel category;
  final AnimationController animationController;
  final Animation animation;

  const CategoryView(
      {Key key, this.category, this.animationController, this.animation})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animationController,
      builder: (BuildContext context, Widget child) {
        return FadeTransition(
          opacity: animation,
          child: Transform(
            transform: Matrix4.translationValues(
                0.0, 50 * (1.0 - animation.value), 0.0),
            child: Card(
              elevation: 5,
              margin: EdgeInsets.only(left: 10, right: 10),
              color: DesignCourseAppTheme.nearlyWhite,
              shape: BeveledRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(5.0)),
              ),
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Expanded(
                      flex: 1,
                      child: ClipRRect(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        child: getIcon(category.varTransactionCode),
                      ),
                    ),
                    Container(
                      height: 40,
                      //color: const Color(colorPrimary),
                      decoration: BoxDecoration(
                          color: const Color(colorPrimary),
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(5.0),
                              bottomRight: Radius.circular(5.0))),
                      child: Align(
                        alignment: Alignment.center,
                        child: Text(
                          category.varDisplayName,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                            letterSpacing: 0.27,
                            color: DesignCourseAppTheme.nearlyWhite,
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

//class CategoryView extends StatelessWidget {
//  final MenuMasterModel category;
//
//  const CategoryView(
//      {Key key, this.category})
//      : super(key: key);
//
//  @override
//  Widget build(BuildContext context) {
//    return Card(
//      elevation: 5,
//      margin: EdgeInsets.only(left: 10, right: 10),
//      color: DesignCourseAppTheme.nearlyWhite,
//      shape: BeveledRectangleBorder(
//        borderRadius: BorderRadius.all(Radius.circular(5.0)),
//      ),
//      child: Container(
//        child: Column(
//          crossAxisAlignment: CrossAxisAlignment.center,
//          mainAxisAlignment: MainAxisAlignment.center,
//          children: <Widget>[
//            Expanded(
//              flex: 1,
//              child: ClipRRect(
//                borderRadius: BorderRadius.all(Radius.circular(10.0)),
//                child: getIcon(category.varTransactionCode),
//              ),
//            ),
//            Container(
//              height: 40,
//              decoration: BoxDecoration(
//                  color: const Color(colorPrimary),
//                  borderRadius: BorderRadius.only(
//                      bottomLeft: Radius.circular(5.0),
//                      bottomRight: Radius.circular(5.0))),
//              child: Align(
//                alignment: Alignment.center,
//                child: Text(
//                  category.varDisplayName,
//                  textAlign: TextAlign.left,
//                  style: TextStyle(
//                    fontWeight: FontWeight.w500,
//                    fontSize: 16,
//                    letterSpacing: 0.27,
//                    color: DesignCourseAppTheme.nearlyWhite,
//                  ),
//                ),
//              ),
//            )
//          ],
//        ),
//      ),
//    );
//  }
//}
