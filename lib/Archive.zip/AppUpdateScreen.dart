import 'dart:async';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:install_plugin/install_plugin.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

class AppUpdateScreen extends StatefulWidget {
  String filePath = '';
  String msg;

  AppUpdateScreen(this.filePath, this.msg);

  AppUpdateState createState() => AppUpdateState(filePath, msg);
}

class AppUpdateState extends State<AppUpdateScreen> {
  static const platform_set = MethodChannel(PROJECT_NAME == 'BASF_HK'
      ? 'com.ecubix.zydustrackntrace/intent'
      : 'com.ecubix.basf/intent');
  BuildContext context;
  double swidth = 0;
  double sheight = 0;
  bool _isLoading = false;
  bool _isDownloading = false;
  ScrollController scrollController = ScrollController();
  List<_TaskInfo> _tasks;
  TargetPlatform platform;
  String _localPath;
  String downloadBtnName = 'Download';
  String filePath = '';
  String message;
  EcpSyncPlugin _battery;

  AppUpdateState(this.filePath, this.message);

  @override
  void initState() {
    super.initState();

    _battery = EcpSyncPlugin();

    _tasks = [];

    if (Platform.isAndroid) {
      FlutterDownloader.registerCallback((id, status, progress) {
        print(
            'Dev Download task ($id) is in status ($status) and process ($progress)');
        if (mounted) {
          setState(() {
            if (status.value == DownloadTaskStatus.complete.value) {
              _isDownloading = false;
              _isLoading = false;
              downloadBtnName = 'Install App';
            }
          });
        }
        final task = _tasks.firstWhere((task) => task.taskId == id);
        if (mounted) {
          setState(() {
            if (task != null) {
              task?.status = status;
              task?.progress = progress;
              print('progress::$progress');
              if (task.status.value == DownloadTaskStatus.complete.value) {
                _isDownloading = false;
                _isLoading = false;
              }
            }
          });
        }
      });

      _isLoading = true;

      checkPermission();
    } else {
      //_permissisonReady = true;
    }
  }

  void checkPermission() async {
    _localPath = (await _findLocalPath()) + '/Download';
    print('_checkPermi');
    print('$_localPath');

    final savedDir = Directory(_localPath);
    final bool hasExisted = await savedDir.exists();
    if (!hasExisted) {
      await savedDir.create();
    }
    if (mounted) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<String> _findLocalPath() async {
    /*final directory = platform == TargetPlatform.android
        ? await getExternalStorageDirectory()
        : await getApplicationDocumentsDirectory();
    return directory.path;*/

    final directory = await getExternalStorageDirectory();
    return directory.path;
  }

  @override
  void dispose() {
    if (Platform.isAndroid) {
      FlutterDownloader.registerCallback(null);
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    platform = Theme.of(context).platform;
    this.context = context;
    final Size screenSize = MediaQuery.of(context).size;

    swidth = screenSize.width;
    sheight = screenSize.height;

    return WillPopScope(
        onWillPop: () async => false,
        child: Scaffold(
          /*appBar:  AppBar(
          title:  Text('Update'),
        ),*/
            body: Container(
              //decoration:  BoxDecoration(image: backgroundImageInner),
              //padding: const EdgeInsets.all(8.0),
                height: screenSize.height,
                width: screenSize.width,
                child: Stack(
                  children: <Widget>[
                    _showBody(),
                    _showCircularProgress(),
                  ],
                ))));
  }

  Widget _showCircularProgress() {
    if (_isLoading) {
      return Center(
          child: const CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Color(colorPrimary))));
    }
    return Container(
      height: 0.0,
      width: 0.0,
    );
  }

  Widget _showBody() {
    return Container(
        decoration: BoxDecoration(color: Colors.white),
        height: sheight,
        width: swidth,
        child: Card(
            margin: const EdgeInsets.all(16),
            child: Container(
                //color: Colors.red,
                height: sheight - 150,
                width: swidth,
                padding: const EdgeInsets.all(8),
                child: Center(
                    child: ListView(
                  children: <Widget>[
                    Container(
                      height: 150,
                    ),
                    Image(
                      image: const AssetImage('assets/download_icon.png'),
                      width: 100,
                      height: 100,
                      color: const Color(colorPrimary),
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.center,
                    ),
                    Container(
                      height: 70,
                    ),
                    Container(
                      child: Text(
                        message,
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'helvetica',
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      margin: const EdgeInsets.all(16),
                    ),
                    Container(
                      height: 70,
                    ),
                    GestureDetector(
                      child: Container(
                        height: 42.0,
                        margin: const EdgeInsets.fromLTRB(30, 0, 30, 0),
                        //padding: EdgeInsets.only(left: 20),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: const Color(colorPrimary),
                          borderRadius: const BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                        ),
                        child: Text(
                          _isDownloading
                              ? '${LocaleUtils.getString(
                              context, 'please_wait')}'
                              : downloadBtnName,
                          style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Poppins',
                            color: Colors.white,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      onTap: () {
                        if (!_isDownloading) {
                          if (Platform.isAndroid) {
                            _battery
                                .checkPermission('Android')
                                .then((String check) {
                              print('===checkPermission=====$check');
                              if (check == 'true') {
                                downloadFile();
                              }
                            });
                          } else {
                            downloadFile();
                          }
                        }
                      },
                    )
                  ],
                )))));
  }

  void downloadFile() async {
    //'http://vcsprojects.co.in/download/SOVG/ECP_SOVG_V_18_2_01.apk'
    print('=======filePath======$filePath');

    if (Platform.isAndroid) {
      final List<String> listTemp = filePath.split('/');
      print(
          '=========listTemp=====${listTemp[listTemp.length - 1].toString()}');

      if (downloadBtnName == 'Download') {
        try {
          var dir = Directory(
              '${_localPath + '/${listTemp[listTemp.length - 1].toString()}'}');
          dir.deleteSync(recursive: true);
        } catch (e) {
          print(e.toString());
        }

        String id = await FlutterDownloader.enqueue(
            url: filePath,
            savedDir: _localPath,
            showNotification: true,
            openFileFromNotification: false);

        if (mounted) {
          setState(() {
            _isLoading = true;
            _isDownloading = true;
          });
        }
      } else {
        print('${_localPath + '/${listTemp[listTemp.length - 1].toString()}'}');
        await InstallPlugin.installApk(
                _localPath + '/${listTemp[listTemp.length - 1].toString()}',
            (PROJECT_NAME == 'BASF_HK'
                ? 'com.ecubix.basf'
                : 'com.ecubix.zydustrackntrace'))
            .then((result) {
          print('install apk $result');
        }).catchError((error) {
          print('install apk error: $error');
        });
      }
    } else {
      //IOS
//      const url = 'http://apps.ecubix.com/ios/ipas/ecpios/';
      final String url = filePath;
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
    }
  }
}

class _TaskInfo {
  _TaskInfo({this.name, this.link});

  final String name;
  final String link;

  String taskId;
  int progress = 0;
  DownloadTaskStatus status = DownloadTaskStatus.undefined;
}
