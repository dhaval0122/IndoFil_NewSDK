import 'dart:convert';
import 'dart:io';

import 'package:ecp_sync_plugin/ecp_sync_plugin.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/Utils/Utils.dart';
import 'package:flutter_basf_hk_app/components/CustomAlertDialog.dart';
import 'package:flutter_basf_hk_app/components/CustomAppbar.dart';
import 'package:flutter_basf_hk_app/components/MyCustomScaffold.dart';
import 'package:flutter_basf_hk_app/database/DatabaseHelper.dart';
import 'package:flutter_basf_hk_app/fragments/ScanningScreen.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';
import 'package:flutter_basf_hk_app/model/LoginResponseModel.dart';
import 'package:flutter_basf_hk_app/styles/colors.dart';
import 'package:flutter_basf_hk_app/styles/strings.dart';
import 'package:flutter_basf_hk_app/styles/style.dart';
import 'package:flutter_basf_hk_app/sync/SyncScreen.dart';
import 'package:flutter_basf_hk_app/webservices/WSConstant.dart';
import 'package:flutter_basf_hk_app/webservices/WSInterface.dart';
import 'package:flutter_basf_hk_app/webservices/WSPresenter.dart';
import 'package:progress_hud/progress_hud.dart';

const String GET_NOTIFICATION = 'GetNotification';
const String MARK_READ = 'MarkRead';

class NotificationScreen extends StatefulWidget {
  @override
  NotificationScreenState createState() => NotificationScreenState();
}

class NotificationScreenState extends State<NotificationScreen>
    implements WSInterface {
  final GlobalKey<ScaffoldState> _key = GlobalKey();

  //final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  Size screenSize;
  BuildContext mContext;
  DatabaseHelper databaseHelper;
  SharedPrefs sharedPrefs;
  Utils mUtils;
  EcpSyncPlugin _battery;
  List<NotificationModel> listDisplay = List();
  bool _loading = false,isNoData = false,isSync = false;
  String displayDateFormat = '';
  WSPresenter wsPresenter;
  String API_CALLING_STATUS = '';
  ProgressHUD _progressHUD;

  NotificationScreenState() {
    wsPresenter = WSPresenter(this);
  }

  void redirectScanScreen() {
    final Route route =
        CupertinoPageRoute(builder: (context) => ScanningScreen());
    Navigator.push(mContext, route);
  }

  void _initLoading() {
    _progressHUD = ProgressHUD(
      backgroundColor: Colors.black38,
      color: Colors.white,
      containerColor: const Color(colorPrimary),
      borderRadius: 5.0,
      text: LocaleUtils.getString(mContext, 'loading_dot'),
      loading: _loading,
    );
  }

  @override
  void initState() {
    super.initState();

    mUtils = Utils();
    sharedPrefs = SharedPrefs();
    databaseHelper = DatabaseHelper.get();
    _battery = EcpSyncPlugin();
    _initLoading();

    sharedPrefs.getString(PREF_DATE_TIME_FORMAT).then((String dateFormat) {
      if (mounted) {
        setState(() {
          if (dateFormat.isNotEmpty) {
            displayDateFormat = dateFormat;
          } else {
            displayDateFormat = DATE_WITH_TIME_DEFAULT_FORMAT;
          }
        });
      }
    });

    sharedPrefs.getString(PREF_USER_TYPE).then((String userType) {
      if (userType.contains('E')) {
        if (mounted) {
          setState(() {
            isSync = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            isSync = true;
          });
        }
      }
    });

    getData();
  }

  void dismissProgressHUD() {
    if (mounted) {
      setState(() {
        if (_loading) {
          _progressHUD.state.show();
        } else {
          _progressHUD.state.dismiss();
        }
        _loading = !_loading;
      });
    }
  }

  String getMessageFromNotification(int index) {
    final StringBuffer strMsg = StringBuffer();
    final List<String> values1 = listDisplay[index].varMessage.split('|');
    //if (values1.length > 0) {
    if (values1.isNotEmpty) {
      for (int j = 0; j < values1.length; j++) {
        strMsg.write(values1[j]);
        strMsg.write('\n');
      }
    } else {
      strMsg.write(listDisplay[index].varMessage);
      strMsg.write('\n');
    }
    return strMsg.toString();
  }

  void _clickSync(bool isLongPress) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        if (isLongPress) {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'FullSyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  showDialog<Map>(
                    barrierDismissible: false,
                    context: mContext,
                    builder: (context) {
                      return CustomAlertDialog(
                        content:
                            LocaleUtils.getString(mContext, 'SyncConformMsg'),
                        title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                        isShowNagativeButton: true,
                        textNagativeButton:
                            LocaleUtils.getString(mContext, 'no'),
                        textPositiveButton:
                            LocaleUtils.getString(mContext, 'yes'),
                        onPressedNegative: () {},
                        onPressedPositive: () {
                          databaseHelper.close();
                          final Route route = CupertinoPageRoute(
                              builder: (context) =>
                                  SyncScreen(
                                      isDbSync: true, isDashboard: false));
                          Navigator.pushReplacement(mContext, route);
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        } else {
          showDialog<Map>(
            barrierDismissible: false,
            context: mContext,
            builder: (context) {
              return CustomAlertDialog(
                content: LocaleUtils.getString(mContext, 'SyncConformMsg'),
                title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                isShowNagativeButton: true,
                textNagativeButton: LocaleUtils.getString(mContext, 'no'),
                textPositiveButton: LocaleUtils.getString(mContext, 'yes'),
                onPressedNegative: () {},
                onPressedPositive: () {
                  databaseHelper.close();
                  final Route route = CupertinoPageRoute(
                      builder: (context) =>
                          SyncScreen(isDbSync: false, isDashboard: false));
                  Navigator.pushReplacement(mContext, route);
                },
              );
            },
          );
        }
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return WillPopScope(
                onWillPop: () {},
                child: CustomAlertDialog(
                  content:
                      LocaleUtils.getString(mContext, 'no_internet_connection'),
                  title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
                  isShowNagativeButton: false,
                  textNagativeButton: '',
                  textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
                  onPressedNegative: () {},
                  onPressedPositive: () {},
                ));
          },
        );
      }
    });
  }

  void getData() {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        /*if (mounted) {
          setState(() {
            loadingFlag = true;
          });
        }*/
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
            sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
              var param = Map();
              param['NotificationId'] = '';
              param[PARAM_PERSON_ID] = initCode;
              param[PARAM_API_TOKEN] = apiToken;
              param[PARAM_ACTION] = GET_NOTIFICATION;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                param[PARAM_DEVICE_ID] = deviceid;
                print(param);

                API_CALLING_STATUS = GET_NOTIFICATION;

                wsPresenter.callAPI(POST_METHOD, NOTIFICATION, param);
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  void markRead(int fkNotificationGlCode) {
    _battery.checkInternet().then((String isConnection) {
      if (isConnection.contains('true')) {
        /*if (mounted) {
          setState(() {
            loadingFlag = true;
          });
        }*/
        _loading = true;
        dismissProgressHUD();

        Future.delayed(const Duration(milliseconds: 700), () {
          sharedPrefs.getString(PREF_INIT_GI_CODE).then((String initCode) {
            sharedPrefs.getString(PREF_API_TOKEN).then((String apiToken) {
              var param = Map();
              param['NotificationId'] = fkNotificationGlCode.toString();
              param[PARAM_PERSON_ID] = initCode;
              param[PARAM_API_TOKEN] = apiToken;
              param[PARAM_ACTION] = MARK_READ;
              param[PARAM_SUB_MODULE_NAME] = Platform.isAndroid
                  ? SUB_MODULE_NAME_ANDROID
                  : SUB_MODULE_NAME_IOS;
              param[PARAM_VERSION] = APP_VERSION;

              sharedPrefs.getString(PREF_DEVICE_ID).then((String deviceid) {
                param[PARAM_DEVICE_ID] = deviceid;
                print(param);

                API_CALLING_STATUS = MARK_READ;

                wsPresenter.callAPI(POST_METHOD, NOTIFICATION, param);
              });
            });
          });
        });
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content:
                  LocaleUtils.getString(mContext, 'no_internet_connection'),
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;
    mContext = context;

    return MyCustomScaffold(
      appBar: CustomAppbar(
        isShowNotification: false,
        isShowSync: isSync,
        isShowHomeIcon: true,
        mContext: context,
        notificationCount: 0,
        databaseHelper: databaseHelper,
        syncPlugin: _battery,
        onBackPress: () {
          Navigator.pop(context, true);
        },
      ).appBar(),
      key: _key,
      bottomNavigationBar: Container(
        height: 50,
        padding: const EdgeInsets.only(left: 7, right: 7),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
              LocaleUtils.getString(
                  mContext, 'NotePleasePerformSync2ViewDetailsInApp'),
              style: TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'helvetica',
                  color: Colors.red[900])),
        ),
      ),
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: <Widget>[
                  Expanded(
                      flex: 1,
                      child: listDisplay.length > 0
                              ? Container(
                                  color: const Color(bgColor),
                                  child: ListView.builder(
                                    shrinkWrap: true,
                                    itemBuilder: (context, position) {
                                      return InkWell(
                                          child: Container(
                                            child: Column(
                                              mainAxisSize: MainAxisSize.max,
                                              children: <Widget>[
                                                Container(
                                                  color: listDisplay[position]
                                                          .chrRead
                                                          .contains('N')
                                                      ? const Color(colorAccent)
                                                      : Colors.white,
                                                  padding:
                                                      const EdgeInsets.only(
                                                          left: 5, right: 5),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: <Widget>[
                                                      Align(
                                                        alignment:
                                                            Alignment.topLeft,
                                                        child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .all(8.0),
                                                          child: Container(
                                                            width: 50,
                                                            height: 50,
                                                            decoration: const BoxDecoration(
                                                                color: Color(
                                                                    colorPrimary),
                                                                shape: BoxShape
                                                                    .circle),
                                                            child: const Icon(
                                                              Icons
                                                                  .notifications_none,
                                                              color:
                                                                  Colors.white,
                                                              size: 30,
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: <Widget>[
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      12.0,
                                                                      12.0,
                                                                      12.0,
                                                                      3.0),
                                                              child: Text(
                                                                listDisplay[position]
                                                                            .varSubject !=
                                                                        null
                                                                    ? listDisplay[
                                                                            position]
                                                                        .varSubject
                                                                    : '',
                                                                style: textStyle =
                                                                    TextStyle(
                                                                  fontSize:
                                                                      15.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w700,
                                                                  fontFamily:
                                                                      'helvetica',
                                                                  color: Colors
                                                                      .black,
                                                                ),
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .fromLTRB(
                                                                      12.0,
                                                                      3.0,
                                                                      12.0,
                                                                      0.0),
                                                              child: Text(
                                                                getMessageFromNotification(
                                                                            position) !=
                                                                        null
                                                                    ? getMessageFromNotification(
                                                                        position)
                                                                    : '',
                                                                style: textStyle =
                                                                    TextStyle(
                                                                  fontSize:
                                                                      14.0,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w400,
                                                                  color: Colors
                                                                      .black,
                                                                ),
                                                              ),
                                                            ),
                                                            Padding(
                                                              padding:
                                                                  const EdgeInsets
                                                                          .only(
                                                                      bottom:
                                                                          3),
                                                              child: Align(
                                                                alignment: Alignment
                                                                    .bottomRight,
                                                                child: Text(
                                                                  listDisplay[position]
                                                                              .dtDate !=
                                                                          null
                                                                      ? listDisplay[
                                                                              position]
                                                                          .dtDate
                                                                      : '',
                                                                  style: textStyle =
                                                                      TextStyle(
                                                                    fontSize:
                                                                        15.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w400,
                                                                    fontFamily:
                                                                        'helvetica',
                                                                    color: Colors
                                                                        .black,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                            listDisplay[position]
                                                                    .chrSync
                                                                    .contains(
                                                                        'Y')
                                                                ? Padding(
                                                                    padding: const EdgeInsets
                                                                            .fromLTRB(
                                                                        12.0,
                                                                        3.0,
                                                                        12.0,
                                                                        7.0),
                                                                    child: Text(
                                                                      LocaleUtils.getString(
                                                                          mContext,
                                                                          'SyncIsRequired'),
                                                                      style: textStyle =
                                                                          TextStyle(
                                                                        fontSize:
                                                                            14.0,
                                                                        fontWeight:
                                                                            FontWeight.w400,
                                                                        color: Colors
                                                                            .black,
                                                                      ),
                                                                    ),
                                                                  )
                                                                : Container(
                                                                    margin: const EdgeInsets
                                                                            .only(
                                                                        bottom:
                                                                            7),
                                                                  ),
                                                          ],
                                                        ),
                                                        flex: 1,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                const Divider(
                                                  color: Color(colorPrimary),
                                                  height: 1,
                                                ),
                                              ],
                                            ),
                                          ),
                                          onTap: () {
                                            if (listDisplay[position]
                                                .chrRead
                                                .contains('N')) {
                                              markRead(listDisplay[position]
                                                  .fk_NotificationGlCode);
                                            }
                                          });
                                    },
                                    itemCount: listDisplay.length,
                                  ),
                                )
                              : Visibility(
                                  child: Container(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Image.asset(
                                          'assets/nodata_icon.png',
                                          height: 100,
                                          width: 100,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 10),
                                          child: Text(
                                            LocaleUtils.getString(
                                                mContext, 'NoDataFound'),
                                            style: prifixTxtStyle,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  visible:
                                      //listDisplay.length <= 0 ? true : false,
                                      isNoData,
                                )),
                ],
              ),
              width: screenSize.width,
              height: screenSize.height,
            ),
            _progressHUD
          ],
        ),
      ),
    );
  }

  @override
  void onLoginError(String errorTxt) {
    /*if (mounted) {
      setState(() {
        loadingFlag = false;
      });
    }*/
    _loading = false;
    dismissProgressHUD();
  }

  @override
  void onLoginSuccess(String response) {
    print(response);

    final dynamic jsonResponse = json.decode(response.toString().trim());
    final LoginResponseModel responseModel =
        LoginResponseModel.fromJson(jsonResponse);
    print(responseModel.Status);
    print(responseModel.Message);

    if (API_CALLING_STATUS == GET_NOTIFICATION) {
      _loading = false;
      dismissProgressHUD();

      listDisplay.clear();
      if (responseModel.Status == '1') {
        listDisplay.addAll(responseModel?.Response?.notificationModelList);
        if(listDisplay.length > 0){
          isNoData = false;
        } else {
          isNoData = true;
        }
        if (mounted) {
          setState(() {});
        }
      } else {}
    } else if (API_CALLING_STATUS == MARK_READ) {
      if (responseModel.Status == '1') {
        getData();
      } else {
        showDialog<Map>(
          barrierDismissible: false,
          context: mContext,
          builder: (context) {
            return CustomAlertDialog(
              content: responseModel.Message,
              title: PROJECT_NAME == 'BASF_HK' ? BASF_HK_APP_Name : Zydus_APP_Name,
              isShowNagativeButton: false,
              textNagativeButton: '',
              textPositiveButton: LocaleUtils.getString(mContext, 'OK'),
              onPressedNegative: () {},
              onPressedPositive: () {},
            );
          },
        );
      }
    }
  }
}
