
import 'package:charts_flutter/flutter.dart' as charts;

/// Sample linear data type.
class LinearSales {
  final int year;
  final double sales;
  final charts.Color color;

  LinearSales(this.year, this.sales,this.color);
}