

class MyStockInfoModel {
  int fk_Product_SKU_Glcode;
  int fk_Product_SKUGlCode;
  String varProduct_SKU_Code;
  String varProduct_SKU_Name;
  double decQty;
  double qtyKG;
  int totalUnit;

  MyStockInfoModel.fromMap(Map<String, dynamic> json) {
    this.fk_Product_SKU_Glcode = json.containsKey('fk_Product_SKU_Glcode') ? json['fk_Product_SKU_Glcode'] : 0;
    this.fk_Product_SKUGlCode = json.containsKey('fk_Product_SKUGlCode') ? json['fk_Product_SKUGlCode'] : 0;
    this.varProduct_SKU_Code = json.containsKey('varProduct_SKU_Code') ? json['varProduct_SKU_Code'] : "";
    this.varProduct_SKU_Name = json['varProduct_SKU_Name'];
    this.decQty = json.containsKey('decQty') ? json['decQty'] : 0;
    this.qtyKG =
    json.containsKey('qtyKG') ? double.parse(json['qtyKG'].toString()) : 0.0;
    this.totalUnit = json.containsKey('totalUnit') ? json['totalUnit'] : 0;
  }
}

class MyStockInfoPopupModel {
  String varBatchNo;
  String dtExpiryDate;
  double decQty;
  double qtyKG;

  MyStockInfoPopupModel.fromMap(Map<String, dynamic> json) {
    this.varBatchNo = json['varBatchNo'];
    this.dtExpiryDate = json['dtExpiryDate'];
    this.decQty = double.parse(json['decQty'].toString());
    this.qtyKG =
    json.containsKey('qtyKG') ? double.parse(json['qtyKG'].toString()) : 0.0;
  }
}
