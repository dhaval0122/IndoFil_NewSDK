



class AgreementResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  AgreementResponseModel({this.Status, this.Message, this.Response});

  factory AgreementResponseModel.fromJson(Map<String, dynamic> json) {
    return AgreementResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  ResponseDataModel();

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    try {
      return ResponseDataModel();
    } catch (e) {
      return null;
    }
  }
}
