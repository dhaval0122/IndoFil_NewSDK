class ForgotResponseModel {
  String Status;
  String Message;
  List<ForgotResponseDataModel> Response;

  ForgotResponseModel({this.Status, this.Message, this.Response});

  factory ForgotResponseModel.fromJson(Map<String, dynamic> json) {
    List<ForgotResponseDataModel> dispatchSummaryList = new List();
    if (json.containsKey('Response')) {
      var dispatchSumList = json['Response'] as List;
      dispatchSummaryList = dispatchSumList
          .map((i) => ForgotResponseDataModel.fromJson(i))
          .toList();
    }

    return ForgotResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: dispatchSummaryList);
  }
}

class ForgotResponseDataModel {
  String varPassword;

  ForgotResponseDataModel({this.varPassword});

  factory ForgotResponseDataModel.fromJson(Map<String, dynamic> json) {
    return ForgotResponseDataModel(varPassword: json['varPassword']);
  }
}
