
class LoginResponseModel {
  String Status;
  String Message;
  String File;
  ResponseDataModel Response;

  LoginResponseModel({this.Status, this.Message, this.File, this.Response});

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) {
    return LoginResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        File: json.containsKey('File') ? json['File'] : "",
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<PersonModel> Person_Mst;
  List<SystemConfigModel> SystemConfiguration_Mst;
  List<ConfigurationModel> configuration_Mst;
  List<MenuMasterModel> Menu_Mst;
  List<EditDoModel> editDO_Mst;
  List<SystemInfoModel> systemInfoList;
  List<NotificationModel> notificationModelList;
  List<SettingsModel> settingModelList;
  List<LanguageDetails> languageDetailsList;
  List<DefaultLanguageDetails> defaultLanguageList;

  ResponseDataModel({
    this.Person_Mst,
    this.SystemConfiguration_Mst,
    this.configuration_Mst,
    this.Menu_Mst,
    this.editDO_Mst,
    this.systemInfoList,
    this.notificationModelList,
    this.settingModelList,
    this.languageDetailsList,
    this.defaultLanguageList,
  });

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    try {
      List<PersonModel> CountryModelMstList = new List();
      List<SystemConfigModel> systemModelMstList = new List();
      List<ConfigurationModel> configMstList = new List();
      List<MenuMasterModel> menuModelMstList = new List();
      List<EditDoModel> editDoMstList = new List();
      List<SystemInfoModel> sysInfoMstList = new List();
      List<NotificationModel> notiMstList = new List();
      List<SettingsModel> settingMstList = new List();
      List<LanguageDetails> langList = new List();
      List<DefaultLanguageDetails> defaultLangList = new List();

      if (parsedJson.containsKey('Person_Mst')) {
        var countryList = parsedJson['Person_Mst'] as List;
        CountryModelMstList =
            countryList.map((i) => PersonModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('SystemConfiguration_Mst')) {
        var countryList = parsedJson['SystemConfiguration_Mst'] as List;
        systemModelMstList =
            countryList.map((i) => SystemConfigModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('Configuration_Details')) {
        var countryList = parsedJson['Configuration_Details'] as List;
        configMstList =
            countryList.map((i) => ConfigurationModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('Menu_Mst')) {
        var countryList = parsedJson['Menu_Mst'] as List;
        menuModelMstList =
            countryList.map((i) => MenuMasterModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('DOInformation')) {
        var countryList = parsedJson['DOInformation'] as List;
        editDoMstList =
            countryList.map((i) => EditDoModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('SystemInformation')) {
        var countryList = parsedJson['SystemInformation'] as List;
        sysInfoMstList =
            countryList.map((i) => SystemInfoModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('Notification')) {
        var countryList = parsedJson['Notification'] as List;
        notiMstList =
            countryList.map((i) => NotificationModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('ProfileSetting')) {
        var countryList = parsedJson['ProfileSetting'] as List;
        settingMstList =
            countryList.map((i) => SettingsModel.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('LanguageDetails')) {
        var countryList = parsedJson['LanguageDetails'] as List;
        langList = countryList.map((i) => LanguageDetails.fromJson(i)).toList();
      }

      if (parsedJson.containsKey('DefaultLanguageDetails')) {
        var countryList = parsedJson['DefaultLanguageDetails'] as List;
        defaultLangList =
            countryList.map((i) => DefaultLanguageDetails.fromJson(i)).toList();
      }

      return ResponseDataModel(
        Person_Mst: CountryModelMstList,
        SystemConfiguration_Mst: systemModelMstList,
        configuration_Mst: configMstList,
        Menu_Mst: menuModelMstList,
        editDO_Mst: editDoMstList,
        systemInfoList: sysInfoMstList,
        notificationModelList: notiMstList,
        settingModelList: settingMstList,
        languageDetailsList: langList,
        defaultLanguageList: defaultLangList,
      );
    } catch (e) {
      //return null;
      print('====catch====${e.toString()}');
      return null;
    }
  }
}

class PersonModel {
  int intGlCode;
  String chrUserType;
  int fk_CountryGlCode;
  String varUserID;
  String varPassword;
  String varSAPCode;
  String varFirstName;
  String varMiddleName;
  String varLastName;
  String varAddress;
  String varEmail;
  String chrUserLock;
  String varPhoneNo;
  String varMobileNo;
  String varFullName;
  int fk_Customer_Type_CountryGlCode;
  int fk_Employee_TypeGlCode;
  int fk_Employee_Designation_CountryGlCode;
  int fk_Political_GeoGlCode;
  int refParentGlCode;
  String chrGender;
  String dtDOB;
  String varPincode;
  String varlatitude;
  String varlongitude;
  String varAgreementUrl;
  String chrAgree;
  String chrActive;
  String dtEntryString;
  int ref_Entry_By;
  String dtModifiedString;
  int ref_Modified_By;
  String dtValidFrom;
  String dtValidTo;
  String varPrintingCode;
  String varOrganisationName;
  String dtLastSyncDate;
  String varAPIToken;
  String varServerName;
  String strDateFormat_MSSQL;
  String strTimeFormat_MSSQL;
  String strDateTimeFormat_MSSQL;
  String varSync_Code;
  String dtSyncDate;
  String dtAgree;
  int fk_LanguageGlCode;

  PersonModel(
      {this.intGlCode,
      this.chrUserType,
      this.fk_CountryGlCode,
      this.varUserID,
      this.varPassword,
      this.varSAPCode,
      this.varFirstName,
      this.varMiddleName,
      this.varLastName,
      this.varAddress,
      this.varEmail,
      this.chrUserLock,
      this.varPhoneNo,
      this.varMobileNo,
      this.varFullName,
      this.fk_Customer_Type_CountryGlCode,
      this.fk_Employee_TypeGlCode,
      this.fk_Employee_Designation_CountryGlCode,
      this.fk_Political_GeoGlCode,
      this.refParentGlCode,
      this.chrGender,
      this.dtDOB,
      this.varPincode,
      this.varlatitude,
      this.varlongitude,
      this.varAgreementUrl,
      this.chrAgree,
      this.chrActive,
      this.dtEntryString,
      this.ref_Entry_By,
      this.dtModifiedString,
      this.ref_Modified_By,
      this.dtValidFrom,
      this.dtValidTo,
      this.varPrintingCode,
      this.varOrganisationName,
      this.dtLastSyncDate,
      this.varAPIToken,
      this.varServerName,
      this.strDateFormat_MSSQL,
      this.strTimeFormat_MSSQL,
      this.strDateTimeFormat_MSSQL,
      this.varSync_Code,
      this.dtSyncDate,
      this.dtAgree,
      this.fk_LanguageGlCode});

  factory PersonModel.fromJson(Map<String, dynamic> json) {
    return PersonModel(
      intGlCode: json['intGlCode'],
      chrUserType: json['chrUserType'],
      fk_CountryGlCode: json['fk_CountryGlCode'],
      varUserID: json['varUserID'],
      varPassword: json['varPassword'],
      varSAPCode: json['varSAPCode'],
      varFirstName: json['varFirstName'],
      varMiddleName: json['varMiddleName'],
      varLastName: json['varLastName'],
      varAddress: json['varAddress'],
      varEmail: json['varEmail'],
      chrUserLock: json['chrUserLock'],
      varPhoneNo: json['varPhoneNo'],
      varMobileNo: json['varMobileNo'],
      varFullName: json['varFullName'],
      fk_Customer_Type_CountryGlCode: json['fk_Customer_Type_CountryGlCode'],
      fk_Employee_TypeGlCode: json['fk_Employee_TypeGlCode'],
      fk_Employee_Designation_CountryGlCode:
          json['fk_Employee_Designation_CountryGlCode'],
      fk_Political_GeoGlCode: json['fk_Political_GeoGlCode'],
      refParentGlCode: json['refParentGlCode'],
      chrGender: json['chrGender'],
      dtDOB: json['dtDOB'],
      varPincode: json['varPincode'],
      varlatitude: json['varlatitude'],
      varlongitude: json['varlongitude'],
      varAgreementUrl: json['varAgreementUrl'],
      chrAgree: json['chrAgree'],
      chrActive: json['chrActive'],
      dtEntryString: json['dtEntryString'],
      ref_Entry_By: json['ref_Entry_By'],
      dtModifiedString: json['dtModifiedString'],
      ref_Modified_By: json['ref_Modified_By'],
      dtValidFrom: json['dtValidFrom'],
      dtValidTo: json['dtValidTo'],
      varPrintingCode: json['varPrintingCode'],
      varOrganisationName: json['varOrganisationName'],
      dtLastSyncDate: json['dtLastSyncDate'],
      varAPIToken: json['varAPIToken'],
      varServerName: json['varServerName'],
      strDateFormat_MSSQL: json['strDateFormat_MSSQL'],
      strTimeFormat_MSSQL: json['strTimeFormat_MSSQL'],
      strDateTimeFormat_MSSQL: json['strDateTimeFormat_MSSQL'],
      varSync_Code: json['varSync_Code'],
      dtSyncDate: json['dtSyncDate'],
      dtAgree: json['dtAgree'],
      fk_LanguageGlCode: json.containsKey('fk_LanguageGlCode')
          ? json['fk_LanguageGlCode'] != null ? json['fk_LanguageGlCode'] : 0
          : 0,
    );
  }

  PersonModel.fromMap(Map<String, dynamic> json) {
    this.intGlCode = json['intGlCode'];
    this.chrUserType = json['chrUserType'];
    this.fk_CountryGlCode = json['fk_CountryGlCode'];
    this.varUserID = json['varUserID'];
    this.varPassword = json['varPassword'];
    this.varSAPCode = json['varSAPCode'];
    this.varFirstName = json['varFirstName'];
    this.varMiddleName = json['varMiddleName'];
    this.varLastName = json['varLastName'];
    this.varAddress = json['varAddress'];
    this.varEmail = json['varEmail'];
    this.chrUserLock = json['chrUserLock'];
    this.varPhoneNo = json['varPhoneNo'];
    this.varMobileNo = json['varMobileNo'];
    this.varFullName = json['varFullName'];
    this.fk_Customer_Type_CountryGlCode =
        json['fk_Customer_Type_CountryGlCode'];
    this.fk_Employee_TypeGlCode = json['fk_Employee_TypeGlCode'];
    this.fk_Employee_Designation_CountryGlCode =
        json['fk_Employee_Designation_CountryGlCode'];
    this.fk_Political_GeoGlCode = json['fk_Political_GeoGlCode'];
    this.refParentGlCode = json['refParentGlCode'];
    this.chrGender = json['chrGender'];
    this.dtDOB = json['dtDOB'];
    this.varPincode = json['varPincode'];
    this.varlatitude = json['varlatitude'];
    this.varlongitude = json['varlongitude'];
    this.varAgreementUrl = json['varAgreementUrl'];
    this.chrAgree = json['chrAgree'];
    this.chrActive = json['chrActive'];
    this.dtEntryString = json['dtEntryString'];
    this.ref_Entry_By = json['ref_Entry_By'];
    this.dtModifiedString = json['dtModifiedString'];
    this.ref_Modified_By = json['ref_Modified_By'];
    this.dtValidFrom = json['dtValidFrom'];
    this.dtValidTo = json['dtValidTo'];
    this.varPrintingCode = json['varPrintingCode'];
    this.varOrganisationName = json['varOrganisationName'];
    this.dtLastSyncDate = json['dtLastSyncDate'];
    this.varAPIToken = json['varAPIToken'];
    this.varServerName = json['varServerName'];
    this.strDateFormat_MSSQL = json['strDateFormat_MSSQL'];
    this.strTimeFormat_MSSQL = json['strTimeFormat_MSSQL'];
    this.strDateTimeFormat_MSSQL = json['strDateTimeFormat_MSSQL'];
    this.varSync_Code = json['varSync_Code'];
    this.dtSyncDate = json['dtSyncDate'];
    this.dtAgree = json['dtAgree'];
    this.fk_LanguageGlCode =
        json.containsKey('fk_LanguageGlCode') ? json['fk_LanguageGlCode'] : 0;
  }
}

class SystemInfoModel {
  String varServer;

  SystemInfoModel({this.varServer});

  factory SystemInfoModel.fromJson(Map<String, dynamic> json) {
    return SystemInfoModel(varServer: json['varServer']);
  }
}

class SystemConfigModel {
  int intGlCode;
  int fk_SubModuleGlCode;
  String varVersion;
  String dtEntryUpdateDate;
  String varProjectName;
  String varErrorCaption;
  String varXMLSettings;

  SystemConfigModel(
      {this.intGlCode,
      this.fk_SubModuleGlCode,
      this.varVersion,
      this.dtEntryUpdateDate,
      this.varProjectName,
      this.varErrorCaption,
      this.varXMLSettings});

  factory SystemConfigModel.fromJson(Map<String, dynamic> json) {
    return SystemConfigModel(
        intGlCode: json['intGlCode'],
        fk_SubModuleGlCode: json['fk_SubModuleGlCode'],
        varVersion: json['varVersion'],
        dtEntryUpdateDate: json['dtEntryUpdateDate'],
        varProjectName: json['varProjectName'],
        varErrorCaption: json['varErrorCaption'],
        varXMLSettings: json['varXMLSettings']);
  }
}

class ConfigurationModel {
  int intGlCode;
  int fk_ConfigurationGlCode;
  String chrConfigType;
  String chrUserType;
  int fk_CustTypeRegionalCode;
  int fk_EmpDesignGlCode;
  int fk_CountryGlCode;
  int fk_PersonGlCode;
  String varPurpose;
  String varCode;
  String varValue1;
  String varValue2;
  String varValue3;
  String varValue4;
  String chrActive;
  String chrSync;
  String varSyncCode;
  String dtSyncDate;

  ConfigurationModel(
      {this.intGlCode,
      this.fk_ConfigurationGlCode,
      this.chrConfigType,
      this.chrUserType,
      this.fk_CustTypeRegionalCode,
      this.fk_EmpDesignGlCode,
      this.fk_CountryGlCode,
      this.fk_PersonGlCode,
      this.varPurpose,
      this.varCode,
      this.varValue1,
      this.varValue2,
      this.varValue3,
      this.varValue4,
      this.chrActive,
      this.chrSync,
      this.varSyncCode,
      this.dtSyncDate});

  factory ConfigurationModel.fromJson(Map<String, dynamic> json) {
    return ConfigurationModel(
        intGlCode: json['intGlCode'],
        fk_ConfigurationGlCode: json['fk_ConfigurationGlCode'],
        chrConfigType: json['chrConfigType'],
        chrUserType: json['chrUserType'],
        fk_CustTypeRegionalCode: json['fk_CustTypeRegionalCode'],
        fk_EmpDesignGlCode: json['fk_EmpDesignGlCode'],
        fk_CountryGlCode: json['fk_CountryGlCode'],
        fk_PersonGlCode: json['fk_PersonGlCode'],
        varPurpose: json['varPurpose'],
        varCode: json['varCode'],
        varValue1: json['varValue1'],
        varValue2: json['varValue2'],
        varValue3: json['varValue3'],
        varValue4: json['varValue4'],
        chrActive: json['chrActive'],
        chrSync: json['chrSync'],
        varSyncCode: json['varSyncCode'],
        dtSyncDate: json['dtSyncDate']);
  }
}

class MenuMasterModel {
  int intGlCode;
  String varMenuName;
  String varDisplayName;
  String varURL;
  int intMenuLevel;
  String chrElementType;
  int intDisplayOrder;
  String varIconPath;
  String chrDisplay;
  String chrHeadType;
  String chrMenuType;
  String chrDBType;
  String refParentMenuGLCode;
  String varTransactionCode;
  String refSubModuleGlCode;
  String dtEntryDate;
  String dtUpdateDate;
  int fkEntryPersonGlCode;
  int fkUpdatePersonGlCode;
  String chrActive;
  String chrSync;
  String varSync_Code;
  String dtSyncDate;

  MenuMasterModel(
      {this.intGlCode,
      this.varMenuName,
      this.varDisplayName,
      this.varURL,
      this.intMenuLevel,
      this.chrElementType,
      this.intDisplayOrder,
      this.varIconPath,
      this.chrDisplay,
      this.chrHeadType,
      this.chrMenuType,
      this.chrDBType,
      this.refParentMenuGLCode,
      this.varTransactionCode,
      this.refSubModuleGlCode,
      this.dtEntryDate,
      this.dtUpdateDate,
      this.fkEntryPersonGlCode,
      this.fkUpdatePersonGlCode,
      this.chrActive,
      this.chrSync,
      this.varSync_Code,
      this.dtSyncDate});

  factory MenuMasterModel.fromJson(Map<String, dynamic> json) {
    return MenuMasterModel(
        intGlCode: json['intGlCode'],
        varMenuName: json['varMenuName'],
        varDisplayName: json['varDisplayName'],
        varURL: json['varURL'],
        intMenuLevel: json['intMenuLevel'],
        chrElementType: json['chrElementType'],
        intDisplayOrder: json['intDisplayOrder'],
        varIconPath: json['varIconPath'],
        chrDisplay: json['chrDisplay'],
        chrHeadType: json['chrHeadType'],
        chrMenuType: json['chrMenuType'],
        chrDBType: json['chrDBType'],
        refParentMenuGLCode: json['refParentMenuGLCode'],
        varTransactionCode: json['varTransactionCode'],
        refSubModuleGlCode: json['refSubModuleGlCode'],
        dtEntryDate: json['dtEntryDate'],
        dtUpdateDate: json['dtUpdateDate'],
        fkEntryPersonGlCode: json['fkEntryPersonGlCode'],
        fkUpdatePersonGlCode: json['fkUpdatePersonGlCode'],
        chrActive: json['chrActive'],
        chrSync: json['chrSync'],
        varSync_Code: json['varSync_Code'],
        dtSyncDate: json['dtSyncDate']);
  }

  MenuMasterModel.fromMap(Map<String, dynamic> json) {
    this.intGlCode = json['intGlCode'];
    this.varMenuName = json['varMenuName'];
    this.varDisplayName = json['varDisplayName'];
    this.varURL = json['varURL'];
    this.intMenuLevel = json['intMenuLevel'];
    this.chrElementType = json['chrElementType'];
    this.intDisplayOrder = json['intDisplayOrder'];
    this.varIconPath = json['varIconPath'];
    this.chrDisplay = json['chrDisplay'];
    this.chrHeadType = json['chrHeadType'];
    this.chrMenuType = json['chrMenuType'];
    this.chrDBType = json['chrDBType'];
    this.refParentMenuGLCode = json['refParentMenuGLCode'].toString();
    this.varTransactionCode = json['varTransactionCode'];
    this.refSubModuleGlCode = json['refSubModuleGlCode'].toString();
    this.dtEntryDate = json['dtEntryDate'];
    this.dtUpdateDate = json['dtUpdateDate'];
    this.fkEntryPersonGlCode = json['fkEntryPersonGlCode'];
    this.fkUpdatePersonGlCode = json['fkUpdatePersonGlCode'];
    this.chrActive = json['chrActive'];
    this.chrSync = json['chrSync'];
    this.varSync_Code = json['varSync_Code'];
    this.dtSyncDate = json['dtSyncDate'];
  }
}

class EditDoModel {
  int fk_Customer_DispatchGlCode;
  int fk_Customer_From_GlCode;
  int fk_Customer_To_GlCode;
  String varDONO;
  String chrTransType;
  String varTranType;
  String dtDispatchDate;
  String varFullName;
  String intTotalUnit;
  String varSAPCode;
  int intTotalProduct;
  String varEntityName;
  String varCustomerName;

  EditDoModel(
      {this.fk_Customer_DispatchGlCode,
      this.fk_Customer_From_GlCode,
      this.fk_Customer_To_GlCode,
      this.varDONO,
      this.chrTransType,
      this.varTranType,
      this.dtDispatchDate,
      this.varFullName,
      this.intTotalUnit,
      this.varSAPCode,
      this.intTotalProduct,
      this.varCustomerName,
      this.varEntityName});

  factory EditDoModel.fromJson(Map<String, dynamic> json) {
    return EditDoModel(
        fk_Customer_DispatchGlCode: json['fk_Customer_DispatchGlCode'],
        fk_Customer_From_GlCode: json['fk_Customer_From_GlCode'],
        fk_Customer_To_GlCode: json['fk_Customer_To_GlCode'],
        varDONO: json['varDONO'],
        chrTransType: json['chrTransType'],
        varTranType: json['varTranType'],
        dtDispatchDate: json['dtDispatchDate'],
        varFullName: json['varFullName'],
        intTotalUnit: json['intTotalUnit'],
        varSAPCode: json['varSAPCode'],
        varEntityName:
            json.containsKey('varEntityName') ? json['varEntityName'] : "",
        varCustomerName:
            json.containsKey('varCustomerName') ? json['varCustomerName'] : "",
        intTotalProduct: json['intTotalProduct']);
  }

  EditDoModel.fromMap(Map<String, dynamic> json) {
    this.fk_Customer_DispatchGlCode = json['fk_Customer_DispatchGlCode'];
    this.fk_Customer_From_GlCode = json['fk_Customer_From_GlCode'];
    this.fk_Customer_To_GlCode = json['fk_Customer_To_GlCode'];
    this.varDONO = json['varDONO'];
    this.chrTransType = json['chrTransType'];
    this.varTranType = json['varTranType'];
    this.dtDispatchDate = json['dtDispatchDate'];
    this.varFullName = json['varFullName'];
    this.intTotalUnit = json['intTotalUnit'];
    this.varSAPCode = json['varSAPCode'];
    this.intTotalProduct = json['intTotalProduct'];
    this.varEntityName =
        json.containsKey('varEntityName') ? json['varEntityName'] : "";
    this.varCustomerName =
        json.containsKey('varCustomerName') ? json['varCustomerName'] : "";
  }
}

class NotificationModel {
  int intCount;
  int fk_NotificationGlCode;
  int fk_GlCode;
  String dtDate;
  String varNotification_Code;
  String varSubject;
  String varMessage;
  String chrRead;
  String chrColor;
  String chrSync;

  NotificationModel({
    this.intCount,
    this.fk_NotificationGlCode,
    this.fk_GlCode,
    this.dtDate,
    this.varNotification_Code,
    this.varSubject,
    this.varMessage,
    this.chrRead,
    this.chrColor,
    this.chrSync,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) {
    return NotificationModel(
      intCount: json.containsKey('intCount') ? json['intCount'] : 0,
      fk_NotificationGlCode: json.containsKey('fk_NotificationGlCode')
          ? json['fk_NotificationGlCode']
          : 0,
      fk_GlCode: json.containsKey('fk_GlCode') ? json['fk_GlCode'] : 0,
      dtDate: json.containsKey('dtDate') ? json['dtDate'] : "",
      varNotification_Code: json.containsKey('varNotification_Code')
          ? json['varNotification_Code']
          : "",
      varSubject: json.containsKey('varSubject') ? json['varSubject'] : "",
      varMessage: json.containsKey('varMessage') ? json['varMessage'] : "",
      chrRead: json.containsKey('chrRead') ? json['chrRead'] : "",
      chrColor: json.containsKey('chrColor') ? json['chrColor'] : "",
      chrSync: json.containsKey('chrSync') ? json['chrSync'] : "",
    );
  }

  NotificationModel.fromMap(Map<String, dynamic> json) {
    this.intCount = json.containsKey('intCount') ? json['intCount'] : 0;
    this.fk_NotificationGlCode = json.containsKey('fk_NotificationGlCode')
        ? json['fk_NotificationGlCode']
        : 0;
    this.fk_GlCode = json.containsKey('fk_GlCode') ? json['fk_GlCode'] : 0;
    this.dtDate = json.containsKey('dtDate') ? json['dtDate'] : "";
    this.varNotification_Code = json.containsKey('varNotification_Code')
        ? json['varNotification_Code']
        : "";
    this.varSubject = json.containsKey('varSubject') ? json['varSubject'] : "";
    this.varMessage = json.containsKey('varMessage') ? json['varMessage'] : "";
    this.chrRead = json.containsKey('chrRead') ? json['chrRead'] : "";
    this.chrColor = json.containsKey('chrColor') ? json['chrColor'] : "";
    this.chrSync = json.containsKey('chrSync') ? json['chrSync'] : "";
  }
}

class SettingsModel {
  String chrNotification;

  SettingsModel({this.chrNotification});

  factory SettingsModel.fromJson(Map<String, dynamic> json) {
    return SettingsModel(
      chrNotification: json['chrNotification'],
    );
  }

  SettingsModel.fromMap(Map<String, dynamic> json) {
    this.chrNotification = json['chrNotification'];
  }
}

class LanguageDetails {
  int intGlCode;
  String varLanguageCode;
  String varLanguageName;
  String varDescription;
  String chrActive;
  String dtEntryDate;
  int ref_Entry_By;
  String dtModifiedDate;
  int ref_Modified_By;
  String chrSync;
  String varSync_Code;
  String dtSyncDate;

  LanguageDetails(
      {this.intGlCode,
      this.varLanguageCode,
      this.varLanguageName,
      this.varDescription,
      this.chrActive,
      this.dtEntryDate,
      this.ref_Entry_By,
      this.dtModifiedDate,
      this.ref_Modified_By,
      this.chrSync,
      this.varSync_Code,
      this.dtSyncDate});

  factory LanguageDetails.fromJson(Map<String, dynamic> json) {
    return LanguageDetails(
      intGlCode: json['intGlCode'],
      varLanguageCode: json['varLanguageCode'],
      varLanguageName: json['varLanguageName'],
      varDescription: json['varDescription'],
      chrActive: json['chrActive'],
      dtEntryDate: json['dtEntryDate'],
      ref_Entry_By: json['ref_Entry_By'],
      dtModifiedDate: json['dtModifiedDate'],
      ref_Modified_By: json['ref_Modified_By'],
      chrSync: json['chrSync'],
      varSync_Code: json['varSync_Code'],
      dtSyncDate: json['dtSyncDate'],
    );
  }

  LanguageDetails.fromMap(Map<String, dynamic> json) {
    this.intGlCode = json['intGlCode'];
    this.varLanguageCode = json['varLanguageCode'];
    this.varLanguageName = json['varLanguageName'];
    this.varDescription = json['varDescription'];
    this.chrActive = json['chrActive'];
    this.dtEntryDate = json['dtEntryDate'];
    this.ref_Entry_By = json['ref_Entry_By'];
    this.dtModifiedDate = json['dtModifiedDate'];
    this.ref_Modified_By = json['ref_Modified_By'];
    this.chrSync = json['chrSync'];
    this.varSync_Code = json['varSync_Code'];
    this.dtSyncDate = json['dtSyncDate'];
  }
}

class DefaultLanguageDetails {
  int fk_DefaultLanguageGlCode;
  String varDefaultLanguageCode;
  String varDefaultLanguageName;

  DefaultLanguageDetails(
      {this.fk_DefaultLanguageGlCode,
      this.varDefaultLanguageCode,
      this.varDefaultLanguageName});

  factory DefaultLanguageDetails.fromJson(Map<String, dynamic> json) {
    return DefaultLanguageDetails(
      fk_DefaultLanguageGlCode: json['fk_DefaultLanguageGlCode'],
      varDefaultLanguageCode: json['varDefaultLanguageCode'],
      varDefaultLanguageName: json['varDefaultLanguageName'],
    );
  }

  DefaultLanguageDetails.fromMap(Map<String, dynamic> json) {
    this.fk_DefaultLanguageGlCode = json['fk_DefaultLanguageGlCode'];
    this.varDefaultLanguageCode = json['varDefaultLanguageCode'];
    this.varDefaultLanguageName = json['varDefaultLanguageName'];
  }
}
