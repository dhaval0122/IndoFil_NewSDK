class CountryTypeModel{
  int intGlCode;
  String varCustomer_Level;
  String varCustomer_Type_Code;
  String varCustomer_Type_Name;
  String chrDefault;

  CountryTypeModel({
    this.intGlCode,
    this.varCustomer_Level,
    this.varCustomer_Type_Code,
    this.varCustomer_Type_Name,
    this.chrDefault});

  factory CountryTypeModel.fromJson(Map<String, dynamic> json)
  {
    return CountryTypeModel(
      intGlCode: json['intGlCode'],
      varCustomer_Level: json['varCustomer_Level'],
      varCustomer_Type_Code: json['varCustomer_Type_Code'],
      varCustomer_Type_Name: json['varCustomer_Type_Name'],
      chrDefault: json['chrDefault'],
    );
  }

}