class ExpiryVisibilityResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  ExpiryVisibilityResponseModel({this.Status, this.Message, this.Response});

  factory ExpiryVisibilityResponseModel.fromJson(Map<String, dynamic> json) {
    return ExpiryVisibilityResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<ExpiryVisibilityModel> ExpiryVisibility;

  ResponseDataModel({this.ExpiryVisibility});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    List<ExpiryVisibilityModel> dispatchTrendsList = new List();
    if (parsedJson.containsKey('ExpiryVisibility')) {
      var dispatchTrendList = parsedJson['ExpiryVisibility'] as List;
      dispatchTrendsList = dispatchTrendList
          .map((i) => ExpiryVisibilityModel.fromJson(i))
          .toList();
    }
    return ResponseDataModel(ExpiryVisibility: dispatchTrendsList);
  }
}

class ExpiryVisibilityModel {
  String varProduct_Main_Group_Code;
  int days_90;
  int days_60;
  int days_30;
  int Expired;

  ExpiryVisibilityModel(
      {this.varProduct_Main_Group_Code,
      this.days_90,
      this.days_60,
      this.days_30,
      this.Expired});

  factory ExpiryVisibilityModel.fromJson(Map<String, dynamic> json) {
    return ExpiryVisibilityModel(
      varProduct_Main_Group_Code: json.containsKey('varProduct_Main_Group_Code')
          ? json['varProduct_Main_Group_Code']
          : "",
      days_90: json.containsKey('Days_90') ? json['Days_90'] : 0,
      days_60: json.containsKey('Days_60') ? json['Days_60'] : 0,
      days_30: json.containsKey('Days_30') ? json['Days_30'] : 0,
      Expired: json.containsKey('Expired') ? json['Expired'] : 0,
    );
  }
}
