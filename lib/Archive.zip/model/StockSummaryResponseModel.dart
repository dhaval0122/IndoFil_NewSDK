class StockSummaryResponseModel {
  String Status;
  String Message;

  //String TotalPhysicalStock;
  ResponseDataModel Response;

  StockSummaryResponseModel({this.Status, this.Message, this.Response});

  factory StockSummaryResponseModel.fromJson(Map<String, dynamic> json) {
    return StockSummaryResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<StockSummaryModel> StockSummary;
  List<TotalPhysicalStock> totalPhysicalStockList;

  ResponseDataModel({this.StockSummary, this.totalPhysicalStockList});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    var dispatchTrendList = parsedJson['StockSummaryDetail'] as List;
    var totalStockList = parsedJson['StockSummary'] as List;

    List<StockSummaryModel> dispatchTrendsList = new List();
    List<TotalPhysicalStock> totalPStockList = new List();

    if (parsedJson.containsKey('StockSummaryDetail')) {
      dispatchTrendsList =
          dispatchTrendList.map((i) => StockSummaryModel.fromJson(i)).toList();
    }
    if (parsedJson.containsKey('StockSummary')) {
      totalPStockList =
          totalStockList.map((i) => TotalPhysicalStock.fromJson(i)).toList();
    }

    return ResponseDataModel(
        StockSummary: dispatchTrendsList,
        totalPhysicalStockList: totalPStockList);
  }
}

class TotalPhysicalStock {
  double totalPhysicalStock;

  TotalPhysicalStock({this.totalPhysicalStock});

  factory TotalPhysicalStock.fromJson(Map<String, dynamic> json) {
    return TotalPhysicalStock(
        totalPhysicalStock: json['TotalPhysicalStock'] != null
            ? json['TotalPhysicalStock']
            : 0.0);
  }
}

class StockSummaryModel {
  String varProduct_Main_Group_Code;
  double TotalQtyKg;

  StockSummaryModel({this.varProduct_Main_Group_Code, this.TotalQtyKg});

  factory StockSummaryModel.fromJson(Map<String, dynamic> json) {
    return StockSummaryModel(
      varProduct_Main_Group_Code: json.containsKey('varProduct_Main_Group_Code')
          ? json['varProduct_Main_Group_Code']
          : "",
      TotalQtyKg: json.containsKey('TotalQtyKg') ? json['TotalQtyKg'] : 0.0,
    );
  }
}
