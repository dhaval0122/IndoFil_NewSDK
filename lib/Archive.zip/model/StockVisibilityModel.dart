
class StockVisibilityCustomerModel {
  int fk_UserGlCode;
  String varCode;
  String varName;

  StockVisibilityCustomerModel.fromJson(Map<String, dynamic> json)
      : fk_UserGlCode = json['fk_UserGlCode'],
        varCode = json['varCode'],
        varName = json['varName'];
}

class StockVisibilityProductModel {
  int fk_PRDGlCode;
  String varPRD_Name;
  double decQty;
  String Favourite;

  StockVisibilityProductModel.fromJson(Map<String, dynamic> json)
      : fk_PRDGlCode = json['fk_PRDGlCode'],
        varPRD_Name = json['varPRD_Name'],
        decQty = json['decQty'],
        Favourite = json['Favourite'];
}

class StockVisibilitySKUModel {
  int fk_PRDGlCode;
  int fk_PSKUGlCode;
  String varPRD_Code;
  String varProduct_SKU_Name;
  double decQty;
  double BlockQty;
  double BlockQtyChanged;

  StockVisibilitySKUModel.fromJson(Map<String, dynamic> json)
      : fk_PRDGlCode = json['fk_PRDGlCode'],
        fk_PSKUGlCode = json['fk_PSKUGlCode'],
        varPRD_Code = json['varPRD_Code'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'],
        decQty = json['decQty'],
        BlockQty = json['BlockQty'],
        BlockQtyChanged = json['BlockQty'];

  String getBlockQty(){
      if(BlockQty%1==0){
        return BlockQty.toInt().toStringAsFixed(1);
      }else{
        return BlockQty.toStringAsFixed(1);
      }
  }
}

class StockVisibilitySKUDialogData {
  int fk_Customer_GlCode;
  String CountryName;
  String WareHouseName;
  int fk_PRDGlCode;
  int fk_Product_SKU_GlCode;
  double decQty;

  StockVisibilitySKUDialogData.fromJson(Map<String, dynamic> json)
      : fk_Customer_GlCode = json['fk_Customer_GlCode'],
        CountryName = json['CountryName'],
        WareHouseName = json['WareHouseName'],
        fk_PRDGlCode = json['fk_PRDGlCode'],
        fk_Product_SKU_GlCode = json['fk_Product_SKU_GlCode'],
        decQty = json['decQty'];
}