class CustomerResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  CustomerResponseModel({this.Status, this.Message, this.Response});

  factory CustomerResponseModel.fromJson(Map<String, dynamic> json) {
    return CustomerResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<CustomerModel> Customer;

  ResponseDataModel({this.Customer});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    try {
      var customerList = parsedJson['Customer'] as List;
      final List<CustomerModel> customerModelMstList =
          customerList.map((i) => CustomerModel.fromJson(i)).toList();

      return ResponseDataModel(Customer: customerModelMstList);
    } catch (e) {
      return null;
    }
  }
}

class CustomerModel {
  int fk_PersonGlCode;
  String varSAPCode;
  String varOrganisationName;

  CustomerModel(
      {this.fk_PersonGlCode, this.varSAPCode, this.varOrganisationName});

  factory CustomerModel.fromJson(Map<String, dynamic> json) {
    return CustomerModel(
      fk_PersonGlCode: json['fk_PersonGlCode'],
      varSAPCode: json['varSAPCode'],
      varOrganisationName: json['varOrganisationName'],
    );
  }
}
