class DispatchTrendResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  DispatchTrendResponseModel({this.Status, this.Message, this.Response});

  factory DispatchTrendResponseModel.fromJson(Map<String, dynamic> json)
  {
    return DispatchTrendResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response'])
    );
  }
}

class ResponseDataModel {
  List<DispatchTrendModel> DispatchTrend;

  ResponseDataModel({this.DispatchTrend});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson){
    var dispatchTrendList = parsedJson['DispatchTrend'].toString().length > 0 ? parsedJson['DispatchTrend'] as List : null;
    List<DispatchTrendModel> dispatchTrendsList = new List();
    if(dispatchTrendList != null) {
      dispatchTrendsList = dispatchTrendList.map((i) =>
          DispatchTrendModel.fromJson(i)).toList();
    }
    return ResponseDataModel(
        DispatchTrend: dispatchTrendsList
    );
  }

}

class DispatchTrendModel {
  String varDateType;
  double CurrentValueInKG;
  double PreviousValueInKG;
  double Growth;

  DispatchTrendModel(
      {this.varDateType, this.CurrentValueInKG, this.PreviousValueInKG, this.Growth});

  factory DispatchTrendModel.fromJson(Map<String, dynamic> json)
  {
    return DispatchTrendModel(
      varDateType: json['varDateType'],
      CurrentValueInKG: json['CurrentValueInKG'],
      PreviousValueInKG: json['PreviousValueInKG'],
      Growth: json['Growth'],
    );
  }

}
