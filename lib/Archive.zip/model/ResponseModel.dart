import 'package:flutter_basf_hk_app/model/CountryModel.dart';
import 'package:flutter_basf_hk_app/model/CountryTypeModel.dart';

class ResponseModel {
  String Status;
  String Message;
  String File;
  ResponseDataModel Response;

  ResponseModel({this.Status, this.Message, this.File, this.Response});

  factory ResponseModel.fromJson(Map<String, dynamic> json) {
    return ResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        File: json.containsKey('File') ? json['File'] : "",
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<CountryModel> Country;
  List<CountryTypeModel> CustomerType;

  ResponseDataModel({this.Country, this.CustomerType});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    try {
      var countryList = parsedJson['Country'] as List;
      var countryTypeListTemp = parsedJson['CustomerType'] as List;
      List<CountryModel> CountryModelMstList =
          countryList.map((i) => CountryModel.fromJson(i)).toList();
      List<CountryTypeModel> CountryTypeList =
          countryTypeListTemp.map((i) => CountryTypeModel.fromJson(i)).toList();

      return ResponseDataModel(
          Country: CountryModelMstList, CustomerType: CountryTypeList);
    } catch (e) {
      return null;
    }
  }
}

class PersonModel {
  int intGlCode;
  String chrUserType;
  int fk_CountryGlCode;
  String varUserID;
  String varPassword;
  String varSAPCode;
  String varFirstName;
  String varMiddleName;
  String varLastName;
  String varAddress;
  String varEmail;
  String chrUserLock;
  String varPhoneNo;
  String varMobileNo;
  String varFullName;
  int fk_Customer_Type_CountryGlCode;
  int fk_Employee_TypeGlCode;
  int fk_Employee_Designation_CountryGlCode;
  int fk_Political_GeoGlCode;
  int refParentGlCode;
  String chrGender;
  String dtDOB;
  String varPincode;
  String varlatitude;
  String varlongitude;
  String varAgreementUrl;
  String chrAgree;
  String chrActive;
  String dtEntryString;
  int ref_Entry_By;
  String dtModifiedString;
  int ref_Modified_By;
  String dtValidFrom;
  String dtValidTo;
  String varPrintingCode;
  String varOrganisationName;
  String dtLastSyncDate;
  String varAPIToken;
  String varServerName;
  String strDateFormat_MSSQL;
  String strTimeFormat_MSSQL;
  String strDateTimeFormat_MSSQL;
  String varSync_Code;
  String dtSyncDate;
  String dtAgree;

  PersonModel(
      {this.intGlCode,
      this.chrUserType,
      this.fk_CountryGlCode,
      this.varUserID,
      this.varPassword,
      this.varSAPCode,
      this.varFirstName,
      this.varMiddleName,
      this.varLastName,
      this.varAddress,
      this.varEmail,
      this.chrUserLock,
      this.varPhoneNo,
      this.varMobileNo,
      this.varFullName,
      this.fk_Customer_Type_CountryGlCode,
      this.fk_Employee_TypeGlCode,
      this.fk_Employee_Designation_CountryGlCode,
      this.fk_Political_GeoGlCode,
      this.refParentGlCode,
      this.chrGender,
      this.dtDOB,
      this.varPincode,
      this.varlatitude,
      this.varlongitude,
      this.varAgreementUrl,
      this.chrAgree,
      this.chrActive,
      this.dtEntryString,
      this.ref_Entry_By,
      this.dtModifiedString,
      this.ref_Modified_By,
      this.dtValidFrom,
      this.dtValidTo,
      this.varPrintingCode,
      this.varOrganisationName,
      this.dtLastSyncDate,
      this.varAPIToken,
      this.varServerName,
      this.strDateFormat_MSSQL,
      this.strTimeFormat_MSSQL,
      this.strDateTimeFormat_MSSQL,
      this.varSync_Code,
      this.dtSyncDate,
      this.dtAgree});

  factory PersonModel.fromJson(Map<String, dynamic> json) {
    return PersonModel(
        intGlCode: json['Status'],
        chrUserType: json['chrUserType'],
        fk_CountryGlCode: json['fk_CountryGlCode'],
        varUserID: json['varUserID'],
        varPassword: json['varPassword'],
        varSAPCode: json['varSAPCode'],
        varFirstName: json['varFirstName'],
        varMiddleName: json['varMiddleName'],
        varLastName: json['varLastName'],
        varAddress: json['varAddress'],
        varEmail: json['varEmail'],
        chrUserLock: json['chrUserLock'],
        varPhoneNo: json['varPhoneNo'],
        varMobileNo: json['varMobileNo'],
        varFullName: json['varFullName'],
        fk_Customer_Type_CountryGlCode: json['fk_Customer_Type_CountryGlCode'],
        fk_Employee_TypeGlCode: json['fk_Employee_TypeGlCode'],
        fk_Employee_Designation_CountryGlCode:
            json['fk_Employee_Designation_CountryGlCode'],
        fk_Political_GeoGlCode: json['fk_Political_GeoGlCode'],
        refParentGlCode: json['refParentGlCode'],
        chrGender: json['chrGender'],
        dtDOB: json['dtDOB'],
        varPincode: json['varPincode'],
        varlatitude: json['varlatitude'],
        varlongitude: json['varlongitude'],
        varAgreementUrl: json['varAgreementUrl'],
        chrAgree: json['chrAgree'],
        chrActive: json['chrActive'],
        dtEntryString: json['dtEntryString'],
        ref_Entry_By: json['ref_Entry_By'],
        dtModifiedString: json['dtModifiedString'],
        ref_Modified_By: json['ref_Modified_By'],
        dtValidFrom: json['dtValidFrom'],
        dtValidTo: json['dtValidTo'],
        varPrintingCode: json['varPrintingCode'],
        varOrganisationName: json['varOrganisationName'],
        dtLastSyncDate: json['dtLastSyncDate'],
        varAPIToken: json['varAPIToken'],
        varServerName: json['varServerName'],
        strDateFormat_MSSQL: json['strDateFormat_MSSQL'],
        strTimeFormat_MSSQL: json['strTimeFormat_MSSQL'],
        strDateTimeFormat_MSSQL: json['strDateTimeFormat_MSSQL'],
        varSync_Code: json['varSync_Code'],
        dtSyncDate: json['dtSyncDate'],
        dtAgree: json['dtAgree']);
  }

/*
  chrUserType,fk_CountryGlCode,varUserID,varPassword,varSAPCode,varFirstName
  varMiddleName,varLastName,varAddress,varEmail,chrUserLock,varPhoneNo,
  varMobileNo,varFullName,fk_Customer_Type_CountryGlCode,fk_Employee_TypeGlCode,
  fk_Employee_Designation_CountryGlCode,fk_Political_GeoGlCode,refParentGlCode,
  chrGender,dtDOB,varPincode,varlatitude,varlongitude,varAgreementUrl,chrAgree,
  chrActive,dtEntryString,ref_Entry_By,dtModifiedString,ref_Modified_By,
  dtValidFrom,dtValidTo,varPrintingCode,varOrganisationName,dtLastSyncDate,
  varAPIToken,varServerName,strDateFormat_MSSQL,strTimeFormat_MSSQL,
  strDateTimeFormat_MSSQL,varSync_Code,dtSyncDate,dtAgree
  */
}
