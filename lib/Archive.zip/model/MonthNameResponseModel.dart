class MonthNameResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  MonthNameResponseModel({this.Status, this.Message, this.Response});

  factory MonthNameResponseModel.fromJson(Map<String, dynamic> json) {
    return MonthNameResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<MonthModel> MonthInformation;

  ResponseDataModel({this.MonthInformation});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    List<MonthModel> dispatchTrendsList = new List();

    if (parsedJson.containsKey('MonthInformation')) {
      var dispatchTrendList = parsedJson['MonthInformation'] as List;
      dispatchTrendsList =
          dispatchTrendList.map((i) => MonthModel.fromJson(i)).toList();
    }

    return ResponseDataModel(MonthInformation: dispatchTrendsList);
  }
}

class MonthModel {
  int MonthNumber;
  String MonthName;
  String chrCurrentMonth;

  MonthModel({this.MonthNumber, this.MonthName, this.chrCurrentMonth});

  factory MonthModel.fromJson(Map<String, dynamic> json) {
    return MonthModel(
        MonthNumber: json.containsKey('MonthNumber') ? json['MonthNumber'] : 0,
        MonthName: json.containsKey('MonthName') ? json['MonthName'] : "",
        chrCurrentMonth:
            json.containsKey('chrCurrentMonth') ? json['chrCurrentMonth'] : "");
  }
}
