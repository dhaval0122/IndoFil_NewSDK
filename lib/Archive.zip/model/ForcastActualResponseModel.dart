class ForcastActualResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  ForcastActualResponseModel({this.Status, this.Message, this.Response});

  factory ForcastActualResponseModel.fromJson(Map<String, dynamic> json) {
    return ForcastActualResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<ForcastActualModel> ForcastVsActual;

  ResponseDataModel({this.ForcastVsActual});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    List<ForcastActualModel> dispatchTrendsList = new List();

    if (parsedJson.containsKey('ForcastVsActual')) {
      var dispatchTrendList = parsedJson['ForcastVsActual'] as List;
      dispatchTrendsList =
          dispatchTrendList.map((i) => ForcastActualModel.fromJson(i)).toList();
    }

    return ResponseDataModel(ForcastVsActual: dispatchTrendsList);
  }
}

class ForcastActualModel {
  String CountryName;
  String MonthName;
  double ForcastValue;
  double ActualValue;

  ForcastActualModel(
      {this.CountryName, this.MonthName, this.ForcastValue, this.ActualValue});

  factory ForcastActualModel.fromJson(Map<String, dynamic> json) {
    return ForcastActualModel(
        CountryName: json.containsKey('CountryName') ? json['CountryName'] : "",
        MonthName: json.containsKey('MonthName') ? json['MonthName'] : "",
        ForcastValue:
            json.containsKey('ForcastValue') ? json['ForcastValue'] : 0,
        ActualValue: json.containsKey('ActualValue') ? json['ActualValue'] : 0);
  }
}
