import 'package:flutter_basf_hk_app/model/CountryModel.dart';
import 'package:flutter_basf_hk_app/model/CountryTypeModel.dart';

class FirstTimeChangePassResponseModel {
  String Status;
  String Message;
  String File;
  List<ChangePasswordModel> Response;

  FirstTimeChangePassResponseModel(
      {this.Status, this.Message, this.File, this.Response});

  factory FirstTimeChangePassResponseModel.fromJson(Map<String, dynamic> json) {
    List<ChangePasswordModel> CountryModelMstList = new List();

    if (json.containsKey('Response')) {
      var countryList = json['Response'] as List;
      CountryModelMstList =
          countryList.map((i) => ChangePasswordModel.fromJson(i)).toList();
    }
    return FirstTimeChangePassResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        File: json.containsKey('File') ? json['File'] : "",
        Response: CountryModelMstList);
  }
}

class ChangePasswordModel {
  String varPassword;

  ChangePasswordModel({this.varPassword});

  factory ChangePasswordModel.fromJson(Map<String, dynamic> json) {
    return ChangePasswordModel(
      varPassword: json.containsKey('varPassword') ? json['varPassword'] : "",
    );
  }
}
