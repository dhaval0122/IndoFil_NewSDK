import 'package:flutter_basf_hk_app/Utils/globals.dart' as globals;

class SalesSummaryModel {
  int fk_DispatchGlCode;
  String varDONO;
  String varEntityName;
  String dtDispatchDate;
  String DispatchTo;
  int TotalUnits;
  int TotalArticle;
  String chrTransType;

  SalesSummaryModel.fromJson(Map<String, dynamic> json)
      : fk_DispatchGlCode = json['fk_DispatchGlCode'],
        varDONO = json['varDONO'],
        varEntityName = json.containsKey('varEntityName')
            ? json['varEntityName']
            : '${globals.DO_NO}',
        dtDispatchDate = json['dtDispatchDate'],
        DispatchTo = json['DispatchTo'],
        TotalUnits = json['TotalUnits'],
        TotalArticle = json['TotalArticle'],
        chrTransType = json['chrTransType'];
}

class SalesSummarySKUModel {
  int fk_SKU_GlCode;
  String varProduct_SKU_Name;
  int TotalUnti;
  double QtyKG;
  String varProduct_SKU_Code;
  String varBatch_No;

  SalesSummarySKUModel.fromJson(Map<String, dynamic> json)
      : fk_SKU_GlCode = json['fk_SKU_GlCode'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'].toString(),
        TotalUnti = json['TotalUnti'],
        QtyKG = json['QtyKG'],
        varProduct_SKU_Code = json['varProduct_SKU_Code'],
        varBatch_No = json['varBatch_No'];
}
class SalesSummarySKUStickerModel {
  int fk_Product_SKU_Glcode;
  String varSticker;
  int intRowNo;

  SalesSummarySKUStickerModel.fromJson(Map<String, dynamic> json)
      : fk_Product_SKU_Glcode = json['fk_Product_SKU_Glcode'],
        varSticker = json['varSticker'],
        intRowNo = json['intRowNo'];
}
