class Country_MstModel {
  int intGlCode;
  String varCode;
  String varName;

  Country_MstModel.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        varCode = json['varCode'],
        varName = json['varName'];
}

class Product_Sku_Mst_Model {
  int intGlCode;
  String varProduct_SKU_Code;
  String varProduct_SKU_Name;

  Product_Sku_Mst_Model.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        varProduct_SKU_Code = json['varProduct_SKU_Code'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'];
}

class Person_Mst_Model {
  int intGlCode;
  String chrUserType;
  int fk_CountryGlCode;
  String varUserID;
  String varSAPCode;
  String varFirstName;
  String varMiddleNa;
  String varLastName;
  String varEmail;
  String varPhoneNo;
  String varMobileNo;
  String varFullName;
  String varOrganisationName;
  int fk_Customer_Type_CountryGlCode;
  String varCustomer_Level;
  String varCustomer_Type_Code;
  String varCustomer_Type_Name;
  int fk_Political_GeoGlCode;

  Person_Mst_Model.fromJson(Map<String, dynamic> json)
      : intGlCode = json['intGlCode'],
        chrUserType = json['chrUserType'],
        fk_CountryGlCode = json['fk_CountryGlCode'],
        varUserID = json['varUserID'],
        varSAPCode = json['varSAPCode'],
        varFirstName = json['varFirstName'],
        varMiddleNa = json['varMiddleNa'],
        varLastName = json['varLastName'],
        varEmail = json['varEmail'],
        varPhoneNo = json['varPhoneNo'],
        varMobileNo = json['varMobileNo'],
        varFullName = json['varFullName'],
        varOrganisationName =
            json['varSAPCode'] + '-' + json['varOrganisationName'],
        fk_Customer_Type_CountryGlCode = json['fk_Customer_Type_CountryGlCode'],
        varCustomer_Level = json['varCustomer_Level'],
        varCustomer_Type_Code = json['varCustomer_Type_Code'],
        varCustomer_Type_Name = json['varCustomer_Type_Name'],
        fk_Political_GeoGlCode = json['fk_Political_GeoGlCode'];
}

class Order_Summary_Model {
  int fk_OrderGlCode;
  String varOrder_No;
  String varCountry_Code;
  String varCountry_Name;
  String varCustomer_Type_Name;
  String varTo_Customer_SAP_Code;
  String varTo_Customer_Name;

  Order_Summary_Model.fromJson(Map<String, dynamic> json)
      : fk_OrderGlCode = json['fk_OrderGlCode'],
        varOrder_No = json['varOrder_No'],
        varCountry_Code = json['varCountry_Code'],
        varCountry_Name = json['varCountry_Name'],
        varCustomer_Type_Name = json['varCustomer_Type_Name'],
        varTo_Customer_SAP_Code = json['varTo_Customer_SAP_Code'],
        varTo_Customer_Name = json['varTo_Customer_Name'];
}

class Order_Product_Summary_Model {
  int intTotalArticle;
  int decTotalQuantity;

  Order_Product_Summary_Model.fromJson(Map<String, dynamic> json)
      : intTotalArticle = json['intTotalArticle'],
        decTotalQuantity = (json['decTotalQuantity'] as double).toInt();
}

class Order_Product_Details {
  int fk_OrderGlCode;
  int fk_Product_SKU_GlCode;
  double decQty;

  Order_Product_Details(
      {this.fk_OrderGlCode, this.fk_Product_SKU_GlCode, this.decQty});

  Order_Product_Details.fromJson(Map<String, dynamic> json)
      : fk_OrderGlCode = json['fk_OrderGlCode'],
        fk_Product_SKU_GlCode = json['fk_Product_SKU_GlCode'],
        decQty = (json['decQty'] as double).toDouble();

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['fk_OrderGlCode'] = this.fk_OrderGlCode;
    data['fk_Product_SKU_GlCode'] = this.fk_Product_SKU_GlCode;
    data['decQty'] = this.decQty;
    return data;
  }
}

class Scanning_Details {
  int fk_OrderGlCode;
  int fk_OrderDetailGlCode;
  int fk_Product_SKUGlCode;
  String varProduct_SKU_Code;
  String varProduct_SKU_Name;
  double decQuantityInKG;
  double decQuantity;

  Scanning_Details(
      {this.fk_OrderGlCode,
      this.fk_OrderDetailGlCode,
      this.fk_Product_SKUGlCode,
      this.varProduct_SKU_Code,
      this.varProduct_SKU_Name,
      this.decQuantityInKG,
      this.decQuantity});

  Scanning_Details.fromJson(Map<String, dynamic> json)
      : fk_OrderGlCode = json['fk_OrderGlCode'],
        fk_OrderDetailGlCode = json['fk_OrderDetailGlCode'],
        fk_Product_SKUGlCode = json['fk_Product_SKUGlCode'],
        varProduct_SKU_Code = json['varProduct_SKU_Code'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'],
        decQuantityInKG = (json['decQuantityInKG'] as double).toDouble(),
        decQuantity = json['decQuantity'];
}
