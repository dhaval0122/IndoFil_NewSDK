class OrderHistoryStatusModel {
  int varStatusCode;
  String varStatus;

  OrderHistoryStatusModel.fromJson(Map<String, dynamic> json)
      : varStatusCode = json['varStatusCode'],
        varStatus = json['varStatus'];
}

class OrderHistorySummaryModel {
  int fk_OrderGlCode;
  String varOrder_No;
  String dtOrderDate;
  String varStatus;
  int intTotalArticle;
  int decQuantityInKG;
  int decQuantity;
  String varTo_Customer_Name;
  String dtLastStatusUpdatedON;

  OrderHistorySummaryModel.fromJson(Map<String, dynamic> json)
      : fk_OrderGlCode = json['fk_OrderGlCode'],
        varOrder_No = json['varOrder_No'],
        dtOrderDate = json['dtOrderDate'],
        varStatus = json['varStatus'],
        intTotalArticle = json['intTotalArticle'],
        decQuantityInKG = (json['decQuantityInKG'] as double).toInt(),
        varTo_Customer_Name = json.containsKey('varTo_Customer_Name')
            ? json['varTo_Customer_Name']
            : '',
        dtLastStatusUpdatedON = json.containsKey('dtLastStatusUpdatedON')
            ? json['dtLastStatusUpdatedON']
            : '',
        decQuantity = json['decQuantity'];
}

class OrderHistoryDetailModel {
  int fk_OrderGlCode;
  int fk_Product_SKUGlCode;
  String varProduct_SKU_Code;
  String varProduct_SKU_Name;
  int decQuantityInKG;
  int decQuantity;

  OrderHistoryDetailModel.fromJson(Map<String, dynamic> json)
      : fk_OrderGlCode = json['fk_OrderGlCode'],
        fk_Product_SKUGlCode = json['fk_Product_SKUGlCode'],
        varProduct_SKU_Code = json['varProduct_SKU_Code'],
        varProduct_SKU_Name = json['varProduct_SKU_Name'],
        decQuantityInKG = (json['decQuantityInKG'] as double).toInt(),
        decQuantity = (json['decQuantity'] as double).toInt();
}
