class CountryModel{
  int intGlCode;
  String varCode;
  String varCountryName;
  String chrDefault;

  CountryModel({this.intGlCode,this.varCode,this.varCountryName,this.chrDefault});

  factory CountryModel.fromJson(Map<String, dynamic> json)
  {
    return CountryModel(
      intGlCode: json['intGlCode'],
      varCode: json['varCode'],
      varCountryName: json['varCountryName'],
      chrDefault: json['chrDefault'],
    );
  }

}