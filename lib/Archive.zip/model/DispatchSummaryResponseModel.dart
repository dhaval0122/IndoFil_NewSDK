class DispatchSummaryResponseModel {
  String Status;
  String Message;
  ResponseDataModel Response;

  DispatchSummaryResponseModel({this.Status, this.Message, this.Response});

  factory DispatchSummaryResponseModel.fromJson(Map<String, dynamic> json) {
    return DispatchSummaryResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: ResponseDataModel.fromJson(json['Response']));
  }
}

class ResponseDataModel {
  List<DispatchSummaryModel> DispatchSummary;

  ResponseDataModel({this.DispatchSummary});

  factory ResponseDataModel.fromJson(Map<String, dynamic> parsedJson) {
    List<DispatchSummaryModel> dispatchSummaryList = new List();
    if (parsedJson.containsKey('DispatchSummary')) {
      var dispatchSumList = parsedJson['DispatchSummary'] as List;
      dispatchSummaryList =
          dispatchSumList.map((i) => DispatchSummaryModel.fromJson(i)).toList();
    }
    return ResponseDataModel(DispatchSummary: dispatchSummaryList);
  }
}

class DispatchSummaryModel {
  String varDateType;
  double CurrentValueInKG;
  double PreviousValueInKG;
  double Performance;
  String IsGrowth;

  DispatchSummaryModel(
      {this.varDateType,
      this.CurrentValueInKG,
      this.PreviousValueInKG,
      this.Performance,
      this.IsGrowth});

  factory DispatchSummaryModel.fromJson(Map<String, dynamic> json) {
    return DispatchSummaryModel(
      varDateType: json.containsKey('varDateType') ? json['varDateType'] : "",
      CurrentValueInKG:
          json.containsKey('CurrentValueInKG') ? json['CurrentValueInKG'] : 0.0,
      PreviousValueInKG: json.containsKey('PreviousValueInKG')
          ? json['PreviousValueInKG']
          : 0.0,
      Performance: json.containsKey('Performance') ? json['Performance'] : 0.0,
      IsGrowth: json.containsKey('IsGrowth') ? json['IsGrowth'] : "",
    );
  }
}
