import 'package:flutter_basf_hk_app/available_to_promise/AvailableToPromise.dart';
import 'package:flutter_basf_hk_app/model/SalesSummaryModel.dart';
import 'package:flutter_basf_hk_app/model/StockVisibilityModel.dart';
import 'package:flutter_basf_hk_app/pallet_adjustment/PalletAdjustmentScreen.dart';
import 'package:flutter_basf_hk_app/sales_inward/InwardScanScreen.dart';
import 'package:flutter_basf_hk_app/sales_inward/SalesInwardModels.dart';
import 'package:flutter_basf_hk_app/setting/SettingScreen.dart';
import 'package:flutter_basf_hk_app/track_n_trace/KnowYourBoxScreen.dart';

import 'OrderHistoryModel.dart';
import 'PlaceOrderModel.dart';

class GeneralResponseModel {
  String Status;
  String Message;
  var Response;

  factory GeneralResponseModel.fromJsonStatus(Map<String, dynamic> json) {
    return GeneralResponseModel(
        Status: json['Status'],
        Message: json['Message'],
        Response: json['Response']);
  }

  GeneralResponseModel({
    this.Status,
    this.Message,
    this.Response,
  });

  List<StockVisibilityCustomerModel> getStockVisibilityCustomerList() {
    List<StockVisibilityCustomerModel> list =
        new List<StockVisibilityCustomerModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list =
          listTmp.map((i) => StockVisibilityCustomerModel.fromJson(i)).toList();
    }

    return list;
  }

  List<StockVisibilityProductModel> getStockVisibilityProductList() {
    List<StockVisibilityProductModel> list =
        new List<StockVisibilityProductModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list =
          listTmp.map((i) => StockVisibilityProductModel.fromJson(i)).toList();
    }

    return list;
  }

  List<StockVisibilitySKUModel> getSKUList() {
    List<StockVisibilitySKUModel> list = new List<StockVisibilitySKUModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list = listTmp.map((i) => StockVisibilitySKUModel.fromJson(i)).toList();
    }

    return list;
  }

  List<StockVisibilitySKUDialogData> getSKUDialogList() {
    List<StockVisibilitySKUDialogData> list =
        new List<StockVisibilitySKUDialogData>();

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list =
          listTmp.map((i) => StockVisibilitySKUDialogData.fromJson(i)).toList();
    }

    return list;
  }

  List<SalesSummaryModel> getSalesSummaryList() {
    List<SalesSummaryModel> list = new List<SalesSummaryModel>();

    if (Response.containsKey('SalesSummary')) {
      var listTmp = Response['SalesSummary'] as List;

      list = listTmp.map((i) => SalesSummaryModel.fromJson(i)).toList();
    }

    return list;
  }

  List<SalesSummarySKUModel> getSalesSummarySKUList() {
    List<SalesSummarySKUModel> list = new List<SalesSummarySKUModel>();

    if (Response.containsKey('SalesSummary')) {
      var listTmp = Response['SalesSummary'] as List;

      list = listTmp.map((i) => SalesSummarySKUModel.fromJson(i)).toList();
    }
    return list;
  }

  List<SalesSummarySKUStickerModel> getSalesSummarySKUStickerList() {
    List<SalesSummarySKUStickerModel> list =
        new List<SalesSummarySKUStickerModel>();

    if (Response.containsKey('SalesSummary')) {
      var listTmp = Response['SalesSummary'] as List;

      list =
          listTmp.map((i) => SalesSummarySKUStickerModel.fromJson(i)).toList();
    }
    return list;
  }

  List<KnowYourBoxModel> getKnowYourBoxModelList() {
    List<KnowYourBoxModel> list = new List<KnowYourBoxModel>();

    if (Response.containsKey('KnowYourBox')) {
      var listTmp = Response['KnowYourBox'] as List;

      list = listTmp.map((i) => KnowYourBoxModel.fromJson(i)).toList();
    }

    if (Response.containsKey('KnowYourBulkBox')) {
      var listTmp = Response['KnowYourBulkBox'] as List;

      list = listTmp.map((i) => KnowYourBoxModel.fromJson(i)).toList();
    }
    return list;
  }

  List<PalletAdjustmentModel> getPalletAdjustmentList() {
    List<PalletAdjustmentModel> list = new List<PalletAdjustmentModel>();

    if (Response.containsKey('Pallet_Details')) {
      var listTmp = Response['Pallet_Details'] as List;

      list = listTmp.map((i) => PalletAdjustmentModel.fromJson(i)).toList();
    }
    return list;
  }

  List<SettingModel> getSettingsModelList() {
    List<SettingModel> list = new List<SettingModel>();

    if (Response.containsKey('ProfileSetting')) {
      var listTmp = Response['ProfileSetting'] as List;

      list = listTmp.map((i) => SettingModel.fromJson(i)).toList();
    }
    return list;
  }

  // Available To Promise
  List<AvailableToPromiseCustomerModel> getAvailableToPromiseCustomerList() {
    List<AvailableToPromiseCustomerModel> list =
        new List<AvailableToPromiseCustomerModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list = listTmp
          .map((i) => AvailableToPromiseCustomerModel.fromJson(i))
          .toList();
    }

    return list;
  }

  List<AvailableToPromiseProductModel> getAvailableToPromiseProductList() {
    List<AvailableToPromiseProductModel> list =
        new List<AvailableToPromiseProductModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list = listTmp
          .map((i) => AvailableToPromiseProductModel.fromJson(i))
          .toList();
    }

    return list;
  }

  List<AvailableToPromiseSKUModel> getAvailableToPromiseSKUList() {
    List<AvailableToPromiseSKUModel> list =
        new List<AvailableToPromiseSKUModel>();
    //final jsonResponse = json.decode(Response);

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list =
          listTmp.map((i) => AvailableToPromiseSKUModel.fromJson(i)).toList();
    }

    return list;
  }

  List<AvailableToPromiseSKUDialogData> getAvailableToPromiseSKUDialogList() {
    List<AvailableToPromiseSKUDialogData> list =
        new List<AvailableToPromiseSKUDialogData>();

    if (Response.containsKey('Stock_Visibility')) {
      var listTmp = Response['Stock_Visibility'] as List;

      list = listTmp
          .map((i) => AvailableToPromiseSKUDialogData.fromJson(i))
          .toList();
    }

    return list;
  }

  int getCheckPendingOrder() {
    int data;

    if (Response.containsKey('CheckPendingOrder')) {
      var tmp = Response['CheckPendingOrder'] as List;
      var tmp2 = tmp.map<int>((m) => m['fk_OrderGlCode'] as int).toList();
      data = tmp2[0];
    }

    return data;
  }

  List<Country_MstModel> getCountryList_PlaceOrder() {
    List<Country_MstModel> list = new List<Country_MstModel>();

    if (Response.containsKey('Country_Mst')) {
      var listTmp = Response['Country_Mst'] as List;

      list = listTmp.map((i) => Country_MstModel.fromJson(i)).toList();
    }
    return list;
  }

  List<Product_Sku_Mst_Model> getProductSkuMstList_PlaceOrder() {
    List<Product_Sku_Mst_Model> list = new List<Product_Sku_Mst_Model>();

    if (Response.containsKey('Product_Sku_Mst')) {
      var listTmp = Response['Product_Sku_Mst'] as List;

      list = listTmp.map((i) => Product_Sku_Mst_Model.fromJson(i)).toList();
    }
    return list;
  }

  List<Person_Mst_Model> getPerson_Mst_PlaceOrder() {
    List<Person_Mst_Model> list = new List<Person_Mst_Model>();

    if (Response.containsKey('Person_Mst')) {
      var listTmp = Response['Person_Mst'] as List;

      list = listTmp.map((i) => Person_Mst_Model.fromJson(i)).toList();
    }
    return list;
  }

  int getInsertOrderId() {
    int data;

    if (Response.containsKey('Order_Header')) {
      var tmp = Response['Order_Header'] as List;
      var tmp2 = tmp.map<int>((m) => m['fk_OrderGlCode'] as int).toList();
      data = tmp2[0];
    }

    return data;
  }

  String getOrderNo() {
    String data;

    if (Response.containsKey('Order_Header')) {
      var tmp = Response['Order_Header'] as List;
      var tmp2 = tmp.map<String>((m) => m['varOrderNo'] as String).toList();
      data = tmp2[0];
    }

    return data;
  }

  Order_Summary_Model getOrder_Summary_PlaceOrder() {
    Order_Summary_Model data;

    if (Response.containsKey('Order_Summary')) {
      var listTmp = Response['Order_Summary'] as List;

      var tmp2 = listTmp.map((i) => Order_Summary_Model.fromJson(i)).toList();
      if (tmp2 != null && tmp2.isNotEmpty) {
        data = tmp2[0];
      }
    }
    return data;
  }

  PalletSummary getPalletSummary() {
    PalletSummary data;

    if (Response.containsKey('Pallet_Summary')) {
      var listTmp = Response['Pallet_Summary'] as List;

      var tmp2 = listTmp.map((i) => PalletSummary.fromJson(i)).toList();
      if (tmp2 != null && tmp2.isNotEmpty) {
        data = tmp2[0];
      }
    }
    return data;
  }

  Order_Product_Summary_Model getOrder_Product_Summary_PlaceOrder() {
    Order_Product_Summary_Model data;

    if (Response.containsKey('Order_Product_Summary')) {
      var listTmp = Response['Order_Product_Summary'] as List;

      var tmp2 =
          listTmp.map((i) => Order_Product_Summary_Model.fromJson(i)).toList();
      if (tmp2 != null && tmp2.isNotEmpty) {
        data = tmp2[0];
      }
    }
    return data;
  }

  List<Scanning_Details> getScanning_Details_PlaceOrder() {
    List<Scanning_Details> list = new List<Scanning_Details>();

    if (Response.containsKey('Scanning_Details')) {
      var listTmp = Response['Scanning_Details'] as List;

      list = listTmp.map((i) => Scanning_Details.fromJson(i)).toList();
    }
    return list;
  }

  List<InwardScanModel> getInwardScanRecords() {
    List<InwardScanModel> list = new List<InwardScanModel>();

    if (Response.containsKey('SalesInwardStickerDetails')) {
      var listTmp = Response['SalesInwardStickerDetails'] as List;

      list = listTmp.map((i) => InwardScanModel.fromJson(i)).toList();
    }
    return list;
  }

  List<OrderHistoryStatusModel> getStatus_OrderHistory() {
    List<OrderHistoryStatusModel> list = new List<OrderHistoryStatusModel>();

    if (Response.containsKey('Status')) {
      var listTmp = Response['Status'] as List;

      list = listTmp.map((i) => OrderHistoryStatusModel.fromJson(i)).toList();
    }
    return list;
  }

  List<OrderHistorySummaryModel> getSummary_OrderHistory() {
    List<OrderHistorySummaryModel> list = new List<OrderHistorySummaryModel>();

    if (Response.containsKey('Order_History_Summary')) {
      var listTmp = Response['Order_History_Summary'] as List;

      list = listTmp.map((i) => OrderHistorySummaryModel.fromJson(i)).toList();
    }
    return list;
  }

  List<OrderHistoryDetailModel> getDetails_OrderHistory() {
    List<OrderHistoryDetailModel> list = new List<OrderHistoryDetailModel>();

    if (Response.containsKey('Order_History_Detail')) {
      var listTmp = Response['Order_History_Detail'] as List;

      list = listTmp.map((i) => OrderHistoryDetailModel.fromJson(i)).toList();
    }
    return list;
  }

  List<SalesInwardSummaryModel> getSalesInwardSummary() {
    List<SalesInwardSummaryModel> list = List<SalesInwardSummaryModel>();

    if (Response.containsKey('SalesInwardSummary')) {
      var listTmp = Response['SalesInwardSummary'] as List;

      list = listTmp.map((i) => SalesInwardSummaryModel.fromJson(i)).toList();
    }
    return list;
  }

  List<SalesInwardStickerDetailsModel> getSalesInwardStickerDetails() {
    List<SalesInwardStickerDetailsModel> list =
    List<SalesInwardStickerDetailsModel>();

    if (Response.containsKey('SalesInwardStickerDetails')) {
      var listTmp = Response['SalesInwardStickerDetails'] as List;

      list = listTmp
          .map((i) => SalesInwardStickerDetailsModel.fromJson(i))
          .toList();
    }
    return list;
  }

  List<SalesInwardDetailsModel> getSalesInwardDetails() {
    List<SalesInwardDetailsModel> list = List<SalesInwardDetailsModel>();

    if (Response.containsKey('SalesInwardDetails')) {
      var listTmp = Response['SalesInwardDetails'] as List;

      list = listTmp.map((i) => SalesInwardDetailsModel.fromJson(i)).toList();
    }
    return list;
  }

  SalesInwardCountModel getSalesInwardCount() {
    SalesInwardCountModel data;

    if (Response.containsKey('SalesInwardCount')) {
      var listTmp = Response['SalesInwardCount'] as List;

      var tmp2 = listTmp.map((i) => SalesInwardCountModel.fromJson(i)).toList();
      if (tmp2 != null && tmp2.isNotEmpty) {
        data = tmp2[0];
      }
    }
    return data;
  }

  List<StickerDetailModel> getInvalidStickers() {
    List<StickerDetailModel> list = List<StickerDetailModel>();

    if (Response.containsKey('StickerDetail')) {
      var listTmp = Response['StickerDetail'] as List;

      list = listTmp.map((i) => StickerDetailModel.fromJson(i)).toList();
    }
    return list;
  }
}
