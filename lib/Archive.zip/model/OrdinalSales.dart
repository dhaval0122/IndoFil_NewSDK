
class OrdinalSales {
  String year;
  int sales;

  OrdinalSales(this.year, this.sales);
}