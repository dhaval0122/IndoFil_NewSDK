import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_basf_hk_app/Login.dart';
import 'package:flutter_basf_hk_app/Prefs/SharedPrefs.dart';
import 'package:flutter_basf_hk_app/localization/LocaleUtils.dart';

import 'package:flutter_basf_hk_app/styles/colors.dart';

import 'package:page_indicator/page_indicator.dart';

import 'webservices/WSConstant.dart';

class IntroSliderScreen extends StatefulWidget {
  @override
  _IntroSliderScreenState createState() => _IntroSliderScreenState();
}

class _IntroSliderScreenState extends State<IntroSliderScreen> {
  Size screenSize;
  SharedPrefs sharedPrefs;

  //void _loginCall() {}

  void navigationPage() {
    Navigator.of(context).pop();
  }

  @override
  void initState() {
    super.initState();

    sharedPrefs = SharedPrefs();

    //startTime();
  }

  Widget firstScreen() {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage('assets/bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      padding: const EdgeInsets.only(left: 10, right: 10, top: 50, bottom: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            LocaleUtils.getString(context, 'WELCOME'),
            style: TextStyle(
              fontSize: 22.0,
              fontWeight: FontWeight.w500,
              fontFamily: 'helvetica',
              color: const Color(colorPrimary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Image.asset(
              PROJECT_NAME == 'BASF_HK' ? 'assets/dlight.png' : 'assets/zydus_dlight.png',
              height: 200.0,
              width: 200.0,
              alignment: Alignment.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              PROJECT_NAME == 'BASF_HK' ?
              LocaleUtils.getString(context, 'smart_inventory_program') : LocaleUtils.getString(context, 'track_trace'),
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w500,
                fontFamily: 'helvetica',
                color: const Color(colorPrimary),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'just_getting_started'),
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w400,
                fontFamily: 'helvetica',
                color: const Color(colorPrimary),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context,
                  'lets_take_a_look_at_some_feature_of_this_application'),
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w400,
                fontFamily: 'helvetica',
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget secondScreen() {
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 10, top: 50, bottom: 10),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage('assets/bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Image.asset(
              'assets/notification.png',
              height: 200.0,
              width: 200.0,
              alignment: Alignment.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'instant_notification'),
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w500,
                fontFamily: 'helvetica',
                color: const Color(colorPrimary),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context,
                  'receive_instant_notification_against_each_dispatch_made_by_supplier'),
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w400,
                fontFamily: 'helvetica',
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget thirdScreen() {
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 10, top: 50, bottom: 10),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage('assets/bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Text(
            LocaleUtils.getString(context, 'WELCOME'),
            style: TextStyle(
              fontSize: 22.0,
              fontWeight: FontWeight.w500,
              fontFamily: 'helvetica',
              color: const Color(colorPrimary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Image.asset(
              'assets/qrcode.png',
              height: 200.0,
              width: 200.0,
              alignment: Alignment.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'easy_to_use'),
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w500,
                fontFamily: 'helvetica',
                color: const Color(colorPrimary),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'user_friendly_interface'),
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w400,
                fontFamily: 'helvetica',
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget fourScreen() {
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 10, top: 50, bottom: 10),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const AssetImage('assets/bg.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 50),
            child: Image.asset(
              'assets/stockinfo.png',
              height: 200.0,
              width: 200.0,
              alignment: Alignment.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'my_stock_info'),
              style: TextStyle(
                fontSize: 18.0,
                fontWeight: FontWeight.w500,
                fontFamily: 'helvetica',
                color: const Color(colorPrimary),
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 20),
            child: Text(
              LocaleUtils.getString(context, 'know_your_current_stock'),
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w400,
                fontFamily: 'helvetica',
                color: Colors.black,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          Padding(
              padding: const EdgeInsets.only(top: 30),
              child: RaisedButton(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
                splashColor: Colors.grey,
                onPressed: () {
                  sharedPrefs.setBool(IS_INTRO_SCREEN, true).then((bool isadd) {
//                    Navigator.of(context).pushReplacementNamed(LOGIN_SCREEN);
                    final Route route =
                        CupertinoPageRoute(builder: (context) => Login());
                    Navigator.pushReplacement(context, route);
                  });
                },
                elevation: 7,
                padding: const EdgeInsets.only(
                    left: 30, right: 30, top: 12, bottom: 12),
                color: const Color(colorPrimary),
                child: Text(LocaleUtils.getString(context, 'get_started'),
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'helvetica')),
              )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    screenSize = MediaQuery.of(context).size;

    return Scaffold(
      body: SafeArea(
          child: Container(
              child: PageIndicatorContainer(
        pageView: PageView(
          controller: PageController(
            initialPage: 0,
          ),
          scrollDirection: Axis.horizontal,
          children: <Widget>[
            firstScreen(),
            secondScreen(),
            thirdScreen(),
            fourScreen()
          ],
        ),
        length: 4,
        align: IndicatorAlign.bottom,
        indicatorSpace: 7.0,
        padding: const EdgeInsets.only(bottom: 30),
        indicatorColor: Colors.grey,
        indicatorSelectorColor: const Color(colorPrimary),
        shape: IndicatorShape.circle(size: 10),
      ))),
    );
  }
}
