package ecp.vcs.com.ecpsyncplugin;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.StrictMode;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.cipherlab.barcode.GeneralString;
import com.cipherlab.barcode.ReaderManager;
import com.cipherlab.barcode.decoder.KeyboardEmulationType;
import com.cipherlab.barcode.decoderparams.ReaderOutputConfiguration;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ecp.vcs.com.ecpsyncplugin.dbSync.SyncData;
import ecp.vcs.com.ecpsyncplugin.filesync.FileSyncCallBack;
import ecp.vcs.com.ecpsyncplugin.filesync.FileSyncTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.API.ApiService;
import ecp.vcs.com.ecpsyncplugin.scansdk.API.RetrofitClient;
import ecp.vcs.com.ecpsyncplugin.scansdk.GsonUtils;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ChallengeResponse;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.LocationBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.Options;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanOptions;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanResponse;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendCustomerDataBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.sdkutil.CustomerSDK;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * EcpSyncPlugin
 */
public class EcpSyncPlugin implements MethodCallHandler, EventChannel.StreamHandler {
    /**
     * Plugin registration.
     *//*
  public static void registerWith(Registrar registrar) {
    final MethodChannel channel = new MethodChannel(registrar.messenger(), "ecp_sync_plugin");
    channel.setMethodCallHandler(new EcpSyncPlugin());
  }

  @Override
  public void onMethodCall(MethodCall call, Result result) {
    if (call.method.equals("getPlatformVersion")) {
      result.success("Android " + android.os.Build.VERSION.RELEASE);
    } else {
      result.notImplemented();
    }
  }*/


    // --Commented out by Inspection (03/04/19, 2:41 PM):private static boolean isFielCopeError = false;
    // --Commented out by Inspection (03/04/19, 2:41 PM):private static String fileCopeException = "";
    private static String URLDownloadDB = "";

    public static final String BASF_HK_PACKAGE_NAME = "com.ecubix.basf";
    public static final String BASF_LAB_PACKAGE_NAME = "com.ecubix.basflab";
    private static final String update_progress = "update_progress";
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.e("BroadCast", " onRecieve"); //do something with intent
            if (intent.getExtras() != null) {
                String SCAN = intent.getExtras().getString("SCAN");
                String JSONDATA = intent.getExtras().getString("JSONDATA");
                assert SCAN != null;
                if (SCAN.equalsIgnoreCase("done")) {
                    Log.e("BroadCast", "JSONDATA:" + JSONDATA);
                    sendBroadCastDetails(11, JSONDATA, 0);
                    registrar.activity().unregisterReceiver(mReceiver);
                } else {
                    sendBroadCastDetails(12, JSONDATA, 0);
                    registrar.activity().unregisterReceiver(mReceiver);
                }
            }
        }
    };
    private com.cipherlab.barcode.ReaderManager mReaderManager;
    /// Create a broadcast object to receive the intent coming from service.
    private final BroadcastReceiver myDataReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // If intent of the Intent_SOFTTRIGGER_DATA string is received
            if (intent.getAction().equals(GeneralString.Intent_SOFTTRIGGER_DATA)) {
                Log.e("1", "Intent_SOFTTRIGGER_DATA");
                Log.e("1", "Intent_SOFTTRIGGER_DATA");
                Log.e("1", "Intent_SOFTTRIGGER_DATA");
                Log.e("1", "Intent_SOFTTRIGGER_DATA");
                // fetch the data within the intent
                String data = intent.getStringExtra(GeneralString.BcReaderData);
                try {
                    if (!data.equalsIgnoreCase("")) {
                        String finalCode = Utils.getSerialNoFromBarcode(data, true);
                        if (!finalCode.equalsIgnoreCase("")) {
                            sendBroadCastDetails(1001, finalCode, 0);
                        } else {
                            sendBroadCastDetails(1001, data, 0);
                        }
                    } else {
                        sendBroadCastDetails(1002, "data not Found", 0);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    sendBroadCastDetails(1002, e.getMessage(), 0);
                }
                // display the fetched data
                //e1.setText(data);
            } else if (intent.getAction().equals(GeneralString.Intent_PASS_TO_APP)) {
                Log.e("2", "Intent_PASS_TO_APP");
                Log.e("2", "Intent_PASS_TO_APP");
                Log.e("2", "Intent_PASS_TO_APP");
                Log.e("2", "Intent_PASS_TO_APP");
                // fetch the data within the intent
                try {
                    String data = intent.getStringExtra(GeneralString.BcReaderData);
                    if (!data.equalsIgnoreCase("")) {
                        String finalCode = Utils.getSerialNoFromBarcode(data, true);
                        if (!finalCode.equalsIgnoreCase("")) {
                            sendBroadCastDetails(1001, finalCode, 0);
                        } else {
                            sendBroadCastDetails(1001, data, 0);
                        }
                    } else {
                        sendBroadCastDetails(1002, "data not Found", 0);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    sendBroadCastDetails(1002, e.getMessage(), 0);
                }
                // display the fetched data
                //e1.setText(data);
                //e1.setText(data);

            } else if (intent.getAction().equals(GeneralString.Intent_READERSERVICE_CONNECTED)) {
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                Log.e("3", "Intent_READERSERVICE_CONNECTED");
                try {
                    //BcReaderType myReaderType = mReaderManager.GetReaderType();
                    //e1.setText(myReaderType.toString());

                    ReaderOutputConfiguration settings = new ReaderOutputConfiguration();
                    mReaderManager.Get_ReaderOutputConfiguration(settings);
                    settings.enableKeyboardEmulation = KeyboardEmulationType.None;
                    //settings.enableKeyboardEmulation = Enable_State.FALSE;
                    mReaderManager.Set_ReaderOutputConfiguration(settings);
                    sendBroadCastDetails(1000, "connected", 0);
                } catch (Exception e) {
                    e.printStackTrace();
                    sendBroadCastDetails(1002, e.getMessage(), 0);
                }


            }

        }
    };

    @Override
    public void onListen(Object arguments, EventChannel.EventSink events) {
        Log.e("BroadCast", "onListen");
        chargingStateChangeReceiver = createChargingStateChangeReceiver(events);
        registrar
                .context()
                .registerReceiver(
                        chargingStateChangeReceiver, new IntentFilter(update_progress));
    }

    @Override
    public void onCancel(Object arguments) {
        Log.e("BroadCast", "onCancel");
        registrar.context().unregisterReceiver(chargingStateChangeReceiver);
        chargingStateChangeReceiver = null;
    }

    public static void registerWith(final PluginRegistry.Registrar registrar) {
        final MethodChannel methodChannel =
                new MethodChannel(registrar.messenger(), "ecp_sync_plugin");
        final EventChannel eventChannel =
                new EventChannel(registrar.messenger(), "ecp_sync_plugin_Progress");
        final EcpSyncPlugin instance = new EcpSyncPlugin(registrar);
        eventChannel.setStreamHandler(instance);
        methodChannel.setMethodCallHandler(instance);

        registrar.addRequestPermissionsResultListener(new PluginRegistry.RequestPermissionsResultListener() {
            @Override
            public boolean onRequestPermissionsResult(int i, String[] strings, int[] ints) {
                return detailsPermission(i, strings, ints, registrar.activity());
            }
        });
    }

    private EcpSyncPlugin(PluginRegistry.Registrar registrar) {
        this.registrar = registrar;
    }

    private final PluginRegistry.Registrar registrar;
    private BroadcastReceiver chargingStateChangeReceiver;

    private Context getActiveContext() {
        return (registrar.activity() != null) ? registrar.activity() : registrar.context();
    }

    @Override
    public void onMethodCall(MethodCall call, Result result) {

        if (call.method.equals("hideKeyboardPlugin")) {

            try {
                View view = registrar.activity().getCurrentFocus();
                if (view != null) {
                    InputMethodManager imm = (InputMethodManager) registrar.activity()
                            .getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }
                result.success("done");
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (call.method.equals("openDateSettings")) {
            try {
                Intent intent = new Intent(android.provider.Settings.ACTION_DATE_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                registrar.activity().startActivity(intent);
                result.success("done");
            } catch (Exception e) {
                e.printStackTrace();
                try {
                    Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    registrar.activity().startActivity(intent);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                result.success("notdone");
            }
        } else if (call.method.equals("restorePreferences")) {

            SharedPreferences mSharedPreferences = registrar.activity().getSharedPreferences("YRTJHGJHFGGDGCJ", Context.MODE_PRIVATE);
            String OrganizationName = mSharedPreferences.getString("varOrganizationName", "");
            String TERMS_CONDITION = mSharedPreferences.getString("TERMS_CONDITION", "");
            String DeviceID = mSharedPreferences.getString("DeviceID", "");
            String NotificationToken = mSharedPreferences.getString("regId", "");
            String password = mSharedPreferences.getString("pref_password", "");
            String userName = mSharedPreferences.getString("varUserID", "");
            String APIToken = mSharedPreferences.getString("varAPIToken", "");
            String dateTimeFormat = mSharedPreferences.getString("DATE_FORMAT", "");
            String UserID = mSharedPreferences.getString("pref_user_name", "");
            String agreementURL = mSharedPreferences.getString("TERMS_CONDITION", "");
            String serverName = mSharedPreferences.getString("varServerName", "");
            String timeFormat = mSharedPreferences.getString("TIME_FORMAT", "");
            String userType = mSharedPreferences.getString("chrUserType", "");
            String fullName = mSharedPreferences.getString("varFullName", "");


            int fkPoliticalGeoGICode = mSharedPreferences.getInt("fk_Political_GeoGlCode", 0);
            int fkEmployeeTypeGICode = mSharedPreferences.getInt("fk_Employee_TypeGlCode", 0);
            int initGICode = mSharedPreferences.getInt("intGlCode", 0);
            int fkCountryGICode = mSharedPreferences.getInt("fk_CountryGlCode", 0);
            int mainCustomerGICode = mSharedPreferences.getInt("MAIN_CUSTOMER_GL_CODE", 0);
            int fkCustomerTypeCountryGICode = mSharedPreferences.getInt("fk_Customer_Type_CountryGlCode", 0);
            int fkEmployeeDesignationCountryGlCode = mSharedPreferences.getInt("fk_Employee_Designation_CountryGlCode", 0);


            boolean isNotification = mSharedPreferences.getBoolean("pref_is_notification_enable", false);
            boolean isIntoScreen = mSharedPreferences.getBoolean("INTRO_SLIDER_STATE", false);
            boolean RememberMe = mSharedPreferences.getBoolean("pref_is_remember_me", false);
            boolean isLogin = mSharedPreferences.getBoolean("pref_is_login", false);

            try {
                JSONObject map = new JSONObject();
                map.put("OrganizationName", OrganizationName);
                map.put("TERMS_CONDITION", TERMS_CONDITION);
                map.put("DeviceID", DeviceID);
                map.put("NotificationToken", NotificationToken);
                map.put("password", password);
                map.put("userName", userName);
                map.put("APIToken", APIToken);
                map.put("dateTimeFormat", dateTimeFormat);
                map.put("UserID", UserID);
                map.put("agreementURL", agreementURL);
                map.put("serverName", serverName);
                map.put("timeFormat", timeFormat);
                map.put("userType", userType);
                map.put("fullName", fullName);
                map.put("fkPoliticalGeoGICode", fkPoliticalGeoGICode);
                map.put("fkEmployeeTypeGICode", fkEmployeeTypeGICode);
                map.put("initGICode", initGICode);
                map.put("fkCountryGICode", fkCountryGICode);
                map.put("mainCustomerGICode", mainCustomerGICode);
                map.put("fkCustomerTypeCountryGICode", fkCustomerTypeCountryGICode);
                map.put("fkEmployeeDesignationCountryGlCode", fkEmployeeDesignationCountryGlCode);

                map.put("isNotification", isNotification);
                map.put("isIntoScreen", isIntoScreen);
                map.put("RememberMe", RememberMe);
                map.put("isLogin", isLogin);

                //JSONArray jsonArray = new JSONArray();
                //jsonArray.put(map);
                Log.e("jsonArray:", "" + map.toString());
                result.success(map.toString());
            } catch (Exception e) {
                e.printStackTrace();
                result.success("notdone");
            }


        } else if (call.method.equals("checkSqliteChiper")) {
            // method removed by dhaval on 03/09/2019 v 3.8.1
            /*try {

                String androidDBPath = call.argument("androidDBPath");
                String flutterDBPath = call.argument("flutterDBPath");
                Log.e("androidDBPath", "" + androidDBPath);
                Log.e("flutterDBPath", "" + flutterDBPath);

                if (new File(androidDBPath).exists()) {
                    SQLiteDatabase.loadLibs(registrar.activity());
                    ExportSqlChiper exportSqlChiper = new ExportSqlChiper();
                    boolean isEncripted = exportSqlChiper.checkDatabaseEnciptedorPlain(registrar.activity(), androidDBPath, "Vcs@1234");
                    if (isEncripted) {
                        exportSqlChiper.migratePlainTextDB(registrar.activity(), androidDBPath, "Vcs@1234");
                        Log.e("found encripted", "found encripted");
                        Utils.copyFile(new File(androidDBPath), new File(flutterDBPath));
                        Log.e("found encripted", "found encripted copy done");
                        Thread.sleep(2000);
                        Utils.deleteFiles(new File(androidDBPath));
                        Thread.sleep(1000);
                        result.success("done");
                    } else {
                        Log.e("not encripted", "not encripted");
                        result.success("notEncripted");
                    }
                } else {
                    result.success("AndroidNotFound");
                }
            } catch (Exception e) {
                e.printStackTrace();
                result.success("CRASH");
            }*/
        } else if (call.method.equalsIgnoreCase("syncronizeData")) {
            if (checkAndRequestPermissions(registrar.activity())) {
                if (call.hasArgument("UserName")) {
                    String _UserName = call.argument("UserName");
                    String _fk_EmpGlCode = call.argument("fk_EmpGlCode");
                    String _ClientName = call.argument("ClientName");
                    String _imei = call.argument("imei");
                    String _version = call.argument("version");
                    String packageName = call.argument("packageName");
                    String _logUploadMethod = call.argument("uploadMethod");
                    String _urlUpload = call.argument("urlUpload");
                    String databaseName = call.argument("databaseName");
                    String dbPassword = call.argument("dbPassword");
                    String isDbEncripted = call.argument("isDbEncripted");
                    String methodSyncID = call.argument("methodSyncID");

                    String fkCustomerGlCode = call.argument("fkCustomerGlCode");
                    String DeviceSyncStatus = call.argument("DeviceSyncStatus");
                    String CustomerCode = call.argument("CustomerCode");
                    String SystemName = call.argument("SystemName");
                    String LastSyncDate = call.argument("LastSyncDate");
                    String ServerSyncId = call.argument("ServerSyncId");
                    String serviceAPIKe = call.argument("serviceAPIKey");

                    if (_UserName != null && !_UserName.isEmpty()) {
//                        if(!packageName.equalsIgnoreCase("") && packageName.equalsIgnoreCase("com.ecubix.basflab")){
//                            SyncDataOptimized syncData = new SyncDataOptimized(registrar.activity(), fileSyncCallBack);
//                            syncData.startSyncData(_UserName, _fk_EmpGlCode, _ClientName, _imei, _version, packageName, _logUploadMethod, _urlUpload, databaseName, dbPassword, isDbEncripted, methodSyncID);
//                        }else {

                        SyncData syncData = new SyncData(registrar.activity(), fileSyncCallBack);
                        syncData.startSyncData(_UserName, _fk_EmpGlCode, _ClientName, _imei, _version, packageName, _logUploadMethod, _urlUpload, databaseName, dbPassword, isDbEncripted, methodSyncID, fkCustomerGlCode, DeviceSyncStatus, CustomerCode, SystemName, LastSyncDate, ServerSyncId, serviceAPIKe);
//                        }
                    } else {
                        result.error("UNAVAILABLE", "Perameters not available.", null);
                    }
                } else {
                    result.error("UNAVAILABLE", "Perameters not available.", null);
                }
            }
        } else if (call.method.equalsIgnoreCase("encodeData")) {
            if (call.hasArgument("details") && call.hasArgument("key")) {
                String details = call.argument("details");
                String key = call.argument("key");
                try {

                    try {
                        String encStr;
                        if (key != null) {
                            encStr = encriptionDetails.Encrypt(details, key);
                            result.success(encStr);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        result.error("UNAVAILABLE", "-" + e.getMessage(), null);
                    }


                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    result.success("error:" + e.getMessage());
                }

            } else {
                result.error("UNAVAILABLE", "perameters not found", null);
            }
        } else if (call.method.equalsIgnoreCase("RE_Encryption")) {
            if (call.hasArgument("details") && call.hasArgument("key")) {
                String details = call.argument("details");
                String key = call.argument("key");
                try {

                    try {
                        String encStr;
                        if (key != null) {
                            encStr = AesCipher.encrypt(details, key);
                            result.success(encStr);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        result.error("UNAVAILABLE", "-" + e.getMessage(), null);
                    }


                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    result.success("error:" + e.getMessage());
                }

            } else {
                result.error("UNAVAILABLE", "perameters not found", null);
            }
        } else if (call.method.equalsIgnoreCase("RE_Description")) {
            if (call.hasArgument("details") && call.hasArgument("key")) {
                String details = call.argument("details");
                String key = call.argument("key");
                try {

                    try {
                        String encStr;
                        if (key != null) {
                            encStr = AesCipher.decrypt(details, key);
                            result.success(encStr);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                        result.error("UNAVAILABLE", "-" + e.getMessage(), null);
                    }


                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    result.success("error:" + e.getMessage());
                }

            } else {
                result.error("UNAVAILABLE", "perameters not found", null);
            }
        } else if (call.method.equalsIgnoreCase("decodeData")) {
            if (call.hasArgument("details") && call.hasArgument("key")) {
                String details = call.argument("details");
                String key = call.argument("key");

                try {
                    assert key != null;
                    String encStr = encriptionDetails.Decrypt(details, key);
                    result.success(encStr);
                } catch (Exception e) {
                    e.printStackTrace();
                    result.error("UNAVAILABLE", "-" + e.getMessage(), null);
                }

            } else {
                result.error("UNAVAILABLE", "perameters not found", null);
            }
        } else if (call.method.equalsIgnoreCase("UniqueNumber")) {

            try {
                String encStr = encriptionDetails.getUniqueNumber(registrar.context());
                result.success(encStr);
            } catch (Exception e) {
                e.printStackTrace();
                result.error("UNAVAILABLE", "-" + e.getMessage(), null);
            }

        } else if (call.method.equalsIgnoreCase("stopScanDeviceChiperLab")) {
            registrar.activity().unregisterReceiver(myDataReceiver);
            try {
                if (mReaderManager != null) {

                    ReaderOutputConfiguration settings = new ReaderOutputConfiguration();
                    mReaderManager.Get_ReaderOutputConfiguration(settings);
                    settings.enableKeyboardEmulation = KeyboardEmulationType.InputMethod;
                    //settings.enableKeyboardEmulation = Enable_State.FALSE;
                    mReaderManager.Set_ReaderOutputConfiguration(settings);

                    mReaderManager.Release();
                    Log.e("mReaderManager", "stoped");
                    result.success("done");
                }
            } catch (Exception e) {
                e.printStackTrace();
                result.success("not done");
            }

        } else if (call.method.equalsIgnoreCase("startScanDeviceChiperLab")) {

            mReaderManager = ReaderManager.InitInstance(registrar.activity());

            IntentFilter filter = new IntentFilter();
            filter.addAction(com.cipherlab.barcode.GeneralString.Intent_SOFTTRIGGER_DATA);
            filter.addAction(com.cipherlab.barcode.GeneralString.Intent_PASS_TO_APP);
            filter.addAction(com.cipherlab.barcode.GeneralString.Intent_READERSERVICE_CONNECTED);
            registrar.activity().registerReceiver(myDataReceiver, filter);
            Log.e("mReaderManager", "started");
            result.success("done");
        } else if (call.method.equalsIgnoreCase("scanBarCodes")) {
            Log.e("scanBarCodes", "scanBarCodes");
//            if (checkAndRequestPermissions(registrar.activity())) {
//
//                registrar.activity().registerReceiver(mReceiver, new IntentFilter("ScanResult"));
//
//                String isGoogleVision = call.argument("isGoogleVision");
//                String isSingleScan = call.argument("isSingleScan");
//                String isPlaySound = call.argument("isPlaySound");
//                String isOnFlase = call.argument("isOnFlase");
//                String themeColor = call.argument("themeColor");
//                String nextBtn = call.argument("nextBtn");
//                String scanText = call.argument("scanText");
//
//                if (isGoogleVision.equalsIgnoreCase("false")) {
//                    Intent i = new Intent(registrar.activity(), CameraBasfActivity.class);
//                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    i.putExtra("isSingleScan", isSingleScan);
//                    i.putExtra("isPlaySound", isPlaySound);
//                    i.putExtra("isOnFlase", isOnFlase);
//                    i.putExtra("themeColor", themeColor);
//                    i.putExtra("nextBtn", nextBtn);
//                    i.putExtra("scanText", scanText);
//                    registrar.context().startActivity(i);
//                    result.success("done");
//                } else {
//                    //zydus check
//                    Intent intent = new Intent(registrar.activity(), BarcodeCaptureActivity.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////                    intent.putExtra(AbstractCaptureActivity.AUTO_FOCUS, true);
////                    intent.putExtra(AbstractCaptureActivity.USE_FLASH, false);
////                    intent.putExtra(AbstractCaptureActivity.FORMATS, Barcode.ALL_FORMATS);
////                    intent.putExtra(AbstractCaptureActivity.MULTIPLE, false);
////                    intent.putExtra(AbstractCaptureActivity.WAIT_TAP, false);
////                    intent.putExtra(AbstractCaptureActivity.SHOW_TEXT, false);
////                    intent.putExtra(AbstractCaptureActivity.PREVIEW_WIDTH, 640);
////                    intent.putExtra(AbstractCaptureActivity.PREVIEW_HEIGHT, 480);
////                    intent.putExtra(AbstractCaptureActivity.CAMERA, CameraSource.CAMERA_FACING_BACK);
////                    intent.putExtra(AbstractCaptureActivity.FPS, 15.0f);
//                    intent.putExtra(BarcodeCaptureActivity.AutoFocus, true);
//                    intent.putExtra("isSingleScan", isSingleScan);
//                    intent.putExtra("isPlaySound", isPlaySound);
//                    intent.putExtra("isOnFlase", isOnFlase);
//                    intent.putExtra("themeColor", themeColor);
//                    intent.putExtra("nextBtn", nextBtn);
//                    intent.putExtra("scanText", scanText);
//                    registrar.context().startActivity(intent);
//                    result.success("done");
//                    //BarcodeCaptureActivity
//                }
//            }
        } else if (call.method.equalsIgnoreCase("checkPermission")) {
            Log.e("checkPermission", "checkPermission");
            if (checkAndRequestPermissions(registrar.activity())) {
                result.success("true");
            } else {
                result.success("false");
            }
        } else if (call.method.equalsIgnoreCase("scanQRCodeViaSDK")) {
            sendBroadCastDetails(777, "PS::Start Progress", 0);
            CustomerSDK.configSDK(registrar.activity(), "https://ar2demo.AccessReal.com:443",
                    "eb501afb0f724ad790a6a721a07df293","SecretKey_f990ff0deb114532803303c12cb9e232", "en_US", new CustomerSDK.ConfigInterface() {
                        @Override
                        public void setConfigResult(ResultBean response) {

//                            sendBroadCastDetails(777, "PS", 0);

                            ChallengeResponse challengeResponse = new ChallengeResponse();
                            ChallengeResponse.ChallengeResponseBean challengeResponseBean = new ChallengeResponse.ChallengeResponseBean();
                            challengeResponseBean.setAuthenticationId("");
                            challengeResponseBean.setChallengeCode("");
                            challengeResponseBean.setResponse("");
                            challengeResponse.setChallengeResponse(challengeResponseBean);
                            Options options = new Options();
                            Options.OptionsBean optionsBean = new Options.OptionsBean();
                            optionsBean.setResponseTemplate("1,2,3");
                            options.setOptions(optionsBean);

                            ScanOptions scanOptions = new ScanOptions();
                            scanOptions.setFlashEnabled(true);
                            scanOptions.setFlashControlEnable(true);
                            scanOptions.setSkipActive(true);
                            scanOptions.setSkipARCodeAuthentication(false);
                            scanOptions.setCameraScale(10);
                            LocationBean locationBean = new LocationBean();
                            locationBean.setLat(0.0);
                            locationBean.setLng(0.0);


                            CustomerSDK.presentScanAuthenticate(registrar.activity(), 0, "", locationBean, challengeResponse, "en_US", options, scanOptions, new CustomerSDK.MainInterface() {
                                @Override
                                public void setUaidResult(SendCustomerDataBean response) {
                                    Log.e("==response==","===response==="+response);

                                    if (response.getCode().equals("0")) {//有验证结果

                                        String stuString = GsonUtils.beanToString(response);
//                                        Intent it = new Intent(Act_Main.this, Act_UaidInfo.class);
//                                        Bundle args = new Bundle();
//                                        args.putString("SendCustomerDataBean", stuString);
//                                        it.putExtras(args);
//                                        startActivity(it);
//                                        loadingDialog.dismisDialog();
                                        sendBroadCastDetails(777, "PD::"+stuString, 0);
                                    } else {   //只有SDK的返回值
                                        String text = "", result;
                                        int resultCode = getData(response.getArCode().getExtendedData());
                                        text = getDataText(response.getArCode().getExtendedData());
                                        if (resultCode == 999 || resultCode == -1) {
                                            result = "Retry";
                                        } else if (resultCode == 0 && text.length() > 0) {
                                            result = "Pass";
                                        } else {
                                            result = "Fail";
                                        }
                                        performScanOwn(text.length() > 0 ? text : "Non", response.getArCode().getExtendedData(), resultCode);

//                                        customDialog(result, true, text);
//                                        sendBroadCastDetails(777, "PD::Stop Progress", 0);
                                    }
                                }
                            });
                        }
                    });

        } else if (call.method.equalsIgnoreCase("getTimeFromUTC")) {
            String date = call.argument("date");
            String format = call.argument("format");
            try {
                String dt = Utils.getTimeFromUTC(date, format);
                result.success(dt);
            } catch (Exception e) {
                e.printStackTrace();
                result.success("error");
            }
        } else if (call.method.equalsIgnoreCase("syncronizeDataFile")) {
            //if (checkWriteExternalPermission()) {
            if (call.hasArgument("UserName")) {
                String UserName = call.argument("UserName");
                String fk_EmpGlCode = call.argument("fk_EmpGlCode");
                String ClientName = call.argument("ClientName");
                String imei = call.argument("imei");
                String version = call.argument("version");
                String packageName = call.argument("packageName");
                String uploadMethod = call.argument("uploadMethod");
                String logUploadMethod = call.argument("logUploadMethod");
                String urlUpload = call.argument("urlUpload");
                String databaseName = call.argument("databaseName");
                Log.e("syncronizeDataFile:", "params:" + UserName);
                String dbPassword = call.argument("dbPassword");
                String isDbEncripted = call.argument("isDbEncripted");

                String fkCustomerGlCode = call.argument("fkCustomerGlCode");
                String DeviceSyncStatus = call.argument("DeviceSyncStatus");
                String CustomerCode = call.argument("CustomerCode");
                String SystemName = call.argument("SystemName");
                String LastSyncDate = call.argument("LastSyncDate");
                String ServerSyncId = call.argument("ServerSyncId");
                String serviceAPIKe = call.argument("serviceAPIKey");

                if (UserName != null && !UserName.isEmpty()) {
                    // Change by Dhaval Patel
//                        if(packageName.equals(BASF_LAB_PACKAGE_NAME)) {
//                            LabFileSyncTask fileSyncTask = new LabFileSyncTask(getActiveContext(), fileSyncCallBack, UserName, fk_EmpGlCode, ClientName, imei, version, packageName, uploadMethod, logUploadMethod, urlUpload, databaseName, dbPassword, isDbEncripted);
//                            fileSyncTask.execute();
//                        } else {
                    FileSyncTask fileSyncTask = new FileSyncTask(registrar.activity(), fileSyncCallBack, UserName, fk_EmpGlCode, ClientName, imei, version, packageName, uploadMethod, logUploadMethod, urlUpload, databaseName, dbPassword, isDbEncripted, fkCustomerGlCode, DeviceSyncStatus, CustomerCode, SystemName, LastSyncDate, ServerSyncId, serviceAPIKe);
                    fileSyncTask.startSyncDataFile();
//                        }
                } else {
                    result.error("UNAVAILABLE", "Perameters not available.", null);
                }
            } else {
                result.error("UNAVAILABLE", "Perameters not available.", null);
            }
            /*} else {
                sendBroadCastDetails(2, "storage permission not granted", 0);
                result.error("UNAVAILABLE", "storage permission not granted", null);
            }*/
        } else if (call.method.equalsIgnoreCase("checkInternet")) {
            boolean isNet = isNetworkConnected(registrar.context());
            //&& hasActiveInternetConnection()
            if (isNet) result.success("true");
            else result.success("false");
        } else if (call.method.equalsIgnoreCase("checkBarCode")) {
            String code = call.argument("code");
            assert code != null;
            String finalCode = Utils.getSerialNoFromBarcode(code, true);
            result.success(finalCode);
        } else if (call.method.equalsIgnoreCase("checkBarCode16")) {
            String code = call.argument("code");
            assert code != null;
            String finalCode = Utils.getSerialNoFromBarcode16(code, true);
            result.success(finalCode);
        } else if (call.method.equalsIgnoreCase("pickFileFromGallary")) {
            /*String numberOfFiles = call.argument("numberOfFiles");
            FilePickerBuilder.Companion.getInstance().setMaxCount(Integer.parseInt(numberOfFiles) > 0 ? Integer.parseInt(numberOfFiles) : 1)
                    //.setSelectedFiles(filePaths)
                    .setActivityTheme(R.style.LibAppTheme)
                    .pickPhoto(registrar.activity());*/
        } else {
            result.notImplemented();
        }
    }

    private int getData(String extendedData) {
        int resultCode = -1;
        JSONObject containerObject = null;
        try {
            if (extendedData != null) {
                containerObject = new JSONObject(extendedData);
                if (containerObject.has("resultCode")) {
                    resultCode = containerObject.optInt("resultCode");
                }
            }
        } catch (JSONException e) {
            resultCode = -1;
        }
        return resultCode;
    }

    private String getDataText(String extendedData) {
        String text = "";
        JSONObject containerObject = null;
        try {
            if (extendedData != null) {
                containerObject = new JSONObject(extendedData);
                if (containerObject.has("text")) {
                    text = containerObject.optString("text");
                }
            }
        } catch (JSONException e) {
            text = extendedData;
        }
        return text;
    }

    static String getDeviceInformation() {
        return "Device Manufacturer: " + Build.MANUFACTURER + "\n";
//                "Device Model: " + Build.MODEL + "\n" +
//                "Device Brand: " + Build.BRAND + "\n" +
//                "Device Product: " + Build.PRODUCT + "\n" +
//                "Android Version: " + Build.VERSION.RELEASE + "\n" +
//                "SDK Version: " + Build.VERSION.SDK_INT + "\n" +
//                "Device ID: " + Build.DEVICE + "\n" +
//                "Hardware: " + Build.HARDWARE + "\n" +
//                "Serial Number: " + Build.SERIAL + "\n";
    }


    private void performScanOwn(String scanCode, String result, int resultCode) {
//        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
//        String userID = sharedPreferences.getString("userID", "");
//        String latitude = sharedPreferences.getString("latitude", "0.0");
//        String longitude = sharedPreferences.getString("longitude", "0.0");
        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        @SuppressLint("HardwareIds") Call<ScanResponse> call = apiService.scanData(getDeviceInformation(),
                Build.BRAND, "25441ed0d8974738", "0.0" + "", "0.0" + "", scanCode.length() > 0 ? scanCode : "Non", result + "", resultCode + "", "3");
        call.enqueue(new Callback<ScanResponse>() {
            @Override
            public void onResponse(Call<ScanResponse> call, Response<ScanResponse> response) {
                if(response.isSuccessful()){
                    response.body(); // have your all data
                    boolean status =response.body().getStatus();
                    String message = response.body().getMessage();
                    String responseCode = response.body().getResponseCode();
                    if(status){
                        String responseResult="";
                        if(responseCode.equalsIgnoreCase("0")){

                            responseResult="Pass";
                            customDialog(responseResult, true, scanCode);
                            sendBroadCastDetails(777, "PD::Stop Progress", 0);
                        }else if(responseCode.equalsIgnoreCase("1")){
                            responseResult="Fail";
                            customDialog(responseResult, true, scanCode);
                            sendBroadCastDetails(777, "PD::Stop Progress", 0);
                        }else if(responseCode.equalsIgnoreCase("-1")){
                            responseResult="Retry";
                            sendBroadCastDetails(888, "PResult::"+result, 0);
                            sendBroadCastDetails(888, "PD::Stop Progress", 0);

                        }
                        Log.e("responseResult===",responseResult);
                        Log.e("responseCode====",responseCode);

                    }

                }
            }

            @Override
            public void onFailure(Call<ScanResponse> call, Throwable t) {
                t.printStackTrace();
//                loadingDialog.dismisDialog();
            }
        });
    }

    @SuppressLint("ResourceType")
    private void customDialog(String result, Boolean isValidUrl, String text) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Tips");
//
//        // set the custom layout
//        final View customLayout = getLayoutInflater().inflate(R.layout.custom_dialog, null);
//        TextView textQrCodeValue= customLayout.findViewById(R.id.textQrValue);
//        if(isValidUrl){
//            textQrCodeValue.setText(text);
//            textQrCodeValue.setTextColor(ContextCompat.getColor(Act_Main.this, getResources().getColor(R.color.some_color)));
//        }
//        builder.setView(customLayout);
//        // create and show the alert dialog
//        AlertDialog dialog = builder.create();
//        dialog.show();

        Log.e("==text==","===text==="+text);
        Log.e("==result==","===result==="+result);

        sendBroadCastDetails(777, "PData::"+text, 0);
        sendBroadCastDetails(777, "PResult::"+result, 0);
        /*final TextView message = new TextView(registrar.activity());
        final SpannableString s =
                new SpannableString("QR Code :: " + text + "\n\n " + "Result :: " + result + "\n");

        Linkify.addLinks(s, Linkify.WEB_URLS);
//        message.setLinkTextColor(android.R.color.holo_blue_light);
        message.setText(s);
        message.setMovementMethod(LinkMovementMethod.getInstance());

        final AlertDialog d = new AlertDialog.Builder(Act_Main.this, R.style.MyDialogTheme)
                .setPositiveButton(android.R.string.ok, null)
                .setIcon(R.mipmap.ic_launcher_round)
                .setMessage(s)
                .create();

        d.show();

        // Make the textview clickable. Must be called after show()
        ((TextView) d.findViewById(android.R.id.message)).setMovementMethod(LinkMovementMethod.getInstance());*/
    }

    private boolean isNetworkConnected(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        @SuppressLint("MissingPermission")
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }

    private boolean hasActiveInternetConnection() {
        boolean issend;
        if (android.os.Build.VERSION.SDK_INT <= 27) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll()
                    .build();
            StrictMode.setThreadPolicy(policy);
            //}
            try {
                URL url = new URL("http://www.google.com");
                HttpURLConnection urlc = (HttpURLConnection) (url.openConnection());
                urlc.setRequestProperty("User-Agent", "Test");
                urlc.setRequestProperty("Connection", "close");
                urlc.setConnectTimeout(1500);
                urlc.connect();
                Log.e("Utils", "Active internet connection");
                issend = (urlc.getResponseCode() == 200);
            } catch (IOException e) {
                Log.e("Utils ret false", "Error checking internet connection", e);
                issend = false;
            }
            return issend;
        } else {
            return true;
        }
    }

    private void sendBroadCastDetails(int type, String details, int progress) {
        //type = 1 => progress, 2 => errors, 3 => sync complate
        Log.e("sendBroadCastDetails", "sendBroadCastDetails");
        Intent intent = new Intent(update_progress);
        intent.putExtra("type", type);
        intent.putExtra("progress", progress);
        intent.putExtra("details", details);
        this.registrar.context().sendBroadcast(intent);
    }

    private BroadcastReceiver createChargingStateChangeReceiver(final EventChannel.EventSink events) {
        return new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                int type = intent.getIntExtra("type", -1);
                int progress = intent.getIntExtra("progress", -1);
                String Details = intent.getStringExtra("details");

                Map<String, String> parameterPost = new HashMap<>();
                parameterPost.clear();
                parameterPost.put("type", String.valueOf(type));
                parameterPost.put("progress", String.valueOf(progress));
                parameterPost.put("Details", Details);

                events.success(parameterPost);
            }
        };
    }


    /*private boolean checkWriteExternalPermission() {
        String permission = android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
        int res = registrar.context().checkCallingOrSelfPermission(permission);
        return (res == PackageManager.PERMISSION_GRANTED);
    }*/


    private static boolean checkAndRequestPermissions(Activity context) {
        if (Build.VERSION.SDK_INT >= 23) {
            int locationPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION);
            int cameraPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA);
            //int contactsPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS);
//            int receiveSMSPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS);
            //int permissionStorage = ContextCompat.checkSelfPermission(this,
            //    Manifest.permission.WRITE_EXTERNAL_STORAGE);

            List<String> listPermissionsNeeded = new ArrayList<>();
            if (locationPermission != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.ACCESS_FINE_LOCATION);
            }
            /**/
            if (cameraPermission != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.CAMERA);
            }
            /*if (contactsPermission != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(Manifest.permission.GET_ACCOUNTS);
            }*/

            //if (receiveSMSPermission != PackageManager.PERMISSION_GRANTED) {
            //  listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
            //}

            if (Build.VERSION.SDK_INT <= 28) {
                int permissionStorage1 = ContextCompat.checkSelfPermission(context,
                        Manifest.permission.READ_EXTERNAL_STORAGE);
                if (permissionStorage1 != PackageManager.PERMISSION_GRANTED) {
                    listPermissionsNeeded.add(Manifest.permission.READ_EXTERNAL_STORAGE);
                }

                int permissionStorage = ContextCompat.checkSelfPermission(context,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE);
                if (permissionStorage != PackageManager.PERMISSION_GRANTED) {
                    listPermissionsNeeded.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                }
            }

            if (Build.VERSION.SDK_INT <= 29) {
                int callPhonePermission = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE);
                if (callPhonePermission != PackageManager.PERMISSION_GRANTED) {
                    listPermissionsNeeded.add(Manifest.permission.READ_PHONE_STATE);

                }
            }

            if (!listPermissionsNeeded.isEmpty()) {
                //ActivityCompat.requestPermissions(context, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_ID_MULTIPLE_PERMISSIONS);
                ActivityCompat.requestPermissions(context, listPermissionsNeeded.toArray(new String[0]), REQUEST_ID_MULTIPLE_PERMISSIONS);
                return false;
            }
        }
        return true;
    }


    public static boolean detailsPermission(int requestCode,
                                            @NonNull String[] permissions, @NonNull int[] grantResults, Activity context) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        String TAG = "Permission";
        Log.d(TAG, "Permission callback called-------");
        if (requestCode == REQUEST_ID_MULTIPLE_PERMISSIONS) {
            Map<String, Integer> perms = new HashMap<>();
            // Initialize the map with both permissions

            perms.put(Manifest.permission.ACCESS_FINE_LOCATION, PackageManager.PERMISSION_GRANTED);
            perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);


            //perms.put(Manifest.permission.GET_ACCOUNTS, PackageManager.PERMISSION_GRANTED);
//            perms.put(Manifest.permission.RECEIVE_SMS, PackageManager.PERMISSION_GRANTED);
            if (Build.VERSION.SDK_INT <= 28) {
                perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
            }
            if (Build.VERSION.SDK_INT <= 29) {
                perms.put(Manifest.permission.READ_PHONE_STATE, PackageManager.PERMISSION_GRANTED);
            }

            // Fill with actual results from user
            if (grantResults.length > 0) {
                for (int i = 0; i < permissions.length; i++)
                    perms.put(permissions[i], grantResults[i]);
                // Check for both permissions
                if (Build.VERSION.SDK_INT <= 28) {
                    if (perms.get(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        Log.d(TAG, "All permission granted");
                        return true;
                    } else {
                        Log.d(TAG, "Some permissions are not granted ask again ");
                        if (ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.ACCESS_FINE_LOCATION)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.CAMERA)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.READ_EXTERNAL_STORAGE)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.READ_PHONE_STATE)) {
                            return false;
                        } else {
                            showAlertWithOkButtonCallback(2, "Some Permission required for use this app.", "", context);
                            return false;
                        }
                    }
                } else if (Build.VERSION.SDK_INT <= 29) {
                    if (perms.get(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        Log.d(TAG, "All permission granted");
                        return true;
                    } else {
                        Log.d(TAG, "Some permissions are not granted ask again ");
                        if (ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.ACCESS_FINE_LOCATION)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.CAMERA)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.READ_PHONE_STATE)) {
                            return false;
                        } else {
                            showAlertWithOkButtonCallback(2, "Some Permission required for use this app.", "", context);
                            return false;
                        }
                    }
                } else {
                    if (perms.get(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        Log.d(TAG, "All permission granted");
                        return true;
                    } else {
                        Log.d(TAG, "Some permissions are not granted ask again ");
                        if (ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.ACCESS_FINE_LOCATION)
                                || ActivityCompat.shouldShowRequestPermissionRationale(context, Manifest.permission.CAMERA)) {
                            return false;
                        } else {
                            showAlertWithOkButtonCallback(2, "Some Permission required for use this app.", "", context);
                            return false;
                        }
                    }
                }

            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    private static void showAlertWithOkButtonCallback(final int type, String text, String
            app_name, final Activity activity) {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(activity);
        builder.setTitle(app_name);
        builder.setMessage(text);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (type == 1) {
                    checkAndRequestPermissions(activity);
                } else {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.fromParts("package", activity.getPackageName(), null));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(intent);
                }
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    private final FileSyncCallBack fileSyncCallBack = new FileSyncCallBack() {
        @Override
        public void onFileSyncResponse(int type, String details, int progress) {
            sendBroadCastDetails(type, details, progress);
        }
    };
}
