package ecp.vcs.com.ecpsyncplugin.dbSync;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.util.Base64;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestTickle;
import com.android.volley.Response;
import com.android.volley.error.AuthFailureError;
import com.android.volley.error.NetworkError;
import com.android.volley.error.NoConnectionError;
import com.android.volley.error.ParseError;
import com.android.volley.error.ServerError;
import com.android.volley.error.TimeoutError;
import com.android.volley.error.VolleyError;
import com.android.volley.request.JsonObjectRequest;
import com.android.volley.request.JsonRequest;
import com.android.volley.request.StringRequest;
import com.android.volley.toolbox.VolleyTickle;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import ecp.vcs.com.ecpsyncplugin.Utils;
import ecp.vcs.com.ecpsyncplugin.filesync.AppIdentifyService;
import ecp.vcs.com.ecpsyncplugin.filesync.CommonFunctionLib;
import ecp.vcs.com.ecpsyncplugin.filesync.FileSyncCallBack;

public class SyncData extends BaseTimmerClass {

    private final Context context;
    private final FileSyncCallBack callBack;
    //private static final String update_progress = "update_progress";
    /*private static final String ECTERNAL_STORAGE_ROOT = "" + Environment
            .getExternalStorageDirectory();

    private static final String ECTERNAL_STORAGE_APP_ROOT = "" + ECTERNAL_STORAGE_ROOT + "/" +
            "Flut12er02app19/com.vcs.ecp";
    private static final String ECTERNAL_STORAGE_APP_SYNC_ROOT = "" + ECTERNAL_STORAGE_APP_ROOT +
            "/SyncBackup";
    private static final String ECTERNAL_STORAGE_APP_DOWNLOAD = "" +
            ECTERNAL_STORAGE_APP_SYNC_ROOT + "/Download";
    private static final String ECTERNAL_STORAGE_APP_UPLOAD = "" + ECTERNAL_STORAGE_APP_SYNC_ROOT
            + "/Upload";*/
    private static String URLDownloadDB = "";
    private String fk_EmpGlCode = "";
    private String ClientName = "";
    private String imei = "";
    private String version = "";
    private String UserName = "";
    private String urlUpload = "";
    private String logUploadMethod = "";
    private String customerId = "";
    private String packageNameIFFCO = "";
    private int syncID = 0;
    private static String responseMsg = "";
    //private String APP_BASF_RE = "com.ecubix.basf";
    private final String APP_DATA_LOGGER = "com.ecubix.vcs.datalogger";
    private final String APP_IFFCO_CPM = "com.ecubix.iffcocpm";
    JSONObject requestJSON;
    JSONObject syncJSON;


    private static String ECTERNAL_STORAGE_ROOT(Context context) {
        return context.getFilesDir().getAbsolutePath();
    }

    private static String ECTERNAL_STORAGE_APP_ROOT(Context context) {
        return ECTERNAL_STORAGE_ROOT(context) + "/" + "Flut12er02app19/com.vcs.ecp";
    }

    public static String ECTERNAL_STORAGE_APP_SYNC_ROOT(Context context) {
        return ECTERNAL_STORAGE_APP_ROOT(context) + "/SyncBackup";
    }

    private static String ECTERNAL_STORAGE_APP_DOWNLOAD(Context context) {
        return ECTERNAL_STORAGE_APP_SYNC_ROOT(context) + "/Download";
    }

    private static String ECTERNAL_STORAGE_APP_UPLOAD(Context context) {
        return ECTERNAL_STORAGE_APP_SYNC_ROOT(context) + "/Upload";
    }

    public SyncData(Context _context, FileSyncCallBack _callBack) {
        this.context = _context;
        this.callBack = _callBack;
        requestJSON = new JSONObject();
        syncJSON = new JSONObject();
    }



    public void startSyncData(String _UserName,
                              String _fk_EmpGlCode,
                              String _ClientName,
                              String _imei,
                              String _version,
                              String packageName,
                              String _logUploadMethod,
                              String _urlUpload,
                              String databaseName,
                              String dbPassword,
                              String isDbEncripted,
                              String methodSyncID,
                              String fkCustomerGlCode,
                              String DeviceSyncStatus,
                              String CustomerCode,
                              String SystemName,
                              String LastSyncDate,
                              String ServerSyncId,
                              String serviceAPIKe) {

        UserName = _UserName;
        fk_EmpGlCode = _fk_EmpGlCode;
        ClientName = _ClientName;
        imei = _imei;
        version = _version;
        urlUpload = _urlUpload;
        logUploadMethod = methodSyncID;
        customerId = fkCustomerGlCode;
        packageNameIFFCO = packageName;
        lastProgress = 0;

        new LongOperation().execute(_UserName, _fk_EmpGlCode, _ClientName, _imei, _version, packageName, _logUploadMethod, _urlUpload, databaseName, dbPassword, isDbEncripted, fkCustomerGlCode, DeviceSyncStatus, CustomerCode, SystemName, LastSyncDate, ServerSyncId, serviceAPIKe);
    }

    @Override
    public void updateAutoProcessDetails(int progress) {
        sendBroadCastDetails(1, "Update Count Auto", progress);
    }

    private class LongOperation extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            File tempFileDownload = new File(SyncData.ECTERNAL_STORAGE_APP_DOWNLOAD(context));
            if (tempFileDownload.exists()) {
                Utils.DeleteRecursive(tempFileDownload);
            }

            File tempFileUpload = new File(SyncData.ECTERNAL_STORAGE_APP_UPLOAD(context));
            if (tempFileUpload.exists()) {
                Utils.DeleteRecursive(tempFileUpload);
            }

            File tempFile1 = new File(SyncData.ECTERNAL_STORAGE_APP_DOWNLOAD(context));
            if (!tempFile1.exists()) {
                //noinspection ResultOfMethodCallIgnored
                tempFile1.mkdirs();
            }

            File tempFile2 = new File(SyncData.ECTERNAL_STORAGE_APP_UPLOAD(context));
            if (!tempFile2.exists()) {
                //noinspection ResultOfMethodCallIgnored
                tempFile2.mkdirs();
            }

            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String doneItem = SyncDB(params[0], params[1], params[2], params[3], params[4], params[5], params[6], params[7], params[8], context, params[9], params[10], params[11], params[12], params[13], params[14], params[14], params[15], params[16]);
            //return "";

            if (!doneItem.equalsIgnoreCase("done")) {
                responseMsg = doneItem;
            }

            // condition for data logger
            if (!params[5].equalsIgnoreCase(APP_DATA_LOGGER)) {
                if (doneItem.equalsIgnoreCase("done")) {
                    startIntentService("Y");
                } else {
                    startIntentService("N");
                }
            }

            try {
                Thread.sleep(2000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            File tempFileRoot = new File(SyncData.ECTERNAL_STORAGE_APP_SYNC_ROOT(context));
            if (tempFileRoot.exists()) {
                Utils.DeleteRecursive(tempFileRoot);
            }

            return doneItem;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && result.equalsIgnoreCase("done")) {

                sendBroadCastDetails(3, responseMsg, 100);
            } else {
                sendBroadCastDetails(2, result, lastProgress);
            }
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private String SyncDB(String UserName, String fk_EmpGlCode, String ClientName, String imei, String
            strVersion, String packageName, String uploadMethod, String urlUpload, String DATABASE_NAME,
                          Context context, String dbPassword, String isDbEncripted, String fkCustomerGlCode,
                          String DeviceSyncStatus, String CustomerCode, String SystemName, String LastSyncDate,
                          String ServerSyncId, String serviceAPIKe) {

        Utils.writeJSONFile(requestJSON, "SYNC_START", Utils.getCurrentDateTime());

        String tempName = Utils.GetCurrentDate("ddMMyyyy_HHmmss") + "_" + UserName;
        String fName = tempName + "_ecp_mobile.db";
        String fZipName = tempName + "_ecp_mobile.zip";
        String exportPath = ECTERNAL_STORAGE_APP_UPLOAD(context);
        Calendar calendar = Calendar.getInstance();
        int WDAY = calendar.get(Calendar.DAY_OF_WEEK);

        String dataDirPath = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + DATABASE_NAME;

        //Utils.writeTextFile("---Export Database Start---", context);
        Utils.writeJSONFile(syncJSON, "1", "---Export Database Start---");
        Utils.writeJSONFile(requestJSON, "EXPORT_FILE_START", Utils.getCurrentDateTime());
        sendBroadCastDetails(1, "export DB", randInt(1, 5));

        if (exportSyncDbNew(dataDirPath, exportPath, fName, WDAY)) {

            Utils.writeJSONFile(requestJSON, "EXPORT_FILE_END", Utils.getCurrentDateTime());
            Utils.writeJSONFile(syncJSON, "2", "---Export Database End---");
            ////Utils.writeTextFile("---Export Database End---", context);
            sendBroadCastDetails(1, "zip DB", randInt(5, 7));


            Utils.writeJSONFile(requestJSON, "CREATE_ZIP_START", Utils.getCurrentDateTime());
            Utils.writeJSONFile(syncJSON, "3", "---Create Zip File Start---");
            ////Utils.writeTextFile("---Create Zip File Start---", context);

            String zipFilePath = Utils.CreateZipFile(exportPath, fName, fZipName, WDAY, dbPassword, isDbEncripted, context);

            Utils.writeJSONFile(requestJSON, "CREATE_ZIP_END", Utils.getCurrentDateTime());
            Utils.writeJSONFile(syncJSON, "4", "---Create Zip File End---");
            ////Utils.writeTextFile("---Create Zip File End---", context);
            sendBroadCastDetails(1, "upload DB", randInt(7, 9));

            if (!zipFilePath.equalsIgnoreCase("")) {

                Utils.writeJSONFile(requestJSON, "CREATE_ZIP_FILE_NAME", fZipName);
                Utils.writeJSONFile(syncJSON, "5", "---Crate ZIP File Name---" + fZipName);
                ////Utils.writeTextFile("---Crate ZIP File Name---" + fZipName, context);

                String size = checkFileZiseString(zipFilePath);

                Utils.writeJSONFile(requestJSON, "CREATE_ZIP_SIZE", size);
                Utils.writeJSONFile(syncJSON, "6", "---ZIP Size---" + size);
                ////Utils.writeTextFile("---ZIP Size---" + size, context);


                Utils.writeJSONFile(requestJSON, "UPLOAD_API_CALL_START", Utils.getCurrentDateTime());
                Utils.writeJSONFile(syncJSON, "7", "---Upload API call start---");
                ////Utils.writeTextFile("---Upload API call start---", context);
                sendBroadCastDetails(1, "upload DB", randInt(9, 19));
                Log.e("REQUEST JSON==", "----requestJSON----" + requestJSON.toString());

                if (Utils.inNetwork(context)) {
                    String items = UploadDatabaseFileZipOld(urlUpload, fZipName, UserName,
                            fk_EmpGlCode, ClientName, imei, strVersion,
                            context, WDAY, exportPath, uploadMethod, fName,
                            DATABASE_NAME, dataDirPath, packageName, dbPassword,
                            isDbEncripted, "FileUpload", requestJSON.toString(), "", fkCustomerGlCode, DeviceSyncStatus, CustomerCode, SystemName, LastSyncDate, ServerSyncId, serviceAPIKe);
                    Log.e("UploadDFileZipOld", "RETURN:::" + items);
                    Log.e("isTimeOut", "RETURN:::" + isTimeOut);
                    if (isTimeOut) {
                        Log.e("isTimeOut_INNNN", "isTimeOut_INNNN:::" + isTimeOut);
                        multipleRequest(urlUpload, fZipName, UserName,
                                fk_EmpGlCode, ClientName, imei, strVersion,
                                context, WDAY, exportPath, uploadMethod, fName,
                                DATABASE_NAME, dataDirPath, packageName, dbPassword,
                                isDbEncripted, "CHECK_DOWNLOAD",
                                requestJSON.toString(), "",
                                fkCustomerGlCode, DeviceSyncStatus,
                                CustomerCode, SystemName, LastSyncDate,
                                ServerSyncId, serviceAPIKe, 1);
                    } else {
//                        Utils.writeJSONFile(syncJSON, "9999", items);
//                        sendBroadCastDetails(2, "API Call Issue", lastProgress);
                        if(items.equalsIgnoreCase("TIMEOUT!!!!!") || items.isEmpty()){
                            multipleRequest(urlUpload, fZipName, UserName,
                                    fk_EmpGlCode, ClientName, imei, strVersion,
                                    context, WDAY, exportPath, uploadMethod, fName,
                                    DATABASE_NAME, dataDirPath, packageName, dbPassword,
                                    isDbEncripted, "CHECK_DOWNLOAD",
                                    requestJSON.toString(), "",
                                    fkCustomerGlCode, DeviceSyncStatus,
                                    CustomerCode, SystemName, LastSyncDate,
                                    ServerSyncId, serviceAPIKe, 1);
                        }
                    }
                    return items;
                } else {
                    ////Utils.writeTextFile("---No Internet Connection.---", context);
                    Utils.writeJSONFile(syncJSON, "41", "---No Internet Connection.---");
                    sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
                    return "No Internet Connection.";
                }
            } else {
                ////Utils.writeTextFile("---Failed to create zip file---", context);
                Utils.writeJSONFile(syncJSON, "8", "---Failed to create zip file---");
                sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
                return "notdone";
            }
        } else {
            ////Utils.writeTextFile("---Export database Failed---", context);
            Utils.writeJSONFile(syncJSON, "9", "---Export database Failed---");
            sendBroadCastDetails(2, "Export database Failed", lastProgress);
            return "notdone";
        }
    }


    /*private static boolean SdIsPresent() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }*/

    boolean isTimeOut = false;

    private boolean exportSyncDbNew(String dataDirPath, String exportPath, String Filename, int Wday) {

        Log.e("dataDirPath", ":" + dataDirPath);
        Log.e("exportPath", ":" + exportPath);

        /*if (!SdIsPresent())
            return false;*/

        if (new File(dataDirPath).exists()) {
            File exportDir = new File(exportPath + "/" + Wday);
            if (!exportDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                exportDir.mkdirs();
            }
            File file = new File(exportDir, Filename);
            try {
                if (!file.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    file.createNewFile();
                    Utils.copyFile(new File(dataDirPath), file);
                    return true;
                } else {
                    return false;
                }
            } catch (IOException e) {
                ////Utils.writeTextFile("---exportSyncDbNew IOException---" + e.toString(), context);
                Utils.writeJSONFile(syncJSON, "10", "---exportSyncDbNew IOException---");
                sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
                //isFielCopeError = true;
                //fileCopeException = "101: " + Utils.checkErrorReset(Utils.ConvertExceptionToString(e));
                return false;
            }
        } else {
            ////Utils.writeTextFile("---exportSyncDbNew---File not exists--", context);
            Utils.writeJSONFile(syncJSON, "11", "---exportSyncDbNew---File not exists--");
            sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
            //isFielCopeError = true;
            //fileCopeException = "101";
            return false;
        }
    }

    RequestTickle mRequestTickle;
    boolean isCheckDownload=true;
    boolean isProgress=true;
    private String UploadDatabaseFileZipOld(String url, final String strFilename, final String UserName, final String fk_EmpGlCode, final String
            ClientName, String Imei, final String strVersion, final Context context, final int WDAY, final String uploadPath, final String MNDatabaseUpload,
                                            final String fName, final String DATABASE_NAME, final String dataDirPath, final String packageName, final String dbPassword, final String isDbEncripted, final String action, String jsonData, String extraFields, final String fkCustomerGlCode, final String DeviceSyncStatus, final String CustomerCode, final String SystemName, final String LastSyncDate, final String ServerSyncId, final String serviceAPIKe) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String[] strSyncMessage = {"Done"};

        ////Utils.writeTextFile("---Convert DB File---", context);
        Utils.writeJSONFile(syncJSON, "12", "---Convert DB File---");

        try {
            String encodeDb = "";
            byte[] fByte = new byte[0];
            try {
                fByte = Utils.ConvertDBFile(uploadPath, strFilename, context, WDAY);

                if (fByte != null) {
                    //encodeDb = Base64.encodeBytes(fByte);
                    encodeDb = Base64.encodeToString(fByte, Base64.DEFAULT);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

//            if (fByte != null && !encodeDb.equalsIgnoreCase("")) {
//                fByte = null;
            // changePercent(randInt(27, 30));

            if (action.equalsIgnoreCase("Process")) {
                if(isProgress) {
                    isProgress=false;
                    sendBroadCastDetails(1, "upload DB", randInt(35, 35));
                    increaseTimmer(35, 45);
                }
            } else if (action.equalsIgnoreCase("CHECK_DOWNLOAD")){
                if(isCheckDownload) {
                    isCheckDownload=false;
                    sendBroadCastDetails(1, "upload DB", randInt(45, 45));
                    increaseTimmer(45, 60);
                }
            } else {
                sendBroadCastDetails(1, "upload DB", randInt(20, 20));
                increaseTimmer(20, 35);
            }

            //VolleyLog.DEBUG = true;

            StringRequest stringRequest = null;
            JsonObjectRequest stringRequest1 = null;

            mRequestTickle = VolleyTickle.newRequestTickle(context);

            if (packageName.equalsIgnoreCase(APP_DATA_LOGGER)) {

                final JSONObject body = new JSONObject();
                try {

                    JSONArray jsonArrayAuth = new JSONArray();
                    JSONObject jsonObjectAuth = new JSONObject();
                    jsonObjectAuth.put("PersonId", fk_EmpGlCode);
                    jsonObjectAuth.put("Password", "");
                    jsonObjectAuth.put("DeviceIMEI", "");
                    jsonObjectAuth.put("Version", strVersion);
                    jsonObjectAuth.put("Token", "");
                    jsonObjectAuth.put("SubModule", "Device");
                    jsonObjectAuth.put("IsVersionCheck", "Y");
                    jsonArrayAuth.put(jsonObjectAuth);

                    JSONArray jsonArrayData = new JSONArray();
                    JSONObject jsonObjectData = new JSONObject();
                    jsonObjectData.put("FileArray", encodeDb);
                    if (encodeDb != null)
                        encodeDb = null;
                    jsonObjectData.put("FileName", strFilename);
                    jsonArrayData.put(jsonObjectData);

                    final JSONObject Root = new JSONObject();
                    Root.put("Auth", jsonArrayAuth);
                    Root.put("Data", jsonArrayData);

                    body.put("Root", Root);

                    Log.e("Params : ", body.toString());
                } catch (JSONException e) {
                    Log.e("JSONException", e.getMessage());
                    e.printStackTrace();
                }

                stringRequest = new StringRequest(Request.Method.POST, url + "" + MNDatabaseUpload, null,
                        null) {
                    @Override
                    public byte[] getBody() {
                        return body.toString().getBytes();
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }

                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Authorization", "Basic VkNTOlZDUw==");
                        params.put("Content-Type", "application/json");
                        Log.e("getHeaders", params.toString());
                        return params;
                    }
                };

            } else if (packageName.equalsIgnoreCase(APP_IFFCO_CPM)) {
                final Map<String, String> parameterPost = new HashMap<>();
                parameterPost.clear();

                //IFFCO CPM
                parameterPost.put("FileArray", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? "" : encodeDb);
                parameterPost.put("FileName", strFilename.isEmpty() ? "" : strFilename);
                parameterPost.put("DeviceId", Imei.isEmpty() ? "" : Imei);
                parameterPost.put("PersonId", fk_EmpGlCode.isEmpty() ? "" : fk_EmpGlCode);
                parameterPost.put("Version", strVersion.isEmpty() ? "" : strVersion);
                parameterPost.put("SubModuleName", ClientName.isEmpty() ? "" : ClientName);
                parameterPost.put("APIToken", UserName.isEmpty() ? "" : UserName);
                parameterPost.put("Action", action.isEmpty() ? "" : action);
                parameterPost.put("ZipPassword", dbPassword.isEmpty() ? "" : dbPassword);
                parameterPost.put("CustomerId", fkCustomerGlCode.isEmpty() ? "" : fkCustomerGlCode);
                parameterPost.put("DeviceSyncStatus", DeviceSyncStatus.isEmpty() ? "" : DeviceSyncStatus);
                parameterPost.put("CustomerCode", CustomerCode.isEmpty() ? "" : CustomerCode);
                parameterPost.put("SystemName", SystemName.isEmpty() ? "" : SystemName);
                parameterPost.put("LastSyncDate", LastSyncDate.isEmpty() ? "" : LastSyncDate);
                parameterPost.put("ServerSyncId", ServerSyncId.isEmpty() ? "" : ServerSyncId);

                String jsonFull = "{\"Sync_Log\":[" + jsonData + "]}";

                parameterPost.put("JsonData", jsonFull);
                parameterPost.put("ExtraFields", extraFields);
                parameterPost.put("SyncId", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? String.valueOf(syncID) : "");

                Log.e("DB Sync", "====strFilename====" + strFilename);
                Log.e("DB Sync", "====Imei====" + Imei);
                Log.e("DB Sync", "====fk_EmpGlCode====" + fk_EmpGlCode);
                Log.e("DB Sync", "====strVersion====" + strVersion);
                Log.e("DB Sync", "====ClientName====" + ClientName);
                Log.e("DB Sync", "====UserName====" + UserName);
                Log.e("DB Sync", "====action====" + action);
                Log.e("DB Sync", "====jsonData====" + jsonData);
                //Log.e("DB Sync", "====parameterPost====" + parameterPost.toString());
                Log.e("DB Sync", "====ZipPassword====" + dbPassword);
                Log.e("DB Sync", "====CustomerId====" + fkCustomerGlCode);
                Log.e("DB Sync", "====serviceAPIKe====" + serviceAPIKe);

                encodeDb = null;


                stringRequest = new StringRequest(Request.Method.POST, url + "" + MNDatabaseUpload, null,
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if (error instanceof NetworkError) {
                                } else if (error instanceof ServerError) {
                                } else if (error instanceof AuthFailureError) {
                                } else if (error instanceof ParseError) {
                                } else if (error instanceof NoConnectionError) {
                                } else if (error instanceof TimeoutError) {
                                    isTimeOut = true;
                                    Log.e("DB Sync", "====TimeoutError====");
                                }
                            }
                        }) {

                    protected Map<String, String> getParams() {
                        if (parameterPost.size() > 0) {
                            return parameterPost;
                        } else {
                            //Utils.printLoge(5, "noperameters jsonTask....", "............" + Utils.parameterPost);
                            return null;
                        }
                    }

                    @Override
                    public String getBodyContentType() {
                        return "application/x-www-form-urlencoded";
                    }


                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("X-ApiKey", "i3BalYxQL");
                        params.put("Content-Type", "application/x-www-form-urlencoded");
                        Log.e("getHeaders", params.toString());
                        return params;
                    }
                };
            } else {
                final Map<String, String> parameterPost = new HashMap<>();
                parameterPost.clear();

                //BASF_HK
//                parameterPost.put("FileArray", action.equalsIgnoreCase("Process") ? "" : encodeDb);
                parameterPost.put("FileArray", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? "" : encodeDb);
                parameterPost.put("FileName", strFilename);
                parameterPost.put("DeviceId", Imei);
                parameterPost.put("PersonId", fk_EmpGlCode);
                parameterPost.put("Version", strVersion);
                parameterPost.put("SubModuleName", ClientName);
                parameterPost.put("APIToken", UserName);
                parameterPost.put("Action", action);

                String jsonFull = "{\"Sync_Log\":[" + jsonData + "]}";

                parameterPost.put("JsonData", jsonFull);
                parameterPost.put("ExtraFields", extraFields);
//                parameterPost.put("SyncId", action.equalsIgnoreCase("Process") ? String.valueOf(syncID) : "");
                parameterPost.put("SyncId", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? String.valueOf(syncID) : "");


                Log.e("DB Sync", "==HK==strFilename====" + strFilename);
                Log.e("DB Sync", "==HK==Imei====" + Imei);
                Log.e("DB Sync", "==HK==fk_EmpGlCode====" + fk_EmpGlCode);
                Log.e("DB Sync", "==HK==strVersion====" + strVersion);
                Log.e("DB Sync", "==HK==ClientName====" + ClientName);
                Log.e("DB Sync", "==HK==UserName====" + UserName);
                Log.e("DB Sync", "==HK==action====" + action);
                Log.e("DB Sync", "==HK==jsonData====" + jsonData);
                Log.e("DB Sync", "==HK==syncID====" + syncID);

                Log.e("DB Sync", "==HK==parameterPost====" + parameterPost.toString());

                encodeDb = null;

                stringRequest1 = new JsonObjectRequest(Request.Method.POST, url + "" + MNDatabaseUpload, new JSONObject(parameterPost),null,
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if (error instanceof NetworkError) {
                                } else if (error instanceof ServerError) {
                                } else if (error instanceof AuthFailureError) {
                                } else if (error instanceof ParseError) {
                                } else if (error instanceof NoConnectionError) {
                                } else if (error instanceof TimeoutError) {
                                    isTimeOut = true;
                                    Log.e("DB Sync", "====TimeoutError====");
                                }
                            }
                        }) {


                    @Override
                    public String getBodyContentType() {
                        return "application/json";
                    }

                    @Override
                    public Map<String, String> getHeaders() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("X-ApiKey", "i3BalYxQL");
                        params.put("Content-Type", "application/json");
                        Log.e("getHeaders", params.toString());
                        return params;
                    }

                };
            }


            int DEFAULT_TIMEOUT_MS = 2700000;
            //int DEFAULT_PROCESS_TIMEOUT_MS = 120000;
            int DEFAULT_PROCESS_TIMEOUT_MS = 60000;

            if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
                isTimeOut = false;
                if(stringRequest != null) {
                    stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                            DEFAULT_PROCESS_TIMEOUT_MS,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                }

                if(stringRequest1 != null) {
                    stringRequest1.setRetryPolicy(new DefaultRetryPolicy(
                            DEFAULT_PROCESS_TIMEOUT_MS,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                }
            } else {
                if(stringRequest != null) {
                    stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                            DEFAULT_TIMEOUT_MS,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                }
                if(stringRequest1 != null) {
                    stringRequest1.setRetryPolicy(new DefaultRetryPolicy(
                            DEFAULT_TIMEOUT_MS,
                            DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                            DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                }
            }
            mRequestTickle.getCache().clear();

//            mRequestTickle.add(stringRequest);
            mRequestTickle.add(stringRequest1);
            NetworkResponse response = mRequestTickle.start();

            Log.e("jsonUploadDownloadDB", "-->" + response.statusCode);
            String jsonUploadDownloadDB;
            if (response.statusCode == 200) {

                jsonUploadDownloadDB = VolleyTickle.parseResponse(response);

//                stopTimer();
//                if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//                    sendBroadCastDetails(1, "upload DB", randInt(60, 60));
//                } else {
//                    sendBroadCastDetails(1, "upload DB", randInt(35, 35));
//                }

                Log.e("download ", "link : " + jsonUploadDownloadDB);
                JSONObject json = new JSONObject(jsonUploadDownloadDB);
                JSONArray jsonArray = json.optJSONArray("Status");
                responseMsg = json.getString("Message");

                try {
                    String syncId = json.optString("SyncId");
                    syncID = syncId != null ? Integer.parseInt(syncId) : 0;
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if (jsonArray != null) {
                    int jsonSize = jsonArray.length();
                    for (int jsonIndex = 0; jsonIndex < jsonSize; jsonIndex++) {
                        JSONObject innerObject = jsonArray.getJSONObject(jsonIndex);
                        if (innerObject != null) {
                            String strValidSync = innerObject.optString("isValid");

                            if (strValidSync.equalsIgnoreCase("True")) {
                                URLDownloadDB = innerObject.optString("Message");
                            } else {
                                strSyncMessage[0] = innerObject.optString("Message");
                            }

                            if (!packageName.equalsIgnoreCase(APP_DATA_LOGGER)) {
                                if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
                                    stopTimer();
//                                        if (strValidSync.equalsIgnoreCase("True")) {
                                    Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_END", Utils.getCurrentDateTime());
                                    ////Utils.writeTextFile("---Process API Call End---", context);
                                    Utils.writeJSONFile(syncJSON, "13", "---Process API Call End---");

                                    strSyncMessage[0] = afterUpload(strSyncMessage[0], strFilename, fName, DATABASE_NAME,
                                            dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);

                                } else {

                                    Utils.writeJSONFile(requestJSON, "UPLOAD_API_CALL_END", Utils.getCurrentDateTime());
                                    ////Utils.writeTextFile("---Upload API Call End---", context);
                                    Utils.writeJSONFile(syncJSON, "14", "---Upload API Call End---");

                                    Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_START", Utils.getCurrentDateTime());
                                    ////Utils.writeTextFile("---Process API Call Start---", context);
                                    Utils.writeJSONFile(syncJSON, "15", "---Process API Call Start---");

                                    if (Utils.inNetwork(context)) {


                                        multipleRequest(urlUpload, strFilename, UserName,
                                                fk_EmpGlCode, ClientName, imei, strVersion,
                                                context, WDAY, uploadPath, MNDatabaseUpload, fName,
                                                DATABASE_NAME, dataDirPath, packageName, dbPassword,
                                                isDbEncripted, "Process",
                                                requestJSON.toString(), "",
                                                fkCustomerGlCode, DeviceSyncStatus,
                                                CustomerCode, SystemName, LastSyncDate,
                                                ServerSyncId, serviceAPIKe, 2);
                                    } else {
                                        stopTimer();
                                        ////Utils.writeTextFile("---No Internet Connection.---", context);
                                        Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
                                        sendBroadCastDetails(2, "Failed to create zip file", lastProgress);


                                    }

                                }
                            } else {
                                stopTimer();
                                strSyncMessage[0] = afterUpload(strSyncMessage[0], strFilename, fName, DATABASE_NAME,
                                        dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                            }
                        }
                    }
                } else {
                    //strSyncMessage = "102";
                    String Status = json.getString("Status");
                    String Response = json.getString("Response");

//                        if (Status.equalsIgnoreCase("1")) {


                    if (!packageName.equalsIgnoreCase(APP_DATA_LOGGER)) {
                        if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//                                    Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_END", Utils.getCurrentDateTime());
//                                    ////Utils.writeTextFile("---Process API Call End---", context);
//                                    Utils.writeJSONFile(syncJSON, "16", "---Process API Call End---");
//
//                                    strSyncMessage = afterUpload(strSyncMessage, strFilename, fName, DATABASE_NAME,
//                                            dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            Log.e("STATUS", "======Status====" + Status);
                            if (Status.contains("1")) {
                                stopTimer();
                                URLDownloadDB = Response;
                                Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_END", Utils.getCurrentDateTime());
                                ////Utils.writeTextFile("---Process API Call End---", context);
                                Utils.writeJSONFile(syncJSON, "13", "---Process API Call End---");

                                strSyncMessage[0] = afterUpload(strSyncMessage[0], strFilename, fName, DATABASE_NAME,
                                        dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                            } else if (Status.contains("3")) {

//                                        try {
//                                            Thread.sleep(60000);
//                                        } catch (InterruptedException e) {
//                                            // TODO Auto-generated catch block
//                                            e.printStackTrace();
//                                        }
                                if (Utils.inNetwork(context)) {
                                    multipleRequest(urlUpload, strFilename, UserName,
                                            fk_EmpGlCode, ClientName, imei, strVersion,
                                            context, WDAY, uploadPath, MNDatabaseUpload, fName,
                                            DATABASE_NAME, dataDirPath, packageName, dbPassword,
                                            isDbEncripted, "CHECK_DOWNLOAD",
                                            requestJSON.toString(), "",
                                            fkCustomerGlCode, DeviceSyncStatus,
                                            CustomerCode, SystemName,
                                            LastSyncDate, ServerSyncId,
                                            serviceAPIKe, 3);
                                } else {
                                    stopTimer();
                                    ////Utils.writeTextFile("---No Internet Connection.---", context);
                                    Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
                                    sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
                                }
                            } else {
                                Log.e("API MESSAGE", "=====MESSAGE====="+json.getString("Message"));
                                stopTimer();
                                ////Utils.writeTextFile("---No Internet Connection.---", context);
                                Utils.writeJSONFile(syncJSON, "8888", "---ERROR MESSAGE---"+json.getString("Message"));
                                sendBroadCastDetails(2, "API FAILED ERROR", lastProgress);
                            }
                        } else {
                            Utils.writeJSONFile(requestJSON, "UPLOAD_API_CALL_END", Utils.getCurrentDateTime());
                            ////Utils.writeTextFile("---Upload API Call End---", context);
                            Utils.writeJSONFile(syncJSON, "17", "---Upload API Call End---");

                            Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_START", Utils.getCurrentDateTime());
                            ////Utils.writeTextFile("---Process API Call Start---", context);
                            Utils.writeJSONFile(syncJSON, "18", "---Process API Call Start---");

                            if (Utils.inNetwork(context)) {
                                multipleRequest(urlUpload, strFilename, UserName,
                                        fk_EmpGlCode, ClientName, imei, strVersion,
                                        context, WDAY, uploadPath, MNDatabaseUpload, fName,
                                        DATABASE_NAME, dataDirPath, packageName, dbPassword,
                                        isDbEncripted, "Process",
                                        requestJSON.toString(), "",
                                        fkCustomerGlCode, DeviceSyncStatus,
                                        CustomerCode, SystemName,
                                        LastSyncDate, ServerSyncId,
                                        serviceAPIKe, 4);
                            } else {
                                stopTimer();
                                ////Utils.writeTextFile("---No Internet Connection.---", context);
                                Utils.writeJSONFile(syncJSON, "43", "---No Internet Connection.---");
                                sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
                            }

                        }
                    } else {
                        stopTimer();
                        strSyncMessage[0] = afterUpload(strSyncMessage[0], strFilename, fName, DATABASE_NAME,
                                dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                    }
//                        } else {
//                            ////Utils.writeTextFile("---Response Error---" + jsonUploadDownloadDB, context);
//                            Utils.writeJSONFile(syncJSON, "19", "---Response Error---" + jsonUploadDownloadDB);
//                            strSyncMessage = "102";
//                            sendBroadCastDetails(2, "Response Error", lastProgress);
//                        }
                }


            } else {

                if (response.statusCode != -1) {
                    if (!isTimeOut) {
                        ////Utils.writeTextFile("---Response Status Not Getting 200---" + response.statusCode, context);
                        Utils.writeJSONFile(syncJSON, "20", "---Response Status Not Getting 200---" + response.statusCode);
                        strSyncMessage[0] = "10002";
                        sendBroadCastDetails(2, "Response Status Error", lastProgress);

                        Log.e("102", "not in isTimeOut case");
                        Log.e("20", "---Response Status Not Getting 200---" + response.statusCode);
                    } else {
                        Log.e("102", "in isTimeOut case");
                        Log.e("20", "---Response Status Not Getting 200---" + response.statusCode);
                    }
                } else {
                    stopTimer();
                    isTimeOut = true;
                    strSyncMessage[0] = "TIMEOUT!!!!!";
                    Log.e("102", "found -1 not do any thing::::"+strSyncMessage[0]);
                    Log.e("20", "---Response Status Not Getting 200---" + response.statusCode);
                }
            }
//            } else {
//                stopTimer();
//                ////Utils.writeTextFile("---File Array Null---", context);
//                Utils.writeJSONFile(syncJSON, "21", "---File Array Null---");
//                strSyncMessage = "103";
//                sendBroadCastDetails(2, "File Array Null", lastProgress);
//            }
        } catch (Exception e) {
            stopTimer();
            e.printStackTrace();
            String error = e.getMessage();
            strSyncMessage[0] = "104: " + error;
            ////Utils.writeTextFile("---Exception Error---" + strSyncMessage, context);
            Utils.writeJSONFile(syncJSON, "22", "---Exception Error---" + strSyncMessage[0]);
            sendBroadCastDetails(2, "Exception Error", lastProgress);
        }
        return strSyncMessage[0];
    }

    private void multipleRequest(String url, final String strFilename, final String UserName, final String fk_EmpGlCode, final String
            ClientName, String Imei, final String strVersion, final Context context, final int WDAY, final String uploadPath, final String MNDatabaseUpload,
                                 final String fName, final String DATABASE_NAME, final String dataDirPath, final String packageName, final String dbPassword, final String isDbEncripted, final String action, String jsonData, String extraFields, final String fkCustomerGlCode, final String DeviceSyncStatus, final String CustomerCode, final String SystemName, final String LastSyncDate, final String ServerSyncId, final String serviceAPIKe, int isFrom) {
        Log.e("==========Process", ":2========");
        Log.e("==========action", ":" + action);
        Log.e("-->isFrom", ":" + isFrom);

        if (mRequestTickle != null) {
            mRequestTickle.getCache().clear();
        }

        if (action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
            try {
                ///Thread.sleep(120000);
                Thread.sleep(60000);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        if (Utils.inNetwork(context)) {

            Log.e("multipleRequest", ":after delay");

            UploadDatabaseFileZipOld(urlUpload, strFilename, UserName,
                    fk_EmpGlCode, ClientName, imei, strVersion,
                    context, WDAY, uploadPath, MNDatabaseUpload, fName,
                    DATABASE_NAME, dataDirPath, packageName, dbPassword,
                    isDbEncripted, action,
                    requestJSON.toString(), "",
                    fkCustomerGlCode, DeviceSyncStatus,
                    CustomerCode, SystemName,
                    LastSyncDate, ServerSyncId,
                    serviceAPIKe);
        } else {
            ////Utils.writeTextFile("---No Internet Connection.---", context);
            Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
            sendBroadCastDetails(2, "Failed to create zip file", lastProgress);
        }

    }

    private String afterUpload(String strUploadMessage, String fZipName, String fName, String databaseName, String dataDirPath, String version, String packageName, String dbPassword, String isDbEncripted) {
        //changePercent(randInt(20, 25));

        //DatabaseExportImport databaseExportImport = new DatabaseExportImport();


        if (strUploadMessage.equalsIgnoreCase("Done")) {

            // data_createJson.put("6_UPLOAD_END", "" + getTimeinSec(new DateTime()));
            sendBroadCastDetails(1, "upload DB", randInt(61, 65));
            // changePercent(randInt(40, 45));

            String DownloadURL = URLDownloadDB;
            //Utils.printLoge1(5, "CALL", "DownloadURL : " + SyncURLDownloadDB);
            if (DownloadURL.trim().length() > 0) {

                // data_createJson.put("7_DOWNLOAD_URL", DownloadURL);

                // changePercent(randInt(45, 50));

                sendBroadCastDetails(1, "upload DB", randInt(65, 68));

                increaseTimmer(68, 85);

                // data_createJson.put("8_DOWNLOAD_START", "" + getTimeinSec(new DateTime()));

                Utils.writeJSONFile(requestJSON, "DOWNLOAD_START", Utils.getCurrentDateTime());
                ////Utils.writeTextFile("---Download DB Start---", context);
                Utils.writeJSONFile(syncJSON, "23", "---Download DB Start---");

                String strDBMessage = DownloadDBFromUrlZip(DownloadURL, fZipName, fName, databaseName, dbPassword);//, context, databaseName

                Utils.writeJSONFile(requestJSON, "DOWNLOAD_END", Utils.getCurrentDateTime());
                ////Utils.writeTextFile("---Download DB End---", context);
                Utils.writeJSONFile(syncJSON, "24", "---Download DB End---");

                stopTimer();

                if (strDBMessage.equals("Done")) {
                    //data_createJson.put("9_DOWNLOAD_END", "" + getTimeinSec(new DateTime()));

                    //changePercent(randInt(82, 90));

                    sendBroadCastDetails(1, "upload DB", randInt(85, 90));


                    Utils.writeJSONFile(requestJSON, "IMPORT_FILE_START", Utils.getCurrentDateTime());
                    ////Utils.writeTextFile("---Import File Start---", context);
                    Utils.writeJSONFile(syncJSON, "25", "---Import File Start---");

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //data_createJson.put("10_RESTORE_DB_START", "" + getTimeinSec(new DateTime()));

                    //int restore = databaseExportImport.restoreDownloadedDb(NEW_APP_VERSION_SYNC, dataDirPath, downloadPath, databaseName);
                    int restore = 0;
                    /*if (!SdIsPresent())
                        restore = 1;*/

                    File exportFile = new File(dataDirPath);
                    File importFile = new File(ECTERNAL_STORAGE_APP_DOWNLOAD(context), databaseName);


                    if (!importFile.exists()) {
                        restore = 1;
                    }

                    Log.e("at::", "isDatabaseCorrupted");

                    /*if (checkCurrupDownload) {
                        Log.e("inside::", "isDatabaseCorrupted");
                        if (Utils.isDatabaseCorrupted(importFile.getAbsolutePath()))
                            restore = 5;
                    }*/

                    if (restore == 0) {

                        Log.e("delete::", "delete db from package");
                        //Dhaval Change: 05/06/18
                        try {
                            Thread.sleep(1000);
                            Utils.deleteFiles(exportFile);
                            Thread.sleep(3000);
                        } catch (Exception e) {
                            Log.e("error::", "delete file 1:" + e.getMessage());
                            ////Utils.writeTextFile("---delete file-1--", context);
                            Utils.writeJSONFile(syncJSON, "26", "---delete file-1--" + e.getMessage());
                            e.printStackTrace();
                            try {
                                Thread.sleep(1000);
                                Utils.deleteFiles(exportFile);
                                Thread.sleep(3000);
                            } catch (Exception eq) {
                                Log.e("error::", "delete file 2:" + e.getMessage());
                                ////Utils.writeTextFile("---delete file-2--", context);
                                Utils.writeJSONFile(syncJSON, "27", "---delete file-2--" + e.getMessage());
                                eq.printStackTrace();
                            }
                        }
                        Log.e("Copy::", "copy db start");
                        try {
                            Thread.sleep(1000);
                            try {
                                //noinspection ResultOfMethodCallIgnored
                                exportFile.createNewFile();
                            } catch (IOException eio) {
                                eio.printStackTrace();
                                //restore = 4;
                            }
                            Thread.sleep(2000);
                            boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                            Thread.sleep(3000);
                            restore = isCopy ? 3 : 2;
                        } catch (Exception e) {
                            Log.e("error::", "copy file 1:" + e.getMessage());
                            ////Utils.writeTextFile("---copy file 1:---", context);
                            Utils.writeJSONFile(syncJSON, "28", "---copy file 1:---" + e.getMessage());
                            e.printStackTrace();
                            //Dhaval change : 05/06/18
                            try {
                                Thread.sleep(2000);
                                boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                                Thread.sleep(3000);
                                restore = isCopy ? 3 : 2;
                            } catch (Exception e1) {
                                Log.e("error::", "copy file 2:" + e.getMessage());
                                ////Utils.writeTextFile("---copy file 2:---", context);
                                Utils.writeJSONFile(syncJSON, "29", "---copy file 2:---" + e.getMessage());
                                e1.printStackTrace();
                                //restore = 1;
                                try {
                                    Thread.sleep(2000);
                                    boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                                    Thread.sleep(3000);
                                    restore = isCopy ? 3 : 2;
                                } catch (Exception e2) {
                                    Log.e("error::", "copy file 2:" + e.getMessage());
                                    ////Utils.writeTextFile("---copy file 3:---", context);
                                    Utils.writeJSONFile(syncJSON, "30", "---copy file 3:---" + e.getMessage());
                                    e2.printStackTrace();
                                    restore = 1;
                                }
                            }
                        }


                        try {
                            Thread.sleep(3000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        Log.e("restore", "restore DB Return:" + restore);
                    }

                    Utils.writeJSONFile(requestJSON, "IMPORT_FILE_END", Utils.getCurrentDateTime());
                    ////Utils.writeTextFile("---Import File End---", context);
                    Utils.writeJSONFile(syncJSON, "31", "---Import File End---");

                    Log.e("DB Sync", "=======restore====" + restore);

                    if (restore == 3) {

                        if(isCheckDownload){
                            isCheckDownload=false;
                        }

                        sendBroadCastDetails(1, "upload DB", randInt(91, 96));

                        try {
                            Thread.sleep(1000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //data_createJson.put("12_CHECK_DB_CURRUPT_START", "" + getTimeinSec(new DateTime()));
                        //boolean isCurrupt = Utils.isDatabaseCorruptedNew(ECPSyncronizationService.this, packageName);
                        //File importFile = new File(ECTERNAL_STORAGE_APP_DOWNLOAD, DbExportImport.DATABASE_NAME);

                        try {
                            Thread.sleep(2000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        /*if (isDbEncripted.equalsIgnoreCase("true")) {
                            try {
                                ExportSqlChiper exportSqlChiper = new ExportSqlChiper();
                                String dataDirPath1 = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + databaseName;
                                Log.e("dataDirPath ", "plain text:" + dataDirPath1);
                                if (exportSqlChiper.checkDatabaseEnciptedorPlain(registrar.context(), dataDirPath1, "")) {
                                    Thread.sleep(500);
                                    exportSqlChiper.migrateEncriptedDB(registrar.context(), dataDirPath1, dbPassword);
                                }
                                Thread.sleep(2000);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }*/


                        Utils.writeJSONFile(requestJSON, "SYNC_END", Utils.getCurrentDateTime());
                        ////Utils.writeTextFile("---Sync End---", context);
                        Utils.writeJSONFile(syncJSON, "32", "---Sync End---");

                        Log.e("SYNC END", "*****syncJSON********" + syncJSON.toString());
                        Log.e("SYNC END", "*****requestJSON*****" + requestJSON.toString());

                        //sendBroadCastDetails(3, "Sync Complate 100%");
                        return "done";

                    } else {
                        if (restore == 2) {
                            //syncStageStatus = "F";
                            //data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 107" + getTimeinSec(new DateTime()));
                            // database currupted
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "107";
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //Utils.printLoge1(5, "CALL", "ERROR : 107");
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 107", lastProgress);

                            ////Utils.writeTextFile("---10_RESTORE_DB_END_FAIL 107---", context);
                            Utils.writeJSONFile(syncJSON, "33", "---10_RESTORE_DB_END_FAIL 107---");

                            return "notdone";
                        } else if (restore == 5) {
                            // syncStageStatus = "F";
                            // data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 223" + getTimeinSec(new DateTime()));

                            // database currupted
                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "225";
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //Utils.printLoge1(5, "CALL", "ERROR : 223");
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 223", lastProgress);

                            ////Utils.writeTextFile("---10_RESTORE_DB_END_FAIL 223---", context);
                            Utils.writeJSONFile(syncJSON, "34", "---10_RESTORE_DB_END_FAIL 223---");

                            return "notdone";
                        } else {
                            // syncStageStatus = "F";
                            // data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 106" + getTimeinSec(new DateTime()));

                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "106";
                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 106", lastProgress);

                            ////Utils.writeTextFile("---10_RESTORE_DB_END_FAIL 106---", context);
                            Utils.writeJSONFile(syncJSON, "35", "---10_RESTORE_DB_END_FAIL 106---");

                            return "notdone";
                        }
                    }
                } else {

                    // syncStageStatus = "F";
                    // data_createJson.put("9_DOWNLOAD_END_FAIL", "ERROR : 106:2 :" + CommonFunctionLib.GetCurrentDate(ENTRY_DATE));

                    //isFielCopeError = true;
                    //fileCopeException = "106: " + Utils.checkErrorReset(strDBMessage);
                    //ECP_Scan_SyncSyncCompleteStatus = false;
                    sendBroadCastDetails(2, "9_DOWNLOAD_END_FAIL", lastProgress);

                    ////Utils.writeTextFile("---9_DOWNLOAD_END_FAIL---", context);
                    Utils.writeJSONFile(syncJSON, "36", "---9_DOWNLOAD_END_FAIL---");

                    return "notdone";
                }
            } else {

                // syncStageStatus = "F";
                //   data_createJson.put("6_DOWNLOAD_END_FAIL", "ERROR : 106:3 :" + getTimeinSec(new DateTime()));

                //   ECP_Scan_SyncSyncCompleteStatus = false;
                sendBroadCastDetails(2, "6_DOWNLOAD_END_FAIL", lastProgress);

                ////Utils.writeTextFile("---6_DOWNLOAD_END_FAIL---", context);
                Utils.writeJSONFile(syncJSON, "37", "---6_DOWNLOAD_END_FAIL---");

                return "notdone";
            }
        } else {

            // syncStageStatus = "F";
            // data_createJson.put("5_UPLOAD_END_FAIL", "ERROR : 101 : " + getTimeinSec(new DateTime()));

            //isFielCopeError = true;
            //fileCopeException = "101: " + Utils.checkErrorReset(strUploadMessage);
            // ECP_Scan_SyncSyncCompleteStatus = false;
            sendBroadCastDetails(2, "5_UPLOAD_END_FAIL", lastProgress);

            ////Utils.writeTextFile("---5_UPLOAD_END_FAIL---", context);
            Utils.writeJSONFile(syncJSON, "38", "---5_UPLOAD_END_FAIL---");

            return "notdone";
        }

        //whenAllProgressDone();
    }

    private String DownloadDBFromUrlZip(String DownloadUrl, String ZipfileName, String dbFilename, String databaseName, String zipPassword) {
        String strSyncMessage = "Done";
        try {
            File downloadDB = new File(ECTERNAL_STORAGE_APP_DOWNLOAD(context));
            if (!downloadDB.exists())
                //noinspection ResultOfMethodCallIgnored
                downloadDB.mkdirs();

            // changePercent(randInt(50, 60));
            sendBroadCastDetails(1, "upload DB", randInt(69, 73));
            File file = new File(ECTERNAL_STORAGE_APP_DOWNLOAD(context), ZipfileName);

            //final int BUFFER_SIZE = 32 * 1024;
            final int BUFFER_SIZE = 3 * 1024;
            URL url = new URL(DownloadUrl);

            URLConnection uCon = url.openConnection();
            //uCon.setConnectTimeout(120000);
            uCon.setConnectTimeout(2700000);
            InputStream downloadInputStream = uCon.getInputStream();
            //int fileLength = ucon.getContentLength();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(downloadInputStream, BUFFER_SIZE);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] byteBuffer = new byte[BUFFER_SIZE];
            int current = 0;

            //changePercent(randInt(65, 70));
            sendBroadCastDetails(1, "upload DB", randInt(74, 80));

            while (current != -1) {
                fileOutputStream.write(byteBuffer, 0, current);
                current = bufferedInputStream.read(byteBuffer, 0, BUFFER_SIZE);
            }


            fileOutputStream.flush();
            fileOutputStream.close();
            downloadInputStream.close();


            //changePercent(randInt(71, 73));

            sendBroadCastDetails(1, "upload DB", randInt(81, 83));

        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = Utils.checkErrorReset(error);
            strSyncMessage = "104: " + error;

            //Utils.writeTextFile("---Download Fail---" + strSyncMessage, context);
            Utils.writeJSONFile(syncJSON, "39", "---Download Fail---" + strSyncMessage);
            sendBroadCastDetails(2, "Download Fail", lastProgress);

        }

        //changePercent(randInt(74, 77));

        if (strSyncMessage.equals("Done")) {
            strSyncMessage = ExtractDownlodedFile(ZipfileName, dbFilename, strSyncMessage, databaseName, zipPassword);
        }
        return strSyncMessage;
    }

    private String ExtractDownlodedFile(String ZipfileName, String dbFilename, String strSyncMessage, String databaseName, String zipPassword) {

        String zipFile = ECTERNAL_STORAGE_APP_DOWNLOAD(context) + "/" + ZipfileName;

        //String size = checkFileZiseString(zipFile);
        //data_createJson.put("9_DOWNLOAD_FILE_SIZE", "" + size);

        //DatabaseExportImport databaseExportImport = new DatabaseExportImport();

        if (!Utils.ExtractSingleFile(zipFile, "" + ECTERNAL_STORAGE_APP_DOWNLOAD(context) + "/", dbFilename, zipPassword)
                .equalsIgnoreCase("Done")) {
            strSyncMessage = "105:";
        } else {
            try {

                sendBroadCastDetails(1, "upload DB", randInt(76, 82));
                //changePercent(randInt(78, 82));

                File f = new File("" + ECTERNAL_STORAGE_APP_DOWNLOAD(context) + "/" + dbFilename);
                File f1 = new File("" + ECTERNAL_STORAGE_APP_DOWNLOAD(context) + "/" + databaseName);
                if (f.exists()) {
                    if (f1.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        f1.delete();
                    }
                    //noinspection ResultOfMethodCallIgnored
                    f.renameTo(f1);
                }
            } catch (Exception e) {
                String error = e.getMessage();
                error = Utils.checkErrorReset(error);
                strSyncMessage = "104: " + error;
                //Utils.writeTextFile("---Extract Download File Fail---" + strSyncMessage, context);
                Utils.writeJSONFile(syncJSON, "40", "---Extract Download File Fail---" + strSyncMessage);
                sendBroadCastDetails(2, "Extract Download File Fail", lastProgress);
            }
        }

        return strSyncMessage;
    }

    private int lastProgress = 0;

    private int randInt(int min, int max) {

        // NOTE: This will (intentionally) not run as written so that folks
        // copy-pasting have to think about how to initialize their
        // Random instance.  Initialization of the Random instance is outside
        // the main scope of the question, but some decent options are to have
        // a field that is initialized once and then re-used as needed or to
        // use ThreadLocalRandom (if using at least Java 1.7).
        //
        // In particular, do NOT do 'Random rand = new Random()' here or you
        // will get not very good / not very random results.
        Random rand = new Random();
        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        lastProgress = rand.nextInt((max - min) + 1) + min;
        return lastProgress;
    }

    private void sendBroadCastDetails(int type, String details, int progress) {
        int mProgress = 0;
        if(isProgress && progress > 45){
            mProgress = 45;
        } else if(isCheckDownload && progress > 60){
            mProgress = 60;
        } else {
            mProgress = progress;
        }
        callBack.onFileSyncResponse(type, details, mProgress);
    }

    private void startIntentService(String status) {

        String jsonFull = "{\"Sync_Log\":[" + requestJSON.toString() + "]}";

        Intent vcsTimeIntent = new Intent(context, AppIdentifyService.class);
        vcsTimeIntent.putExtra("SyncId", syncID);
        vcsTimeIntent.putExtra("DeviceSyncStatus", status);
        vcsTimeIntent.putExtra("DeviceSyncJson", syncJSON.toString());
        vcsTimeIntent.putExtra("PersonId", fk_EmpGlCode);
        vcsTimeIntent.putExtra("SubModuleName", ClientName);
        vcsTimeIntent.putExtra("DeviceId", imei);
        vcsTimeIntent.putExtra("Version", version);
        vcsTimeIntent.putExtra("APIToken", UserName);
        vcsTimeIntent.putExtra("BaseUrl", urlUpload);
        vcsTimeIntent.putExtra("logUploadMethod", logUploadMethod);
        vcsTimeIntent.putExtra("SyncType", "D");
        vcsTimeIntent.putExtra("SyncLogJson", jsonFull);
        vcsTimeIntent.putExtra("ExtraFields", "");
        vcsTimeIntent.putExtra("CustomerID", customerId != null ? "0" : customerId);
        vcsTimeIntent.putExtra("packageName", packageNameIFFCO);

        Log.e("SYNC END", "*****syncJSON********" + syncJSON.toString());
        Log.e("SYNC END", "*****requestJSON*****" + jsonFull);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(vcsTimeIntent);
        } else {
            context.startService(vcsTimeIntent);
        }
    }

    private String checkFileZiseString(String path) {
        String isCompress;
        File f = new File(path);
        long totalLength = f.length();
        String sizeMB = CommonFunctionLib.size(totalLength);
        Log.e("sizeMB", "" + sizeMB);
        isCompress = sizeMB;
        return isCompress;
    }
}
