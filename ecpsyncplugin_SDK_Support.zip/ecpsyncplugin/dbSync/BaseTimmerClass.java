package ecp.vcs.com.ecpsyncplugin.dbSync;

import android.os.Handler;

import java.util.Timer;
import java.util.TimerTask;

abstract public class BaseTimmerClass {

    private Timer mTimer1;
    private TimerTask mTt1;
    private Handler mTimerHandler = new Handler();
    private int mMin = 0;
    private int mMax = 0;

    public abstract void updateAutoProcessDetails(int progress);

    protected void stopTimer() {
        if (mTimer1 != null) {
            mMin = 0;
            mMax = 0;
            mTimer1.cancel();
            mTimer1.purge();
        }
    }

    protected void startTimer() {
        mTimer1 = new Timer();
        mTt1 = new TimerTask() {
            public void run() {
                mTimerHandler.post(new Runnable() {
                    public void run() {
                        //TODO
                        if (mMin < mMax) {
                            mMin++;
                        }
                        updateAutoProcessDetails(mMin);
                    }
                });
            }
        };

        mTimer1.schedule(mTt1, 1, 10000);
    }

    protected void increaseTimmer(int min, int max) {
        stopTimer();
        mMin = min;
        mMax = max;
        startTimer();
    }
}
