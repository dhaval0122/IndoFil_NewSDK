package ecp.vcs.com.ecpsyncplugin.scansdk.API;

import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanResponse;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {

//    @FormUrlEncoded
//    @POST("login.php")
//    Call<LoginResponse> loginUser(
//            @Field("username") String username,
//            @Field("password") String password
//            // Add more fields as needed
//    );
//
//
//    @FormUrlEncoded
//    @POST("printer_details_save.php")
//    Call<LoginResponse> saveDetails(
//            @Field("printer_make") String printer_make,
//            @Field("printer_model") String printer_model,
//            @Field("head_make") String head_make,
//            @Field("head_model") String head_model,
//            @Field("created_by") String created_by
//            // Add more fields as needed
//    );


    @FormUrlEncoded
    @POST("scan.php")
    Call<ScanResponse> scanData(
            @Field("device_name") String device_name,
            @Field("device_type") String device_type,
            @Field("imei") String imei,
            @Field("location_lat") String location_lat,
            @Field("location_lng") String location_lng,
            @Field("scancode") String scancode,
            @Field("result_value") String result_value,
            @Field("result_code") String result_code,
            @Field("user_id") String user_id
            // Add more fields as needed
    );
}
