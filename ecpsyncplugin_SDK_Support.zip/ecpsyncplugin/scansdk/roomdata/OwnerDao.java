package ecp.vcs.com.ecpsyncplugin.scansdk.roomdata;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface OwnerDao {

    @Insert
    void insterOwner(Owner owner);

//    @Delete
//    void deleteOwner(Owner owner);

    @Query("SELECT * FROM owner")
    List<Owner> getOwnerList();

    @Query("SELECT * FROM owner WHERE huaid =:code or euaid = :code or thirdcode = :code")
    Owner getInfoByCode(String code);

//    //2.根据code删除表中数据（单个）
//    @Query("DELETE  FROM owner  WHERE code = :code")
//    void DeleteQRinfo(String code);

//    //删除全部信息
//    @Query("delete from owner")
//    void deletAllData();

    //根据code把issave修改  0//显示 1//不显示
    @Query("UPDATE owner SET issave= :issave WHERE huaid = :code or euaid = :code")
    void updateWords(String code, String issave);

}
