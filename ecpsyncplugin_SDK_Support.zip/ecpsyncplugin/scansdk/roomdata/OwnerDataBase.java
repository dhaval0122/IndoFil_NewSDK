package ecp.vcs.com.ecpsyncplugin.scansdk.roomdata;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Owner.class}, version = 1)
public abstract class OwnerDataBase extends RoomDatabase {

    private static final String DATABASE_NAME = "owner_db";
    private static OwnerDataBase ownerDataBase;
    public static synchronized OwnerDataBase getInstance(Context context) {
        if (ownerDataBase == null) {
            ownerDataBase = Room.databaseBuilder(context.getApplicationContext(),
                    OwnerDataBase.class, DATABASE_NAME).build();
        }
        return ownerDataBase;
    }

    public abstract OwnerDao ownerDao();


}