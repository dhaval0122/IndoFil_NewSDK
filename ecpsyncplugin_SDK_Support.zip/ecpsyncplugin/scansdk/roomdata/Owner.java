package ecp.vcs.com.ecpsyncplugin.scansdk.roomdata;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "owner")
public class Owner {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id", typeAffinity = ColumnInfo.INTEGER)//主键
    public int id;

    @ColumnInfo(name = "code", typeAffinity = ColumnInfo.TEXT)//code
    public String code;

    @ColumnInfo(name = "type", typeAffinity = ColumnInfo.TEXT)//l类型
    public String type;

    @ColumnInfo(name = "euaid", typeAffinity = ColumnInfo.TEXT)//euaid
    public String euaid;

    @ColumnInfo(name = "huaid", typeAffinity = ColumnInfo.TEXT)//huaid
    public String huaid;

    @ColumnInfo(name = "scantime", typeAffinity = ColumnInfo.TEXT)//扫描时间
    public String scantime;

    @ColumnInfo(name = "signature", typeAffinity = ColumnInfo.TEXT)//签名
    public String signature;

    @ColumnInfo(name = "issave", typeAffinity = ColumnInfo.TEXT)//issave
    public String issave;

    @ColumnInfo(name = "thirdcode", typeAffinity = ColumnInfo.TEXT)//第三方编码
    public String thirdcode;

    public Owner(String code, String type, String euaid, String huaid, String scantime, String signature, String issave, String thirdcode) {
        this.code = code;
        this.type = type;
        this.euaid = euaid;
        this.huaid = huaid;
        this.scantime = scantime;
        this.signature = signature;
        this.issave = issave;
        this.thirdcode = thirdcode;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEuaid() {
        return euaid;
    }

    public void setEuaid(String euaid) {
        this.euaid = euaid;
    }

    public String getHuaid() {
        return huaid;
    }

    public void setHuaid(String huaid) {
        this.huaid = huaid;
    }

    public String getScantime() {
        return scantime;
    }

    public void setScantime(String scantime) {
        this.scantime = scantime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public String getIssave() {
        return issave;
    }

    public void setIssave(String issave) {
        this.issave = issave;
    }

    public String getThirdcode() {
        return thirdcode;
    }

    public void setThirdcode(String thirdcode) {
        this.thirdcode = thirdcode;
    }
}
