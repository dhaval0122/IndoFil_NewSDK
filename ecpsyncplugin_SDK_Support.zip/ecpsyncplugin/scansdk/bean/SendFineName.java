package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class SendFineName {

    /**
     * fileName : 6405a611e4b01b9d32c96da5.cer
     */

    private String fileName;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
