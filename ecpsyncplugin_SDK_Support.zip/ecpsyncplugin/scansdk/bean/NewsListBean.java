package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class NewsListBean {

    /**
     * pageNo : 0
     * pageSize : 0
     * companyCode : string
     */

    private int pageNo;
    private int pageSize;
    private String companyCode;

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
}
