/*
 * @(#)PKDto.java       Nov 28, 2017 5:46:55 PM
 *
 * Copyright (c) 2004-2016 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class PKDto {
    private String id;

    private String publicFile;

    private String privateFile;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPublicFile() {
        return publicFile;
    }

    public void setPublicFile(String publicFile) {
        this.publicFile = publicFile;
    }

    public String getPrivateFile() {
        return privateFile;
    }

    public void setPrivateFile(String privateFile) {
        this.privateFile = privateFile;
    }

}
