package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class SendCustomerDataBean {


    private String code;
    private Object message;
    private VerifyEntity data;
    private ARCode arCode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public VerifyEntity getData() {
        return data;
    }

    public void setData(VerifyEntity data) {
        this.data = data;
    }

    public ARCode getArCode() {
        return arCode;
    }

    public void setArCode(ARCode arCode) {
        this.arCode = arCode;
    }
}
