package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetRsaFineNameBean {

    /**
     * code : 0
     * message : {"zh_TW":"成功","en_US":"Successful","zh_CN":"成功"}
     * data : {"id":"6966739528260391424","publicFileName":"6405a611e4b01b9d32c96da5.cer"}
     */

    private String code;
    private Object message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class MessageBean {
        /**
         * zh_TW : 成功
         * en_US : Successful
         * zh_CN : 成功
         */

        private String zh_TW;
        private String en_US;
        private String zh_CN;

        public String getZh_TW() {
            return zh_TW;
        }

        public void setZh_TW(String zh_TW) {
            this.zh_TW = zh_TW;
        }

        public String getEn_US() {
            return en_US;
        }

        public void setEn_US(String en_US) {
            this.en_US = en_US;
        }

        public String getZh_CN() {
            return zh_CN;
        }

        public void setZh_CN(String zh_CN) {
            this.zh_CN = zh_CN;
        }
    }

    public static class DataBean {
        /**
         * id : 6966739528260391424
         * publicFileName : 6405a611e4b01b9d32c96da5.cer
         */

        private String id;
        private String publicFileName;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getPublicFileName() {
            return publicFileName;
        }

        public void setPublicFileName(String publicFileName) {
            this.publicFileName = publicFileName;
        }
    }
}
