package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class ResponResultBean {

    private String code;
    private Object message;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public static class MessageBean {
        private String zh_TW;
        private String en_US;
        private String zh_CN;

        public String getZh_TW() {
            return zh_TW;
        }

        public void setZh_TW(String zh_TW) {
            this.zh_TW = zh_TW;
        }

        public String getEn_US() {
            return en_US;
        }

        public void setEn_US(String en_US) {
            this.en_US = en_US;
        }

        public String getZh_CN() {
            return zh_CN;
        }

        public void setZh_CN(String zh_CN) {
            this.zh_CN = zh_CN;
        }
    }
}
