package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;

public class Options implements Serializable {

    private OptionsBean options;

    public OptionsBean getOptions() {
        return options;
    }

    public void setOptions(OptionsBean options) {
        this.options = options;
    }

    public static class OptionsBean implements Serializable {
        private String responseTemplate;

        public String getResponseTemplate() {
            return responseTemplate;
        }

        public void setResponseTemplate(String responseTemplate) {
            this.responseTemplate = responseTemplate;
        }
    }
}
