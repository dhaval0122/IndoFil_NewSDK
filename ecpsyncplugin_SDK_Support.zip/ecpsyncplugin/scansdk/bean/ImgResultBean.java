package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class ImgResultBean {
    private String code;
    private Object message;
    private byte[] data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }
}
