package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.util.List;

public class BwListResultBean {

    /**
     * code : string
     * message : {"en_US":"Successful","zh_CN":"成功","zh_TW":"成功"}
     * data : {"listList":[{"targetCode":"string"}],"listType":"string"}
     */

    private String code;
    private Object message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }
    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }



    public static class DataBean {
        /**
         * listList : [{"targetCode":"string"}]
         * listType : string
         */

        private String listType;
        private List<ListListBean> listList;

        public String getListType() {
            return listType;
        }

        public void setListType(String listType) {
            this.listType = listType;
        }

        public List<ListListBean> getListList() {
            return listList;
        }

        public void setListList(List<ListListBean> listList) {
            this.listList = listList;
        }

        public static class ListListBean {
            /**
             * targetCode : string
             */

            private String targetCode;

            public String getTargetCode() {
                return targetCode;
            }

            public void setTargetCode(String targetCode) {
                this.targetCode = targetCode;
            }
        }
    }
}
