package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class BannerBean {

    /**
     * companyCode : string
     */

    private String companyCode;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }
}
