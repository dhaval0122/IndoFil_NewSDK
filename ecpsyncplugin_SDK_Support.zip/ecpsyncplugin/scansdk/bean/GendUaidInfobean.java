package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.util.List;

public class GendUaidInfobean {

    /**
     * code : 0
     * message : Successful
     * data : {"uaid":{"companyCode":"shilc","uaid":"YzsU51SYD5A7","authenticated":true,"specs":{"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]},"labelTypeCode":null,"currentOwner":{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1680160860000,"blockchainTransactionId":null},"uaidBatch":{"batchNumber":87,"seqNumber":3},"thirdPartyCode":null,"layerNumberInSpecs":2,"expiresAt":1711693000000,"status":2},"ownerHistory":[{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1680160860000,"blockchainTransactionId":null}],"scanData":{"lastScanAt":1680162952000,"firstScanByDisplayName":"<Anonymous>","totalScanCount":5,"firstScanAt":1680160860000,"lastScanByDisplayName":"<Anonymous>","firstScanByUsername":"<Anonymous>","lastScanByUsername":"<Anonymous>"},"productBatch":{"productCategoryCode":"type","images":[{"code":"img","imagePath":"641be9fce4b0a96e72973a2d.jpg","sequence":1,"displayFlag":true}],"rawMaterials":[],"attributes":[{"code":"name","name":{"ms_MY":"Nama Produk","zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","ja_JP":"製品名"},"value":{"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"maintenance_period","name":{"ms_MY":"Tempoh Jaminan (Tahun)","zh_TW":"保養期限(年)","en_US":"Guarantee Period (Year)","zh_CN":"保养期限(年)","ja_JP":"保証期間(年)"},"value":"12","sequence":2,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"qanda_url","name":{"ms_MY":"autan Soal Jawab","zh_TW":"問與答鏈接","en_US":"Q&A Link","zh_CN":"问与答链接","ja_JP":"Q&Aリンク"},"value":{"ms_MY":"全额啊啊啊啊啊啊啊啊","zh_TW":"全额啊啊啊啊啊啊啊啊","en_US":"全额啊啊啊啊啊啊啊啊","zh_CN":"全额啊啊啊啊啊啊啊啊","ja_JP":"全额啊啊啊啊啊啊啊啊"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"instructions_url","name":{"ms_MY":"Pautan Manual","zh_TW":"說明書鏈接","en_US":"Specification Link","zh_CN":"说明书链接","ja_JP":"仕様書リンク"},"value":{"ms_MY":"啊啊啊啊啊啊啊啊","zh_TW":"啊啊啊啊啊啊啊啊","en_US":"啊啊啊啊啊啊啊啊","zh_CN":"啊啊啊啊啊啊啊啊","ja_JP":"啊啊啊啊啊啊啊啊"},"sequence":4,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"detailed_url","name":{"ms_MY":"Pautan Perincian","zh_TW":"詳情鏈接","en_US":"Details Link","zh_CN":"详情链接","ja_JP":"詳細リンク"},"value":{"ms_MY":"发发发发发发","zh_TW":"发发发发发发","en_US":"发发发发发发","zh_CN":"发发发发发发","ja_JP":"发发发发发发"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"owner","name":{"ms_MY":"pemilik","zh_TW":"擁有者","en_US":"Owner","zh_CN":"拥有者","ja_JP":"所有者"},"value":"(System Generated)","sequence":6,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"thirdPartyCode","name":{"ms_MY":"Pengekodan Pihak Ketiga","zh_TW":"第三方編碼","en_US":"Third-Party Code","zh_CN":"第三方编码","ja_JP":"サードパーティーコード"},"value":"(System Generated)","sequence":7,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true}],"productNumber":"Product03","productName":{"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"},"productBatchNumber":"Product03_lot01","blockchainTransactionId":null}}
     */

    private String code;
    private String message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * uaid : {"companyCode":"shilc","uaid":"YzsU51SYD5A7","authenticated":true,"specs":{"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]},"labelTypeCode":null,"currentOwner":{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1680160860000,"blockchainTransactionId":null},"uaidBatch":{"batchNumber":87,"seqNumber":3},"thirdPartyCode":null,"layerNumberInSpecs":2,"expiresAt":1711693000000,"status":2}
         * ownerHistory : [{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1680160860000,"blockchainTransactionId":null}]
         * scanData : {"lastScanAt":1680162952000,"firstScanByDisplayName":"<Anonymous>","totalScanCount":5,"firstScanAt":1680160860000,"lastScanByDisplayName":"<Anonymous>","firstScanByUsername":"<Anonymous>","lastScanByUsername":"<Anonymous>"}
         * productBatch : {"productCategoryCode":"type","images":[{"code":"img","imagePath":"641be9fce4b0a96e72973a2d.jpg","sequence":1,"displayFlag":true}],"rawMaterials":[],"attributes":[{"code":"name","name":{"ms_MY":"Nama Produk","zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","ja_JP":"製品名"},"value":{"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"maintenance_period","name":{"ms_MY":"Tempoh Jaminan (Tahun)","zh_TW":"保養期限(年)","en_US":"Guarantee Period (Year)","zh_CN":"保养期限(年)","ja_JP":"保証期間(年)"},"value":"12","sequence":2,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"qanda_url","name":{"ms_MY":"autan Soal Jawab","zh_TW":"問與答鏈接","en_US":"Q&A Link","zh_CN":"问与答链接","ja_JP":"Q&Aリンク"},"value":{"ms_MY":"全额啊啊啊啊啊啊啊啊","zh_TW":"全额啊啊啊啊啊啊啊啊","en_US":"全额啊啊啊啊啊啊啊啊","zh_CN":"全额啊啊啊啊啊啊啊啊","ja_JP":"全额啊啊啊啊啊啊啊啊"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"instructions_url","name":{"ms_MY":"Pautan Manual","zh_TW":"說明書鏈接","en_US":"Specification Link","zh_CN":"说明书链接","ja_JP":"仕様書リンク"},"value":{"ms_MY":"啊啊啊啊啊啊啊啊","zh_TW":"啊啊啊啊啊啊啊啊","en_US":"啊啊啊啊啊啊啊啊","zh_CN":"啊啊啊啊啊啊啊啊","ja_JP":"啊啊啊啊啊啊啊啊"},"sequence":4,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"detailed_url","name":{"ms_MY":"Pautan Perincian","zh_TW":"詳情鏈接","en_US":"Details Link","zh_CN":"详情链接","ja_JP":"詳細リンク"},"value":{"ms_MY":"发发发发发发","zh_TW":"发发发发发发","en_US":"发发发发发发","zh_CN":"发发发发发发","ja_JP":"发发发发发发"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"owner","name":{"ms_MY":"pemilik","zh_TW":"擁有者","en_US":"Owner","zh_CN":"拥有者","ja_JP":"所有者"},"value":"(System Generated)","sequence":6,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"thirdPartyCode","name":{"ms_MY":"Pengekodan Pihak Ketiga","zh_TW":"第三方編碼","en_US":"Third-Party Code","zh_CN":"第三方编码","ja_JP":"サードパーティーコード"},"value":"(System Generated)","sequence":7,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true}],"productNumber":"Product03","productName":{"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"},"productBatchNumber":"Product03_lot01","blockchainTransactionId":null}
         */

        private UaidBean uaid;
        private ScanDataBean scanData;
        private ProductBatchBean productBatch;
        private List<OwnerHistoryBean> ownerHistory;

        public UaidBean getUaid() {
            return uaid;
        }

        public void setUaid(UaidBean uaid) {
            this.uaid = uaid;
        }

        public ScanDataBean getScanData() {
            return scanData;
        }

        public void setScanData(ScanDataBean scanData) {
            this.scanData = scanData;
        }

        public ProductBatchBean getProductBatch() {
            return productBatch;
        }

        public void setProductBatch(ProductBatchBean productBatch) {
            this.productBatch = productBatch;
        }

        public List<OwnerHistoryBean> getOwnerHistory() {
            return ownerHistory;
        }

        public void setOwnerHistory(List<OwnerHistoryBean> ownerHistory) {
            this.ownerHistory = ownerHistory;
        }

        public static class UaidBean {
            /**
             * companyCode : shilc
             * uaid : YzsU51SYD5A7
             * authenticated : true
             * specs : {"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]}
             * labelTypeCode : null
             * currentOwner : {"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1680160860000,"blockchainTransactionId":null}
             * uaidBatch : {"batchNumber":87,"seqNumber":3}
             * thirdPartyCode : null
             * layerNumberInSpecs : 2
             * expiresAt : 1711693000000
             * status : 2
             */

            private String companyCode;
            private String uaid;
            private boolean authenticated;
            private SpecsBean specs;
            private Object labelTypeCode;
            private CurrentOwnerBean currentOwner;
            private UaidBatchBean uaidBatch;
            private Object thirdPartyCode;
            private int layerNumberInSpecs;
            private long expiresAt;
            private int status;

            public String getCompanyCode() {
                return companyCode;
            }

            public void setCompanyCode(String companyCode) {
                this.companyCode = companyCode;
            }

            public String getUaid() {
                return uaid;
            }

            public void setUaid(String uaid) {
                this.uaid = uaid;
            }

            public boolean isAuthenticated() {
                return authenticated;
            }

            public void setAuthenticated(boolean authenticated) {
                this.authenticated = authenticated;
            }

            public SpecsBean getSpecs() {
                return specs;
            }

            public void setSpecs(SpecsBean specs) {
                this.specs = specs;
            }

            public Object getLabelTypeCode() {
                return labelTypeCode;
            }

            public void setLabelTypeCode(Object labelTypeCode) {
                this.labelTypeCode = labelTypeCode;
            }

            public CurrentOwnerBean getCurrentOwner() {
                return currentOwner;
            }

            public void setCurrentOwner(CurrentOwnerBean currentOwner) {
                this.currentOwner = currentOwner;
            }

            public UaidBatchBean getUaidBatch() {
                return uaidBatch;
            }

            public void setUaidBatch(UaidBatchBean uaidBatch) {
                this.uaidBatch = uaidBatch;
            }

            public Object getThirdPartyCode() {
                return thirdPartyCode;
            }

            public void setThirdPartyCode(Object thirdPartyCode) {
                this.thirdPartyCode = thirdPartyCode;
            }

            public int getLayerNumberInSpecs() {
                return layerNumberInSpecs;
            }

            public void setLayerNumberInSpecs(int layerNumberInSpecs) {
                this.layerNumberInSpecs = layerNumberInSpecs;
            }

            public long getExpiresAt() {
                return expiresAt;
            }

            public void setExpiresAt(long expiresAt) {
                this.expiresAt = expiresAt;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public static class SpecsBean {
                /**
                 * type : 1
                 * layers : [{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]
                 */

                private int type;
                private List<LayersBean> layers;

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public List<LayersBean> getLayers() {
                    return layers;
                }

                public void setLayers(List<LayersBean> layers) {
                    this.layers = layers;
                }

                public static class LayersBean {
                    /**
                     * layerNumber : 1
                     * type : 1
                     * format : 1
                     * subFormat : null
                     */

                    private int layerNumber;
                    private int type;
                    private int format;
                    private Object subFormat;

                    public int getLayerNumber() {
                        return layerNumber;
                    }

                    public void setLayerNumber(int layerNumber) {
                        this.layerNumber = layerNumber;
                    }

                    public int getType() {
                        return type;
                    }

                    public void setType(int type) {
                        this.type = type;
                    }

                    public int getFormat() {
                        return format;
                    }

                    public void setFormat(int format) {
                        this.format = format;
                    }

                    public Object getSubFormat() {
                        return subFormat;
                    }

                    public void setSubFormat(Object subFormat) {
                        this.subFormat = subFormat;
                    }
                }
            }

            public static class CurrentOwnerBean {
                /**
                 * username : <Anonymous>
                 * displayName : <Anonymous>
                 * avatarImagePath : null
                 * effectiveAt : 1680160860000
                 * blockchainTransactionId : null
                 */

                private String username;
                private String displayName;
                private Object avatarImagePath;
                private long effectiveAt;
                private Object blockchainTransactionId;

                public String getUsername() {
                    return username;
                }

                public void setUsername(String username) {
                    this.username = username;
                }

                public String getDisplayName() {
                    return displayName;
                }

                public void setDisplayName(String displayName) {
                    this.displayName = displayName;
                }

                public Object getAvatarImagePath() {
                    return avatarImagePath;
                }

                public void setAvatarImagePath(Object avatarImagePath) {
                    this.avatarImagePath = avatarImagePath;
                }

                public long getEffectiveAt() {
                    return effectiveAt;
                }

                public void setEffectiveAt(long effectiveAt) {
                    this.effectiveAt = effectiveAt;
                }

                public Object getBlockchainTransactionId() {
                    return blockchainTransactionId;
                }

                public void setBlockchainTransactionId(Object blockchainTransactionId) {
                    this.blockchainTransactionId = blockchainTransactionId;
                }
            }

            public static class UaidBatchBean {
                /**
                 * batchNumber : 87
                 * seqNumber : 3
                 */

                private int batchNumber;
                private int seqNumber;

                public int getBatchNumber() {
                    return batchNumber;
                }

                public void setBatchNumber(int batchNumber) {
                    this.batchNumber = batchNumber;
                }

                public int getSeqNumber() {
                    return seqNumber;
                }

                public void setSeqNumber(int seqNumber) {
                    this.seqNumber = seqNumber;
                }
            }
        }

        public static class ScanDataBean {
            /**
             * lastScanAt : 1680162952000
             * firstScanByDisplayName : <Anonymous>
             * totalScanCount : 5
             * firstScanAt : 1680160860000
             * lastScanByDisplayName : <Anonymous>
             * firstScanByUsername : <Anonymous>
             * lastScanByUsername : <Anonymous>
             */

            private long lastScanAt;
            private String firstScanByDisplayName;
            private int totalScanCount;
            private long firstScanAt;
            private String lastScanByDisplayName;
            private String firstScanByUsername;
            private String lastScanByUsername;

            public long getLastScanAt() {
                return lastScanAt;
            }

            public void setLastScanAt(long lastScanAt) {
                this.lastScanAt = lastScanAt;
            }

            public String getFirstScanByDisplayName() {
                return firstScanByDisplayName;
            }

            public void setFirstScanByDisplayName(String firstScanByDisplayName) {
                this.firstScanByDisplayName = firstScanByDisplayName;
            }

            public int getTotalScanCount() {
                return totalScanCount;
            }

            public void setTotalScanCount(int totalScanCount) {
                this.totalScanCount = totalScanCount;
            }

            public long getFirstScanAt() {
                return firstScanAt;
            }

            public void setFirstScanAt(long firstScanAt) {
                this.firstScanAt = firstScanAt;
            }

            public String getLastScanByDisplayName() {
                return lastScanByDisplayName;
            }

            public void setLastScanByDisplayName(String lastScanByDisplayName) {
                this.lastScanByDisplayName = lastScanByDisplayName;
            }

            public String getFirstScanByUsername() {
                return firstScanByUsername;
            }

            public void setFirstScanByUsername(String firstScanByUsername) {
                this.firstScanByUsername = firstScanByUsername;
            }

            public String getLastScanByUsername() {
                return lastScanByUsername;
            }

            public void setLastScanByUsername(String lastScanByUsername) {
                this.lastScanByUsername = lastScanByUsername;
            }
        }

        public static class ProductBatchBean {
            /**
             * productCategoryCode : type
             * images : [{"code":"img","imagePath":"641be9fce4b0a96e72973a2d.jpg","sequence":1,"displayFlag":true}]
             * rawMaterials : []
             * attributes : [{"code":"name","name":{"ms_MY":"Nama Produk","zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","ja_JP":"製品名"},"value":{"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"maintenance_period","name":{"ms_MY":"Tempoh Jaminan (Tahun)","zh_TW":"保養期限(年)","en_US":"Guarantee Period (Year)","zh_CN":"保养期限(年)","ja_JP":"保証期間(年)"},"value":"12","sequence":2,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"qanda_url","name":{"ms_MY":"autan Soal Jawab","zh_TW":"問與答鏈接","en_US":"Q&A Link","zh_CN":"问与答链接","ja_JP":"Q&Aリンク"},"value":{"ms_MY":"全额啊啊啊啊啊啊啊啊","zh_TW":"全额啊啊啊啊啊啊啊啊","en_US":"全额啊啊啊啊啊啊啊啊","zh_CN":"全额啊啊啊啊啊啊啊啊","ja_JP":"全额啊啊啊啊啊啊啊啊"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"instructions_url","name":{"ms_MY":"Pautan Manual","zh_TW":"說明書鏈接","en_US":"Specification Link","zh_CN":"说明书链接","ja_JP":"仕様書リンク"},"value":{"ms_MY":"啊啊啊啊啊啊啊啊","zh_TW":"啊啊啊啊啊啊啊啊","en_US":"啊啊啊啊啊啊啊啊","zh_CN":"啊啊啊啊啊啊啊啊","ja_JP":"啊啊啊啊啊啊啊啊"},"sequence":4,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"detailed_url","name":{"ms_MY":"Pautan Perincian","zh_TW":"詳情鏈接","en_US":"Details Link","zh_CN":"详情链接","ja_JP":"詳細リンク"},"value":{"ms_MY":"发发发发发发","zh_TW":"发发发发发发","en_US":"发发发发发发","zh_CN":"发发发发发发","ja_JP":"发发发发发发"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"owner","name":{"ms_MY":"pemilik","zh_TW":"擁有者","en_US":"Owner","zh_CN":"拥有者","ja_JP":"所有者"},"value":"(System Generated)","sequence":6,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"thirdPartyCode","name":{"ms_MY":"Pengekodan Pihak Ketiga","zh_TW":"第三方編碼","en_US":"Third-Party Code","zh_CN":"第三方编码","ja_JP":"サードパーティーコード"},"value":"(System Generated)","sequence":7,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true}]
             * productNumber : Product03
             * productName : {"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"}
             * productBatchNumber : Product03_lot01
             * blockchainTransactionId : null
             */

            private String productCategoryCode;
            private String productNumber;
            private ProductNameBean productName;
            private String productBatchNumber;
            private Object blockchainTransactionId;
            private List<ImagesBean> images;
            private List<?> rawMaterials;
            private List<AttributesBean> attributes;

            public String getProductCategoryCode() {
                return productCategoryCode;
            }

            public void setProductCategoryCode(String productCategoryCode) {
                this.productCategoryCode = productCategoryCode;
            }

            public String getProductNumber() {
                return productNumber;
            }

            public void setProductNumber(String productNumber) {
                this.productNumber = productNumber;
            }

            public ProductNameBean getProductName() {
                return productName;
            }

            public void setProductName(ProductNameBean productName) {
                this.productName = productName;
            }

            public String getProductBatchNumber() {
                return productBatchNumber;
            }

            public void setProductBatchNumber(String productBatchNumber) {
                this.productBatchNumber = productBatchNumber;
            }

            public Object getBlockchainTransactionId() {
                return blockchainTransactionId;
            }

            public void setBlockchainTransactionId(Object blockchainTransactionId) {
                this.blockchainTransactionId = blockchainTransactionId;
            }

            public List<ImagesBean> getImages() {
                return images;
            }

            public void setImages(List<ImagesBean> images) {
                this.images = images;
            }

            public List<?> getRawMaterials() {
                return rawMaterials;
            }

            public void setRawMaterials(List<?> rawMaterials) {
                this.rawMaterials = rawMaterials;
            }

            public List<AttributesBean> getAttributes() {
                return attributes;
            }

            public void setAttributes(List<AttributesBean> attributes) {
                this.attributes = attributes;
            }

            public static class ProductNameBean {
                /**
                 * ms_MY : Product03
                 * zh_TW : Product03
                 * en_US : 商品03
                 * zh_CN : Product03
                 * ja_JP : Product03
                 */

                private String ms_MY;
                private String zh_TW;
                private String en_US;
                private String zh_CN;
                private String ja_JP;

                public String getMs_MY() {
                    return ms_MY;
                }

                public void setMs_MY(String ms_MY) {
                    this.ms_MY = ms_MY;
                }

                public String getZh_TW() {
                    return zh_TW;
                }

                public void setZh_TW(String zh_TW) {
                    this.zh_TW = zh_TW;
                }

                public String getEn_US() {
                    return en_US;
                }

                public void setEn_US(String en_US) {
                    this.en_US = en_US;
                }

                public String getZh_CN() {
                    return zh_CN;
                }

                public void setZh_CN(String zh_CN) {
                    this.zh_CN = zh_CN;
                }

                public String getJa_JP() {
                    return ja_JP;
                }

                public void setJa_JP(String ja_JP) {
                    this.ja_JP = ja_JP;
                }
            }

            public static class ImagesBean {
                /**
                 * code : img
                 * imagePath : 641be9fce4b0a96e72973a2d.jpg
                 * sequence : 1
                 * displayFlag : true
                 */

                private String code;
                private String imagePath;
                private int sequence;
                private boolean displayFlag;

                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                public String getImagePath() {
                    return imagePath;
                }

                public void setImagePath(String imagePath) {
                    this.imagePath = imagePath;
                }

                public int getSequence() {
                    return sequence;
                }

                public void setSequence(int sequence) {
                    this.sequence = sequence;
                }

                public boolean isDisplayFlag() {
                    return displayFlag;
                }

                public void setDisplayFlag(boolean displayFlag) {
                    this.displayFlag = displayFlag;
                }
            }

            public static class AttributesBean {
                /**
                 * code : name
                 * name : {"ms_MY":"Nama Produk","zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","ja_JP":"製品名"}
                 * value : {"ms_MY":"Product03","zh_TW":"Product03","en_US":"商品03","zh_CN":"Product03","ja_JP":"Product03"}
                 * sequence : 1
                 * valueType : 1
                 * fieldType : 1
                 * displayFormat : null
                 * displayFlag : true
                 */

                private String code;
                private NameBean name;
                private ValueBean value;
                private int sequence;
                private int valueType;
                private int fieldType;
                private Object displayFormat;
                private boolean displayFlag;

                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                public NameBean getName() {
                    return name;
                }

                public void setName(NameBean name) {
                    this.name = name;
                }

                public ValueBean getValue() {
                    return value;
                }

                public void setValue(ValueBean value) {
                    this.value = value;
                }

                public int getSequence() {
                    return sequence;
                }

                public void setSequence(int sequence) {
                    this.sequence = sequence;
                }

                public int getValueType() {
                    return valueType;
                }

                public void setValueType(int valueType) {
                    this.valueType = valueType;
                }

                public int getFieldType() {
                    return fieldType;
                }

                public void setFieldType(int fieldType) {
                    this.fieldType = fieldType;
                }

                public Object getDisplayFormat() {
                    return displayFormat;
                }

                public void setDisplayFormat(Object displayFormat) {
                    this.displayFormat = displayFormat;
                }

                public boolean isDisplayFlag() {
                    return displayFlag;
                }

                public void setDisplayFlag(boolean displayFlag) {
                    this.displayFlag = displayFlag;
                }

                public static class NameBean {
                    /**
                     * ms_MY : Nama Produk
                     * zh_TW : 商品名
                     * en_US : Product Name
                     * zh_CN : 商品名
                     * ja_JP : 製品名
                     */

                    private String ms_MY;
                    private String zh_TW;
                    private String en_US;
                    private String zh_CN;
                    private String ja_JP;

                    public String getMs_MY() {
                        return ms_MY;
                    }

                    public void setMs_MY(String ms_MY) {
                        this.ms_MY = ms_MY;
                    }

                    public String getZh_TW() {
                        return zh_TW;
                    }

                    public void setZh_TW(String zh_TW) {
                        this.zh_TW = zh_TW;
                    }

                    public String getEn_US() {
                        return en_US;
                    }

                    public void setEn_US(String en_US) {
                        this.en_US = en_US;
                    }

                    public String getZh_CN() {
                        return zh_CN;
                    }

                    public void setZh_CN(String zh_CN) {
                        this.zh_CN = zh_CN;
                    }

                    public String getJa_JP() {
                        return ja_JP;
                    }

                    public void setJa_JP(String ja_JP) {
                        this.ja_JP = ja_JP;
                    }
                }

                public static class ValueBean {
                    /**
                     * ms_MY : Product03
                     * zh_TW : Product03
                     * en_US : 商品03
                     * zh_CN : Product03
                     * ja_JP : Product03
                     */

                    private String ms_MY;
                    private String zh_TW;
                    private String en_US;
                    private String zh_CN;
                    private String ja_JP;

                    public String getMs_MY() {
                        return ms_MY;
                    }

                    public void setMs_MY(String ms_MY) {
                        this.ms_MY = ms_MY;
                    }

                    public String getZh_TW() {
                        return zh_TW;
                    }

                    public void setZh_TW(String zh_TW) {
                        this.zh_TW = zh_TW;
                    }

                    public String getEn_US() {
                        return en_US;
                    }

                    public void setEn_US(String en_US) {
                        this.en_US = en_US;
                    }

                    public String getZh_CN() {
                        return zh_CN;
                    }

                    public void setZh_CN(String zh_CN) {
                        this.zh_CN = zh_CN;
                    }

                    public String getJa_JP() {
                        return ja_JP;
                    }

                    public void setJa_JP(String ja_JP) {
                        this.ja_JP = ja_JP;
                    }
                }
            }
        }

        public static class OwnerHistoryBean {
            /**
             * username : <Anonymous>
             * displayName : <Anonymous>
             * avatarImagePath : null
             * effectiveAt : 1680160860000
             * blockchainTransactionId : null
             */

            private String username;
            private String displayName;
            private Object avatarImagePath;
            private long effectiveAt;
            private Object blockchainTransactionId;

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public Object getAvatarImagePath() {
                return avatarImagePath;
            }

            public void setAvatarImagePath(Object avatarImagePath) {
                this.avatarImagePath = avatarImagePath;
            }

            public long getEffectiveAt() {
                return effectiveAt;
            }

            public void setEffectiveAt(long effectiveAt) {
                this.effectiveAt = effectiveAt;
            }

            public Object getBlockchainTransactionId() {
                return blockchainTransactionId;
            }

            public void setBlockchainTransactionId(Object blockchainTransactionId) {
                this.blockchainTransactionId = blockchainTransactionId;
            }
        }
    }
}
