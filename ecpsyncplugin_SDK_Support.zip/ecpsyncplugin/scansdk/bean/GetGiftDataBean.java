package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetGiftDataBean {

    /**
     * code : string
     * message : {"en_US":"Successful","zh_CN":"成功","zh_TW":"成功"}
     * data : {"giftReceiveVerify":"string"}
     */

    private String code;
    private Object message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }


    public static class DataBean {
        /**
         * giftReceiveVerify : string
         */

        private String giftReceiveVerify;

        public String getGiftReceiveVerify() {
            return giftReceiveVerify;
        }

        public void setGiftReceiveVerify(String giftReceiveVerify) {
            this.giftReceiveVerify = giftReceiveVerify;
        }
    }
}
