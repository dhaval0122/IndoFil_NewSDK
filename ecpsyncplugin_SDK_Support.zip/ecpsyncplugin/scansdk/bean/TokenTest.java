package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class TokenTest {

    /**
     * code : 0
     * message : Successful
     * data : {"companyCode":"axbsec","refreshTokenExpiresAt":1678001738779,"sessionTokenExpiresAt":1677915338779,"sessionToken":"eyJ0eXBlIjoiYWNjZXNzIiwiYWxnIjoiSFM1MTIifQ.eyJleHAiOjE2Nzc5MTUzMzgsImp0aSI6IjVlOWRlOWUwODhhYjRmZDZiOTI5NjdkOTk4YmJiZjMzIn0.XG_dExK-C_jGs1_TqqAgkwjAq4-JAGnPSYWiTHa9nyku_WsaYN7owHiV4CdnoWJTgYzZ_ucJd-nANFyVlVJHxQ","tokenType":"Bearer","refreshToken":"eyJ0eXBlIjoicmVmcmVzaCIsImFsZyI6IkhTNTEyIn0.eyJleHAiOjE2NzgwMDE3MzgsImp0aSI6IjVlOWRlOWUwODhhYjRmZDZiOTI5NjdkOTk4YmJiZjMzIn0.pS4X65IY-3Rtr6YB6JDLrEJdqQSj8qWeewm8fVrRhVp2mNfKgz1GtVLv7010AXgOElUkUD_ZsKY8uOtyTA8Qug"}
     */

    private String code;
    private String message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * companyCode : axbsec
         * refreshTokenExpiresAt : 1678001738779
         * sessionTokenExpiresAt : 1677915338779
         * sessionToken : eyJ0eXBlIjoiYWNjZXNzIiwiYWxnIjoiSFM1MTIifQ.eyJleHAiOjE2Nzc5MTUzMzgsImp0aSI6IjVlOWRlOWUwODhhYjRmZDZiOTI5NjdkOTk4YmJiZjMzIn0.XG_dExK-C_jGs1_TqqAgkwjAq4-JAGnPSYWiTHa9nyku_WsaYN7owHiV4CdnoWJTgYzZ_ucJd-nANFyVlVJHxQ
         * tokenType : Bearer
         * refreshToken : eyJ0eXBlIjoicmVmcmVzaCIsImFsZyI6IkhTNTEyIn0.eyJleHAiOjE2NzgwMDE3MzgsImp0aSI6IjVlOWRlOWUwODhhYjRmZDZiOTI5NjdkOTk4YmJiZjMzIn0.pS4X65IY-3Rtr6YB6JDLrEJdqQSj8qWeewm8fVrRhVp2mNfKgz1GtVLv7010AXgOElUkUD_ZsKY8uOtyTA8Qug
         */

        private String companyCode;
        private long refreshTokenExpiresAt;
        private long sessionTokenExpiresAt;
        private String sessionToken;
        private String tokenType;
        private String refreshToken;

        public String getCompanyCode() {
            return companyCode;
        }

        public void setCompanyCode(String companyCode) {
            this.companyCode = companyCode;
        }

        public long getRefreshTokenExpiresAt() {
            return refreshTokenExpiresAt;
        }

        public void setRefreshTokenExpiresAt(long refreshTokenExpiresAt) {
            this.refreshTokenExpiresAt = refreshTokenExpiresAt;
        }

        public long getSessionTokenExpiresAt() {
            return sessionTokenExpiresAt;
        }

        public void setSessionTokenExpiresAt(long sessionTokenExpiresAt) {
            this.sessionTokenExpiresAt = sessionTokenExpiresAt;
        }

        public String getSessionToken() {
            return sessionToken;
        }

        public void setSessionToken(String sessionToken) {
            this.sessionToken = sessionToken;
        }

        public String getTokenType() {
            return tokenType;
        }

        public void setTokenType(String tokenType) {
            this.tokenType = tokenType;
        }

        public String getRefreshToken() {
            return refreshToken;
        }

        public void setRefreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
        }
    }
}
