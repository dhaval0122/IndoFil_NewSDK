package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class OwnerCardBean {


    /**
     * uaid : string
     * scantime : string
     * signature : string
     */

    private String uaid;
    private String scantime;
    private String signature;

    public String getUaid() {
        return uaid;
    }

    public void setUaid(String uaid) {
        this.uaid = uaid;
    }

    public String getScantime() {
        return scantime;
    }

    public void setScantime(String scantime) {
        this.scantime = scantime;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }
}
