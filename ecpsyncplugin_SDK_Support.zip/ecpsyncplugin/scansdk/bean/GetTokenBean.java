package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetTokenBean {

    private String companyCode;
    private long refreshTokenExpiresAt;
    private long sessionTokenExpiresAt;
    private String sessionToken;
    private String tokenType;
    private String refreshToken;

    public String getCompanyCode() {
        return companyCode;
    }

    public void setCompanyCode(String companyCode) {
        this.companyCode = companyCode;
    }

    public long getRefreshTokenExpiresAt() {
        return refreshTokenExpiresAt;
    }

    public void setRefreshTokenExpiresAt(long refreshTokenExpiresAt) {
        this.refreshTokenExpiresAt = refreshTokenExpiresAt;
    }

    public long getSessionTokenExpiresAt() {
        return sessionTokenExpiresAt;
    }

    public void setSessionTokenExpiresAt(long sessionTokenExpiresAt) {
        this.sessionTokenExpiresAt = sessionTokenExpiresAt;
    }

    public String getSessionToken() {
        return sessionToken;
    }

    public void setSessionToken(String sessionToken) {
        this.sessionToken = sessionToken;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

}
