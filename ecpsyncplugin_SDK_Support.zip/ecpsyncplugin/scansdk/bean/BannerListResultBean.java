package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;
import java.util.List;

public class BannerListResultBean implements Serializable {

    /**
     * code : 0
     * message : {"zh_TW":"成功","en_US":"Successful","zh_CN":"成功"}
     * data : [{"id":"4679529775088272896","img":"\"{\\\"en_US\\\": \\\"5d721189e4b00e8f5f3bbaf5.jpg\\\", \\\"zh_CN\\\": \\\"5dee11a6e4b05df0062f36db.jpg\\\", \\\"zh_TW\\\": \\\"5d721189e4b00e8f5f3bbaf5.jpg\\\"}\"","url":"http://www.360doc.com/content/13/1009/11/12424571_320027721.shtml"},{"id":"5326150333221570048","img":"\"{\\\"en_US\\\": \\\"5fbe2a81e4b0112882bf60e5.png\\\", \\\"zh_CN\\\": \\\"5fbe2a81e4b0112882bf60e5.png\\\", \\\"zh_TW\\\": \\\"5fbe2a81e4b0112882bf60e5.png\\\"}\"","url":"http://www.baidu.com"},{"id":"3905745998810448384","img":"\"{\\\"zh_CN\\\": \\\"5dedc443e4b05df0062f3633.png\\\"}\"","url":"http://www.360doc.com/content/13/1009/11/12424571_320027721.shtml"},{"id":"4679530152273643008","img":"\"{\\\"en_US\\\": \\\"5d72119be4b00e8f5f3bbafa.jpg\\\", \\\"zh_CN\\\": \\\"5d72119be4b00e8f5f3bbafa.jpg\\\", \\\"zh_TW\\\": \\\"5d72119be4b00e8f5f3bbafa.jpg\\\"}\"","url":"http://www.360doc.com/content/13/1009/11/12424571_320027721.shtml"},{"id":"3908265843523322368","img":"\"{\\\"en_US\\\": \\\"5abb93e3e4b064294fb25eea.jpg\\\", \\\"zh_CN\\\": \\\"5d2e9b6ee4b07f6b49a08500.jpg\\\", \\\"zh_TW\\\": \\\"5ab49baa58a4a31e83da9b80.jpg\\\"}\"","url":"http://www.360doc.com/content/13/1009/11/12424571_320027721.shtml1"}]
     */

    private String code;
    private Object message;
    private List<DataBean> data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class MessageBean {
        /**
         * zh_TW : 成功
         * en_US : Successful
         * zh_CN : 成功
         */

        private String zh_TW;
        private String en_US;
        private String zh_CN;

        public String getZh_TW() {
            return zh_TW;
        }

        public void setZh_TW(String zh_TW) {
            this.zh_TW = zh_TW;
        }

        public String getEn_US() {
            return en_US;
        }

        public void setEn_US(String en_US) {
            this.en_US = en_US;
        }

        public String getZh_CN() {
            return zh_CN;
        }

        public void setZh_CN(String zh_CN) {
            this.zh_CN = zh_CN;
        }
    }

    public static class DataBean implements Serializable {

        private String id;
        private String img;
        private String url;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getImg() {
            return img;
        }

        public void setImg(String img) {
            this.img = img;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }
}
