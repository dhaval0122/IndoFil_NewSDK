package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;

public class ChallengeResponse implements Serializable {

    private ChallengeResponseBean challengeResponse;

    public ChallengeResponseBean getChallengeResponse() {
        return challengeResponse;
    }

    public void setChallengeResponse(ChallengeResponseBean challengeResponse) {
        this.challengeResponse = challengeResponse;
    }

    public static class ChallengeResponseBean implements Serializable {

        private String authenticationId;
        private String challengeCode;
        private String response;
        private String uaid;

        public String getAuthenticationId() {
            return authenticationId;
        }

        public void setAuthenticationId(String authenticationId) {
            this.authenticationId = authenticationId;
        }

        public String getChallengeCode() {
            return challengeCode;
        }

        public void setChallengeCode(String challengeCode) {
            this.challengeCode = challengeCode;
        }

        public String getResponse() {
            return response;
        }

        public void setResponse(String response) {
            this.response = response;
        }

        public String getUaid() {
            return uaid;
        }

        public void setUaid(String uaid) {
            this.uaid = uaid;
        }
    }
}
