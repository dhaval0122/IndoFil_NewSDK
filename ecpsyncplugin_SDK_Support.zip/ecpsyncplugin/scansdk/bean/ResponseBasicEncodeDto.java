/*
 * @(#)ResponseBasicEncodeDto.java       Nov 28, 2017 1:43:10 PM
 *
 * Copyright (c) 2004-2016 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class ResponseBasicEncodeDto extends ResBasicDto {
    private String data;

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

}
