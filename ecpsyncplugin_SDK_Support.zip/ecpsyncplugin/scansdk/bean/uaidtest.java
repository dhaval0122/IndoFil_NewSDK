package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.util.List;

public class uaidtest {

    /**
     * code : 0
     * message : Successful
     * data : {"uaid":{"companyCode":"axbsec","uaid":"oLweybFeEQdg","authenticated":true,"specs":{"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]},"labelTypeCode":null,"currentOwner":{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1677829137000,"blockchainTransactionId":null},"uaidBatch":{"batchNumber":1857,"seqNumber":2},"thirdPartyCode":null,"layerNumberInSpecs":2,"expiresAt":1772436337000,"status":2},"hiddenProductInfo":[],"ownerHistory":[{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1677829137000,"blockchainTransactionId":null}],"scanData":{"lastScanAt":1677829137000,"firstScanByDisplayName":"<Anonymous>","totalScanCount":1,"firstScanAt":1677829137000,"lastScanByDisplayName":"<Anonymous>","firstScanByUsername":"<Anonymous>","lastScanByUsername":"<Anonymous>"},"challenge":{"challengeCode":null,"format":"1"},"authenticationMessage":{"code":"msg_code_successful","message":"{\"title\":\"Congratulation!\",\"content\":\"Your product has been authenticated successfully.\"}"},"authenticationId":"6966722314815934976","ownershipData":{"scantime":1677829137000,"signature":"d7/1sIUbMC3x1xMlz8o9IyoBGwszmBN2kQoXnHlonZLbifxqljPr5uoXKm/W+8iCiAwjBhRRjNVatw+rTN/a7c6aKnTRcki7k0AYds508qINFbtKbHHuf1hnCutme31ejm8AgH/6Ej0FSB6GTbxkdcDy18gXkPcfXRV2UyRhG/bX34AsBxe8FX1N+q6AJPWwrfzMDggpEV1CoRYHG8q5KtCoI7GXfT4vAOCX8bn/4ad+ICvFw5DnLJSA3+XjeTDPubobRJIulLPvV08z6JiSwEhAaE07FFb3HOj/wxgTdCEJy5QoCGjciVUjigNkIv8w8HV9ZgKufxv+Ow1WiDSlY7NJzkH1IzxoWoA6aLPsVA2A0KJV1MpqPlsCnuYhjRHq593bSyRWqFtzjAKybiIABRE8olg3GU+onVwQHBUfq3G0jkvq2yOXwV/5Qi60x120q+YIEuVoGHDwCvW238eDca6DfXlJ53hDUq/nln37D4UIGoN4aXzEwXTazR5RXbeeri+1G65NaETV11M/tM2u+7px3sPBwsn0V9cyvbERrjOXSizUTx+rJR+AEYNnGLwpjvmtu/5ZohN+o1nlAvryaFOhWBnkIpBWpQcgL9mgUOl0LsAlOm3a4ad8YUOSvItNkgld0J7x3kY33eMTEvt71IxKucjbFQvcJt842s0Zj14=","type":"owner","euaid":"0ytwodm5AQTU","huaid":"oLweybFeEQdg"},"productBatch":{"productCategoryCode":"fish","images":[{"code":"img","imagePath":"5e9437f3e4b0a1438e50fb7d.jpeg","sequence":1,"displayFlag":true},{"code":"1530becc-378f-4502-8f48-a96341611555","imagePath":"5f5097b6e4b0fc8a2586d765.jpg","sequence":2,"displayFlag":true}],"rawMaterials":[],"attributes":[{"code":null,"name":{"zh_TW":"不是好东西","en_US":"不是好东西","zh_CN":"不是好东西"},"value":{"zh_TW":"啊啊","en_US":"啊啊","zh_CN":"啊啊"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"883ab58a-c6d6-44e5-8e78-180aca35a327","name":{"zh_TW":"捕捞日期","en_US":"捕捞日期","zh_CN":"捕捞日期"},"value":"2020-09-30","sequence":2,"valueType":2,"fieldType":1,"displayFormat":"yyyy-mm-dd","displayFlag":true},{"code":"6f24a784-3720-43ff-a6a8-5c5f4b4ccc1b","name":{"zh_TW":"长度","en_US":"长度","zh_CN":"长度"},"value":{"zh_TW":"222","en_US":"222","zh_CN":"66"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"13aed908-6a58-4224-9b8d-65f5adfdda78","name":{"zh_TW":"重量","en_US":"重量","zh_CN":"净重量"},"value":"60kg","sequence":4,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"name","name":{"zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","vi_VN":"Tên sản phẩm"},"value":{"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true}],"productNumber":"wutou.ww.","productName":{"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"},"productBatchNumber":"删除","blockchainTransactionId":null}}
     */

    private String code;
    private String message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * uaid : {"companyCode":"axbsec","uaid":"oLweybFeEQdg","authenticated":true,"specs":{"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]},"labelTypeCode":null,"currentOwner":{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1677829137000,"blockchainTransactionId":null},"uaidBatch":{"batchNumber":1857,"seqNumber":2},"thirdPartyCode":null,"layerNumberInSpecs":2,"expiresAt":1772436337000,"status":2}
         * hiddenProductInfo : []
         * ownerHistory : [{"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1677829137000,"blockchainTransactionId":null}]
         * scanData : {"lastScanAt":1677829137000,"firstScanByDisplayName":"<Anonymous>","totalScanCount":1,"firstScanAt":1677829137000,"lastScanByDisplayName":"<Anonymous>","firstScanByUsername":"<Anonymous>","lastScanByUsername":"<Anonymous>"}
         * challenge : {"challengeCode":null,"format":"1"}
         * authenticationMessage : {"code":"msg_code_successful","message":"{\"title\":\"Congratulation!\",\"content\":\"Your product has been authenticated successfully.\"}"}
         * authenticationId : 6966722314815934976
         * ownershipData : {"scantime":1677829137000,"signature":"d7/1sIUbMC3x1xMlz8o9IyoBGwszmBN2kQoXnHlonZLbifxqljPr5uoXKm/W+8iCiAwjBhRRjNVatw+rTN/a7c6aKnTRcki7k0AYds508qINFbtKbHHuf1hnCutme31ejm8AgH/6Ej0FSB6GTbxkdcDy18gXkPcfXRV2UyRhG/bX34AsBxe8FX1N+q6AJPWwrfzMDggpEV1CoRYHG8q5KtCoI7GXfT4vAOCX8bn/4ad+ICvFw5DnLJSA3+XjeTDPubobRJIulLPvV08z6JiSwEhAaE07FFb3HOj/wxgTdCEJy5QoCGjciVUjigNkIv8w8HV9ZgKufxv+Ow1WiDSlY7NJzkH1IzxoWoA6aLPsVA2A0KJV1MpqPlsCnuYhjRHq593bSyRWqFtzjAKybiIABRE8olg3GU+onVwQHBUfq3G0jkvq2yOXwV/5Qi60x120q+YIEuVoGHDwCvW238eDca6DfXlJ53hDUq/nln37D4UIGoN4aXzEwXTazR5RXbeeri+1G65NaETV11M/tM2u+7px3sPBwsn0V9cyvbERrjOXSizUTx+rJR+AEYNnGLwpjvmtu/5ZohN+o1nlAvryaFOhWBnkIpBWpQcgL9mgUOl0LsAlOm3a4ad8YUOSvItNkgld0J7x3kY33eMTEvt71IxKucjbFQvcJt842s0Zj14=","type":"owner","euaid":"0ytwodm5AQTU","huaid":"oLweybFeEQdg"}
         * productBatch : {"productCategoryCode":"fish","images":[{"code":"img","imagePath":"5e9437f3e4b0a1438e50fb7d.jpeg","sequence":1,"displayFlag":true},{"code":"1530becc-378f-4502-8f48-a96341611555","imagePath":"5f5097b6e4b0fc8a2586d765.jpg","sequence":2,"displayFlag":true}],"rawMaterials":[],"attributes":[{"code":null,"name":{"zh_TW":"不是好东西","en_US":"不是好东西","zh_CN":"不是好东西"},"value":{"zh_TW":"啊啊","en_US":"啊啊","zh_CN":"啊啊"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"883ab58a-c6d6-44e5-8e78-180aca35a327","name":{"zh_TW":"捕捞日期","en_US":"捕捞日期","zh_CN":"捕捞日期"},"value":"2020-09-30","sequence":2,"valueType":2,"fieldType":1,"displayFormat":"yyyy-mm-dd","displayFlag":true},{"code":"6f24a784-3720-43ff-a6a8-5c5f4b4ccc1b","name":{"zh_TW":"长度","en_US":"长度","zh_CN":"长度"},"value":{"zh_TW":"222","en_US":"222","zh_CN":"66"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"13aed908-6a58-4224-9b8d-65f5adfdda78","name":{"zh_TW":"重量","en_US":"重量","zh_CN":"净重量"},"value":"60kg","sequence":4,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"name","name":{"zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","vi_VN":"Tên sản phẩm"},"value":{"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true}],"productNumber":"wutou.ww.","productName":{"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"},"productBatchNumber":"删除","blockchainTransactionId":null}
         */

        private UaidBean uaid;
        private ScanDataBean scanData;
        private ChallengeBean challenge;
        private AuthenticationMessageBean authenticationMessage;
        private String authenticationId;
        private OwnershipDataBean ownershipData;
        private ProductBatchBean productBatch;
        private List<?> hiddenProductInfo;
        private List<OwnerHistoryBean> ownerHistory;

        public UaidBean getUaid() {
            return uaid;
        }

        public void setUaid(UaidBean uaid) {
            this.uaid = uaid;
        }

        public ScanDataBean getScanData() {
            return scanData;
        }

        public void setScanData(ScanDataBean scanData) {
            this.scanData = scanData;
        }

        public ChallengeBean getChallenge() {
            return challenge;
        }

        public void setChallenge(ChallengeBean challenge) {
            this.challenge = challenge;
        }

        public AuthenticationMessageBean getAuthenticationMessage() {
            return authenticationMessage;
        }

        public void setAuthenticationMessage(AuthenticationMessageBean authenticationMessage) {
            this.authenticationMessage = authenticationMessage;
        }

        public String getAuthenticationId() {
            return authenticationId;
        }

        public void setAuthenticationId(String authenticationId) {
            this.authenticationId = authenticationId;
        }

        public OwnershipDataBean getOwnershipData() {
            return ownershipData;
        }

        public void setOwnershipData(OwnershipDataBean ownershipData) {
            this.ownershipData = ownershipData;
        }

        public ProductBatchBean getProductBatch() {
            return productBatch;
        }

        public void setProductBatch(ProductBatchBean productBatch) {
            this.productBatch = productBatch;
        }

        public List<?> getHiddenProductInfo() {
            return hiddenProductInfo;
        }

        public void setHiddenProductInfo(List<?> hiddenProductInfo) {
            this.hiddenProductInfo = hiddenProductInfo;
        }

        public List<OwnerHistoryBean> getOwnerHistory() {
            return ownerHistory;
        }

        public void setOwnerHistory(List<OwnerHistoryBean> ownerHistory) {
            this.ownerHistory = ownerHistory;
        }

        public static class UaidBean {
            /**
             * companyCode : axbsec
             * uaid : oLweybFeEQdg
             * authenticated : true
             * specs : {"type":1,"layers":[{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]}
             * labelTypeCode : null
             * currentOwner : {"username":"<Anonymous>","displayName":"<Anonymous>","avatarImagePath":null,"effectiveAt":1677829137000,"blockchainTransactionId":null}
             * uaidBatch : {"batchNumber":1857,"seqNumber":2}
             * thirdPartyCode : null
             * layerNumberInSpecs : 2
             * expiresAt : 1772436337000
             * status : 2
             */

            private String companyCode;
            private String uaid;
            private boolean authenticated;
            private SpecsBean specs;
            private Object labelTypeCode;
            private CurrentOwnerBean currentOwner;
            private UaidBatchBean uaidBatch;
            private Object thirdPartyCode;
            private int layerNumberInSpecs;
            private long expiresAt;
            private int status;

            public String getCompanyCode() {
                return companyCode;
            }

            public void setCompanyCode(String companyCode) {
                this.companyCode = companyCode;
            }

            public String getUaid() {
                return uaid;
            }

            public void setUaid(String uaid) {
                this.uaid = uaid;
            }

            public boolean isAuthenticated() {
                return authenticated;
            }

            public void setAuthenticated(boolean authenticated) {
                this.authenticated = authenticated;
            }

            public SpecsBean getSpecs() {
                return specs;
            }

            public void setSpecs(SpecsBean specs) {
                this.specs = specs;
            }

            public Object getLabelTypeCode() {
                return labelTypeCode;
            }

            public void setLabelTypeCode(Object labelTypeCode) {
                this.labelTypeCode = labelTypeCode;
            }

            public CurrentOwnerBean getCurrentOwner() {
                return currentOwner;
            }

            public void setCurrentOwner(CurrentOwnerBean currentOwner) {
                this.currentOwner = currentOwner;
            }

            public UaidBatchBean getUaidBatch() {
                return uaidBatch;
            }

            public void setUaidBatch(UaidBatchBean uaidBatch) {
                this.uaidBatch = uaidBatch;
            }

            public Object getThirdPartyCode() {
                return thirdPartyCode;
            }

            public void setThirdPartyCode(Object thirdPartyCode) {
                this.thirdPartyCode = thirdPartyCode;
            }

            public int getLayerNumberInSpecs() {
                return layerNumberInSpecs;
            }

            public void setLayerNumberInSpecs(int layerNumberInSpecs) {
                this.layerNumberInSpecs = layerNumberInSpecs;
            }

            public long getExpiresAt() {
                return expiresAt;
            }

            public void setExpiresAt(long expiresAt) {
                this.expiresAt = expiresAt;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public static class SpecsBean {
                /**
                 * type : 1
                 * layers : [{"layerNumber":1,"type":1,"format":1,"subFormat":null},{"layerNumber":2,"type":2,"format":1,"subFormat":null}]
                 */

                private int type;
                private List<LayersBean> layers;

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public List<LayersBean> getLayers() {
                    return layers;
                }

                public void setLayers(List<LayersBean> layers) {
                    this.layers = layers;
                }

                public static class LayersBean {
                    /**
                     * layerNumber : 1
                     * type : 1
                     * format : 1
                     * subFormat : null
                     */

                    private int layerNumber;
                    private int type;
                    private int format;
                    private Object subFormat;

                    public int getLayerNumber() {
                        return layerNumber;
                    }

                    public void setLayerNumber(int layerNumber) {
                        this.layerNumber = layerNumber;
                    }

                    public int getType() {
                        return type;
                    }

                    public void setType(int type) {
                        this.type = type;
                    }

                    public int getFormat() {
                        return format;
                    }

                    public void setFormat(int format) {
                        this.format = format;
                    }

                    public Object getSubFormat() {
                        return subFormat;
                    }

                    public void setSubFormat(Object subFormat) {
                        this.subFormat = subFormat;
                    }
                }
            }

            public static class CurrentOwnerBean {
                /**
                 * username : <Anonymous>
                 * displayName : <Anonymous>
                 * avatarImagePath : null
                 * effectiveAt : 1677829137000
                 * blockchainTransactionId : null
                 */

                private String username;
                private String displayName;
                private Object avatarImagePath;
                private long effectiveAt;
                private Object blockchainTransactionId;

                public String getUsername() {
                    return username;
                }

                public void setUsername(String username) {
                    this.username = username;
                }

                public String getDisplayName() {
                    return displayName;
                }

                public void setDisplayName(String displayName) {
                    this.displayName = displayName;
                }

                public Object getAvatarImagePath() {
                    return avatarImagePath;
                }

                public void setAvatarImagePath(Object avatarImagePath) {
                    this.avatarImagePath = avatarImagePath;
                }

                public long getEffectiveAt() {
                    return effectiveAt;
                }

                public void setEffectiveAt(long effectiveAt) {
                    this.effectiveAt = effectiveAt;
                }

                public Object getBlockchainTransactionId() {
                    return blockchainTransactionId;
                }

                public void setBlockchainTransactionId(Object blockchainTransactionId) {
                    this.blockchainTransactionId = blockchainTransactionId;
                }
            }

            public static class UaidBatchBean {
                /**
                 * batchNumber : 1857
                 * seqNumber : 2
                 */

                private int batchNumber;
                private int seqNumber;

                public int getBatchNumber() {
                    return batchNumber;
                }

                public void setBatchNumber(int batchNumber) {
                    this.batchNumber = batchNumber;
                }

                public int getSeqNumber() {
                    return seqNumber;
                }

                public void setSeqNumber(int seqNumber) {
                    this.seqNumber = seqNumber;
                }
            }
        }

        public static class ScanDataBean {
            /**
             * lastScanAt : 1677829137000
             * firstScanByDisplayName : <Anonymous>
             * totalScanCount : 1
             * firstScanAt : 1677829137000
             * lastScanByDisplayName : <Anonymous>
             * firstScanByUsername : <Anonymous>
             * lastScanByUsername : <Anonymous>
             */

            private long lastScanAt;
            private String firstScanByDisplayName;
            private int totalScanCount;
            private long firstScanAt;
            private String lastScanByDisplayName;
            private String firstScanByUsername;
            private String lastScanByUsername;

            public long getLastScanAt() {
                return lastScanAt;
            }

            public void setLastScanAt(long lastScanAt) {
                this.lastScanAt = lastScanAt;
            }

            public String getFirstScanByDisplayName() {
                return firstScanByDisplayName;
            }

            public void setFirstScanByDisplayName(String firstScanByDisplayName) {
                this.firstScanByDisplayName = firstScanByDisplayName;
            }

            public int getTotalScanCount() {
                return totalScanCount;
            }

            public void setTotalScanCount(int totalScanCount) {
                this.totalScanCount = totalScanCount;
            }

            public long getFirstScanAt() {
                return firstScanAt;
            }

            public void setFirstScanAt(long firstScanAt) {
                this.firstScanAt = firstScanAt;
            }

            public String getLastScanByDisplayName() {
                return lastScanByDisplayName;
            }

            public void setLastScanByDisplayName(String lastScanByDisplayName) {
                this.lastScanByDisplayName = lastScanByDisplayName;
            }

            public String getFirstScanByUsername() {
                return firstScanByUsername;
            }

            public void setFirstScanByUsername(String firstScanByUsername) {
                this.firstScanByUsername = firstScanByUsername;
            }

            public String getLastScanByUsername() {
                return lastScanByUsername;
            }

            public void setLastScanByUsername(String lastScanByUsername) {
                this.lastScanByUsername = lastScanByUsername;
            }
        }

        public static class ChallengeBean {
            /**
             * challengeCode : null
             * format : 1
             */

            private Object challengeCode;
            private String format;

            public Object getChallengeCode() {
                return challengeCode;
            }

            public void setChallengeCode(Object challengeCode) {
                this.challengeCode = challengeCode;
            }

            public String getFormat() {
                return format;
            }

            public void setFormat(String format) {
                this.format = format;
            }
        }

        public static class AuthenticationMessageBean {
            /**
             * code : msg_code_successful
             * message : {"title":"Congratulation!","content":"Your product has been authenticated successfully."}
             */

            private String code;
            private String message;

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public String getMessage() {
                return message;
            }

            public void setMessage(String message) {
                this.message = message;
            }
        }

        public static class OwnershipDataBean {
            /**
             * scantime : 1677829137000
             * signature : d7/1sIUbMC3x1xMlz8o9IyoBGwszmBN2kQoXnHlonZLbifxqljPr5uoXKm/W+8iCiAwjBhRRjNVatw+rTN/a7c6aKnTRcki7k0AYds508qINFbtKbHHuf1hnCutme31ejm8AgH/6Ej0FSB6GTbxkdcDy18gXkPcfXRV2UyRhG/bX34AsBxe8FX1N+q6AJPWwrfzMDggpEV1CoRYHG8q5KtCoI7GXfT4vAOCX8bn/4ad+ICvFw5DnLJSA3+XjeTDPubobRJIulLPvV08z6JiSwEhAaE07FFb3HOj/wxgTdCEJy5QoCGjciVUjigNkIv8w8HV9ZgKufxv+Ow1WiDSlY7NJzkH1IzxoWoA6aLPsVA2A0KJV1MpqPlsCnuYhjRHq593bSyRWqFtzjAKybiIABRE8olg3GU+onVwQHBUfq3G0jkvq2yOXwV/5Qi60x120q+YIEuVoGHDwCvW238eDca6DfXlJ53hDUq/nln37D4UIGoN4aXzEwXTazR5RXbeeri+1G65NaETV11M/tM2u+7px3sPBwsn0V9cyvbERrjOXSizUTx+rJR+AEYNnGLwpjvmtu/5ZohN+o1nlAvryaFOhWBnkIpBWpQcgL9mgUOl0LsAlOm3a4ad8YUOSvItNkgld0J7x3kY33eMTEvt71IxKucjbFQvcJt842s0Zj14=
             * type : owner
             * euaid : 0ytwodm5AQTU
             * huaid : oLweybFeEQdg
             */

            private long scantime;
            private String signature;
            private String type;
            private String euaid;
            private String huaid;

            public long getScantime() {
                return scantime;
            }

            public void setScantime(long scantime) {
                this.scantime = scantime;
            }

            public String getSignature() {
                return signature;
            }

            public void setSignature(String signature) {
                this.signature = signature;
            }

            public String getType() {
                return type;
            }

            public void setType(String type) {
                this.type = type;
            }

            public String getEuaid() {
                return euaid;
            }

            public void setEuaid(String euaid) {
                this.euaid = euaid;
            }

            public String getHuaid() {
                return huaid;
            }

            public void setHuaid(String huaid) {
                this.huaid = huaid;
            }
        }

        public static class ProductBatchBean {
            /**
             * productCategoryCode : fish
             * images : [{"code":"img","imagePath":"5e9437f3e4b0a1438e50fb7d.jpeg","sequence":1,"displayFlag":true},{"code":"1530becc-378f-4502-8f48-a96341611555","imagePath":"5f5097b6e4b0fc8a2586d765.jpg","sequence":2,"displayFlag":true}]
             * rawMaterials : []
             * attributes : [{"code":null,"name":{"zh_TW":"不是好东西","en_US":"不是好东西","zh_CN":"不是好东西"},"value":{"zh_TW":"啊啊","en_US":"啊啊","zh_CN":"啊啊"},"sequence":1,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"883ab58a-c6d6-44e5-8e78-180aca35a327","name":{"zh_TW":"捕捞日期","en_US":"捕捞日期","zh_CN":"捕捞日期"},"value":"2020-09-30","sequence":2,"valueType":2,"fieldType":1,"displayFormat":"yyyy-mm-dd","displayFlag":true},{"code":"6f24a784-3720-43ff-a6a8-5c5f4b4ccc1b","name":{"zh_TW":"长度","en_US":"长度","zh_CN":"长度"},"value":{"zh_TW":"222","en_US":"222","zh_CN":"66"},"sequence":3,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"13aed908-6a58-4224-9b8d-65f5adfdda78","name":{"zh_TW":"重量","en_US":"重量","zh_CN":"净重量"},"value":"60kg","sequence":4,"valueType":2,"fieldType":1,"displayFormat":null,"displayFlag":true},{"code":"name","name":{"zh_TW":"商品名","en_US":"Product Name","zh_CN":"商品名","vi_VN":"Tên sản phẩm"},"value":{"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"},"sequence":5,"valueType":1,"fieldType":1,"displayFormat":null,"displayFlag":true}]
             * productNumber : wutou.ww.
             * productName : {"zh_TW":"乌头","en_US":"乌头","zh_CN":"乌头"}
             * productBatchNumber : 删除
             * blockchainTransactionId : null
             */

            private String productCategoryCode;
            private String productNumber;
            private ProductNameBean productName;
            private String productBatchNumber;
            private Object blockchainTransactionId;
            private List<ImagesBean> images;
            private List<?> rawMaterials;
            private List<AttributesBean> attributes;

            public String getProductCategoryCode() {
                return productCategoryCode;
            }

            public void setProductCategoryCode(String productCategoryCode) {
                this.productCategoryCode = productCategoryCode;
            }

            public String getProductNumber() {
                return productNumber;
            }

            public void setProductNumber(String productNumber) {
                this.productNumber = productNumber;
            }

            public ProductNameBean getProductName() {
                return productName;
            }

            public void setProductName(ProductNameBean productName) {
                this.productName = productName;
            }

            public String getProductBatchNumber() {
                return productBatchNumber;
            }

            public void setProductBatchNumber(String productBatchNumber) {
                this.productBatchNumber = productBatchNumber;
            }

            public Object getBlockchainTransactionId() {
                return blockchainTransactionId;
            }

            public void setBlockchainTransactionId(Object blockchainTransactionId) {
                this.blockchainTransactionId = blockchainTransactionId;
            }

            public List<ImagesBean> getImages() {
                return images;
            }

            public void setImages(List<ImagesBean> images) {
                this.images = images;
            }

            public List<?> getRawMaterials() {
                return rawMaterials;
            }

            public void setRawMaterials(List<?> rawMaterials) {
                this.rawMaterials = rawMaterials;
            }

            public List<AttributesBean> getAttributes() {
                return attributes;
            }

            public void setAttributes(List<AttributesBean> attributes) {
                this.attributes = attributes;
            }

            public static class ProductNameBean {
                /**
                 * zh_TW : 乌头
                 * en_US : 乌头
                 * zh_CN : 乌头
                 */

                private String zh_TW;
                private String en_US;
                private String zh_CN;

                public String getZh_TW() {
                    return zh_TW;
                }

                public void setZh_TW(String zh_TW) {
                    this.zh_TW = zh_TW;
                }

                public String getEn_US() {
                    return en_US;
                }

                public void setEn_US(String en_US) {
                    this.en_US = en_US;
                }

                public String getZh_CN() {
                    return zh_CN;
                }

                public void setZh_CN(String zh_CN) {
                    this.zh_CN = zh_CN;
                }
            }

            public static class ImagesBean {
                /**
                 * code : img
                 * imagePath : 5e9437f3e4b0a1438e50fb7d.jpeg
                 * sequence : 1
                 * displayFlag : true
                 */

                private String code;
                private String imagePath;
                private int sequence;
                private boolean displayFlag;

                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                public String getImagePath() {
                    return imagePath;
                }

                public void setImagePath(String imagePath) {
                    this.imagePath = imagePath;
                }

                public int getSequence() {
                    return sequence;
                }

                public void setSequence(int sequence) {
                    this.sequence = sequence;
                }

                public boolean isDisplayFlag() {
                    return displayFlag;
                }

                public void setDisplayFlag(boolean displayFlag) {
                    this.displayFlag = displayFlag;
                }
            }

            public static class AttributesBean {
                /**
                 * code : null
                 * name : {"zh_TW":"不是好东西","en_US":"不是好东西","zh_CN":"不是好东西"}
                 * value : {"zh_TW":"啊啊","en_US":"啊啊","zh_CN":"啊啊"}
                 * sequence : 1
                 * valueType : 1
                 * fieldType : 1
                 * displayFormat : null
                 * displayFlag : true
                 */

                private Object code;
                private NameBean name;
                private ValueBean value;
                private int sequence;
                private int valueType;
                private int fieldType;
                private Object displayFormat;
                private boolean displayFlag;

                public Object getCode() {
                    return code;
                }

                public void setCode(Object code) {
                    this.code = code;
                }

                public NameBean getName() {
                    return name;
                }

                public void setName(NameBean name) {
                    this.name = name;
                }

                public ValueBean getValue() {
                    return value;
                }

                public void setValue(ValueBean value) {
                    this.value = value;
                }

                public int getSequence() {
                    return sequence;
                }

                public void setSequence(int sequence) {
                    this.sequence = sequence;
                }

                public int getValueType() {
                    return valueType;
                }

                public void setValueType(int valueType) {
                    this.valueType = valueType;
                }

                public int getFieldType() {
                    return fieldType;
                }

                public void setFieldType(int fieldType) {
                    this.fieldType = fieldType;
                }

                public Object getDisplayFormat() {
                    return displayFormat;
                }

                public void setDisplayFormat(Object displayFormat) {
                    this.displayFormat = displayFormat;
                }

                public boolean isDisplayFlag() {
                    return displayFlag;
                }

                public void setDisplayFlag(boolean displayFlag) {
                    this.displayFlag = displayFlag;
                }

                public static class NameBean {
                    /**
                     * zh_TW : 不是好东西
                     * en_US : 不是好东西
                     * zh_CN : 不是好东西
                     */

                    private String zh_TW;
                    private String en_US;
                    private String zh_CN;

                    public String getZh_TW() {
                        return zh_TW;
                    }

                    public void setZh_TW(String zh_TW) {
                        this.zh_TW = zh_TW;
                    }

                    public String getEn_US() {
                        return en_US;
                    }

                    public void setEn_US(String en_US) {
                        this.en_US = en_US;
                    }

                    public String getZh_CN() {
                        return zh_CN;
                    }

                    public void setZh_CN(String zh_CN) {
                        this.zh_CN = zh_CN;
                    }
                }

                public static class ValueBean {
                    /**
                     * zh_TW : 啊啊
                     * en_US : 啊啊
                     * zh_CN : 啊啊
                     */

                    private String zh_TW;
                    private String en_US;
                    private String zh_CN;

                    public String getZh_TW() {
                        return zh_TW;
                    }

                    public void setZh_TW(String zh_TW) {
                        this.zh_TW = zh_TW;
                    }

                    public String getEn_US() {
                        return en_US;
                    }

                    public void setEn_US(String en_US) {
                        this.en_US = en_US;
                    }

                    public String getZh_CN() {
                        return zh_CN;
                    }

                    public void setZh_CN(String zh_CN) {
                        this.zh_CN = zh_CN;
                    }
                }
            }
        }

        public static class OwnerHistoryBean {
            /**
             * username : <Anonymous>
             * displayName : <Anonymous>
             * avatarImagePath : null
             * effectiveAt : 1677829137000
             * blockchainTransactionId : null
             */

            private String username;
            private String displayName;
            private Object avatarImagePath;
            private long effectiveAt;
            private Object blockchainTransactionId;

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public Object getAvatarImagePath() {
                return avatarImagePath;
            }

            public void setAvatarImagePath(Object avatarImagePath) {
                this.avatarImagePath = avatarImagePath;
            }

            public long getEffectiveAt() {
                return effectiveAt;
            }

            public void setEffectiveAt(long effectiveAt) {
                this.effectiveAt = effectiveAt;
            }

            public Object getBlockchainTransactionId() {
                return blockchainTransactionId;
            }

            public void setBlockchainTransactionId(Object blockchainTransactionId) {
                this.blockchainTransactionId = blockchainTransactionId;
            }
        }
    }
}
