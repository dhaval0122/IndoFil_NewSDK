package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.util.List;

public class VerifyEntity {

    private UaidBean uaid;
    private Object hiddenProductInfo;
    private List<OwnerHistoryBean> ownerHistory;
    private ScanDataBean scanData;
    private ChallengeBean challenge;
    private AuthenticationMessageBean authenticationMessage;
    private String authenticationId;
    private OwnerShipData ownershipData;
    private ProductBatchBean productBatch;

    public UaidBean getUaid() {
        return uaid;
    }

    public void setUaid(UaidBean uaid) {
        this.uaid = uaid;
    }

    public Object getHiddenProductInfo() {
        return hiddenProductInfo;
    }

    public void setHiddenProductInfo(Object hiddenProductInfo) {
        this.hiddenProductInfo = hiddenProductInfo;
    }

    public List<OwnerHistoryBean> getOwnerHistory() {
        return ownerHistory;
    }

    public void setOwnerHistory(List<OwnerHistoryBean> ownerHistory) {
        this.ownerHistory = ownerHistory;
    }

    public ScanDataBean getScanData() {
        return scanData;
    }

    public void setScanData(ScanDataBean scanData) {
        this.scanData = scanData;
    }

    public ChallengeBean getChallenge() {
        return challenge;
    }

    public void setChallenge(ChallengeBean challenge) {
        this.challenge = challenge;
    }

    public AuthenticationMessageBean getAuthenticationMessage() {
        return authenticationMessage;
    }

    public void setAuthenticationMessage(AuthenticationMessageBean authenticationMessage) {
        this.authenticationMessage = authenticationMessage;
    }

    public String getAuthenticationId() {
        return authenticationId;
    }

    public void setAuthenticationId(String authenticationId) {
        this.authenticationId = authenticationId;
    }

    public OwnerShipData getOwnershipData() {
        return ownershipData;
    }

    public void setOwnershipData(OwnerShipData ownershipData) {
        this.ownershipData = ownershipData;
    }

    public ProductBatchBean getProductBatch() {
        return productBatch;
    }

    public void setProductBatch(ProductBatchBean productBatch) {
        this.productBatch = productBatch;
    }

    public static class UaidBean {
        private String companyCode;
        private String uaid;
        private boolean authenticated;
        private SpecsBean specs;
        private CurrentOwnerBean currentOwner;
        private UaidBatchBean uaidBatch;
        private Object thirdPartyCode;
        private int layerNumberInSpecs;
        private long expiresAt;
        private int status;

        public String getCompanyCode() {
            return companyCode;
        }

        public void setCompanyCode(String companyCode) {
            this.companyCode = companyCode;
        }

        public String getUaid() {
            return uaid;
        }

        public void setUaid(String uaid) {
            this.uaid = uaid;
        }

        public boolean isAuthenticated() {
            return authenticated;
        }

        public void setAuthenticated(boolean authenticated) {
            this.authenticated = authenticated;
        }

        public SpecsBean getSpecs() {
            return specs;
        }

        public void setSpecs(SpecsBean specs) {
            this.specs = specs;
        }

        public CurrentOwnerBean getCurrentOwner() {
            return currentOwner;
        }

        public void setCurrentOwner(CurrentOwnerBean currentOwner) {
            this.currentOwner = currentOwner;
        }

        public UaidBatchBean getUaidBatch() {
            return uaidBatch;
        }

        public void setUaidBatch(UaidBatchBean uaidBatch) {
            this.uaidBatch = uaidBatch;
        }

        public Object getThirdPartyCode() {
            return thirdPartyCode;
        }

        public void setThirdPartyCode(Object thirdPartyCode) {
            this.thirdPartyCode = thirdPartyCode;
        }

        public int getLayerNumberInSpecs() {
            return layerNumberInSpecs;
        }

        public void setLayerNumberInSpecs(int layerNumberInSpecs) {
            this.layerNumberInSpecs = layerNumberInSpecs;
        }

        public long getExpiresAt() {
            return expiresAt;
        }

        public void setExpiresAt(long expiresAt) {
            this.expiresAt = expiresAt;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public static class SpecsBean {
            private int type;
            private List<LayersBean> layers;

            public int getType() {
                return type;
            }

            public void setType(int type) {
                this.type = type;
            }

            public List<LayersBean> getLayers() {
                return layers;
            }

            public void setLayers(List<LayersBean> layers) {
                this.layers = layers;
            }

            public static class LayersBean {
                private int layerNumber;
                private int type;
                private int format;
                private Object subFormat;

                public int getLayerNumber() {
                    return layerNumber;
                }

                public void setLayerNumber(int layerNumber) {
                    this.layerNumber = layerNumber;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public int getFormat() {
                    return format;
                }

                public void setFormat(int format) {
                    this.format = format;
                }

                public Object getSubFormat() {
                    return subFormat;
                }

                public void setSubFormat(Object subFormat) {
                    this.subFormat = subFormat;
                }
            }
        }

        public static class CurrentOwnerBean {
            private String username;
            private String displayName;
            private String avatarImagePath;
            private long effectiveAt;
            private String blockchainTransactionId;

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }

            public String getDisplayName() {
                return displayName;
            }

            public void setDisplayName(String displayName) {
                this.displayName = displayName;
            }

            public String getAvatarImagePath() {
                return avatarImagePath;
            }

            public void setAvatarImagePath(String avatarImagePath) {
                this.avatarImagePath = avatarImagePath;
            }

            public long getEffectiveAt() {
                return effectiveAt;
            }

            public void setEffectiveAt(long effectiveAt) {
                this.effectiveAt = effectiveAt;
            }

            public String getBlockchainTransactionId() {
                return blockchainTransactionId;
            }

            public void setBlockchainTransactionId(String blockchainTransactionId) {
                this.blockchainTransactionId = blockchainTransactionId;
            }
        }

        public static class UaidBatchBean {
            private int batchNumber;
            private int seqNumber;

            public int getBatchNumber() {
                return batchNumber;
            }

            public void setBatchNumber(int batchNumber) {
                this.batchNumber = batchNumber;
            }

            public int getSeqNumber() {
                return seqNumber;
            }

            public void setSeqNumber(int seqNumber) {
                this.seqNumber = seqNumber;
            }
        }
    }

    public static class ScanDataBean {
        private long lastScanAt;
        private String firstScanByDisplayName;
        private int totalScanCount;
        private long firstScanAt;
        private String lastScanByDisplayName;
        private String firstScanByUsername;
        private String lastScanByUsername;

        public long getLastScanAt() {
            return lastScanAt;
        }

        public void setLastScanAt(long lastScanAt) {
            this.lastScanAt = lastScanAt;
        }

        public String getFirstScanByDisplayName() {
            return firstScanByDisplayName;
        }

        public void setFirstScanByDisplayName(String firstScanByDisplayName) {
            this.firstScanByDisplayName = firstScanByDisplayName;
        }

        public int getTotalScanCount() {
            return totalScanCount;
        }

        public void setTotalScanCount(int totalScanCount) {
            this.totalScanCount = totalScanCount;
        }

        public long getFirstScanAt() {
            return firstScanAt;
        }

        public void setFirstScanAt(long firstScanAt) {
            this.firstScanAt = firstScanAt;
        }

        public String getLastScanByDisplayName() {
            return lastScanByDisplayName;
        }

        public void setLastScanByDisplayName(String lastScanByDisplayName) {
            this.lastScanByDisplayName = lastScanByDisplayName;
        }

        public String getFirstScanByUsername() {
            return firstScanByUsername;
        }

        public void setFirstScanByUsername(String firstScanByUsername) {
            this.firstScanByUsername = firstScanByUsername;
        }

        public String getLastScanByUsername() {
            return lastScanByUsername;
        }

        public void setLastScanByUsername(String lastScanByUsername) {
            this.lastScanByUsername = lastScanByUsername;
        }
    }

    public static class ChallengeBean {
        private Object challengeCode;
        private String format;

        public Object getChallengeCode() {
            return challengeCode;
        }

        public void setChallengeCode(Object challengeCode) {
            this.challengeCode = challengeCode;
        }

        public String getFormat() {
            return format;
        }

        public void setFormat(String format) {
            this.format = format;
        }
    }

    public static class AuthenticationMessageBean {
        private String code;
        private Object message;

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public Object getMessage() {
            return message;
        }

        public void setMessage(Object message) {
            this.message = message;
        }

        public static class MessageBean {
            private String zh_TW;
            private String en_US;
            private String zh_CN;

            public String getZh_TW() {
                return zh_TW;
            }

            public void setZh_TW(String zh_TW) {
                this.zh_TW = zh_TW;
            }

            public String getEn_US() {
                return en_US;
            }

            public void setEn_US(String en_US) {
                this.en_US = en_US;
            }

            public String getZh_CN() {
                return zh_CN;
            }

            public void setZh_CN(String zh_CN) {
                this.zh_CN = zh_CN;
            }
        }
    }

    public static class ProductBatchBean {
        private String productCategoryCode;
        private List<ImagesBean> images;
        private List<?> rawMaterials;
        private List<AttributesBean> attributes;
        private String productNumber;
        private Object productName;
        private String productBatchNumber;
        private String blockchainTransactionId;

        public String getProductCategoryCode() {
            return productCategoryCode;
        }

        public void setProductCategoryCode(String productCategoryCode) {
            this.productCategoryCode = productCategoryCode;
        }

        public List<ImagesBean> getImages() {
            return images;
        }

        public void setImages(List<ImagesBean> images) {
            this.images = images;
        }

        public List<?> getRawMaterials() {
            return rawMaterials;
        }

        public void setRawMaterials(List<?> rawMaterials) {
            this.rawMaterials = rawMaterials;
        }

        public List<AttributesBean> getAttributes() {
            return attributes;
        }

        public void setAttributes(List<AttributesBean> attributes) {
            this.attributes = attributes;
        }

        public String getProductNumber() {
            return productNumber;
        }

        public void setProductNumber(String productNumber) {
            this.productNumber = productNumber;
        }

        public Object getProductName() {
            return productName;
        }

        public void setProductName(Object productName) {
            this.productName = productName;
        }

        public String getProductBatchNumber() {
            return productBatchNumber;
        }

        public void setProductBatchNumber(String productBatchNumber) {
            this.productBatchNumber = productBatchNumber;
        }

        public String getBlockchainTransactionId() {
            return blockchainTransactionId;
        }

        public void setBlockchainTransactionId(String blockchainTransactionId) {
            this.blockchainTransactionId = blockchainTransactionId;
        }

        public static class ProductNameBean {
            private String ms_MY;
            private String zh_TW;
            private String en_US;
            private String zh_CN;

            public String getMs_MY() {
                return ms_MY;
            }

            public void setMs_MY(String ms_MY) {
                this.ms_MY = ms_MY;
            }

            public String getZh_TW() {
                return zh_TW;
            }

            public void setZh_TW(String zh_TW) {
                this.zh_TW = zh_TW;
            }

            public String getEn_US() {
                return en_US;
            }

            public void setEn_US(String en_US) {
                this.en_US = en_US;
            }

            public String getZh_CN() {
                return zh_CN;
            }

            public void setZh_CN(String zh_CN) {
                this.zh_CN = zh_CN;
            }
        }

        public static class ImagesBean {
            private String code;
            private String imagePath;
            private int sequence;
            private boolean displayFlag;

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public String getImagePath() {
                return imagePath;
            }

            public void setImagePath(String imagePath) {
                this.imagePath = imagePath;
            }

            public int getSequence() {
                return sequence;
            }

            public void setSequence(int sequence) {
                this.sequence = sequence;
            }

            public boolean isDisplayFlag() {
                return displayFlag;
            }

            public void setDisplayFlag(boolean displayFlag) {
                this.displayFlag = displayFlag;
            }
        }

        public static class AttributesBean {
            private String code;
            private Object name;
            private Object value;
            private int sequence;
            private int valueType;
            private int fieldType;
            private Object displayFormat;
            private boolean displayFlag;

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public Object getName() {
                return name;
            }

            public void setName(Object name) {
                this.name = name;
            }

            public Object getValue() {
                return value;
            }

            public void setValue(Object value) {
                this.value = value;
            }

            public int getSequence() {
                return sequence;
            }

            public void setSequence(int sequence) {
                this.sequence = sequence;
            }

            public int getValueType() {
                return valueType;
            }

            public void setValueType(int valueType) {
                this.valueType = valueType;
            }

            public int getFieldType() {
                return fieldType;
            }

            public void setFieldType(int fieldType) {
                this.fieldType = fieldType;
            }

            public Object getDisplayFormat() {
                return displayFormat;
            }

            public void setDisplayFormat(Object displayFormat) {
                this.displayFormat = displayFormat;
            }

            public boolean isDisplayFlag() {
                return displayFlag;
            }

            public void setDisplayFlag(boolean displayFlag) {
                this.displayFlag = displayFlag;
            }

            public static class NameBean {
                private String ms_MY;
                private String zh_TW;
                private String en_US;
                private String zh_CN;

                public String getMs_MY() {
                    return ms_MY;
                }

                public void setMs_MY(String ms_MY) {
                    this.ms_MY = ms_MY;
                }

                public String getZh_TW() {
                    return zh_TW;
                }

                public void setZh_TW(String zh_TW) {
                    this.zh_TW = zh_TW;
                }

                public String getEn_US() {
                    return en_US;
                }

                public void setEn_US(String en_US) {
                    this.en_US = en_US;
                }

                public String getZh_CN() {
                    return zh_CN;
                }

                public void setZh_CN(String zh_CN) {
                    this.zh_CN = zh_CN;
                }
            }

            public static class ValueBean {
                private String ms_MY;
                private String zh_TW;
                private String en_US;
                private String zh_CN;

                public String getMs_MY() {
                    return ms_MY;
                }

                public void setMs_MY(String ms_MY) {
                    this.ms_MY = ms_MY;
                }

                public String getZh_TW() {
                    return zh_TW;
                }

                public void setZh_TW(String zh_TW) {
                    this.zh_TW = zh_TW;
                }

                public String getEn_US() {
                    return en_US;
                }

                public void setEn_US(String en_US) {
                    this.en_US = en_US;
                }

                public String getZh_CN() {
                    return zh_CN;
                }

                public void setZh_CN(String zh_CN) {
                    this.zh_CN = zh_CN;
                }
            }
        }
    }

    public static class  OwnerShipData{
        private String euaid;
        private String huaid;
        private String signature;
        private String type;
        private String scantime;

        public String getEuaid() {
            return euaid;
        }

        public void setEuaid(String euaid) {
            this.euaid = euaid;
        }

        public String getHuaid() {
            return huaid;
        }

        public void setHuaid(String huaid) {
            this.huaid = huaid;
        }

        public String getSignature() {
            return signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getScantime() {
            return scantime;
        }

        public void setScantime(String scantime) {
            this.scantime = scantime;
        }
    }
    public static class OwnerHistoryBean {
        private String username;
        private String displayName;
        private String avatarImagePath;
        private long effectiveAt;
        private String blockchainTransactionId;

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getDisplayName() {
            return displayName;
        }

        public void setDisplayName(String displayName) {
            this.displayName = displayName;
        }

        public String getAvatarImagePath() {
            return avatarImagePath;
        }

        public void setAvatarImagePath(String avatarImagePath) {
            this.avatarImagePath = avatarImagePath;
        }

        public long getEffectiveAt() {
            return effectiveAt;
        }

        public void setEffectiveAt(long effectiveAt) {
            this.effectiveAt = effectiveAt;
        }

        public String getBlockchainTransactionId() {
            return blockchainTransactionId;
        }

        public void setBlockchainTransactionId(String blockchainTransactionId) {
            this.blockchainTransactionId = blockchainTransactionId;
        }
    }
}
