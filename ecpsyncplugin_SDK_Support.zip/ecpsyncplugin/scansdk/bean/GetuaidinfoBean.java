package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetuaidinfoBean {

    /**
     * uaid : string
     * thirdPartyCode : string
     * options : {"responseTemplate":"1,2,4"}
     */

    private String uaid;
    private String thirdPartyCode;
    private OptionsBean options;

    public String getUaid() {
        return uaid;
    }

    public void setUaid(String uaid) {
        this.uaid = uaid;
    }

    public String getThirdPartyCode() {
        return thirdPartyCode;
    }

    public void setThirdPartyCode(String thirdPartyCode) {
        this.thirdPartyCode = thirdPartyCode;
    }

    public OptionsBean getOptions() {
        return options;
    }

    public void setOptions(OptionsBean options) {
        this.options = options;
    }

    public static class OptionsBean {
        /**
         * responseTemplate : 1,2,4
         */

        private String responseTemplate;

        public String getResponseTemplate() {
            return responseTemplate;
        }

        public void setResponseTemplate(String responseTemplate) {
            this.responseTemplate = responseTemplate;
        }
    }
}
