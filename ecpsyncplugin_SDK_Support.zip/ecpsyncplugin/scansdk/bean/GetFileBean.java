package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetFileBean {

    /**
     * fileName : string
     */

    private String fileName;

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
