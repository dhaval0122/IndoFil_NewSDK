package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class ARCode {
    private int authenticatedResult;
    private String extendedData;

    public int getAuthenticatedResult() {
        return authenticatedResult;
    }

    public void setAuthenticatedResult(int authenticatedResult) {
        this.authenticatedResult = authenticatedResult;
    }

    public String getExtendedData() {
        return extendedData;
    }

    public void setExtendedData(String extendedData) {
        this.extendedData = extendedData;
    }
}
