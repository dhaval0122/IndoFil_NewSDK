package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GiftBean {

    /**
     * giftType : string
     * receiveUserId : string
     * verifyId : string
     */

    private String giftType;
    private String receiveUserId;
    private String verifyId;

    public String getGiftType() {
        return giftType;
    }

    public void setGiftType(String giftType) {
        this.giftType = giftType;
    }

    public String getReceiveUserId() {
        return receiveUserId;
    }

    public void setReceiveUserId(String receiveUserId) {
        this.receiveUserId = receiveUserId;
    }

    public String getVerifyId() {
        return verifyId;
    }

    public void setVerifyId(String verifyId) {
        this.verifyId = verifyId;
    }
}
