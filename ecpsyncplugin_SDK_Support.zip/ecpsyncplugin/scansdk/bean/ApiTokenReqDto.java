package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

/**
 * Created by huaxingl on 2019/3/14.
 */

public class ApiTokenReqDto {
    private String appId;
    private String appKey;
    private String apiKey;


    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getApiKey() {
        return apiKey;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
    }
}
