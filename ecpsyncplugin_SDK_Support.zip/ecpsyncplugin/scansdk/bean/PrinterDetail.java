package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PrinterDetail implements Parcelable {
    @SerializedName("printer_make")
    @Expose
    public String printer_make;
    @SerializedName("printer_model")
    @Expose
    public String printer_model;
    @SerializedName("head_make")
    @Expose
    public String head_make;
    @SerializedName("head_model")
    @Expose
    public String head_model;
    @SerializedName("created_by")
    @Expose
    public String created_by;

    protected PrinterDetail(Parcel in) {
        printer_make = in.readString();
        printer_model = in.readString();
        head_make = in.readString();
        head_model = in.readString();
        created_by = in.readString();
    }

    public static final Creator<PrinterDetail> CREATOR = new Creator<PrinterDetail>() {
        @Override
        public PrinterDetail createFromParcel(Parcel in) {
            return new PrinterDetail(in);
        }

        @Override
        public PrinterDetail[] newArray(int size) {
            return new PrinterDetail[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(printer_make);
        dest.writeString(printer_model);
        dest.writeString(head_make);
        dest.writeString(head_model);
        dest.writeString(created_by);
    }
}
