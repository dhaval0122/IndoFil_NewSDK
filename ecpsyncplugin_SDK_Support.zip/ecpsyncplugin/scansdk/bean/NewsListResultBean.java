package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;
import java.util.List;

public class NewsListResultBean implements Serializable {


    /**
     * code : 0
     * message : Successful
     * data : {"pageNo":1,"pageSize":10,"orderBy":"sortDate","totalCount":23,"result":[{"img":"63a3f4e4d352f65c7a1d1981.png","sortDate":1671718233000,"title":"日本语言测试","url":"http://172.16.10.95/portal/showNews-en.html?id=6966319944138237440&headless=true"},{"img":"61765fc6e4b0a7ca360b2d84.jpg","sortDate":1635385314000,"title":"32121","url":"http://172.16.10.95/portal/showNews-en.html?id=5810163753093694976&headless=true"},{"img":"60f0e1d3e4b06247fc74bf0c.jpg","sortDate":1626431559000,"title":"sdfsfsssfsd","url":"http://172.16.10.95/portal/showNews-en.html?id=5663387896313284096&headless=true"},{"img":"60f01386e4b06c417249b3a2.png","sortDate":1626346548000,"title":"t2","url":"http://172.16.10.95/portal/showNews-en.html?id=5662501762687305216&headless=true"},{"img":"60f01232e4b06c417249b39f.png","sortDate":1626346212000,"title":"t1","url":"http://172.16.10.95/portal/showNews-en.html?id=5662496064825984512&headless=true"},{"img":"60f004f0e4b06c417249b39c.png","sortDate":1626342813000,"title":"ww","url":"http://172.16.10.95/portal/showNews-en.html?id=5662439114817930752&headless=true"},{"img":"60e3c54be4b0485996cef5ba.jpg","sortDate":1625626305000,"title":"23","url":"http://172.16.10.95/portal/showNews-en.html?id=5648971603418023424&headless=true"},{"img":"60c03747e4b08c56d3143840.jpg","sortDate":1625061600000,"title":"print1231","url":"http://172.16.10.95/portal/showNews-en.html?id=5609878736649324032&headless=true"},{"img":"60cc391de4b09d429daf8428.jpg","sortDate":1624111854000,"title":"时区测试1","url":"http://172.16.10.95/portal/showNews-en.html?id=5623080726980199936&headless=true"},{"img":"5c90850be4b05f430a00c705.jpg","sortDate":1624085312000,"title":"321312","url":"http://172.16.10.95/portal/showNews-en.html?id=4431536221000304128&headless=true"}],"extendedInfo":null,"startRow":0}
     */

    private String code;
    private String message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean implements Serializable {
        /**
         * pageNo : 1
         * pageSize : 10
         * orderBy : sortDate
         * totalCount : 23
         * result : [{"img":"63a3f4e4d352f65c7a1d1981.png","sortDate":1671718233000,"title":"日本语言测试","url":"http://172.16.10.95/portal/showNews-en.html?id=6966319944138237440&headless=true"},{"img":"61765fc6e4b0a7ca360b2d84.jpg","sortDate":1635385314000,"title":"32121","url":"http://172.16.10.95/portal/showNews-en.html?id=5810163753093694976&headless=true"},{"img":"60f0e1d3e4b06247fc74bf0c.jpg","sortDate":1626431559000,"title":"sdfsfsssfsd","url":"http://172.16.10.95/portal/showNews-en.html?id=5663387896313284096&headless=true"},{"img":"60f01386e4b06c417249b3a2.png","sortDate":1626346548000,"title":"t2","url":"http://172.16.10.95/portal/showNews-en.html?id=5662501762687305216&headless=true"},{"img":"60f01232e4b06c417249b39f.png","sortDate":1626346212000,"title":"t1","url":"http://172.16.10.95/portal/showNews-en.html?id=5662496064825984512&headless=true"},{"img":"60f004f0e4b06c417249b39c.png","sortDate":1626342813000,"title":"ww","url":"http://172.16.10.95/portal/showNews-en.html?id=5662439114817930752&headless=true"},{"img":"60e3c54be4b0485996cef5ba.jpg","sortDate":1625626305000,"title":"23","url":"http://172.16.10.95/portal/showNews-en.html?id=5648971603418023424&headless=true"},{"img":"60c03747e4b08c56d3143840.jpg","sortDate":1625061600000,"title":"print1231","url":"http://172.16.10.95/portal/showNews-en.html?id=5609878736649324032&headless=true"},{"img":"60cc391de4b09d429daf8428.jpg","sortDate":1624111854000,"title":"时区测试1","url":"http://172.16.10.95/portal/showNews-en.html?id=5623080726980199936&headless=true"},{"img":"5c90850be4b05f430a00c705.jpg","sortDate":1624085312000,"title":"321312","url":"http://172.16.10.95/portal/showNews-en.html?id=4431536221000304128&headless=true"}]
         * extendedInfo : null
         * startRow : 0
         */

        private int pageNo;
        private int pageSize;
        private String orderBy;
        private int totalCount;
        private Object extendedInfo;
        private int startRow;
        private List<ResultBean> result;

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public String getOrderBy() {
            return orderBy;
        }

        public void setOrderBy(String orderBy) {
            this.orderBy = orderBy;
        }

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public Object getExtendedInfo() {
            return extendedInfo;
        }

        public void setExtendedInfo(Object extendedInfo) {
            this.extendedInfo = extendedInfo;
        }

        public int getStartRow() {
            return startRow;
        }

        public void setStartRow(int startRow) {
            this.startRow = startRow;
        }

        public List<ResultBean> getResult() {
            return result;
        }

        public void setResult(List<ResultBean> result) {
            this.result = result;
        }

        public static class ResultBean implements Serializable {
            /**
             * img : 63a3f4e4d352f65c7a1d1981.png
             * sortDate : 1671718233000
             * title : 日本语言测试
             * url : http://172.16.10.95/portal/showNews-en.html?id=6966319944138237440&headless=true
             */

            private String img;
            private long sortDate;
            private String title;
            private String url;

            public String getImg() {
                return img;
            }

            public void setImg(String img) {
                this.img = img;
            }

            public long getSortDate() {
                return sortDate;
            }

            public void setSortDate(long sortDate) {
                this.sortDate = sortDate;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getUrl() {
                return url;
            }

            public void setUrl(String url) {
                this.url = url;
            }
        }
    }
}
