package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

public class GetPkBean {

    private String code;
    private String message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        private String id;
        private String createUserId;
        private String createDate;
        private String updateUserId;
        private String updateDate;
        private String remarks;
        private Integer delFlag;
        private String ownCompanyId;
        private String name;
        private String publicFile;
        private String privateFile;
        private Integer keyDefault;
        private Long createTime;
        private Integer status;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getCreateUserId() {
            return createUserId;
        }

        public void setCreateUserId(String createUserId) {
            this.createUserId = createUserId;
        }

        public String getCreateDate() {
            return createDate;
        }

        public void setCreateDate(String createDate) {
            this.createDate = createDate;
        }

        public String getUpdateUserId() {
            return updateUserId;
        }

        public void setUpdateUserId(String updateUserId) {
            this.updateUserId = updateUserId;
        }

        public String getUpdateDate() {
            return updateDate;
        }

        public void setUpdateDate(String updateDate) {
            this.updateDate = updateDate;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }

        public Integer getDelFlag() {
            return delFlag;
        }

        public void setDelFlag(Integer delFlag) {
            this.delFlag = delFlag;
        }

        public String getOwnCompanyId() {
            return ownCompanyId;
        }

        public void setOwnCompanyId(String ownCompanyId) {
            this.ownCompanyId = ownCompanyId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPublicFile() {
            return publicFile;
        }

        public void setPublicFile(String publicFile) {
            this.publicFile = publicFile;
        }

        public String getPrivateFile() {
            return privateFile;
        }

        public void setPrivateFile(String privateFile) {
            this.privateFile = privateFile;
        }

        public Integer getKeyDefault() {
            return keyDefault;
        }

        public void setKeyDefault(Integer keyDefault) {
            this.keyDefault = keyDefault;
        }

        public Long getCreateTime() {
            return createTime;
        }

        public void setCreateTime(Long createTime) {
            this.createTime = createTime;
        }

        public Integer getStatus() {
            return status;
        }

        public void setStatus(Integer status) {
            this.status = status;
        }
    }
}
