package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;
import java.util.List;

public class ScanHisResultBean implements Serializable {

    /**
     * code : 0
     * message : {"zh_TW":"成功","en_US":"Successful","zh_CN":"成功"}
     * data : {"pageNo":1,"pageSize":20,"orderBy":null,"totalCount":5,"result":[{"createDate":1677569235000,"giftStatus":1,"giftType":null,"id":6966705281885671936,"productName":"y99y","verifyStatus":3},{"createDate":1677568720000,"giftStatus":1,"giftType":null,"id":6966705248099308032,"productName":"y99y","verifyStatus":3},{"createDate":1677230830000,"giftStatus":1,"giftType":null,"id":6966683104154096128,"productName":"y99y","verifyStatus":3},{"createDate":1677144384000,"giftStatus":1,"giftType":null,"id":6966677438861677056,"productName":"y99y","verifyStatus":3},{"createDate":1677143078000,"giftStatus":1,"giftType":null,"id":6966677353258816000,"productName":"y99y","verifyStatus":3}],"extendedInfo":null,"startRow":0}
     */

    private String code;
    private Object message;
    private DataBean data;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Object getMessage() {
        return message;
    }

    public void setMessage(Object message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }


    public static class DataBean implements Serializable {
        /**
         * pageNo : 1
         * pageSize : 20
         * orderBy : null
         * totalCount : 5
         * result : [{"createDate":1677569235000,"giftStatus":1,"giftType":null,"id":6966705281885671936,"productName":"y99y","verifyStatus":3},{"createDate":1677568720000,"giftStatus":1,"giftType":null,"id":6966705248099308032,"productName":"y99y","verifyStatus":3},{"createDate":1677230830000,"giftStatus":1,"giftType":null,"id":6966683104154096128,"productName":"y99y","verifyStatus":3},{"createDate":1677144384000,"giftStatus":1,"giftType":null,"id":6966677438861677056,"productName":"y99y","verifyStatus":3},{"createDate":1677143078000,"giftStatus":1,"giftType":null,"id":6966677353258816000,"productName":"y99y","verifyStatus":3}]
         * extendedInfo : null
         * startRow : 0
         */

        private int pageNo;
        private int pageSize;
        private Object orderBy;
        private int totalCount;
        private Object extendedInfo;
        private int startRow;
        private List<ResultBean> result;

        public int getPageNo() {
            return pageNo;
        }

        public void setPageNo(int pageNo) {
            this.pageNo = pageNo;
        }

        public int getPageSize() {
            return pageSize;
        }

        public void setPageSize(int pageSize) {
            this.pageSize = pageSize;
        }

        public Object getOrderBy() {
            return orderBy;
        }

        public void setOrderBy(Object orderBy) {
            this.orderBy = orderBy;
        }

        public int getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(int totalCount) {
            this.totalCount = totalCount;
        }

        public Object getExtendedInfo() {
            return extendedInfo;
        }

        public void setExtendedInfo(Object extendedInfo) {
            this.extendedInfo = extendedInfo;
        }

        public int getStartRow() {
            return startRow;
        }

        public void setStartRow(int startRow) {
            this.startRow = startRow;
        }

        public List<ResultBean> getResult() {
            return result;
        }

        public void setResult(List<ResultBean> result) {
            this.result = result;
        }

        public static class ResultBean implements Serializable {
            /**
             * createDate : 1677569235000
             * giftStatus : 1
             * giftType : null
             * id : 6966705281885671936
             * productName : y99y
             * verifyStatus : 3
             */

            private long createDate;
            private int giftStatus;
            private Object giftType;
            private long id;
            private String productName;
            private int verifyStatus;

            public long getCreateDate() {
                return createDate;
            }

            public void setCreateDate(long createDate) {
                this.createDate = createDate;
            }

            public int getGiftStatus() {
                return giftStatus;
            }

            public void setGiftStatus(int giftStatus) {
                this.giftStatus = giftStatus;
            }

            public Object getGiftType() {
                return giftType;
            }

            public void setGiftType(Object giftType) {
                this.giftType = giftType;
            }

            public long getId() {
                return id;
            }

            public void setId(long id) {
                this.id = id;
            }

            public String getProductName() {
                return productName;
            }

            public void setProductName(String productName) {
                this.productName = productName;
            }

            public int getVerifyStatus() {
                return verifyStatus;
            }

            public void setVerifyStatus(int verifyStatus) {
                this.verifyStatus = verifyStatus;
            }
        }
    }
}
