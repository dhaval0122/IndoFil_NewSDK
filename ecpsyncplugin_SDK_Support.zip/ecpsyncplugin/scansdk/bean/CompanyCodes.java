package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;
import java.util.List;

public class CompanyCodes implements Serializable {

    private Boolean isBlackList;
    private List<String> companyCodes;

    public Boolean getBlackList() {
        return isBlackList;
    }

    public void setBlackList(Boolean blackList) {
        isBlackList = blackList;
    }

    public List<String> getCompanyCodes() {
        return companyCodes;
    }

    public void setCompanyCodes(List<String> companyCodes) {
        this.companyCodes = companyCodes;
    }
}
