package ecp.vcs.com.ecpsyncplugin.scansdk.bean;

import java.io.Serializable;

public class ScanOptions implements Serializable {

    private Boolean flashEnabled;
    private Boolean flashControlEnable;
    private Boolean skipActive;
    private Boolean skipARCodeAuthentication;
    private  int cameraScale;
    private CompanyCodes companyCodes;


    public Boolean getFlashEnabled() {
        return flashEnabled;
    }

    public void setFlashEnabled(Boolean flashEnabled) {
        this.flashEnabled = flashEnabled;
    }

    public Boolean getFlashControlEnable() {
        return flashControlEnable;
    }

    public void setFlashControlEnable(Boolean flashControlEnable) {
        this.flashControlEnable = flashControlEnable;
    }

    public Boolean getSkipActive() {
        return skipActive;
    }

    public void setSkipActive(Boolean skipActive) {
        this.skipActive = skipActive;
    }

    public Boolean getSkipARCodeAuthentication() {
        return skipARCodeAuthentication;
    }

    public void setSkipARCodeAuthentication(Boolean skipARCodeAuthentication) {
        this.skipARCodeAuthentication = skipARCodeAuthentication;
    }

    public int getCameraScale() {
        return cameraScale;
    }

    public void setCameraScale(int cameraScale) {
        this.cameraScale = cameraScale;
    }

    public CompanyCodes getCompanyCodes() {
        return companyCodes;
    }

    public void setCompanyCodes(CompanyCodes companyCodes) {
        this.companyCodes = companyCodes;
    }
}
