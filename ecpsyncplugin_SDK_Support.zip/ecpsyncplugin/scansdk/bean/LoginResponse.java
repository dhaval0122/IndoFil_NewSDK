package ecp.vcs.com.ecpsyncplugin.scansdk.bean;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class LoginResponse {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("status")
    @Expose
    private Boolean status;
    @SerializedName("user_id")
    @Expose
    private String userId;

    @SerializedName("printer_details")
    @Expose
    private ArrayList<PrinterDetail> printer_details;

    public ArrayList<PrinterDetail> getPrinter_details() {
        return printer_details;
    }

    public void setPrinter_details(ArrayList<PrinterDetail> printer_details) {
        this.printer_details = printer_details;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

}

