package ecp.vcs.com.ecpsyncplugin.scansdk.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.alibaba.fastjson.JSON;

import ecp.vcs.com.ecpsyncplugin.R;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ApiTokenReqDto;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ChallengeResponse;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GetTokenBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.LocationBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.Options;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ResponseBasicEncodeDto;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanOptions;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.VerifyEntity;
import ecp.vcs.com.ecpsyncplugin.scansdk.roomdata.Owner;
import ecp.vcs.com.ecpsyncplugin.scansdk.roomdata.OwnerDataBase;
import ecp.vcs.com.ecpsyncplugin.scansdk.sdkutil.CustomerSDK;
import ecp.vcs.com.ecpsyncplugin.scansdk.task.BaseTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.PreferenceHelper;
import com.isprint.arcode2sdk.ARScannerActivity;

import java.util.HashMap;
import java.util.Map;

public class Activity_GetUaidData extends Activity {  //这是一个完全透明的空白act
    private static final int ARCODE_SCAN = 1;
    private int PERMISSIONS_CAMERA = 1;
    private PreferenceHelper preferenceHelper;
    private int authenticateFromServer;
    private ChallengeResponse challengeResponse;
    private String locales, realUserIPAddress;
    private Options options;
    private ScanOptions scanOptions;
    private LocationBean locationBean;
    private OwnerDataBase ownerDataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_my_mian_lib);
        preferenceHelper = PreferenceHelper.getInstance(Activity_GetUaidData.this);
        ownerDataBase = OwnerDataBase.getInstance(this);
        if (preferenceHelper.getSavedData("sessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("sessionToken", ""))) {
            AndroidUtil.showToastMessage(Activity_GetUaidData.this,"GetSessionTokenAsync--->CustomerSDK is not configured, please check the relevant configuration.");
            finish();
            CustomerSDK.SetARcoreResultAndExtendedData(1000, "");
        } else {
            Bundle bundle = getIntent().getExtras();
            if (bundle != null) {
                authenticateFromServer = bundle.getInt("authenticateFromServer");
                challengeResponse = (ChallengeResponse) bundle.getSerializable("challengeResponse");
                locales = bundle.getString("locales");
                options = (Options) bundle.getSerializable("options");
                scanOptions = (ScanOptions) bundle.getSerializable("scanOptions");
                locationBean = (LocationBean) bundle.getSerializable("locationBean");
                realUserIPAddress = bundle.getString("realUserIPAddress");
            }
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            GetSessionTokenAsync(Activity_GetUaidData.this, locales, ARCODE_SCAN);  //现请求传入token再唤起扫描页面
        }
    }

    private void GetSessionTokenAsync(final Context mContext, String locales, final int requestCode) {
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        final String randomStr = AndroidUtil.getN();
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.GETSESSIONTOKEN;
        ApiTokenReqDto dto = new ApiTokenReqDto();
        dto.setAppId(preferenceHelper.getSavedData("appId",""));
        dto.setApiKey(preferenceHelper.getSavedData("apiKey",""));
        BaseTask task = new BaseTask( mContext,randomStr, JSON.toJSONString(dto), api, locales, AndroidUtil.ReqType.POST);
        task.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {

                if (response != null) {
                    ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                    GetTokenBean getTokenBean = JSON.parseObject(decodeStr, GetTokenBean.class);
                    if (res.getCode().equals("0")) {
                        String sessionToken = getTokenBean.getSessionToken();
                        startScan(mContext, requestCode, sessionToken);
                    }else {
                        CustomerSDK.SetARcoreResultAndExtendedData(1000, "");
                        Toast.makeText(Activity_GetUaidData.this,res.getMessage(),Toast.LENGTH_LONG).show();
                        finish();
                    }
                }

            }

            @Override
            public void setErr() {
                finish();
                CustomerSDK.SetARcoreResultAndExtendedData(1000, "");
            }

            @Override
            public void doSomething() {
            }
        });
        task.execute();
    }

    private void startScan(Context mContext, int requestCode, String token) {

        String udid = android.provider.Settings.Secure.getString(mContext.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);;

        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.GETTDATA;
//        Log.d("startScan", "api:" + api);
//        Log.d("startScan", "token:" + token);
        ARScannerActivity.setAccessRealRestURL(api);


        Map<String, String> restHeaders = new HashMap<String, String>();
        restHeaders.put("Authorization", token);
        restHeaders.put("locale", AndroidUtil.getLanguage(mContext));
        ARScannerActivity.setAccessRealRestHeaders(restHeaders);


        String appCode = "Android_customer";
        Map<String, Object> restParams = new HashMap<String, Object>();
        restParams.put("appCode", appCode);
        restParams.put("udid", udid);
        ARScannerActivity.setAccessRealRestParams(restParams);


        Map<String, Object> params = new HashMap<String, Object>();
        params.put("skipActive", scanOptions.getSkipActive());

        ARScannerActivity.setInitialZoom(scanOptions.getCameraScale());
        ARScannerActivity.setTest(params);
        ARScannerActivity.setFlashEnabled(scanOptions.getFlashEnabled());
        ARScannerActivity.setFlashControlEnabled(scanOptions.getFlashControlEnable());
//        ARScannerActivity.setCompanyCodeList(scanOptions.getCompanyCodes().getBlackList(), scanOptions.getCompanyCodes().getCompanyCodes());


        if (ContextCompat.checkSelfPermission(Activity_GetUaidData.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
//            Log.i(TAG, "需要授权 ");
            if (ActivityCompat.shouldShowRequestPermissionRationale(Activity_GetUaidData.this, Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
//                Log.i(TAG, "拒绝过了");
                Toast.makeText(mContext, "Please enable camera permission for this app in Settings - App Management.", Toast.LENGTH_SHORT).show();
            } else {
//                Log.i(TAG, "进行授权");
                ActivityCompat.requestPermissions(Activity_GetUaidData.this, new String[]{Manifest.permission.CAMERA}, PERMISSIONS_CAMERA);
            }
        } else {
//            Log.i(TAG, "不需要授权 ");
            Intent intent = new Intent(Activity_GetUaidData.this, ARScannerActivity.class);
            startActivityForResult(intent, requestCode);
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null) {
            if (requestCode == ARCODE_SCAN) {
                if (resultCode == RESULT_OK) {
                    /*-------------------------------------------------------------------------------*/            //得到SDK得到的结果
                    String result = data.getStringExtra("qrtext");
                    int arresult = data.getIntExtra("arresult", 0);
                    String serverData = data.getStringExtra("serverData");
                    String extendedData = data.getStringExtra("extendedData");
                    String code = data.getStringExtra("code");
                    String errorCode = data.getIntExtra("errorCode", 0) + "";
                    String message = data.getStringExtra("message");
                    /*-------------------------------------------------------------------------------*/
                    Log.d("arcoderesult", "result:" + result);
                    Log.d("arcoderesult", "arresult:" + arresult);
                    Log.d("arcoderesult", "serverData:" + serverData);
                    Log.d("arcoderesult", "extendedData:" + extendedData);
                    Log.d("arcoderesult", "code:" + code);
                    Log.d("arcoderesult", "errorCode:" + errorCode);
                    Log.d("arcoderesult", "message:" + message);


                    switch (arresult) {
                        // 51：收到服务器的错误返回
                        case ARScannerActivity.AR_RESULT_NETWORK_ERROR:
                            showStrDialog("Failed to connect to the server. Please check your Internet connection and try again.");
                            break;
                        // 52：服务器异常返回
                        case ARScannerActivity.AR_RESULT_SERVER_ERROR:
                            showStrDialog("Server error. Please check with Infra Team");
                            break;
                        // 53：出现操作错误
                        case ARScannerActivity.AR_RESULT_OPERATIONAL_ERROR:
                            showStrDialog("Operational error. Please check with Operations Team.");
                            break;
                        // 54：可疑的编码错误
                        case ARScannerActivity.AR_RESULT_DEV_ERROR:
                            showStrDialog("Internal error. Please check with Dev Team.");
                            break;
                    }

                    if (authenticateFromServer == 1) { //代表要做验证
                        if (TextUtils.isEmpty(result)) {
                            CustomerSDK.SetARcoreResultAndExtendedData(arresult, extendedData);
                        } else {


                            if (challengeResponse.getChallengeResponse().getChallengeCode().equals("2")) {//授权码
                                challengeResponse.getChallengeResponse().setResponse(result);  //setResponse的意思是 是需要把二次扫码获得的值set进去只针对授权码
                                result = challengeResponse.getChallengeResponse().getUaid();
                            }

                            /*
                             *  result=长连接  ---用于接口请求
                             * qrcode=短链接  ---用于搜索数据库
                             * */


                            String qrcode = AndroidUtil.getUaid(result).trim();
                            new QuerOwnerTask(result, qrcode, arresult,extendedData, realUserIPAddress, locationBean, challengeResponse, locales, options).execute();


                        }
                    } else { //代表不做验证 返回SDK数字和ExtendedData给用户
                        CustomerSDK.SetARcoreResultAndExtendedData(arresult, extendedData);
                    }
                    finish();

                }
            }
        } else {
            finish(); //如果没有返回值 则关闭当前页面
            CustomerSDK.SetARcoreResultAndExtendedData(1000, "");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSIONS_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(Activity_GetUaidData.this, "同意授权。", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Activity_GetUaidData.this, ARScannerActivity.class);
                startActivityForResult(intent, requestCode);
            } else {
//                Toast.makeText(Activity_GetUaidData.this, "拒绝授权。", Toast.LENGTH_SHORT).show();
                finish();
                CustomerSDK.SetARcoreResultAndExtendedData(1000, "");
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    // 显示Dialog
    private void showStrDialog(String msg) {
        LayoutInflater layoutInflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View view = layoutInflater.inflate(R.layout.layout_dialog_textview, null);
        AlertDialog.Builder ab = new AlertDialog.Builder(Activity_GetUaidData.this);
        ab.setView(view);
        TextView tv = view.findViewById(R.id.text);
        SpannableString spannableString = new SpannableString(msg);
        tv.setText(spannableString);
        ab.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        ab.setCancelable(false);
        ab.show();
    }

    /*根据扫码查询是否有签名记录*/
    private class QuerOwnerTask extends AsyncTask<Void, Void, Void> {
        String result;
        String qrcode;
        int arresult;
        String realUserIPAddress;
        LocationBean locationBean;
        ChallengeResponse challengeResponse;
        String locales;
        Options options;
        String extendedData;

        public QuerOwnerTask(String result, String qrcode, int arresult, String extendedData,String realUserIPAddress, LocationBean locationBean, ChallengeResponse challengeResponse, String locales, Options options) {
            this.result = result;
            this.qrcode = qrcode;
            this.arresult = arresult;
            this.extendedData = extendedData;
            this.realUserIPAddress = realUserIPAddress;
            this.locationBean = locationBean;
            this.challengeResponse = challengeResponse;
            this.locales = locales;
            this.options = options;
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            VerifyEntity.OwnerShipData ownerShipData = new VerifyEntity.OwnerShipData();
            Owner owner = ownerDataBase.ownerDao().getInfoByCode(qrcode);
            String signature = "";
            String euaid = "";
            String huaid = "";
            String scantime = "";
            String type = "";

            if (owner != null) {//有数据  把数据库里面的数据拿出来给网络请求
//                Log.d("signature", "signature---" + signature);
                signature = owner.getSignature();
                euaid = owner.getEuaid();
                huaid = owner.getHuaid();
                scantime = owner.getScantime();
                type = owner.getType();

                ownerShipData.setEuaid(euaid);
                ownerShipData.setHuaid(huaid);
                ownerShipData.setScantime(scantime);
                ownerShipData.setSignature(signature);
                ownerShipData.setType(type);
            }
            CustomerSDK.UaidAuthenticate(Activity_GetUaidData.this, result, arresult,extendedData, realUserIPAddress, locationBean, challengeResponse, locales, options, signature, ownerShipData);

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }
}
