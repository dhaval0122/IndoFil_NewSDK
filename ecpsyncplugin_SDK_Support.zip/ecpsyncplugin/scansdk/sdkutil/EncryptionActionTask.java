package ecp.vcs.com.ecpsyncplugin.scansdk.sdkutil;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.fastjson.JSON;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GetRsaFineNameBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendFineName;
import ecp.vcs.com.ecpsyncplugin.scansdk.task.DownloadRsaFileAsynchTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.task.GetRsaFileNameAsynchTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.HttpUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.PreferenceHelper;

public class EncryptionActionTask {
    public static void GetRsaFileName(final Context mContext) {
        String sessionToken;
        final PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.GetRsaFileName;
        GetRsaFileNameAsynchTask getRsaFileNameTask = new GetRsaFileNameAsynchTask(mContext, "",api, sessionToken, "en_US", AndroidUtil.ReqType.POST);
        getRsaFileNameTask.setCallBack(new GetRsaFileNameAsynchTask.CallBack() {
            @Override
            public void setStr(String response) {
                GetRsaFineNameBean dataBean = JSON.parseObject(response, GetRsaFineNameBean.class);
                if ("0".equals(dataBean.getCode())) {
//                    Log.d("GetRsaFileName","pubKeyId->"+dataBean.getData().getId());
//                    Log.d("GetRsaFileName","PublicFileName->"+dataBean.getData().getPublicFileName());
                    preferenceHelper.setDataSave("pubKeyId", dataBean.getData().getId());
                    DownloadRsaFile(mContext, dataBean.getData().getPublicFileName());
                } else {
                    AndroidUtil.showToastMessage(mContext, "GetRsaFileName Fail -> " + dataBean.getMessage());
                }
            }
            @Override
            public void setErr() {
            }
            @Override
            public void doSomething() {
            }
        });
        getRsaFileNameTask.execute();
    }

    public static void DownloadRsaFile(final Context mContext, String FileName) {
        String sessionToken;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        SendFineName sendFineName = new SendFineName();
        sendFineName.setFileName(FileName);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.DownRsaFile;
        DownloadRsaFileAsynchTask downRsaFileTask = new DownloadRsaFileAsynchTask(mContext, JSON.toJSONString(sendFineName), api, sessionToken, "en_US", AndroidUtil.ReqType.POST);
        downRsaFileTask.setCallBack(new DownloadRsaFileAsynchTask.CallBack() {
            @Override
            public void setStr(String response) {
//                Log.d("GetRsaFileName", response);
                try {
                    saveCertificateToFile(mContext, response, HttpUtil.PUBLIC_KEY_PATH, HttpUtil.PUBLIC_KEY);
                } catch (CertificateException | IOException e) {
                    throw new RuntimeException(e);
                }
            }
            @Override
            public void setErr() {
            }
            @Override
            public void doSomething() {
            }
        });
        downRsaFileTask.execute();
    }

    public static void saveCertificateToFile(Context mContext, String pemCertificate, String path, String fileName) throws CertificateException, IOException {
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        InputStream inputStream = new ByteArrayInputStream(pemCertificate.getBytes(StandardCharsets.UTF_8));
        X509Certificate certificate = (X509Certificate) cf.generateCertificate(inputStream);
        File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
        FileOutputStream outputStream = new FileOutputStream(file);
        outputStream.write(certificate.getEncoded());
        outputStream.close();
    }

}
