package ecp.vcs.com.ecpsyncplugin.scansdk.sdkutil;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.List;

import ecp.vcs.com.ecpsyncplugin.scansdk.activity.Activity_GetUaidData;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ARCode;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ApiTokenReqDto;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.AuthenticateBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.BannerBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.BannerListResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.BwListResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ChallengeResponse;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ChangeUserPwdBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GetGiftDataBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GetTokenBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GetuaidinfoBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.GiftBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ImgResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.LocationBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.LoginResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.LogoutResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.NewsListBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.NewsListResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.OpenApiLoginBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.Options;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.OwnerCardBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ResponResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ResponseBasicEncodeDto;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanHisResultBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanOptions;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.ScanhistoryBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendCustomerDataBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendUaidInfobean;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.VerifyEntity;
import ecp.vcs.com.ecpsyncplugin.scansdk.roomdata.Owner;
import ecp.vcs.com.ecpsyncplugin.scansdk.roomdata.OwnerDataBase;
import ecp.vcs.com.ecpsyncplugin.scansdk.task.BaseTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.task.GetOwnerImgTask;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.PreferenceHelper;

public class CustomerSDK {

    private static MainInterface mainif;
    private static ConfigInterface configif;
    private static LogingInterface longif;
    private static LogoutInterface logoutif;
    private static ScanhistoryInterface scanhisif;
    private static GiftInterface giftif;
    private static NewsListInterface newslistif;
    private static BannerInterface bannerif;
    private static BWListInterface bwListIntf;
    private static GetOwnerImageInterface getOwnerImageIf;
    private static GetUAIDInformationInterface getUAIDInformatif;
    private static ChangeUserPwdInterface changeUserPwdif;

    public interface MainInterface {
        void setUaidResult(SendCustomerDataBean response);
    }

    public interface ConfigInterface {
        void setConfigResult(ResultBean response);
    }

    public interface LogingInterface {
        void setLoginResult(ResultBean response);
    }

    public interface LogoutInterface {
        void setLogoutResult(ResultBean response);
    }

    public interface ScanhistoryInterface {
        void setScanHistoryResult(ScanHisResultBean scanHisResultBean);
    }

    public interface GiftInterface {
        void setGiftresult(GetGiftDataBean response);
    }

    public interface NewsListInterface {
        void setNewsListResult(NewsListResultBean newsListResultBean);
    }

    public interface BannerInterface {
        void setBannerListResult(BannerListResultBean bannerListResultBean);
    }

    public interface BWListInterface {
        void setBwResult(BwListResultBean bwListResultBean);
    }

    public interface GetOwnerImageInterface {
        void setOwnerImgResult(ImgResultBean imgResult);
    }

    public interface GetUAIDInformationInterface {
        void setUaidinfoResult(SendUaidInfobean sendUaidInfobean);
    }

    public interface ChangeUserPwdInterface {
        void setChangeUserPwdResult(ResultBean response);
    }


    /*-----------------------------------------------------------------------------------------------------------------------------------------------*/
    /*1.初始化SDK配置 服务器地址”、“appId”、“apiKey”*/// CustomerSDK.configSDK(server:@“www.axbinfosec.cn”, appId:@“appId”,apiKey:@“apiKey”);
    public static void configSDK(final Context mContext, final String Server, final String appId, final String apiKey, String locales, ConfigInterface configInterface) {
        configif = configInterface;
        final String randomStr = AndroidUtil.getN();

        String api = Server + AndroidUtil.GETSESSIONTOKEN;
        ApiTokenReqDto dto = new ApiTokenReqDto();
        dto.setAppId(appId);
        dto.setApiKey(apiKey);
        BaseTask task = new BaseTask(mContext, randomStr, JSON.toJSONString(dto), api, locales, AndroidUtil.ReqType.POST);
        task.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                if (response != null) {
                    PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
                    ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                    GetTokenBean getTokenBean = JSON.parseObject(decodeStr, GetTokenBean.class);

                    if (res.getCode().equals("0")) { //成功后会保存 Server appId apiKey
                        preferenceHelper.setDataSave("Server", Server);
                        preferenceHelper.setDataSave("appId", appId);
                        preferenceHelper.setDataSave("apiKey", apiKey);
                        preferenceHelper.setDataSave("companyCode", getTokenBean.getCompanyCode());
                        preferenceHelper.setDataSave("sessionToken", getTokenBean.getTokenType() + " " + getTokenBean.getSessionToken());
                        EncryptionActionTask.GetRsaFileName(mContext);
                    }


                    ResultBean configResultBean = new ResultBean();
                    configResultBean.setCode(res.getCode());
                    configResultBean.setMessage(res.getMessage());
                    configif.setConfigResult(configResultBean);
                }
            }

            @Override
            public void setErr() {

            }

            @Override
            public void doSomething() {
            }
        });
        task.execute();
    }

    //3.2.2验证 --应用场景 UAID验证、验证码验证、授权码验证、收礼验证 :CustomerSDK.authenticate(uaid:@“uaid”);
    public static void authenticate(Context mContext, String uaid, String realUserIPAddress, LocationBean location, ChallengeResponse challengeResponse, String locales, Options options, MainInterface mainInterface) {
        mainif = mainInterface;
        String qrcode = AndroidUtil.getUaid(uaid).trim();

        new QuerOwnerTask(mContext, uaid, qrcode, realUserIPAddress, location, challengeResponse, locales, options).execute();

    }

    //跳转代码空白页面的代码---其实就是3.2.3扫码验证 CustomerSDK.presentScanAuthenticate();
    public static void presentScanAuthenticate(Context mContext, int authenticateFromServer, String realUserIPAddress, LocationBean locationBean, ChallengeResponse challengeResponse, String locales, Options options, ScanOptions scanOptions, MainInterface mainInterface) {
        mainif = mainInterface;
        Intent it = new Intent(mContext, Activity_GetUaidData.class);
        Bundle args = new Bundle();
        args.putInt("authenticateFromServer", authenticateFromServer);
        args.putSerializable("challengeResponse", challengeResponse);
        args.putString("locales", locales);
        args.putString("realUserIPAddress", realUserIPAddress);
        args.putSerializable("options", options);
        args.putSerializable("locationBean", locationBean);
        args.putSerializable("scanOptions", scanOptions);
        it.putExtras(args);
        mContext.startActivity(it);
    }

    //3.3.1用户登录功能 CustomerSDK.login();
    public static void login(Context mContext, String username, String password, String locales, LogingInterface logingInterface) {
        final String randomStr = AndroidUtil.getN();
        longif = logingInterface;
        final PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        OpenApiLoginBean apiLoginBean = new OpenApiLoginBean();
        apiLoginBean.setAppId(preferenceHelper.getSavedData("appId", ""));
        apiLoginBean.setApiKey(preferenceHelper.getSavedData("apiKey", ""));
        apiLoginBean.setUsername(username);
        apiLoginBean.setPassword(password);


        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.LOGIN;

        BaseTask loginTask = new BaseTask(mContext, randomStr, JSON.toJSONString(apiLoginBean), api, locales, AndroidUtil.ReqType.POST);
        loginTask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);

                if ("0".equals(res.getCode())) {
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                    LoginResultBean loginResultBean = JSON.parseObject(decodeStr, LoginResultBean.class);
                    preferenceHelper.setDataSave("LoginSessionToken", loginResultBean.getTokenType() + " " + loginResultBean.getSessionToken());//登录成功

                    ResultBean resultBean = new ResultBean();
                    resultBean.setCode(res.getCode());
                    resultBean.setMessage(res.getMessage());
                    longif.setLoginResult(resultBean);
                } else {
                    ResultBean resultBean = new ResultBean();
                    resultBean.setCode(res.getCode());
                    resultBean.setMessage(res.getMessage());
                    longif.setLoginResult(resultBean);
                }

            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        loginTask.execute();
    }

    //3.3.2用户登出功能  CustomerSDK.logout();
    public static void logout(Context mContext, String locales, LogoutInterface logoutInterface) {

        logoutif = logoutInterface;
        final PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        String LoginSessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.LOGOUT;
        BaseTask logoutTask = new BaseTask(mContext, "", api, LoginSessionToken, locales, AndroidUtil.ReqType.POST, "");
        logoutTask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                LogoutResultBean logoutResultBean = JSON.parseObject(response, LogoutResultBean.class);
                if ("0".equals(logoutResultBean.getCode())) {//登出成功
                    preferenceHelper.setDataSave("LoginSessionToken", "");
                }
                ResultBean resultBean = new ResultBean();
                resultBean.setCode(logoutResultBean.getCode());
                resultBean.setMessage(logoutResultBean.getMessage());
                logoutif.setLogoutResult(resultBean);
            }

            @Override
            public void setErr() {
            }

            @Override
            public void doSomething() {
            }
        });
        logoutTask.execute();
    }

    public static void scanHistory(Context mContext, int pageNo, int pageSize, String type, String locales, ScanhistoryInterface scanhistoryInterface) {

        String sessionToken;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }


        final String randomStr = AndroidUtil.getN();
        scanhisif = scanhistoryInterface;
        ScanhistoryBean scanhistoryBean = new ScanhistoryBean();
        scanhistoryBean.setPageNo(pageNo);
        scanhistoryBean.setPageSize(pageSize);
        scanhistoryBean.setType(type);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.ScanHis;
        BaseTask getScanHisDatatask = new BaseTask(mContext, randomStr, JSON.toJSONString(scanhistoryBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getScanHisDatatask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                ScanHisResultBean.DataBean dataBean = JSON.parseObject(decodeStr, ScanHisResultBean.DataBean.class);
                if ("0".equals(res.getCode())) {
                    ScanHisResultBean scanHisResultBean = new ScanHisResultBean();
                    scanHisResultBean.setCode(res.getCode());
                    scanHisResultBean.setMessage(res.getMessage());
                    scanHisResultBean.setData(dataBean);
                    scanhisif.setScanHistoryResult(scanHisResultBean);
                } else {
                    ScanHisResultBean scanHisResultBean = new ScanHisResultBean();
                    scanHisResultBean.setCode(res.getCode());
                    scanHisResultBean.setMessage(res.getMessage());
                    scanhisif.setScanHistoryResult(scanHisResultBean);
                }

            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        getScanHisDatatask.execute();
    }

    public static void sendGift(Context mContext, String giftType, String receiveUserId, String verifyId, String locales, GiftInterface giftInterface) {

        String sessionToken;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }


        final String randomStr = AndroidUtil.getN();
        giftif = giftInterface;
        GiftBean giftBean = new GiftBean();
        giftBean.setGiftType(giftType);
        giftBean.setReceiveUserId(receiveUserId);
        giftBean.setVerifyId(verifyId);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.Gift;
        BaseTask getGiftDataTask = new BaseTask(mContext, randomStr, JSON.toJSONString(giftBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getGiftDataTask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);

                if ("0".equals(res.getCode())) {
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);

                    GetGiftDataBean getGiftDataBean = new GetGiftDataBean();
                    GetGiftDataBean.DataBean dataBean = new GetGiftDataBean.DataBean();
                    dataBean.setGiftReceiveVerify(decodeStr);
                    getGiftDataBean.setCode(res.getCode());
                    getGiftDataBean.setMessage(res.getMessage());
                    getGiftDataBean.setData(dataBean);
                    giftif.setGiftresult(getGiftDataBean);
                } else {
                    GetGiftDataBean getGiftDataBean = new GetGiftDataBean();
                    getGiftDataBean.setCode(res.getCode());
                    getGiftDataBean.setMessage(res.getMessage());
                    giftif.setGiftresult(getGiftDataBean);
                }

            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        getGiftDataTask.execute();
    }

    public static void newsList(Context mContext, int pageNo, int pageSize, String locales, NewsListInterface newsListInterface) {
        String sessionToken = "";
        String companyCode = "";
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        if (!preferenceHelper.getSavedData("companyCode", "").equals("") || !TextUtils.isEmpty(preferenceHelper.getSavedData("companyCode", ""))) {
            companyCode = preferenceHelper.getSavedData("companyCode", "axbsec");
        }
        final String randomStr = AndroidUtil.getN();
        newslistif = newsListInterface;
        NewsListBean newsListBean = new NewsListBean();
        newsListBean.setPageNo(pageNo);
        newsListBean.setPageSize(pageSize);
        newsListBean.setCompanyCode(companyCode);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.NewsList;
        BaseTask getScanHisDatatask = new BaseTask(mContext, randomStr, JSON.toJSONString(newsListBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getScanHisDatatask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                NewsListResultBean.DataBean dataBean = JSON.parseObject(decodeStr, NewsListResultBean.DataBean.class);
                if ("0".equals(res.getCode())) {
                    NewsListResultBean newsListResultBean = new NewsListResultBean();
                    newsListResultBean.setCode(res.getCode());
                    newsListResultBean.setMessage(res.getMessage());
                    newsListResultBean.setData(dataBean);
                    newslistif.setNewsListResult(newsListResultBean);
                } else {
                    NewsListResultBean newsListResultBean = new NewsListResultBean();
                    newsListResultBean.setCode(res.getCode());
                    newsListResultBean.setMessage(res.getMessage());
                    newslistif.setNewsListResult(newsListResultBean);
                }
            }

            @Override
            public void setErr() {
            }

            @Override
            public void doSomething() {
            }
        });
        getScanHisDatatask.execute();
    }

    public static void bannerList(Context mContext, String locales, BannerInterface bannerInterfacr) {
        String sessionToken;
        String companyCode = "";
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        if (!preferenceHelper.getSavedData("companyCode", "").equals("") || !TextUtils.isEmpty(preferenceHelper.getSavedData("companyCode", ""))) {
            companyCode = preferenceHelper.getSavedData("companyCode", "axbsec");
        }
        final String randomStr = AndroidUtil.getN();
        bannerif = bannerInterfacr;
        BannerBean bannerBean = new BannerBean();
        bannerBean.setCompanyCode(companyCode);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.BannerList;
        BaseTask getBannerListrask = new BaseTask(mContext, randomStr, JSON.toJSONString(bannerBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getBannerListrask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                List<BannerListResultBean.DataBean> dataBeanArrayList;
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
//                String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                JSONArray objects = JSONArray.parseArray(res.getData());
                dataBeanArrayList = objects.toJavaList(BannerListResultBean.DataBean.class);
                if ("0".equals(res.getCode())) {
                    BannerListResultBean bannerListResultBean = new BannerListResultBean();
                    bannerListResultBean.setCode(res.getCode());
                    bannerListResultBean.setMessage(res.getMessage());
                    bannerListResultBean.setData(dataBeanArrayList);
                    bannerif.setBannerListResult(bannerListResultBean);
                } else {
                    BannerListResultBean bannerListResultBean = new BannerListResultBean();
                    bannerListResultBean.setCode(res.getCode());
                    bannerListResultBean.setMessage(res.getMessage());
                    bannerif.setBannerListResult(bannerListResultBean);
                }
            }

            @Override
            public void setErr() {
            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        getBannerListrask.execute();
    }

    public static void blackwhiteList(Context mContext, String locales, BWListInterface bwListInterface) {
        String sessionToken;
        String companyCode = "";
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        if (!preferenceHelper.getSavedData("companyCode", "").equals("") || !TextUtils.isEmpty(preferenceHelper.getSavedData("companyCode", ""))) {
            companyCode = preferenceHelper.getSavedData("companyCode", "axbsec");
        }
        final String randomStr = AndroidUtil.getN();
        bwListIntf = bwListInterface;
        BannerBean bannerBean = new BannerBean();
        bannerBean.setCompanyCode(companyCode);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.BlackwhiteList;
        BaseTask getScanHisDatatask = new BaseTask(mContext, randomStr, JSON.toJSONString(bannerBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getScanHisDatatask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                BwListResultBean.DataBean dataBean = JSON.parseObject(decodeStr, BwListResultBean.DataBean.class);


                if ("0".equals(res.getCode())) {
                    BwListResultBean bwListResultBean = new BwListResultBean();
                    bwListResultBean.setCode(res.getCode());
                    bwListResultBean.setMessage(res.getMessage());
                    bwListResultBean.setData(dataBean);
                    bwListIntf.setBwResult(bwListResultBean);
                } else {
                    BwListResultBean bwListResultBean = new BwListResultBean();
                    bwListResultBean.setCode(res.getCode());
                    bwListResultBean.setMessage(res.getMessage());
                    bwListIntf.setBwResult(bwListResultBean);

                }

            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        getScanHisDatatask.execute();
    }

    public static void ownShipCard(Context mContext, String euaid, String huaid, String scantime, String signature, String locales, GetOwnerImageInterface getOwnerImageInterface) {


        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        String sessionToken = preferenceHelper.getSavedData("sessionToken", "");


        final String randomStr = AndroidUtil.getN();
        getOwnerImageIf = getOwnerImageInterface;
        OwnerCardBean ownerCardBean = new OwnerCardBean();
        ownerCardBean.setUaid(huaid);
//        ownerCardBean.setHuaid(huaid);
        ownerCardBean.setScantime(scantime);
        ownerCardBean.setSignature(signature);


        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.GetOwnershipCard;
        GetOwnerImgTask getGiftDataTask = new GetOwnerImgTask(mContext, randomStr, JSON.toJSONString(ownerCardBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
        getGiftDataTask.setCallBack(new GetOwnerImgTask.CallBack() {

            @Override
            public void setStr(byte[] response) {
                ImgResultBean imgResultBean = new ImgResultBean();
                imgResultBean.setCode("0");
                imgResultBean.setData(response);
                imgResultBean.setMessage("");
                getOwnerImageIf.setOwnerImgResult(imgResultBean);
            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        getGiftDataTask.execute();
    }

    public static void uaidInfo(Context mContext, String uaid, String thirdPartyCode, Options options, String locales, GetUAIDInformationInterface getUAIDInformationInterface) {

        String sessionToken;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        if (sessionToken.equals("") || TextUtils.isEmpty(sessionToken)) {
            AndroidUtil.showToastMessage(mContext, "CustomerSDK is not configured, please check the relevant configuration.");
        } else {
            final String randomStr = AndroidUtil.getN();
            getUAIDInformatif = getUAIDInformationInterface;
            GetuaidinfoBean getuaidinfoBean = new GetuaidinfoBean();
            getuaidinfoBean.setUaid(uaid);
            getuaidinfoBean.setThirdPartyCode(thirdPartyCode);
            GetuaidinfoBean.OptionsBean optionsBean = new GetuaidinfoBean.OptionsBean();
            optionsBean.setResponseTemplate(options.getOptions().getResponseTemplate());
            getuaidinfoBean.setOptions(optionsBean);
            String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.Uaidinfo;
            BaseTask getuaidTask = new BaseTask(mContext, randomStr, JSON.toJSONString(getuaidinfoBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
            getuaidTask.setCallBack(new BaseTask.CallBack() {
                @Override
                public void setStr(String response) {


                    ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);

                    if (res.getCode().equals("0")) {
                        String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                        JSONObject jsono = JSON.parseObject(decodeStr);
                        JSONObject jsonObjectUaid = jsono.getJSONObject("uaid");
                        JSONArray jsonArrayOwnerHis = jsono.getJSONArray("ownerHistory");
                        JSONObject jsonObjectProductBatch = jsono.getJSONObject("productBatch");
                        JSONObject jsonObjectScanData = jsono.getJSONObject("scanData");
                        SendUaidInfobean sendUaidInfobean = new SendUaidInfobean();
                        SendUaidInfobean.DataBean.UaidBean uaidBean = JSON.parseObject(jsonObjectUaid.toJSONString(), SendUaidInfobean.DataBean.UaidBean.class);
                        SendUaidInfobean.DataBean.ProductBatchBean productBatchBean = JSON.parseObject(jsonObjectProductBatch.toJSONString(), SendUaidInfobean.DataBean.ProductBatchBean.class);
                        SendUaidInfobean.DataBean.ScanDataBean scanDataBean = JSON.parseObject(jsonObjectScanData.toJSONString(), SendUaidInfobean.DataBean.ScanDataBean.class);
                        List<SendUaidInfobean.DataBean.OwnerHistoryBean> ownerHistoryList = new ArrayList<>();
                        for (int i = 0; i < jsonArrayOwnerHis.size(); i++) {
                            JSONObject jsonObjectOwnerHis = jsonArrayOwnerHis.getJSONObject(i);
                            SendUaidInfobean.DataBean.OwnerHistoryBean ownerHistory = JSON.parseObject(jsonObjectOwnerHis.toJSONString(), SendUaidInfobean.DataBean.OwnerHistoryBean.class);
                            ownerHistoryList.add(ownerHistory);
                        }
                        SendUaidInfobean.DataBean dataBean = new SendUaidInfobean.DataBean();
                        dataBean.setUaid(uaidBean);
                        dataBean.setOwnerHistory(ownerHistoryList);
                        dataBean.setProductBatch(productBatchBean);
                        dataBean.setScanData(scanDataBean);
                        sendUaidInfobean.setCode(res.getCode());
                        sendUaidInfobean.setMessage(res.getMessage());
                        sendUaidInfobean.setData(dataBean);
                        getUAIDInformatif.setUaidinfoResult(sendUaidInfobean);
                    } else {
                        SendUaidInfobean sendUaidInfobean = new SendUaidInfobean();
                        sendUaidInfobean.setCode(res.getCode());
                        sendUaidInfobean.setMessage(res.getMessage());
                        getUAIDInformatif.setUaidinfoResult(sendUaidInfobean);
                    }


                }

                @Override
                public void setErr() {

                    ResultBean resultBean = new ResultBean();
                    resultBean.setCode("-1");
                    resultBean.setMessage("Error");
                    getUAIDInformatif.setUaidinfoResult(null);
                }

                @Override
                public void doSomething() {
                    // TODO Auto-generated method stub

                }
            });
            getuaidTask.execute();
        }

    }


//    //需要用户写回调onActivityResult 此方法只是唤起扫描框1
//    public static void StartScan(Context mContext, String locales, int requestCode, ScanOptions scanOptions) {
//
//        String api = AndroidUtil.GetCustomerUrl() + AndroidUtil.GETSESSIONTOKEN;
//        ApiTokenReqDto dto = new ApiTokenReqDto();
//        dto.setAppId(AndroidUtil.APPID);
//        dto.setApiKey(AndroidUtil.APPKEY);
//        BaseTask task = new BaseTask(mContext, JSON.toJSONString(dto), api, locales, AndroidUtil.ReqType.POST);
//        task.setCallBack(new BaseTask.CallBack() {
//            @Override
//            public void setStr(String response) {
//                GetTokenBean getTokenBean = JSON.parseObject(response, GetTokenBean.class);
//                if (getTokenBean.getCode().equals("0")) {
//                    startScan(mContext, requestCode, getTokenBean.getData().getSessionToken(), scanOptions);
//                }
//            }
//
//            @Override
//            public void setErr() {
//
//            }
//
//            @Override
//            public void doSomething() {
//            }
//        });
//        task.execute();
//    }

    /*-----------------------------------------------------------------------------------------------------------------------------------------------*/


    //内部方法用户只需要SDK结果的时候调用arresult+extendedData
    public static void SetARcoreResultAndExtendedData(int arresult, String extendedData) {
        SendCustomerDataBean sendCustomerDataBean = new SendCustomerDataBean();
        sendCustomerDataBean.setCode("");
        sendCustomerDataBean.setMessage("");
        sendCustomerDataBean.setData(null);
        ARCode arCode = new ARCode();
        arCode.setExtendedData(extendedData);
        arCode.setAuthenticatedResult(arresult);
        sendCustomerDataBean.setArCode(arCode);
        if (mainif != null) {
            mainif.setUaidResult(sendCustomerDataBean);
        }
    }

    //内部方法UAID验证
    public static void UaidAuthenticate(final Context mContext, String uaid, final int arresult, final String extendedData, String realUserIPAddress, LocationBean location, ChallengeResponse challengeResponse, String locales, final Options options, String signature, final VerifyEntity.OwnerShipData owdata) {
        PackageManager packageManager = null;
        ApplicationInfo applicationInfo = null;
        PackageInfo packageInfo = null;
        try {
            packageManager = mContext.getPackageManager();
            applicationInfo = packageManager.getApplicationInfo(mContext.getPackageName(), 0);
            packageInfo = packageManager.getPackageInfo(mContext.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            applicationInfo = null;
        }

        final String randomStr = AndroidUtil.getN();
        String udid = android.provider.Settings.Secure.getString(mContext.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        String applicationName = (String) packageManager.getApplicationLabel(applicationInfo);
        String sessionToken;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
            sessionToken = preferenceHelper.getSavedData("sessionToken", "");
        } else {
            sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
        }
        if (sessionToken.equals("") || TextUtils.isEmpty(sessionToken)) {
            AndroidUtil.showToastMessage(mContext, "CustomerSDK is not configured, please check the relevant configuration.");
        } else {
            String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.AUTHENTICATEUAID;
            AuthenticateBean authenticateBean = new AuthenticateBean();
            authenticateBean.setUaid(uaid);
            authenticateBean.setSignature(signature);
            authenticateBean.setRealUserIPAddress(realUserIPAddress);
            AuthenticateBean.ChallengeResponseBean challengeResponseBean = new AuthenticateBean.ChallengeResponseBean();
            challengeResponseBean.setAuthenticationId(challengeResponse.getChallengeResponse().getAuthenticationId());
            challengeResponseBean.setChallengeCode(challengeResponse.getChallengeResponse().getChallengeCode());
            challengeResponseBean.setResponse(challengeResponse.getChallengeResponse().getResponse());
            authenticateBean.setChallengeResponse(challengeResponseBean);
            AuthenticateBean.LocationBean locationBean = new AuthenticateBean.LocationBean();
            locationBean.setLat(location.getLat());
            locationBean.setLng(location.getLng());
            authenticateBean.setLocation(locationBean);
            AuthenticateBean.DeviceBean deviceBean = new AuthenticateBean.DeviceBean();
            deviceBean.setBrand(Build.BRAND);
            deviceBean.setModel(Build.MODEL);
            deviceBean.setOs("1");
            deviceBean.setOsVersion(Build.VERSION.RELEASE);
            deviceBean.setUdid(udid);
            authenticateBean.setDevice(deviceBean);
            AuthenticateBean.ApplicationBean applicationBean = new AuthenticateBean.ApplicationBean();
            applicationBean.setType("1");
            applicationBean.setAppName(applicationName);
            applicationBean.setVersion(packageInfo.versionName);
            authenticateBean.setApplication(applicationBean);
            AuthenticateBean.OptionsBean optionsBean = new AuthenticateBean.OptionsBean();
            optionsBean.setResponseTemplate(options.getOptions().getResponseTemplate());
            authenticateBean.setOptions(optionsBean);


            AuthenticateBean.ParamsBean.ArcodeBean arcodeBean = new AuthenticateBean.ParamsBean.ArcodeBean();
            arcodeBean.setAuthenticatedResult(arresult);
            arcodeBean.setArsdkExtendedInfo(extendedData);

            AuthenticateBean.ParamsBean paramsBean = new AuthenticateBean.ParamsBean();
            paramsBean.setArcode(arcodeBean);
            authenticateBean.setParams(paramsBean);
            BaseTask task = new BaseTask(mContext, randomStr, JSON.toJSONString(authenticateBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
            task.setCallBack(new BaseTask.CallBack() {
                @Override
                public void setStr(String response) {


                    SendCustomerDataBean sendCustomerDataBean = new SendCustomerDataBean();
                    ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                    VerifyEntity verifyEntity = JSON.parseObject(decodeStr, VerifyEntity.class);//获取到服务器的返回结果
                    sendCustomerDataBean.setData(verifyEntity);
                    ARCode arCode = new ARCode();
                    arCode.setAuthenticatedResult(arresult);
                    arCode.setExtendedData(extendedData);
                    sendCustomerDataBean.setArCode(arCode);

                    if (res.getCode().equals("0")) {

                        if (options.getOptions().getResponseTemplate().contains("1") || options.getOptions().getResponseTemplate().contains("1.4")) {
                            if (verifyEntity.getOwnershipData() != null) {
                                String room_qrcode = verifyEntity.getUaid().getUaid();
                                String room_type = verifyEntity.getOwnershipData().getType();
                                String room_euaid = verifyEntity.getOwnershipData().getEuaid();
                                String room_huaid = verifyEntity.getOwnershipData().getHuaid();
                                String room_scantime = String.valueOf(verifyEntity.getOwnershipData().getScantime());
                                String room_signature = verifyEntity.getOwnershipData().getSignature();
                                new InsertOwnerTask(mContext, room_qrcode, room_type, room_euaid, room_huaid, room_scantime, room_signature, "").execute();
                            } else {
                                VerifyEntity.OwnerShipData ownerShipData = new VerifyEntity.OwnerShipData();
                                ownerShipData.setEuaid(owdata.getEuaid());
                                ownerShipData.setHuaid(owdata.getHuaid());
                                ownerShipData.setScantime(owdata.getScantime());
                                ownerShipData.setSignature(owdata.getSignature());
                                ownerShipData.setType(owdata.getType());
                                sendCustomerDataBean.getData().setOwnershipData(ownerShipData);
                            }
                        }
                        sendCustomerDataBean.setCode(res.getCode());
                        sendCustomerDataBean.setMessage(res.getMessage());
                        mainif.setUaidResult(sendCustomerDataBean);
                    } else {
                        sendCustomerDataBean.setData(null);
                        sendCustomerDataBean.setCode(res.getCode());
                        sendCustomerDataBean.setMessage(res.getMessage());
                        mainif.setUaidResult(sendCustomerDataBean);
                    }
                }

                @Override
                public void setErr() {
                }

                @Override
                public void doSomething() {
                }
            });
            task.execute();
        }
    }

//    //需要用户写回调onActivityResult 此方法只是唤起扫描框2
//    private static void startScan(Context mContext, int requestCode, String token, ScanOptions scanOptions) {
//        String api = AndroidUtil.GetCustomerUrl() + AndroidUtil.GETTDATA;
//        Log.d("startScan", "api:" + api);
//        Log.d("startScan", "token:" + token);
//        ARScannerActivity.setAccessRealRestURL(api);
//        Map<String, String> restHeaders = new HashMap<String, String>();
//        restHeaders.put("Authorization", token);
//        restHeaders.put("locale", AndroidUtil.getLanguage(mContext));
//        ARScannerActivity.setAccessRealRestHeaders(restHeaders);
//        String appCode = "Android_customer";
//        Map<String, Object> restParams = new HashMap<String, Object>();
//        restParams.put("appCode", appCode);
//        restParams.put("udid", Apl.udid);
//        ARScannerActivity.setAccessRealRestParams(restParams);
//        Map<String, Object> params = new HashMap<String, Object>();
//        params.put("skipActive", scanOptions.getSkipActive());
//        ARScannerActivity.setInitialZoom(scanOptions.getCameraScale());
//        ARScannerActivity.setTest(params);
//        ARScannerActivity.setFlashEnabled(scanOptions.getFlashEnabled());
//        ARScannerActivity.setFlashControlEnabled(scanOptions.getFlashControlEnable());
//        ARScannerActivity.setCompanyCodeList(scanOptions.getCompanyCodes().getBlackList(), scanOptions.getCompanyCodes().getCompanyCodes());
//        Intent intent = new Intent(mContext, ARScannerActivity.class);
//        Activity activity = (Activity) mContext;
//        activity.startActivityForResult(intent, requestCode);
//    }

    //如果有拥有者信息 则插入到数据库
    private static class InsertOwnerTask extends AsyncTask<Void, Void, Void> {
        String code;
        String type;
        String euaid;
        String huaid;
        String scantime;
        String signature;
        String thirdcode;
        Context mContext;

        public InsertOwnerTask(Context mContext, String code, String type, String euaid, String huaid, String scantime, String signature, String thirdcode) {
            this.mContext = mContext;
            this.code = code;
            this.type = type;
            this.euaid = euaid;
            this.huaid = huaid;
            this.scantime = scantime;
            this.signature = signature;
            this.thirdcode = thirdcode;
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            OwnerDataBase ownerDataBase = OwnerDataBase.getInstance(mContext);
            ownerDataBase.ownerDao().insterOwner(new Owner(code, type, euaid, huaid, scantime, signature, "0", thirdcode)); //0代表没有显示
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }

    /*根据扫码查询是否有签名记录*/
    private static class QuerOwnerTask extends AsyncTask<Void, Void, Void> {

        String qrcode;
        String uaid;
        String realUserIPAddress;
        LocationBean location;
        ChallengeResponse challengeResponse;
        String locales;
        Options options;
        Context mContext;

        public QuerOwnerTask(Context mContext, String uaid, String qrcode, String realUserIPAddress, LocationBean location, ChallengeResponse challengeResponse, String locales, Options options) {
            this.mContext = mContext;
            this.uaid = uaid;
            this.qrcode = qrcode;
            this.realUserIPAddress = realUserIPAddress;
            this.location = location;
            this.challengeResponse = challengeResponse;
            this.locales = locales;
            this.options = options;
        }

        @Override
        protected Void doInBackground(Void... arg0) {
            OwnerDataBase ownerDataBase = OwnerDataBase.getInstance(mContext);
            final VerifyEntity.OwnerShipData ownerShipData = new VerifyEntity.OwnerShipData();
            Owner owner = ownerDataBase.ownerDao().getInfoByCode(qrcode);
            String signature = "";
            String euaid = "";
            String huaid = "";
            String scantime = "";
            String type = "";
            if (owner != null) {  //有数据  把数据库里面的数据拿出来给网络请求
                signature = owner.getSignature();
                euaid = owner.getEuaid();
                huaid = owner.getHuaid();
                scantime = owner.getScantime();
                type = owner.getType();
                ownerShipData.setEuaid(euaid);
                ownerShipData.setHuaid(huaid);
                ownerShipData.setScantime(scantime);
                ownerShipData.setSignature(signature);
                ownerShipData.setType(type);
            }

            String udid = android.provider.Settings.Secure.getString(mContext.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            PackageManager packageManager = null;
            ApplicationInfo applicationInfo = null;
            PackageInfo packageInfo = null;
            try {
                packageManager = mContext.getPackageManager();
                applicationInfo = packageManager.getApplicationInfo(mContext.getPackageName(), 0);
                packageInfo = packageManager.getPackageInfo(mContext.getPackageName(), 0);
            } catch (PackageManager.NameNotFoundException e) {
                applicationInfo = null;
            }

            String applicationName = (String) packageManager.getApplicationLabel(applicationInfo);
            final AuthenticateBean authenticateBean = new AuthenticateBean();
            authenticateBean.setUaid(uaid);
            authenticateBean.setSignature(signature);
            authenticateBean.setRealUserIPAddress(realUserIPAddress);
            AuthenticateBean.ChallengeResponseBean challengeResponseBean = new AuthenticateBean.ChallengeResponseBean();
            challengeResponseBean.setAuthenticationId(challengeResponse.getChallengeResponse().getAuthenticationId());
            challengeResponseBean.setChallengeCode(challengeResponse.getChallengeResponse().getChallengeCode());
            challengeResponseBean.setResponse(challengeResponse.getChallengeResponse().getResponse());
            authenticateBean.setChallengeResponse(challengeResponseBean);
            AuthenticateBean.LocationBean locationBean = new AuthenticateBean.LocationBean();
            locationBean.setLat(location.getLat());
            locationBean.setLng(location.getLng());
            authenticateBean.setLocation(locationBean);
            AuthenticateBean.DeviceBean deviceBean = new AuthenticateBean.DeviceBean();
            deviceBean.setBrand(Build.BRAND);
            deviceBean.setModel(Build.MODEL);
            deviceBean.setOs("1");
            deviceBean.setOsVersion(Build.VERSION.RELEASE);
            deviceBean.setUdid(udid);
            authenticateBean.setDevice(deviceBean);
            AuthenticateBean.ApplicationBean applicationBean = new AuthenticateBean.ApplicationBean();
            applicationBean.setType("1");
            applicationBean.setAppName(applicationName);
            applicationBean.setVersion(packageInfo.versionName);
            authenticateBean.setApplication(applicationBean);
            AuthenticateBean.OptionsBean optionsBean = new AuthenticateBean.OptionsBean();
            optionsBean.setResponseTemplate(options.getOptions().getResponseTemplate());
            authenticateBean.setOptions(optionsBean);
//            AuthenticateBean.ParamsBean.ArcodeBean arcodeBean = new AuthenticateBean.ParamsBean.ArcodeBean();
//            arcodeBean.setAuthenticatedResult();
//            arcodeBean.setArsdkExtendedInfo("");
//            AuthenticateBean.ParamsBean paramsBean = new AuthenticateBean.ParamsBean();
//            paramsBean.setArcode(arcodeBean);
//            authenticateBean.setParams(paramsBean);

            new Thread() {
                @Override
                public void run() {
                    super.run();
                    Task(authenticateBean, ownerShipData);
                }
            }.start();

            return null;
        }

        private void Task(AuthenticateBean authenticateBean, final VerifyEntity.OwnerShipData ownerShipData) {
            String sessionToken;
            PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
            if (preferenceHelper.getSavedData("LoginSessionToken", "").equals("") || TextUtils.isEmpty(preferenceHelper.getSavedData("LoginSessionToken", ""))) {
                sessionToken = preferenceHelper.getSavedData("sessionToken", "");
            } else {
                sessionToken = preferenceHelper.getSavedData("LoginSessionToken", "");
            }
            final String randomStr = AndroidUtil.getN();
            String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.AUTHENTICATEUAID;
            BaseTask task = new BaseTask(mContext, randomStr, JSON.toJSONString(authenticateBean), api, sessionToken, locales, AndroidUtil.ReqType.POST);
            task.setCallBack(new BaseTask.CallBack() {
                @Override
                public void setStr(String response) {

                    SendCustomerDataBean sendCustomerDataBean = new SendCustomerDataBean();
                    ResponseBasicEncodeDto res = JSON.parseObject(response, ResponseBasicEncodeDto.class);
                    String decodeStr = AndroidUtil.deCodeJson(res.getData(), randomStr);
                    VerifyEntity verifyEntity = JSON.parseObject(decodeStr, VerifyEntity.class);//获取到服务器的返回结果
                    sendCustomerDataBean.setData(verifyEntity);

                    if (res.getCode().equals("0")) {
                        if (options.getOptions().getResponseTemplate().contains("1") || options.getOptions().getResponseTemplate().contains("1.4")) {
                            if (verifyEntity.getOwnershipData() != null) {
                                String room_qrcode = verifyEntity.getUaid().getUaid();
                                String room_type = verifyEntity.getOwnershipData().getType();
                                String room_euaid = verifyEntity.getOwnershipData().getEuaid();
                                String room_huaid = verifyEntity.getOwnershipData().getHuaid();
                                String room_scantime = String.valueOf(verifyEntity.getOwnershipData().getScantime());
                                String room_signature = verifyEntity.getOwnershipData().getSignature();
                                new InsertOwnerTask(mContext, room_qrcode, room_type, room_euaid, room_huaid, room_scantime, room_signature, "").execute();
                            } else {
                                sendCustomerDataBean.getData().setOwnershipData(ownerShipData);
                            }
                        }
                        sendCustomerDataBean.setCode(res.getCode());
                        sendCustomerDataBean.setMessage(res.getMessage());

                        mainif.setUaidResult(sendCustomerDataBean);//把封装好的数据返回给用户 包含code message data(VerifyEntity)  和 authenticatedResult
                    } else {
                        SendCustomerDataBean dataBean = new SendCustomerDataBean();
                        dataBean.setMessage(res.getMessage());
                        dataBean.setCode(res.getCode());
                        mainif.setUaidResult(dataBean);
                    }


                }

                @Override
                public void setErr() {
                }

                @Override
                public void doSomething() {
                }
            });
            task.execute();
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
        }
    }


    //Modify User Password
    public static void ModifyPassword(Context mContext, String oldPwd, String newPwd, String locales, ChangeUserPwdInterface changeUserPwdInterface) {
        final String randomStr = AndroidUtil.getN();
        changeUserPwdif = changeUserPwdInterface;
        ChangeUserPwdBean changeUserPwdBean = new ChangeUserPwdBean();
        changeUserPwdBean.setOldPwd(oldPwd);
        changeUserPwdBean.setNewPwd(newPwd);
        String api = AndroidUtil.GetCustomerUrl(mContext) + AndroidUtil.ModifyUserPassword;

        BaseTask loginTask = new BaseTask(mContext, randomStr, JSON.toJSONString(changeUserPwdBean), api, locales, AndroidUtil.ReqType.POST);
        loginTask.setCallBack(new BaseTask.CallBack() {
            @Override
            public void setStr(String response) {
                ResponResultBean res = JSON.parseObject(response, ResponResultBean.class);
                ResultBean resultBean = new ResultBean();
                resultBean.setCode(res.getCode());
                resultBean.setMessage(res.getMessage());
                changeUserPwdif.setChangeUserPwdResult(resultBean);
            }

            @Override
            public void setErr() {


            }

            @Override
            public void doSomething() {
                // TODO Auto-generated method stub

            }
        });
        loginTask.execute();
    }


}
