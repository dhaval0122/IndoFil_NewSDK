/*
 * @(#)BaseTask.java       Nov 28, 2017 10:18:18 AM
 *
 * Copyright (c) 2004-2016 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.task;

import android.content.Context;
import android.os.AsyncTask;

import com.alibaba.fastjson.JSON;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.HttpUtilNew;

//用于加密文件
public class GetRsaFileNameAsynchTask extends AsyncTask<Void, Void, Integer> {
    String response = "", locales = "";
    String json, head, api;
    boolean isShowMsg = true;
    CallBack callBack;
    int reqType;
    Context mContext;


    public GetRsaFileNameAsynchTask(Context mContext, String json, String api, String head, String locales, int reqType) {
        this.mContext = mContext;
        this.json = json;
        this.api = api;
        this.head = head;
        this.locales = locales;
        this.reqType = reqType;
    }


    @Override
    protected Integer doInBackground(Void... params) {
        int result = AndroidUtil.HttpResponseUtil.SUCCESS;//SUCCESS
        try {

            response = HttpUtilNew.postToServerByHttpClient(mContext,api, json, head, locales, reqType);
            if (response != null && !"".equals(response.trim())) {
                if (JSON.parseObject(response).get("code") != null) {
                    String code = JSON.parseObject(response).get("code").toString();
                    if ("119302".equals(code) || "100026".equals(code) || "100027".equals(code)) {
                        result = AndroidUtil.HttpResponseUtil.SPECIAL1;
                    } else if ("100025".equals(code) || "100024".equals(code)) {
                        result = AndroidUtil.HttpResponseUtil.SPECIAL2;
                    } else {
                        result = AndroidUtil.HttpResponseUtil.SUCCESS;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(Integer result) {
        super.onPostExecute(result);
        if (callBack != null) {
            callBack.doSomething();
        }
        if (result == AndroidUtil.HttpResponseUtil.SUCCESS) {
            if (callBack != null) {
                callBack.setStr(response);
            }
        } else if (result == AndroidUtil.HttpResponseUtil.SPECIAL1) {
            AndroidUtil.showToastMessage(mContext,JSON.parseObject(response).getString("message"));
            if (callBack != null) {
                callBack.setErr();
            }
        } else if (result == AndroidUtil.HttpResponseUtil.SPECIAL2) {
            if (isShowMsg) {
                AndroidUtil.showToastMessage(mContext,JSON.parseObject(response).getString("message"));
                callBack.setErr();
            }
            if (callBack != null) {
                callBack.setErr();
            }
        } else {
            if (isShowMsg) {
                AndroidUtil.showToastMessage(mContext,"Error");
                callBack.setErr();
            }
            if (callBack != null) {
                callBack.setErr();

            }
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    public void setCallBack(CallBack callBack) {
        this.callBack = callBack;
    }

    public interface CallBack {
        void setStr(String response);
        void setErr();
        void doSomething();
    }


}