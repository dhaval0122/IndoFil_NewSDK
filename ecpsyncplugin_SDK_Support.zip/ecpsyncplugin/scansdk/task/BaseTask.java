/*
 * @(#)BaseTask.java       Nov 28, 2017 10:18:18 AM
 *
 * Copyright (c) 2004-2016 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendRequestBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.HttpUtilNew;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.PreferenceHelper;

public class BaseTask extends AsyncTask<Void, Void, Integer> {
    PreferenceHelper preferenceHelper;
    String response = "", locales = "", randomStr = "", type = "";
    String json, head, api;
    boolean isShowMsg = true;
    CallBack callBack;
    int reqType;
    Context mContext;

    public BaseTask(Context mContext, String randomStr, String json, String api, String locales, int reqType) {
        this.mContext = mContext;
        this.randomStr = randomStr;

        this.json = json;
        Log.d("BaseTask", "json->" + json);
        this.api = api;
        this.locales = locales;
        this.reqType = reqType;
        preferenceHelper = PreferenceHelper.getInstance(mContext);
    }


    public BaseTask(Context mContext, String randomStr, String json, String api, String head, String locales, int reqType) {
        this.mContext = mContext;
        this.randomStr = randomStr;
        this.json = json;
        Log.d("BaseTask", "json->" + json);
        this.api = api;
        this.head = head;
        this.locales = locales;
        this.reqType = reqType;
        preferenceHelper = PreferenceHelper.getInstance(mContext);
    }

    public BaseTask(Context mContext, String json, String api, String head, String locales, int reqType, String type) {
        this.mContext = mContext;
        this.json = json;
        Log.d("BaseTask", "json->" + json);
        this.api = api;
        this.head = head;
        this.locales = locales;
        this.reqType = reqType;
        this.type = type;
        preferenceHelper = PreferenceHelper.getInstance(mContext);
    }

    @Override
    protected Integer doInBackground(Void... params) {


        String pubKeyId = preferenceHelper.getSavedData("pubKeyId", "0");
        Log.d("BaseTask", "pubKeyId->" + pubKeyId);
        SendRequestBean sendRequestBean = new SendRequestBean();
        int result = AndroidUtil.HttpResponseUtil.DEFAULT;
        try {
            String key = AndroidUtil.RSAEncrypt(mContext, randomStr);
            sendRequestBean.setKey(key);
            sendRequestBean.setPubKeyId(pubKeyId);
            sendRequestBean.setParam(AndroidUtil.enCodeJson(json, randomStr));
            response = HttpUtilNew.postToServerByHttpClient(mContext, api, JSON.toJSONString(sendRequestBean), head, locales, reqType);
            if (response != null && !"".equals(response.trim())) {
                if (JSON.parseObject(response).get("code") != null) {
                    String code = JSON.parseObject(response).get("code").toString();
                    if ("119302".equals(code) || "100026".equals(code) || "100027".equals(code)) {
                        result = AndroidUtil.HttpResponseUtil.SPECIAL1;
                    } else if ("100025".equals(code) || "100024".equals(code)) {
                        result = AndroidUtil.HttpResponseUtil.SPECIAL2;
                    } else {
                        result = AndroidUtil.HttpResponseUtil.SUCCESS;
                    }
                }
            }else {
                result = AndroidUtil.HttpResponseUtil.SPECIAL3;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(Integer result) {
        super.onPostExecute(result);
        if (callBack != null) {
            callBack.doSomething();
        }
        if (result == AndroidUtil.HttpResponseUtil.SUCCESS) {
            if (callBack != null) {
                callBack.setStr(response);
            }
        } else if (result == AndroidUtil.HttpResponseUtil.SPECIAL1) {
            AndroidUtil.showToastMessage(mContext, JSON.parseObject(response).getString("message"));
            if (callBack != null) {
                callBack.setErr();
            }
        } else if (result == AndroidUtil.HttpResponseUtil.SPECIAL2) {
            if (isShowMsg) {
                preferenceHelper.setDataSave("pubKeyId", "0");
                AndroidUtil.showToastMessage(mContext, JSON.parseObject(response).getString("message"));
                callBack.setErr();
            }
            if (callBack != null) {
                callBack.setErr();
            }
        } else if (result == AndroidUtil.HttpResponseUtil.SPECIAL3) {
            if (callBack != null) {
                callBack.setErr();
            }

        }else {
            if (isShowMsg) {
                AndroidUtil.showToastMessage(mContext, "Error");
                callBack.setErr();
            }
            if (callBack != null) {
                callBack.setErr();

            }
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    public void setCallBack(CallBack callBack) {
        this.callBack = callBack;
    }

    public interface CallBack {
        void setStr(String response);

        void setErr();

        void doSomething();
    }


}