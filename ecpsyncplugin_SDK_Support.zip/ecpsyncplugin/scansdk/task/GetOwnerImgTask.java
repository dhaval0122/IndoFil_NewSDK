/*
 * @(#)BaseTask.java       Nov 28, 2017 10:18:18 AM
 *
 * Copyright (c) 2004-2016 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.task;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import ecp.vcs.com.ecpsyncplugin.scansdk.bean.SendRequestBean;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.AndroidUtil;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.HttpUtilNew;
import ecp.vcs.com.ecpsyncplugin.scansdk.util.PreferenceHelper;

//ownShipCard
public class GetOwnerImgTask extends AsyncTask<Void, Void, Integer> {
    String locales = "", randomStr = "";
    String json, head, api;
    boolean isShowMsg = true;
    CallBack callBack;
    int reqType;
    Context mContext;
    byte[] response = null;

    public GetOwnerImgTask(Context mContext, String randomStr, String json, String api, String head, String locales, int reqType) {
        this.mContext = mContext;
        this.randomStr = randomStr;
        this.json = json;
        Log.d("BaseTask", "JSON:" + json);
        this.api = api;
        this.head = head;
        this.locales = locales;
        this.reqType = reqType;
    }


    @Override
    protected Integer doInBackground(Void... params) {
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        String pubKeyId = preferenceHelper.getSavedData("pubKeyId", "0");
        SendRequestBean sendRequestBean = new SendRequestBean();
        int result = AndroidUtil.HttpResponseUtil.SUCCESS;//SUCCESS
        try {
            String key = AndroidUtil.RSAEncrypt(mContext, randomStr);
            sendRequestBean.setKey(key);
            sendRequestBean.setPubKeyId(pubKeyId);
            sendRequestBean.setParam(AndroidUtil.enCodeJson(json, randomStr));
            response = HttpUtilNew.postToServerByHttpClientGetimg(mContext, api, json, head, locales, reqType);
            if (response != null) {
                result = AndroidUtil.HttpResponseUtil.SUCCESS;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    protected void onPostExecute(Integer result) {
        super.onPostExecute(result);
        if (callBack != null) {
            callBack.doSomething();
        }
        if (result == AndroidUtil.HttpResponseUtil.SUCCESS) {
            if (callBack != null) {
                callBack.setStr(response);
            }
        } else {
            if (isShowMsg) {
                AndroidUtil.showToastMessage(mContext, "Error");
                callBack.setErr();
            }
            if (callBack != null) {
                callBack.setErr();

            }
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

    }

    public void setCallBack(CallBack callBack) {
        this.callBack = callBack;
    }
    public interface CallBack {
        void setStr(byte[] response);

        void setErr();

        void doSomething();
    }


}