/*
 * @(#)LibraryX509TrustManager.java        Jan 11, 2014 7:16:52 PM
 *
 * Copyright (c) 2002-2014 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.util;

import android.util.Log;

import java.math.BigInteger;
import java.security.Principal;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.X509TrustManager;

/**
 * @ClassName: LibraryX509TrustManager
 * @Description: TODO
 * @author Mark Wang
 * @date Jan 11, 2014 7:19:14 PM
 * 
 */
public class LibX509TrustManagerOld implements X509TrustManager {
    public static final String TAG = "LibraryX509TrustManager";

    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        if (null != chain) {
            for (int k = 0; k < chain.length; k++) {
                X509Certificate cer = chain[k];
                print(cer);
            }
            try {
                chain[0].checkValidity();
            } catch (Exception e) {
                throw new CertificateException("Certificate not valid or trusted.");
            }
        }
        Log.d(TAG, "check client trusted. authType-->[" + authType + "]");
    }

    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        if (null != chain) {
            for (int k = 0; k < chain.length; k++) {
                X509Certificate cer = chain[k];
                print(cer);
            }
            try {
                chain[0].checkValidity();
            } catch (Exception e) {
                throw new CertificateException("Certificate not valid or trusted.");
            }
        }
        Log.d(TAG, "check servlet trusted. authType-->[" + authType + "]");
    }

    public X509Certificate[] getAcceptedIssuers() {
        Log.d(TAG, "get acceptedissuer");
        return null;
    }

    private void print(X509Certificate cer) {
        int version = cer.getVersion();
        String sinname = cer.getSigAlgName();
        String type = cer.getType();
        String algorname = cer.getPublicKey().getAlgorithm();
        BigInteger serialnum = cer.getSerialNumber();
        Principal principal = cer.getIssuerDN();
        String principalname = principal.getName();
        Log.d(TAG, "version=" + version + ", sinname=" + sinname + ", type=" + type + ", algorname=" + algorname
                + ", serialnum=" + serialnum + ", principalname=" + principalname);
    }

}
