package ecp.vcs.com.ecpsyncplugin.scansdk.util;

//import static android.os.Build.VERSION_CODES.R;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.isprint.vccard.algorithm.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.Locale;
import java.util.Random;

import javax.crypto.Cipher;

import ecp.vcs.com.ecpsyncplugin.R;

public class AndroidUtil {
    private static final String PACKAGE_URL_SCHEME = "package:"; // 方案
    public static final String HOSTNAME_ACCESSREAL = "accessreal";
    public static final String HOSTNAME_AXBINFOSEC = "axbinfosec";

    /*-----------------------------------------------------------------------------------------*/
    // 获取T值
//    public static final String GETTDATA = "/apiSqr/sqrDataAnalyze/getTData";

    public static final String GETTDATA = "/apiSqr/sqrDataAnalyze/getTDataBycompany";

    // 获取ApiToken
    public static final String GETTOKEN = "/apiDev/getToken";
    // 刷新ApiToken
    public static final String REFRESHTOKEN = "/apiDev/refreshToken";
    // OPENAPI-------登录
    public static final String LOGIN = "/api/v1/consumer/auth/login";
    // OPENAPI-------Scan History
    public static final String ScanHis = "/api/v1/consumer/scanHistory";
    // OPENAPI------- Ownership Card
    public static final String GetOwnershipCard = "/api/v1/consumer/ownShipCard";
    // OPENAPI-------NewsList
    public static final String NewsList = "/api/v1/consumer/newsList";

    public static final String Gift = "/api/v1/consumer/sendGift";


    // OPENAPI-------BannerList
    public static final String BannerList = "/api/v1/consumer/bannerList";
    // OPENAPI-------BlackwhiteList
    public static final String BlackwhiteList = "/api/v1/consumer/blackwhiteList";
    // OPENAPI-------Uaidinfo
    public static final String Uaidinfo = "/api/v1/app/uaid/info";
    // OPENAPI-------登出
    public static final String LOGOUT = "/api/v1/app/auth/logout";
    // OPENAPI-------UAID验证
    public static final String AUTHENTICATEUAID = "/api/v1/app/uaid/authenticate";
    // OPENAPI-------获取GetSessionToken
    public static final String GETSESSIONTOKEN = "/api/v1/app/auth/token/get";
    public static final String GetRsaFileName = "/api/v1/app/getDefaultRsaFile";
    public static final String DownRsaFile = "/api/v1/app/getRasFile";


    //发送验证码 ->没登录
    public static final String SendValidCode = "/api/v1/app/sys/user/sendValidCode";
    //重置用户密码
    public static final String ResetPwd = "/api/v1/app/sys/user/resetPwd";
    //上传图片
    public static final String UploadImg = "/api/v1/app/sys/file/uploadImg";
    //注册用户账户
    public static final String Register = "/api/v1/app/sys/user/register";
    //将 APP 账户与他人绑定
    public static final String BindAccountWithOthers = "/api/v1/app/sys/user/bind";


    //修改用户密码
    public static final String ModifyUserPassword = "/api/v1/consumer/sys/user/changePwd";
    //删除 AccessReal 账户
    public static final String DeleteAccessRealAccount = "/api/v1/consumer/sys/user/destroy";
    //在图像中生成验证码
    public static final String GenImgValidCode = "/api/v1/consumer/sys/user/genImgValidCode";
    //修改用户信息
    public static final String ModifyUserInfo = "/api/v1/consumer/sys/user/update";
    //发送验证码->已登录
    public static final String SendValidCodeByUser = "/api/v1/consumer/sys/user/sendValidCode";
    //获取用户信息详情
    public static final String GetUserDetail = "/api/v1/consumer/sys/user/detail";
    //保存 UAID 反馈
    public static final String SaveUAIDFeedback = "/api/v1/consumer/verify/feedback/save";
    //按页面列出反馈历史记录
    public static final String GetListFeedback = "/api/v1/consumer/verify/feedback/pageList";
    //UAID 反馈详情
    public static final String GetUAIDFeedback = "/api/v1/consumer/verify/feedback/detail";
    //获取购买/礼品历史记录
    public static final String GiftPurchaseHistory = "/api/v1/consumer/verify/giftPurchaseHistory";
    //导入拥有者卡
    public static final String ImportOwnShipCard = "/api/v1/consumer/verify/importOwnShipCard";
    //获取扫描历史记录详细信息
    public static final String GetHistoryDetail = "/api/v1/consumer/verify/historyDetail";
    //用户积分信息
    public static final String GetPointMsg = "/api/v1/consumer/reward/pointMsg";
    //兑换商店列表
    public static final String GetStoreGroupList = "/api/v1/consumer/reward/storeGroupList";
    //礼品类型列表
    public static final String GetRewardItemCateList = "/api/v1/consumer/reward/rewardItemCateList";
    //礼品清单
    public static final String GetRewardItemList = "/api/v1/consumer/reward/rewardItemList";
    //礼品详情
    public static final String GetRewardItemDetail = "/api/v1/consumer/reward/rewardItemDetail";
    //用户积分历史列表
    public static final String GetUserPointList = "/api/v1/consumer/reward/userPointList";
    //兑换历史列表
    public static final String GetRedemptionHistory = "/api/v1/consumer/reward/redemptionHistory";
    //申请兑换
    public static final String GetApplyRedemption = "/api/v1/consumer/reward/applyRedemption";







    /*-----------------------------------------------------------------------------------------*/


    public static String GetCustomerUrl(Context mContext) {
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        String Server = preferenceHelper.getSavedData("Server", "");
        return Server;
    }


    public static String getN() {
        Random random = new Random();
        return (random.nextInt(89999999) + 10000000) + "" + (random.nextInt(89999999) + 10000000);
    }

    public interface HttpResponseUtil {
        public static final int SUCCESS = 0;

        public static final int DEFAULT = -1;

        public static final int WRONG_FORMAT = -2;

        public static final int NOT_RESPONSE = -3;

        public static final int NOT_PUBLIC_KEY = -4;

        public static final int ENCODE_RESPONSE = -5;

        public static final int DECODE_RESPONSE = -6;

        public static final int SPECIAL1 = -7;

        public static final int SPECIAL2 = -8;

        public static final int SPECIAL3 = -9;

    }

    public interface ReqType {
        public static final int GET = 0;
        public static final int POST = 1;


    }


    public static String deCodeJson(String json, String key) {
        return AESCipher.aesDecryptString(json, key);
    }

    public static String RSAEncrypt(Context mContext, String key) throws Exception {
        InputStream is = null;
        FileInputStream file_inputstream = null;
        FileOutputStream fos = null;
        PreferenceHelper preferenceHelper = PreferenceHelper.getInstance(mContext);
        String filePath = "";
        if (!"0".equals(preferenceHelper.getSavedData("pubKeyId", "0"))) {
            file_inputstream = new FileInputStream(mContext.getFilesDir().getAbsolutePath() + "/" + HttpUtil.PUBLIC_KEY_PATH + "/" + HttpUtil.PUBLIC_KEY);
        } else {
            is = mContext.getResources().openRawResource(R.raw.public_key_1);
            if (!FileUtils.isFileExist(mContext, HttpUtil.PUBLIC_KEY_PATH, HttpUtil.PUBLIC_KEY)) {
                FileUtils.createSDDir(mContext, HttpUtil.PUBLIC_KEY_PATH);
                FileUtils.createSDFile(mContext, HttpUtil.PUBLIC_KEY_PATH, HttpUtil.PUBLIC_KEY);
            }
            File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + HttpUtil.PUBLIC_KEY_PATH + "/" + HttpUtil.PUBLIC_KEY);
            if (file.exists()) {
                if (file.isDirectory()) {
                    FileUtils.deleteDirectory(file);
                } else {
                    FileUtils.forceDelete(file);
                }
            }
            fos = new FileOutputStream(file);
            byte buf[] = new byte[1024];
            int numread;
            while ((numread = is.read(buf)) != -1) {
                fos.write(buf, 0, numread);
            }
            is.close();
            fos.close();
            file_inputstream = new FileInputStream(mContext.getFilesDir().getAbsolutePath() + "/" + HttpUtil.PUBLIC_KEY_PATH + "/" + HttpUtil.PUBLIC_KEY);
        }
        CertificateFactory certificate_factory = CertificateFactory.getInstance("X.509");
        X509Certificate x509certificate = (X509Certificate) certificate_factory.generateCertificate(file_inputstream);
        RSAPublicKey publicKey = (RSAPublicKey) x509certificate.getPublicKey();
        Cipher cipher = Cipher.getInstance("RSA/None/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        /** 执行加密操作 */
        byte[] b1 = cipher.doFinal(key.getBytes("utf-8"));
        return new String(Base64.encode(b1));
    }

    public static String enCodeJson(String json, String key) throws Exception {

        return AESCipher.aesEncryptString(json, key);
    }

    public static BitmapFactory.Options setOptions(BitmapFactory.Options opts) {
        opts.inJustDecodeBounds = false;
        opts.inPurgeable = true;
        opts.inInputShareable = true;
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        opts.inSampleSize = 1;
        return opts;
    }

    public static void showToastMessage(Context mContext, String message) {
        Toast toast = Toast.makeText(mContext, message, Toast.LENGTH_LONG);
        toast.show();
    }

    public static String getLanguage(Context context) {

        Locale locale = context.getResources().getConfiguration().locale;
        String language = locale.getDisplayLanguage();
        String local = Locale.getDefault().toString();
        String msg = "";
        if (language.equals("中文") && local.equals("zh_CN_#Hant")) {
            msg = "zh_TW";
        } else if (local.contains("zh_CN") || local.contains(" zh_CN_#Hans")) {
            msg = "zh_CN";
        } else if (local.contains("TW") || local.contains("zh_CN_#Hant") || local.contains("zh_TW") || local.contains("Hant") || local.contains("zh_HK")) {
            msg = "en_US";
        } else if (language.equals("英文")) {
            msg = "en_US";
        } else {
            msg = "en_US";
        }
        return msg;
    }

    public static boolean isCameraUseable(Context mContext) {
        return isCameraGranted(mContext);
    }

    public static boolean isCameraGranted(Context mContext) {
        return ContextCompat.checkSelfPermission(mContext, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }


    public static String getUaid(String uaid) {
        if (checkUaid(uaid)) {
            try {
                String tempStr = uaid.substring(uaid.indexOf("?") + 1);
                String[] arrayParam = tempStr.split("&");
                String productType = "";
                if (arrayParam != null && arrayParam.length > 0) {
                    productType = arrayParam[0].substring(arrayParam[0].indexOf("=") + 1);
                }
                if (productType != null && !"".equals(productType.trim())) {
                    uaid = productType;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return uaid;
    }

    public static boolean checkUaid(String uaid) {
        if (uaid != null && !"".equals(uaid.trim()) && (uaid.contains("q.do?u=") || uaid.contains("q?u="))) {
            return true;
        } else {
            return false;
        }
    }
}
