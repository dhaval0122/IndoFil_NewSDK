/*
 * @(#)FileUtils.java        Jan 12, 2014 7:27:00 PM
 *
 * Copyright (c) 2002-2014 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.util;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import ecp.vcs.com.ecpsyncplugin.R;

/**
 * @ClassName: FileUtils
 * @Description: TODO
 * @author Mark Wang
 * @date Jan 12, 2014 7:27:00 PM
 * 
 */
public class FileUtils {
//    public static String SDPATH = null;

    /**
     * <p>
     * Title:
     * </p>
     * <p>
     * Description:
     * </p>
     *
     * @param path
     * @param fileName
     * @return
     * @throws IOException
     */
    public static File createSDFile(Context mContext,String path, String fileName) throws IOException {
        File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
        file.createNewFile();
        return file;
    }

    /**
     * create dir on the SD card
     *
     * @param dirName
     * @return
     */
    public static File createSDDir(Context mContext,String dirName) {
        File dir = new File(mContext.getFilesDir().getAbsolutePath() + "/" + dirName);
        dir.mkdir();
        return dir;
    }

    /**
     * Judge if the folder exists on the SD card
     *
     * @param fileName
     * @return
     */
    public static boolean isFileExist(Context mContext,String path, String fileName) {
        File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
        return file.exists();
    }

    public static void deleteDirectory(File directory) throws IOException {
        if (!directory.exists()) {
            return;
        }
        cleanDirectory(directory);
        if (!directory.delete()) {
            String message = "Unable to delete directory " + directory + ".";

            throw new IOException(message);
        }
    }

    public static void cleanDirectory(File directory) throws IOException {
        if (!directory.exists()) {
            String message = directory + " does not exist";
            throw new IllegalArgumentException(message);
        }

        if (!directory.isDirectory()) {
            String message = directory + " is not a directory";
            throw new IllegalArgumentException(message);
        }

        File[] files = directory.listFiles();
        if (files == null) {
            throw new IOException("Failed to list contents of " + directory);
        }

        IOException exception = null;
        for (int i = 0; i < files.length; i++) {
            File file = files[i];
            try {
                forceDelete(file);
            }
            catch(IOException ioe) {
                exception = ioe;
            }
        }

        if (null != exception)
            throw exception;
    }

    public static void forceDelete(File file) throws IOException {
        if (file.isDirectory()) {
            deleteDirectory(file);
        }
        else {
            if (!file.exists()) {
                throw new FileNotFoundException("File does not exist: " + file);
            }
            if (!file.delete()) {
                String message = "Unable to delete file: " + file;

                throw new IOException(message);
            }
        }
    }

    public static int copy(InputStream input, OutputStream output) throws IOException {
        long count = copyLarge(input, output);
        if (count > 2147483647L) {
            return -1;
        }
        return (int) count;
    }

    public static long copyLarge(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[4096];
        long count = 0L;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    public static void saveBitmap(Context mContext,Bitmap bm, String picName) {
        try {
            if (!isFileExist( mContext,"")) {
                File tempf = createSDDir(mContext,"");
            }
            File f = new File(mContext.getFilesDir().getAbsolutePath(), picName + ".JPEG");
            if (f.exists()) {
                f.delete();
            }
            FileOutputStream out = new FileOutputStream(f);
            bm.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();
        }
        catch(FileNotFoundException e) {
            e.printStackTrace();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean isFileExist(Context mContext,String fileName) {
        File file = new File(mContext.getFilesDir().getAbsolutePath() + fileName);
        file.isFile();
        return file.exists();
    }

    public static void delFile(Context mContext,String fileName) {
        File file = new File(mContext.getFilesDir().getAbsolutePath() + fileName);
        if (file.isFile()) {
            file.delete();
        }
        file.exists();
    }

    public static void deleteDir(Context mContext) {
        File dir = new File(mContext.getFilesDir().getAbsolutePath());
        if (dir == null || !dir.exists() || !dir.isDirectory())
            return;

        for (File file : dir.listFiles()) {
            if (file.isFile())
                file.delete();
            else if (file.isDirectory())
                deleteDir(mContext);
        }
        dir.delete();
    }

    public static boolean fileIsExists(String path) {
        try {
            File f = new File(path);
            if (!f.exists()) {
                return false;
            }
        }
        catch(Exception e) {

            return false;
        }
        return true;
    }

    public static Bitmap readFile(Context mContext, String path, String fileName) throws Exception {
        Bitmap bm = null;

        if (!fileName.toLowerCase().endsWith(".jpg") && !fileName.toLowerCase().endsWith(".png")
                && !fileName.toLowerCase().endsWith(".jpeg") && !fileName.toLowerCase().endsWith(".bmp")
                && !fileName.toLowerCase().endsWith(".gif")) {
            fileName = fileName + ".jpg";
        }

        File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
        if (file.exists()) {
            long len = file.length();
            byte[] bytes = new byte[(int) len];
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
            int r = bufferedInputStream.read(bytes);
            bufferedInputStream.close();
            BitmapFactory.Options factory = new BitmapFactory.Options();
            factory = AndroidUtil.setOptions(factory);
            bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, factory);
        }
        else {
            bm = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.back_dark);
        }

        return bm;
    }

}
