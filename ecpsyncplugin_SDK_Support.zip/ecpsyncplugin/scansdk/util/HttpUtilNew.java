/*
 * @(#)HttpUtil.java        Jan 11, 2014 7:03:56 PM
 *
 * Copyright (c) 2002-2014 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.util;


import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.security.cert.CertificateException;

import cn.hutool.core.io.IoUtil;


public class HttpUtilNew {

    private static String convertStreamToString(InputStream is) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"), 8 * 1024);
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

    public static String postToServerByHttpClient(Context mContext,String path, String value, String head, String locales, int reqType) {
        String jsonString = null;
        try {
            HttpResponse response = null;
            HttpClient client = getHttpClient(mContext);
            if (reqType == AndroidUtil.ReqType.POST) {
                HttpPost request = new HttpPost(path);
                String parameter = new String(URLEncoder.encode(value, "utf-8"));
                request.setEntity(new StringEntity(value));
                request.addHeader("ACCEPT", "*/*");
                request.setHeader("Content-Type", "application/json; charset=utf-8");
                if (locales.equals("") || TextUtils.isEmpty(locales)) {
                    request.setHeader("locales", AndroidUtil.getLanguage(mContext));
                } else {
                    request.setHeader("locales", locales);
                }
                request.setHeader("Authorization", head);
                response = client.execute(request);
            } else if (reqType == AndroidUtil.ReqType.GET) {
                HttpPost request = new HttpPost(path);
                request.addHeader("ACCEPT", "*/*");
                request.setHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
                response = client.execute(request);
            }
            if (response != null) {
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    InputStream entityStream;
                    entityStream = response.getEntity().getContent();
                    jsonString = convertStreamToString(entityStream);
                }
            }
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonString;
    }


    public static byte[] postToServerByHttpClientGetimg(Context mContext,String path, String value, String head, String locales, int reqType) {
        Log.d("postToServerByHttpClient", "path:" + path + "  " + "value:" + value + "  " + "head:" + head + "  " + "locales:" + locales + "  " + "reqtype:" + reqType);
        byte[]  picBy  = null;
        try {
            HttpResponse response = null;
            HttpClient client = getHttpClient(mContext);
            if (reqType == AndroidUtil.ReqType.POST) {
                HttpPost request = new HttpPost(path);
                String parameter = new String(URLEncoder.encode(value, "utf-8"));
                request.setEntity(new StringEntity(value));
                request.addHeader("ACCEPT", "*/*");
                request.setHeader("Content-Type", "application/json; charset=utf-8");
                if (locales.equals("") || TextUtils.isEmpty(locales)) {
                    request.setHeader("locales", AndroidUtil.getLanguage(mContext));
                } else {
                    request.setHeader("locales", locales);
                }
                request.setHeader("Authorization", head);
                response = client.execute(request);
            } else if (reqType == AndroidUtil.ReqType.GET) {
                HttpPost request = new HttpPost(path);
                request.addHeader("ACCEPT", "*/*");
                request.setHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
                response = client.execute(request);
            }
            if (response != null) {
                int statusCode = response.getStatusLine().getStatusCode();
                if (statusCode == 200) {
                    InputStream entityStream;
                    entityStream = response.getEntity().getContent();
                    picBy = IoUtil.readBytes(entityStream );

                }
            }
        } catch (KeyManagementException e) {
            e.printStackTrace();
        } catch (UnrecoverableKeyException e) {
            e.printStackTrace();
        } catch (KeyStoreException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (CertificateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return picBy;
    }

    public static synchronized HttpClient getHttpClient(Context context) throws KeyStoreException,
            NoSuchAlgorithmException, CertificateException, IOException, KeyManagementException,
            UnrecoverableKeyException {
        DefaultHttpClient httpClient = null;
        try {
            KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
            trustStore.load(null, null);
            SSLSocketFactory sf = new SSLSocketFactoryEx(trustStore);
            sf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER); // 允许所有主机的验证

            HttpParams params = new BasicHttpParams();

            HttpProtocolParams.setVersion(params, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(params, HTTP.UTF_8);
            HttpProtocolParams.setUseExpectContinue(params, true);

            ConnManagerParams.setTimeout(params, 10000);
            HttpConnectionParams.setConnectionTimeout(params, 15000);
            HttpConnectionParams.setSoTimeout(params, 20000);

            SchemeRegistry schreg = new SchemeRegistry();
            schreg.register(new Scheme("http", PlainSocketFactory.getSocketFactory(),
                    80));
            schreg.register(new Scheme("https", sf,
                    443));
            ClientConnectionManager conman = new ThreadSafeClientConnManager(params, schreg);
            httpClient = new DefaultHttpClient(conman, params);
        } catch (java.security.cert.CertificateException e) {
            e.printStackTrace();
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return httpClient;
    }

    static class SSLSocketFactoryEx extends SSLSocketFactory {

        SSLContext sslContext = SSLContext.getInstance("TLS");

        public SSLSocketFactoryEx(KeyStore truststore)
                throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException, UnrecoverableKeyException {
            super(truststore);

            TrustManager tm = new X509TrustManager() {

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                    return null;
                }

                @Override
                public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType)
                        throws java.security.cert.CertificateException {

                }

                @Override
                public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType)
                        throws java.security.cert.CertificateException {
                    try {
                        chain[0].checkValidity();
                    } catch (Exception e) {
                        throw new java.security.cert.CertificateException("Certificate not valid or trusted.");
                    }
                }
            };

            sslContext.init(null, new TrustManager[]{tm}, null);
        }

        @Override
        public Socket createSocket(Socket socket, String host, int port, boolean autoClose)
                throws IOException, UnknownHostException {
            return sslContext.getSocketFactory().createSocket(socket, host, port, autoClose);
        }

        @Override
        public Socket createSocket() throws IOException {
            return sslContext.getSocketFactory().createSocket();
        }
    }
}
