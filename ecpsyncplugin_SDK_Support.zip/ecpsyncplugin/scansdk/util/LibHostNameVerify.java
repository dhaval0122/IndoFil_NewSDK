/*
 * @(#)LibraryHostNameVerify.java        Jan 11, 2014 7:18:02 PM
 *
 * Copyright (c) 2002-2014 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of 
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.util;

import android.util.Log;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

/**
 * @ClassName: LibraryHostNameVerify
 * @Description: verify host name
 * @author Mark Wang
 * @date Jan 11, 2014 7:18:58 PM
 *
 */
public class LibHostNameVerify implements HostnameVerifier {
    public static final String TAG = "LibraryHostNameVerify";

    public boolean verify(String hostname, SSLSession session) {
        Log.d("HostnameVerifier", "hostname-->[" + hostname + "],PeerHost-->[" + session.getPeerHost() + "]");
        if (hostname.toLowerCase().contains(AndroidUtil.HOSTNAME_ACCESSREAL) || hostname.toLowerCase().contains(AndroidUtil.HOSTNAME_AXBINFOSEC)) {
            return true;
        }else{
            return false;
        }
    }

}
