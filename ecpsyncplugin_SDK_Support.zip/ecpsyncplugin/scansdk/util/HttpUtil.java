/*
 * @(#)HttpUtil.java        Jan 11, 2014 7:03:56 PM
 *
 * Copyright (c) 2002-2014 i-Sprint Technologies, Inc.
 * address
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of
 * i-Sprint Technologies, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with i-Sprint.
 */
package ecp.vcs.com.ecpsyncplugin.scansdk.util;


import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

/**
 * @author Mark Wang
 * @ClassName: HttpUtil
 * @Description: provide UaidVerification post and get method to communication with server
 * @date Jan 11, 2014 7:04:54 PM
 */
public class HttpUtil {

    public static String PUBLIC_KEY_PATH = "PublicKey";
    public static String PUBLIC_KEY = "public_key";

    public static boolean downFileByHttps(Context mContext, String downloadurl, String path, String fileName) {
        FileOutputStream fos = null;
        InputStream input = null;
        HttpsURLConnection conn = null;
        boolean result = false;
        try {
            URL url = new URL(downloadurl);
            SSLContext sslctxt = SSLContext.getInstance("TLS");
            sslctxt.init(null, new TrustManager[]{new LibX509TrustManagerOld()}, new java.security.SecureRandom());
            conn = (HttpsURLConnection) url.openConnection();
            conn.setSSLSocketFactory(sslctxt.getSocketFactory());
            conn.setHostnameVerifier(new LibHostNameVerify());
            conn.connect();
            int respCode = conn.getResponseCode();
            input = conn.getInputStream();
            File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
            if (!file.exists()) {
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
                try {
                    file.createNewFile();
                } catch (IOException e) {
                    return result;
                }
            } else {
                FileUtils.forceDelete(file);
            }
            fos = new FileOutputStream(file);
            FileUtils.copy(input, fos);
            result = true;
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return result;
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
                if (input != null) {
                    input.close();
                }
                if (conn != null) {
                    conn.disconnect();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
    public static boolean downFileByHttp(Context mContext,String url, String path, String fileName) {

        boolean isSuccuss = false;
        InputStream is = null;
        FileOutputStream fos = null;
        String errorCode = "";
        String errorMsg = "";
        try {
            URL tmpUrl = new URL(url);

            URLConnection conn = tmpUrl.openConnection();
            conn.connect();
            conn.setConnectTimeout(15000);
            is = conn.getInputStream();
            // errorCode = conn.getHeaderField("errorCode");
            // if (!"0".equals(errorCode)) {
            // errorMsg = new
            // String(Base64.decode(conn.getHeaderField("errorMessage")));
            // }
            int fileSize = conn.getContentLength();
            if (!FileUtils.isFileExist(mContext,path, fileName)) {
                FileUtils.createSDDir(mContext,path);
                FileUtils.createSDFile(mContext,path, fileName);
            }
            File file = new File(mContext.getFilesDir().getAbsolutePath() + "/" + path + "/" + fileName);
            if (file.exists()) {
                if (file.isDirectory()) {
                    FileUtils.deleteDirectory(file);
                } else {
                    FileUtils.forceDelete(file);
                }
            }
            fos = new FileOutputStream(file);
            byte buf[] = new byte[1024];
            int downLoadFilePosition = 0;
            int numread;

            while ((numread = is.read(buf)) != -1) {
                fos.write(buf, 0, numread);
                downLoadFilePosition += numread;
            }
            is.close();
            fos.close();
            isSuccuss = true;
            if (fileSize != downLoadFilePosition) {
            }
            if (downLoadFilePosition <= 0) {
                isSuccuss = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            isSuccuss = false;
        }

        return isSuccuss;
    }

}
