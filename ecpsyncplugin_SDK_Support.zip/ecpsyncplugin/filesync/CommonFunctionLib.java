package ecp.vcs.com.ecpsyncplugin.filesync;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;


public class CommonFunctionLib {
    static String GetCurrentDate(String Format) {

        String Date = null;
        try {
            Calendar cal = new GregorianCalendar();
            DateFormat dateFormat = new SimpleDateFormat(Format, Locale.US);
            Date = dateFormat.format(cal.getTime());
//			Log.e(" Date ", " : " + Date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Date;
    }

    /*private static String appendZeroDay(int selectedDay) {
        String day;
        if (selectedDay < 10) {
            day = "0" + String.valueOf(selectedDay);
        } else {
            day = String.valueOf(selectedDay);
        }
        return day;
    }



    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();
    }


    public static boolean hasActiveInternetConnection() {
        boolean issend;
        if (Build.VERSION.SDK_INT <= 27) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll()
                    .build();
            StrictMode.setThreadPolicy(policy);
            //}
            try {
                URL url = new URL("http://www.google.com");
                HttpURLConnection urlc = (HttpURLConnection) (url.openConnection());
                urlc.setRequestProperty("User-Agent", "Test");
                urlc.setRequestProperty("Connection", "close");
                urlc.setConnectTimeout(1500);
                urlc.connect();
                Log.e("Utils", "Active internet connection");
                issend = (urlc.getResponseCode() == 200);
            } catch (IOException e) {
                Log.e("Utils ret false", "Error checking internet connection", e);
                issend = false;
            }
            return issend;
        } else {
            return true;
        }

        //return true;
    }

    private static void writeToFile(final String fileName,
                                    final String fileContent, final String directoryName) {
        File dir = new File(directoryName);
        dir.mkdirs();
        File file = new File(dir, fileName);

        try {
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream f = new FileOutputStream(file, true);
            PrintWriter pw = new PrintWriter(f);
            pw.append("\n" + fileContent);
            //pw.append("\n---------------------\n");
            pw.flush();
            pw.close();
            f.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("ECP", "******* File not found. Did you" +
                    " add a WRITE_EXTERNAL_STORAGE permission to the     manifest?");
        }
    }*/

    public static String size(long size) {
        String hrSize;

        double k = size / 1024.0;
        double m = ((size / 1024.0) / 1024.0);
        double g = (((size / 1024.0) / 1024.0) / 1024.0);
        double t = ((((size / 1024.0) / 1024.0) / 1024.0) / 1024.0);

        DecimalFormat dec = new DecimalFormat("0.00");

        if (t > 1) {
            hrSize = dec.format(t).concat(" TB");
        } else if (g > 1) {
            hrSize = dec.format(g).concat(" GB");
        } else if (m > 1) {
            hrSize = dec.format(m).concat(" MB");
        } else if (k > 1) {
            hrSize = dec.format(k).concat(" KB");
        } else {
            hrSize = dec.format((double) size).concat(" Bytes");
        }

        return hrSize;
    }

    static String checkErrorReset(String errorString) {
        String messges = "";
        try {
            if (!errorString.equalsIgnoreCase("")) {
                if (errorString.contains("ECONNREFUSED") || errorString.contains("ENETUNREACH")) {
                    messges = "Internet connection reset, Please try again";
                } else if (errorString.contains("ETIMEDOUT")) {
                    messges = "Internet connection timeout, Please try again";
                } else {
                    messges = errorString;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            messges = errorString;
        }
        return messges;
    }

    /*public static String ConvertExceptionToString(Throwable e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }

    public static String CreateZipFile(String uploadPath, String FileName, String fZipName, int WDAY) {
        //uploadPath till /Upload
        //Utils.writeToFileMainSync("inside CreateZipFile");
        //String DB_PATH = Constant.ECTERNAL_STORAGE_APP_UPLOAD;
        uploadPath = uploadPath + "/" + WDAY + "/";
        String mPath = uploadPath + FileName;
        File dbFile = new File(mPath);
        String zipFileName = uploadPath + fZipName;
        if (dbFile.exists()) {
            //Utils.writeToFileMainSync("inside CreateZipFile exists");
            zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName);
        } else {
            //Utils.writeToFileMainSync("inside CreateZipFile not exists");
            zipFileName = "";
        }
        return zipFileName;
    }*/

    /*private static String AddFilesWithStandardZipEncryption(File dbFile, String zipFilePath) {
        String done;
        try {
            // Initiate ZipFile object with the path/name of the zip file.
            // Zip file may not necessarily exist. If zip file exists, then
            // all these files are added to the zip file. If zip file does not
            // exist, then a new zip file is created with the files mentioned
            ZipFile zipFile = new ZipFile(zipFilePath);
            // Build the list of files to be added in the array list
            // Objects of type File have to be added to the ArrayList
            ArrayList filesToAdd = new ArrayList();
            //noinspection unchecked
            filesToAdd.add(dbFile);

            // Initiate Zip Parameters which define various properties such
            // as compression method, etc. More parameters are explained in other
            // examples
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate
            // compression
            // Set the compression level. This value has to be in between 0 to 9
            // Several predefined compression levels are available
            // DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
            // DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
            // DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
            // DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
            // DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            // Now add files to the zip file
            // Note: To add a single file, the method addFile can be used
            // Note: If the zip file already exists and if this zip file is a split file
            // then this method throws an exception as Zip Format Specification does not
            // allow updating split zip files
            zipFile.addFiles(filesToAdd, parameters);
            done = zipFilePath;
        } catch (Exception e) {
            e.printStackTrace();
            done = "";
        }
        return done;
    }*/

    /*private static void printLoge(final int which, final String message, final String message1) {
        if (which >= 5) {
            if (which == 11) {
                Log.w(message, message1);
            } else {
                if (message1.length() > 2000) {
                    longInfo(message, message1);
                } else {
                    Log.e(message, message1);
                }
            }
        }
    }

    private static void longInfo(String strq, String str) {
        if (str.length() > 2000) {
            Log.e("" + strq, str.substring(0, 2000));
            longInfo(strq, str.substring(2000));
        } else {
            Log.e("" + strq, str);
        }
    }*/
}
