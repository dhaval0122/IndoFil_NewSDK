package ecp.vcs.com.ecpsyncplugin.filesync;


import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import ecp.vcs.com.ecpsyncplugin.Utils;


public class DatabaseHelper {
    private static final String TAG = "DatabaseHelper";
    //private static final String path = "DatabaseHelper";

    private SQLiteDatabase db;

    DatabaseHelper(String path) {
        db = SQLiteDatabase.openDatabase(path, null, 0);
        if (Build.VERSION.SDK_INT > 27) {
            db.disableWriteAheadLogging();
        }
    }

    SQLiteDatabase open() throws SQLException {
        //SQLiteDatabase db = this.getWritableDatabase();
        // # for Android 9 Support Target is 28
        if (Build.VERSION.SDK_INT > 27) {
            db.disableWriteAheadLogging();
        }
        return db;
    }

    public void close() throws SQLException {
        //SQLiteDatabase db = this.getWritableDatabase();
        // # for Android 9 Support Target is 28
        if (db != null)
            db.close();

    }

    private SQLiteDatabase openForRead() throws SQLException {
        //SQLiteDatabase db = this.getReadableDatabase();
        // # for Android 9 Support Target is 28
        if (Build.VERSION.SDK_INT > 27) {
            db.disableWriteAheadLogging();
        }
        return db;
    }

    /*public void commitChanges() {
        //SQLiteDatabase db = this.getReadableDatabase();
        // # for Android 9 Support Target is 28
        try {
            db.execSQL("PRAGMA wal_checkpoint");
            db.execSQL("PRAGMA journal_mode=DELETE");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    /*private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);

        fileOrDirectory.delete();
    }*/

    // Sagar
    JSONArray getJsonArrayFromTableName(String tableName) {
        JSONArray jsonArray = new JSONArray();

        String selectQuery = "SELECT * FROM " + tableName +
                " WHERE chrSync = 'N'";
        Log.e(TAG, "===tableName===selectQuery=======" + selectQuery);

        SQLiteDatabase db = this.openForRead();
        Cursor cursor = db.rawQuery(selectQuery, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for (int i = 0; i < totalColumn; i++) {
                if (cursor.getColumnName(i) != null) {
                    String cName = cursor.getColumnName(i);
                    try {
                        switch (cursor.getType(i)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                rowObject.put(cName, cursor.getInt(i));
                                break;
                            case Cursor.FIELD_TYPE_FLOAT:
                                rowObject.put(cName, String.valueOf(cursor.getFloat(i)));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                rowObject.put(cName, cursor.getString(i));
                                break;
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "Exception converting cursor column to json field: " + cName);
                    }
                }
            }
            jsonArray.put(rowObject);
            cursor.moveToNext();
        }
        cursor.close();
        //Log.e("JSON", jsonArray.toString());
        return jsonArray;
    }


    JSONArray getJsonArrayFromTableNameForIFFCO(String tableName) {
        JSONArray jsonArray = new JSONArray();

        String selectQuery = "SELECT * FROM " + tableName +
                " WHERE CHR_SYNC = 'N'";
        Log.e(TAG, "===tableName===selectQuery=======" + selectQuery);

        SQLiteDatabase db = this.openForRead();
        Cursor cursor = db.rawQuery(selectQuery, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for (int i = 0; i < totalColumn; i++) {
                if (cursor.getColumnName(i) != null) {
                    String cName = cursor.getColumnName(i);
                    try {
                        switch (cursor.getType(i)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                rowObject.put(cName, cursor.getInt(i));
                                break;
                            case Cursor.FIELD_TYPE_FLOAT:
                                rowObject.put(cName, String.valueOf(cursor.getFloat(i)));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                rowObject.put(cName, cursor.getString(i));
                                break;
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "Exception converting cursor column to json field: " + cName);
                    }
                }
            }
            jsonArray.put(rowObject);
            cursor.moveToNext();
        }
        cursor.close();
        //Log.e("JSON", jsonArray.toString());
        return jsonArray;
    }

    /*public List<String> getStringJsonArrayFromTableName(String tableName, int NumberOfRecordPerArray) {
        JSONArray jsonArray = new JSONArray();
        List<String> listString = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + tableName +
                " WHERE chrSync = 'N'";
        Log.e(TAG, "===tableName===selectQuery=======" + selectQuery);

        SQLiteDatabase db = this.openForRead();
        Cursor cursor = db.rawQuery(selectQuery, null);

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int totalRecords = cursor.getCount();
            int totalColumn = cursor.getColumnCount();
            JSONObject rowObject = new JSONObject();

            for (int i = 0; i < totalColumn; i++) {
                if (cursor.getColumnName(i) != null) {
                    String cName = cursor.getColumnName(i);
                    try {
                        switch (cursor.getType(i)) {
                            case Cursor.FIELD_TYPE_INTEGER:
                                rowObject.put(cName, cursor.getInt(i));
                                break;
                            case Cursor.FIELD_TYPE_FLOAT:
                                rowObject.put(cName, cursor.getFloat(i));
                                break;
                            case Cursor.FIELD_TYPE_STRING:
                                rowObject.put(cName, cursor.getString(i));
                                break;
                        }
                    } catch (Exception ex) {
                        Log.e(TAG, "Exception converting cursor column to json field: " + cName);
                    }
                }
            }
            jsonArray.put(rowObject);

            if (jsonArray.length() >= NumberOfRecordPerArray || (cursor.getPosition() + 1) == totalRecords) {
                listString.add(jsonArray.toString());
                jsonArray = new JSONArray();
            }
            cursor.moveToNext();
        }
        cursor.close();
        //Log.e("JSON", jsonArray.toString());
        return listString;
    }*/

    void writeTransactionTablesToFile(String tableName, int NumberOfRecordPerArray, int intRowNumber, String filePath) {
        boolean isExit = false;
        int fileCount = 0;

        JSONArray jsonArray = new JSONArray();

        do {
            String selectQuery = "SELECT * FROM " + tableName +
                    " WHERE chrSync = 'N' AND intGlCode > '" + intRowNumber + "' LIMIT 2000";
            Log.e(TAG, "QUERY==>" + selectQuery);

            SQLiteDatabase db = this.openForRead();
            Cursor cursor = db.rawQuery(selectQuery, null);

            boolean isBlank = cursor.moveToFirst();
            if (!isBlank) {
                isExit = true;
            }
            while (!cursor.isAfterLast()) {
                int totalRecords = cursor.getCount();
                int totalColumn = cursor.getColumnCount();
                JSONObject rowObject = new JSONObject();

                for (int i = 0; i < totalColumn; i++) {
                    if (cursor.getColumnName(i) != null) {
                        String cName = cursor.getColumnName(i);
                        try {
                            switch (cursor.getType(i)) {
                                case Cursor.FIELD_TYPE_INTEGER:
                                    rowObject.put(cName, cursor.getInt(i));
                                    break;
                                case Cursor.FIELD_TYPE_FLOAT:
                                    rowObject.put(cName, String.valueOf(cursor.getFloat(i)));
                                    break;
                                case Cursor.FIELD_TYPE_STRING:
                                    rowObject.put(cName, cursor.getString(i));
                                    break;
                            }
                        } catch (Exception ex) {
                            Log.e(TAG, "Exception converting cursor column to json field: " + cName);
                        }
                    }
                }
                jsonArray.put(rowObject);

                if (jsonArray.length() >= NumberOfRecordPerArray || (cursor.getPosition() + 1) == totalRecords) {
                    fileCount++;
                    FileSyncTask.generateTextFile(filePath, tableName + "$_" + (fileCount) + ".txt", jsonArray.toString());
                    try {
                        intRowNumber = jsonArray.getJSONObject(jsonArray.length() - 1).getInt("intGlCode");
                    } catch (Exception e) {
                        e.printStackTrace();
                        isExit = true;
                    }
                    jsonArray = new JSONArray();
                }
                cursor.moveToNext();
            }
            cursor.close();
        } while (!isExit);
    }

    void writeTransactionTablesToFileForIFFCO(String tableName, int NumberOfRecordPerArray, int intRowNumber, String filePath) {
        boolean isExit = false;
        int fileCount = 0;

        JSONArray jsonArray = new JSONArray();

        do {
            String selectQuery = "SELECT * FROM " + tableName +
                    " WHERE CHR_SYNC = 'N' AND INT_GLCODE > '" + intRowNumber + "' LIMIT 2000";
            Log.e(TAG, "QUERY==>" + selectQuery);

            SQLiteDatabase db = this.openForRead();
            Cursor cursor = db.rawQuery(selectQuery, null);

            boolean isBlank = cursor.moveToFirst();
            if (!isBlank) {
                isExit = true;
            }
            while (!cursor.isAfterLast()) {
                int totalRecords = cursor.getCount();
                int totalColumn = cursor.getColumnCount();
                JSONObject rowObject = new JSONObject();

                for (int i = 0; i < totalColumn; i++) {
                    if (cursor.getColumnName(i) != null) {
                        String cName = cursor.getColumnName(i);
                        try {
                            switch (cursor.getType(i)) {
                                case Cursor.FIELD_TYPE_INTEGER:
                                    rowObject.put(cName, cursor.getInt(i));
                                    break;
                                case Cursor.FIELD_TYPE_FLOAT:
                                    rowObject.put(cName, String.valueOf(cursor.getFloat(i)));
                                    break;
                                case Cursor.FIELD_TYPE_STRING:
                                    rowObject.put(cName, cursor.getString(i));
                                    break;
                            }
                        } catch (Exception ex) {
                            Log.e(TAG, "Exception converting cursor column to json field: " + cName);
                        }
                    }
                }
                jsonArray.put(rowObject);

                if (jsonArray.length() >= NumberOfRecordPerArray || (cursor.getPosition() + 1) == totalRecords) {
                    fileCount++;
                    FileSyncTask.generateTextFile(filePath, tableName + "$_" + (fileCount) + ".txt", jsonArray.toString());
                    try {
                        intRowNumber = jsonArray.getJSONObject(jsonArray.length() - 1).getInt("INT_GLCODE");
                    } catch (Exception e) {
                        e.printStackTrace();
                        isExit = true;
                    }
                    jsonArray = new JSONArray();
                }
                cursor.moveToNext();
            }
            cursor.close();
        } while (!isExit);
    }


    /*public boolean insertRecordDynamicUsingContentValues(String tableName, JSONArray jsonArray) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_PARTNER_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_STRICKER_Details);
        SQLiteDatabase db = open();
        try {
            *//*if (tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)) {
                Log.e("HFGGFHG", "jkjhkjhl");
            }*//*
            db.beginTransaction();

            if (!isTranTable) {
                db.delete(tableName, null, null);
            } else {
                db.delete(tableName, "chrSync=+?", new String[]{"N"});
            }

            for (int i = 0; i < jsonArray.length(); i++) {
                ContentValues contentValues = new ContentValues();
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    Iterator<String> iter = jsonObject.keys();

                    while (iter.hasNext()) {
                        String key = iter.next();
                        Object tmp = jsonObject.opt(key);
                        if (tmp != null) {
                            if (tmp instanceof String)
                                contentValues.put(key, (String) jsonObject.opt(key));
                            else if (tmp instanceof Integer)
                                contentValues.put(key, (Integer) jsonObject.opt(key));
                            else if (tmp instanceof Long)
                                contentValues.put(key, (Long) jsonObject.opt(key));
                            else if (tmp instanceof Float)
                                contentValues.put(key, (Float) jsonObject.opt(key));
                            else if (tmp instanceof Double)
                                contentValues.put(key, (Double) jsonObject.opt(key));
                        } else {
                            contentValues.put(key, "");
                        }
                    }

                    if (isTranTable) {
                        String chrTran = contentValues.getAsString("chrTran");
                        contentValues.remove("chrTran");

                        try {
                            if ("I".equalsIgnoreCase(chrTran) || "U".equalsIgnoreCase(chrTran) || chrTran == null) {
                                db.delete(tableName, "varSync_Code=+?", new String[]{contentValues.getAsString("varSync_Code")});
                                long id = db.insert(tableName, null, contentValues);
                                Log.e("Insert", tableName + " - " + id);
                            } else if ("D".equalsIgnoreCase(chrTran)) {
                                db.delete(tableName, "varSync_Code=+?", new String[]{contentValues.getAsString("varSync_Code")});
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }

                        *//*
                        if (chrTran.equalsIgnoreCase("I")) {
                            long id = db.insert(tableName, null, contentValues);
                            Log.e("Insert", tableName + " - " + id);
                        } else if (chrTran.equalsIgnoreCase("U")) {
                            long id = db.update(tableName, contentValues, "varSync_Code=" + contentValues.get("varSync_Code"), null);
                            Log.e("Update", tableName + " - " + id);
                        } else if (chrTran.equalsIgnoreCase("D")) {
                            long id = db.delete(tableName, "varSync_Code=+?", new String[]{contentValues.getAsString("varSync_Code")});
                            Log.e("Delete", tableName + " - " + id);
                        }*//*
                    } else {
                        long id = db.insert(tableName, null, contentValues);
                        Log.e("Insert", tableName + " - " + id);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    return false;
                }
            }

            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }*/

    /*public boolean insertRecordDynamic2(String tableName, final JSONArray jsonArray) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_PARTNER_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_STRICKER_Details);
        SQLiteDatabase db = open();
        try {
            *//*if (tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)) {
                Log.e("HFGGFHG", "jkjhkjhl");
            }*//*
            db.beginTransaction();

            if (!isTranTable) {
                db.delete(tableName, null, null);
            } else {
                db.delete(tableName, "chrSync=+?", new String[]{"N"});
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.append("INSERT INTO ").append(tableName)
                        .append(" ( ");

                StringBuilder sbQuery2 = new StringBuilder();
                try {
                    Iterator<String> iterKey = jsonArray.getJSONObject(0).keys();
                    StringBuilder valuesQ = new StringBuilder("");

                    while (iterKey.hasNext()) {
                        String key = iterKey.next();
                        if (key.equalsIgnoreCase("chrTran")) {
                            continue;
                        }
                        sbQuery2.append(sbQuery2.length() > 0 ? ", " + key : key);
                        valuesQ.append(valuesQ.length() > 0 ? ",?" : "?");
                    }
                    sbQuery.append(sbQuery2);
                    sbQuery.append(" ) ");
                    sbQuery.append(" values(" + valuesQ + ")");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                SQLiteStatement statement = db.compileStatement(sbQuery.toString());

                for (int i = 0; i < jsonArray.length(); i++) {
                    statement.clearBindings();
                    try {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        int pos = 1;
                        String chrTran = "";
                        if (jsonObject.has("chrTran")) {
                            chrTran = (String) jsonObject.opt("chrTran");
                            jsonObject.remove("chrTran");
                        }

                        Iterator<String> iter = jsonObject.keys();
                        while (iter.hasNext()) {
                            String key = iter.next();
                            Object tmp = jsonObject.opt(key);

                            if (tmp != null) {
                                if (tmp instanceof String)
                                    statement.bindString(pos, (String) tmp);
                                else if (tmp instanceof Integer)
                                    statement.bindLong(pos, (Integer) tmp);
                                else if (tmp instanceof Long)
                                    statement.bindLong(pos, (Long) tmp);
                                else if (tmp instanceof Float)
                                    statement.bindDouble(pos, (Float) tmp);
                                else if (tmp instanceof Double)
                                    statement.bindDouble(pos, (Double) tmp);
                                else
                                    statement.bindString(pos, tmp.toString());
                            } else {
                                statement.bindString(pos, "");
                            }
                            pos++;
                        }

                        if (isTranTable) {
                            try {
                                String varSync_Code = jsonObject.has("varSync_Code") ? (String) jsonObject.opt("varSync_Code") : "";

                                if ("I".equalsIgnoreCase(chrTran) || "U".equalsIgnoreCase(chrTran) || chrTran == null) {
                                    db.delete(tableName, "varSync_Code=+?", new String[]{varSync_Code});
                                    long id = statement.executeInsert();
                                    Log.e("Insert", tableName + " - " + id);
                                } else if ("D".equalsIgnoreCase(chrTran)) {
                                    db.delete(tableName, "varSync_Code=+?", new String[]{varSync_Code});
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                return false;
                            }
                        } else {
                            long id = statement.executeInsert();
                            Log.e("Insert", tableName + " - " + id);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        return false;
                    }
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }*/

    boolean insertRecordDynamic3(String tableName, final JSONArray jsonArray,JSONObject syncJSON) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_GENERAL_RECEIVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_Customer_Sticker_Scrap)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_Customer_Sticker_Consume)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_DAMAGE_TYPE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_PARTNER_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_PALLET_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_STRICKER_Details);
        SQLiteDatabase db = open();
        try {
            db.beginTransaction();
            if (!isTranTable) {
                Log.e("TRUE", "=AAAA===!===isTranTable============" + tableName);
                db.delete(tableName, null, null);
            } else {
                if (!tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_GENERAL_RECEIVE)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE)) {
                    Log.e("TRUE", "==BBBB=====isTranTable============" + tableName);
                    db.delete(tableName, "chrSync=+?", new String[]{"N"});
                }
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.append("INSERT INTO ").append(tableName)
                        .append(" ( ");

                StringBuilder sbQuery2 = new StringBuilder();
                try {
                    Iterator<String> iterKey = jsonArray.getJSONObject(0).keys();
                    //StringBuilder valuesQ = new StringBuilder("");
                    int pos = 0;
                    while (iterKey.hasNext()) {
                        String key = iterKey.next();
                        if (key.equalsIgnoreCase("chrTran")) {
                            continue;
                        }
                        if (pos != 0) {
                            sbQuery2.append(",");
                        }
                        pos = pos + 1;
                        sbQuery2.append(key);
                    }
                    sbQuery.append(sbQuery2);
                    sbQuery.append(" ) VALUES");
                } catch (Exception e) {
                    e.printStackTrace();
                    ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
                    Utils.writeJSONFile(syncJSON,"32","---Exception Error--insertRecordDynamic3--"+e.getMessage());
                }

                int arraySize = jsonArray.length();
                int BATCHSIZE = 500;
                int intBatch = (int) Math.ceil(arraySize * 1.00 / BATCHSIZE);
                int intRemainder = arraySize % BATCHSIZE;
                int intMaxRecords = BATCHSIZE;

                for (int b = 0; b < intBatch; b++) {
                    StringBuilder finalInsert = new StringBuilder();
                    finalInsert.append(sbQuery);
                    if (b == (intBatch - 1)) {
                        intMaxRecords = intRemainder == 0 ? BATCHSIZE : intRemainder;
                    }
                    StringBuilder valuesBuiler = new StringBuilder();
                    List<String> deleteValues = new ArrayList<>();
                    StringBuilder deleteQ = new StringBuilder();

                    int innerLoopSize = ((b * BATCHSIZE) + intMaxRecords);

                    for (int m = (b * BATCHSIZE); m < innerLoopSize; m++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(m);

                        if (jsonObject.has("chrTran")) {
                            String chrTran = jsonObject.getString("chrTran");
                            if (jsonObject.has("varSync_Code")) {
                                deleteQ.append(deleteValues.size() <= 0 ? "?" : ",?");
                                deleteValues.add(jsonObject.getString("varSync_Code"));
                            }

                            if (chrTran != null && chrTran.equalsIgnoreCase("d")) {
                                /*if (m == innerLoopSize) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }*/
                                continue;
                            }
                        }

                        Iterator<String> iter = jsonObject.keys();

                        if (valuesBuiler.length() > 0) {
                            valuesBuiler.append(",");
                        }
                        valuesBuiler.append("(");
                        while (iter.hasNext()) {
                            String key = iter.next();
                            if (key.equalsIgnoreCase("chrTran")) {
                                if (!iter.hasNext()) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }
                                continue;
                            }
                            Object tmp = jsonObject.opt(key);
                            if (tmp != null && !tmp.toString().equalsIgnoreCase("") && !tmp.toString().equalsIgnoreCase("null")) {
                                valuesBuiler.append("'");
                                valuesBuiler.append(tmp.toString().replace("'", "''"));
                                valuesBuiler.append("'");
                            } else {
                                valuesBuiler.append("NULL");
                            }
                            valuesBuiler.append(iter.hasNext() ? "," : "");
                        }
                        //valuesBuiler.append(m == ((b * BATCHSIZE) + intMaxRecords) - 1 ? ")" : "),");
                        valuesBuiler.append(")");
                    }
                    finalInsert.append(valuesBuiler);
                    Log.e("FINAL_INSERT_QUERY", finalInsert.toString());

                    if (isTranTable) {
                        String[] s = new String[deleteValues.size()];
                        s = deleteValues.toArray(s);
                        Log.e("","====deleteQ====="+deleteQ.toString());
                        Log.e("","=====s======="+s);
                        db.delete(tableName, "varSync_Code IN (" + deleteQ.toString() + ")", s);
                    }
                    db.execSQL(finalInsert.toString());
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
            Utils.writeJSONFile(syncJSON,"33","---Exception Error--insertRecordDynamic3--"+e.getMessage());
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }

    boolean insertRecordDynamicForIFFCO(String tableName, final JSONArray jsonArray,JSONObject syncJSON) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK_REMOVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CUSTOMER_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CUSTOMER_TYPE_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_BLOCK_TYPE)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CROP_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_SEASON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_POLITICAL_GEOGRAPHY_LEVEL_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_PALLET_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_SKU_STRICKER_Details)
                || tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_STRICKER_Details);
        SQLiteDatabase db = open();
        try {
            db.beginTransaction();
            if (!isTranTable) {
                Log.e("TRUE", "=AAAA===!===isTranTable============" + tableName);
                db.delete(tableName, null, null);
            } else {
                if (!tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK)
                        && !tableName.equalsIgnoreCase(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK_REMOVE)) {
                    Log.e("TRUE", "==BBBB=====isTranTable============" + tableName);
                    db.delete(tableName, "CHR_SYNC=+?", new String[]{"N"});
                }
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.append("INSERT INTO ").append(tableName)
                        .append(" ( ");

                StringBuilder sbQuery2 = new StringBuilder();
                try {
                    Iterator<String> iterKey = jsonArray.getJSONObject(0).keys();
                    //StringBuilder valuesQ = new StringBuilder("");
                    int pos = 0;
                    while (iterKey.hasNext()) {
                        String key = iterKey.next();
                        if (key.equalsIgnoreCase("CHR_TRAN")) {
                            continue;
                        }
                        if (pos != 0) {
                            sbQuery2.append(",");
                        }
                        pos = pos + 1;
                        sbQuery2.append(key);
                    }
                    sbQuery.append(sbQuery2);
                    sbQuery.append(" ) VALUES");
                } catch (Exception e) {
                    e.printStackTrace();
                    ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
                    Utils.writeJSONFile(syncJSON, "32", "---Exception Error--insertRecordDynamic3--" + e.getMessage());
                }

                int arraySize = jsonArray.length();
                int BATCHSIZE = 500;
                int intBatch = (int) Math.ceil(arraySize * 1.00 / BATCHSIZE);
                int intRemainder = arraySize % BATCHSIZE;
                int intMaxRecords = BATCHSIZE;

                for (int b = 0; b < intBatch; b++) {
                    StringBuilder finalInsert = new StringBuilder();
                    finalInsert.append(sbQuery);
                    if (b == (intBatch - 1)) {
                        intMaxRecords = intRemainder == 0 ? BATCHSIZE : intRemainder;
                    }
                    StringBuilder valuesBuiler = new StringBuilder();
                    List<String> deleteValues = new ArrayList<>();
                    StringBuilder deleteQ = new StringBuilder();

                    int innerLoopSize = ((b * BATCHSIZE) + intMaxRecords);

                    for (int m = (b * BATCHSIZE); m < innerLoopSize; m++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(m);

                        if (jsonObject.has("CHR_TRAN")) {
                            String chrTran = jsonObject.getString("CHR_TRAN");
                            if (jsonObject.has("VAR_SYNC_CODE")) {
                                deleteQ.append(deleteValues.size() <= 0 ? "?" : ",?");
                                deleteValues.add(jsonObject.getString("VAR_SYNC_CODE"));
                            }

                            if (chrTran != null && chrTran.equalsIgnoreCase("d")) {
                                /*if (m == innerLoopSize) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }*/
                                continue;
                            }
                        }

                        Iterator<String> iter = jsonObject.keys();

                        if (valuesBuiler.length() > 0) {
                            valuesBuiler.append(",");
                        }
                        valuesBuiler.append("(");
                        while (iter.hasNext()) {
                            String key = iter.next();
                            if (key.equalsIgnoreCase("CHR_TRAN")) {
                                if (!iter.hasNext()) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }
                                continue;
                            }
                            Object tmp = jsonObject.opt(key);
                            if (tmp != null && !tmp.toString().equalsIgnoreCase("") && !tmp.toString().equalsIgnoreCase("null")) {
                                valuesBuiler.append("'");
                                valuesBuiler.append(tmp.toString().replace("'", "''"));
                                valuesBuiler.append("'");
                            } else {
                                valuesBuiler.append("NULL");
                            }
                            valuesBuiler.append(iter.hasNext() ? "," : "");
                        }
                        //valuesBuiler.append(m == ((b * BATCHSIZE) + intMaxRecords) - 1 ? ")" : "),");
                        valuesBuiler.append(")");
                    }
                    finalInsert.append(valuesBuiler);
                    Log.e("FINAL_INSERT_QUERY", finalInsert.toString());

                    if (isTranTable) {
                        String[] s = new String[deleteValues.size()];
                        s = deleteValues.toArray(s);
                        Log.e("", "====deleteQ=====" + deleteQ.toString());
                        Log.e("", "=====s=======" + s);
                        db.delete(tableName, "VAR_SYNC_CODE IN (" + deleteQ.toString() + ")", s);
                    }
                    db.execSQL(finalInsert.toString());
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
            Utils.writeJSONFile(syncJSON, "33", "---Exception Error--insertRecordDynamic3--" + e.getMessage());
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }

    boolean insertRecordDynamicForLAB(String tableName, final JSONArray jsonArray,JSONObject syncJSON) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_STORE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_DISPOSAL)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_MATERIAL_ALLOCATION)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_MATERIAL_RETURN)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_STICKER_DETAILS);
        SQLiteDatabase db = open();
        try {
            db.beginTransaction();
            if (!isTranTable) {
                Log.e("TRUE", "=AAAA===!===isTranTable============" + tableName);
                db.delete(tableName, null, null);
            } else {
                if (!tableName.equalsIgnoreCase(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS)) {
                    Log.e("TRUE", "==BBBB=====isTranTable============" + tableName);
                    db.delete(tableName, "chrSync=+?", new String[]{"N"});
                }
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.append("INSERT INTO ").append(tableName)
                        .append(" ( ");

                StringBuilder sbQuery2 = new StringBuilder();
                try {
                    Iterator<String> iterKey = jsonArray.getJSONObject(0).keys();
                    //StringBuilder valuesQ = new StringBuilder("");
                    int pos = 0;
                    while (iterKey.hasNext()) {
                        String key = iterKey.next();
                        if (key.equalsIgnoreCase("chrTran")) {
                            continue;
                        }
                        if (pos != 0) {
                            sbQuery2.append(",");
                        }
                        pos = pos + 1;
                        sbQuery2.append(key);
                    }
                    sbQuery.append(sbQuery2);
                    sbQuery.append(" ) VALUES");
                } catch (Exception e) {
                    e.printStackTrace();
                    ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
                    Utils.writeJSONFile(syncJSON,"32","---Exception Error--insertRecordDynamic3--"+e.getMessage());
                }

                int arraySize = jsonArray.length();
                int BATCHSIZE = 500;
                int intBatch = (int) Math.ceil(arraySize * 1.00 / BATCHSIZE);
                int intRemainder = arraySize % BATCHSIZE;
                int intMaxRecords = BATCHSIZE;

                for (int b = 0; b < intBatch; b++) {
                    StringBuilder finalInsert = new StringBuilder();
                    finalInsert.append(sbQuery);
                    if (b == (intBatch - 1)) {
                        intMaxRecords = intRemainder == 0 ? BATCHSIZE : intRemainder;
                    }
                    StringBuilder valuesBuiler = new StringBuilder();
                    List<String> deleteValues = new ArrayList<>();
                    StringBuilder deleteQ = new StringBuilder();

                    int innerLoopSize = ((b * BATCHSIZE) + intMaxRecords);

                    for (int m = (b * BATCHSIZE); m < innerLoopSize; m++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(m);

                        if (jsonObject.has("chrTran")) {
                            String chrTran = jsonObject.getString("chrTran");
                            if (jsonObject.has("varSync_Code")) {
                                deleteQ.append(deleteValues.size() <= 0 ? "?" : ",?");
                                deleteValues.add(jsonObject.getString("varSync_Code"));
                            }

                            if (chrTran != null && chrTran.equalsIgnoreCase("d")) {
                                /*if (m == innerLoopSize) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }*/
                                continue;
                            }
                        }

                        Iterator<String> iter = jsonObject.keys();

                        if (valuesBuiler.length() > 0) {
                            valuesBuiler.append(",");
                        }
                        valuesBuiler.append("(");
                        while (iter.hasNext()) {
                            String key = iter.next();
                            if (key.equalsIgnoreCase("chrTran")) {
                                if (!iter.hasNext()) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }
                                continue;
                            }
                            Object tmp = jsonObject.opt(key);
                            if (tmp != null && !tmp.toString().equalsIgnoreCase("") && !tmp.toString().equalsIgnoreCase("null")) {
                                valuesBuiler.append("'");
                                valuesBuiler.append(tmp.toString().replace("'", "''"));
                                valuesBuiler.append("'");
                            } else {
                                valuesBuiler.append("NULL");
                            }
                            valuesBuiler.append(iter.hasNext() ? "," : "");
                        }
                        //valuesBuiler.append(m == ((b * BATCHSIZE) + intMaxRecords) - 1 ? ")" : "),");
                        valuesBuiler.append(")");
                    }
                    finalInsert.append(valuesBuiler);
                    Log.e("FINAL_INSERT_QUERY", finalInsert.toString());

                    if (isTranTable) {
                        String[] s = new String[deleteValues.size()];
                        s = deleteValues.toArray(s);
                        Log.e("","====deleteQ====="+deleteQ.toString());
                        Log.e("","=====s======="+s);
                        db.delete(tableName, "varSync_Code IN (" + deleteQ.toString() + ")", s);
                    }
                    db.execSQL(finalInsert.toString());
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            ////Utils.writeTextFile("---Exception Error--insertRecordDynamic3--"+e.getMessage());
            Utils.writeJSONFile(syncJSON,"33","---Exception Error--insertRecordDynamic3--"+e.getMessage());
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }

    /*public boolean insertRecordDynamic4(String tableName, final JSONArray jsonArray) {
        boolean isTranTable = tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PERSON_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_PRODUCT_SKU_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_PARTNER_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CUSTOMER_TYPE_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_POLITICAL_GEOGRAPHY_DETAILS)
                || tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_STRICKER_Details);
        SQLiteDatabase db = open();
        try {
            *//*if (tableName.equalsIgnoreCase(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE)) {
                Log.e("HFGGFHG", "jkjhkjhl");
            }*//*
            db.beginTransaction();

            if (!isTranTable) {
                db.delete(tableName, null, null);
            } else {
                db.delete(tableName, "chrSync=+?", new String[]{"N"});
            }

            if (jsonArray != null && jsonArray.length() > 0) {
                StringBuilder sbQuery = new StringBuilder();
                sbQuery.append("INSERT INTO ").append(tableName)
                        .append(" ( ");

                StringBuilder sbQuery2 = new StringBuilder();
                try {
                    Iterator<String> iterKey = jsonArray.getJSONObject(0).keys();
                    StringBuilder valuesQ = new StringBuilder("");
                    int pos = 0;
                    while (iterKey.hasNext()) {
                        String key = iterKey.next();
                        if (key.equalsIgnoreCase("chrTran")) {
                            continue;
                        }
                        if (pos != 0) {
                            sbQuery2.append(",");
                        }
                        pos = pos + 1;
                        sbQuery2.append(key);
                    }
                    sbQuery.append(sbQuery2);
                    sbQuery.append(" ) ");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                int arraySize = jsonArray.length();
                int BATCHSIZE = 400;
                int intBatch = (int) Math.ceil(arraySize * 1.00 / BATCHSIZE);
                int intRemainder = arraySize % BATCHSIZE;
                int intMaxRecords = BATCHSIZE;

                for (int b = 0; b < intBatch; b++) {
                    StringBuilder finalInsert = new StringBuilder();
                    finalInsert.append(sbQuery);
                    if (b == (intBatch - 1)) {
                        intMaxRecords = intRemainder == 0 ? BATCHSIZE : intRemainder;
                    }
                    StringBuilder valuesBuiler = new StringBuilder();
                    List<String> deleteValues = new ArrayList<>();
                    for (int m = (b * BATCHSIZE); m < ((b * BATCHSIZE) + intMaxRecords); m++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(m);

                        if (jsonObject.has("chrTran")) {
                            String chrTran = jsonObject.getString("chrTran");
                            String varSync_Code = jsonObject.has("varSync_Code") ? (String) jsonObject.opt("varSync_Code") : "";
                            deleteValues.add(varSync_Code);
                            if (chrTran != null && chrTran.equalsIgnoreCase("d")) {
                                continue;
                            }
                        }

                        Iterator<String> iter = jsonObject.keys();

                        valuesBuiler.append("SELECT ");
                        while (iter.hasNext()) {
                            String key = iter.next();
                            if (key.equalsIgnoreCase("chrTran")) {
                                if (!iter.hasNext()) {
                                    valuesBuiler.deleteCharAt(valuesBuiler.lastIndexOf(","));
                                }
                                continue;
                            }
                            Object tmp = jsonObject.opt(key);
                            if (tmp != null) {
                                valuesBuiler.append("'");
                                valuesBuiler.append(tmp.toString());
                                valuesBuiler.append("' AS " + key);


                            } else {

                                valuesBuiler.append("'' AS " + key);

                            }
                            valuesBuiler.append(iter.hasNext() ? "," : "");
                        }
                        valuesBuiler.append(m == ((b * BATCHSIZE) + intMaxRecords) - 1 ? "" : " UNION ALL ");
                    }
                    finalInsert.append("SELECT " + sbQuery2.toString() + " FROM(" + valuesBuiler + ") as res");
                    Log.e("FINAL_INSERT_QUERY", finalInsert.toString());

                    if (isTranTable) {
                        String[] s = new String[deleteValues.size()];
                        s = deleteValues.toArray(s);
                        db.delete(tableName, "varSync_Code=+?", s);
                    }
                    db.execSQL(finalInsert.toString());
                }
            }
            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            db.endTransaction();
        }

        return true;
    }*/

}
