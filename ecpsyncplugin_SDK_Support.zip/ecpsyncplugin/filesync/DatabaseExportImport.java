package ecp.vcs.com.ecpsyncplugin.filesync;

import android.util.Log;

import net.lingala.zip4j.core.ZipFile;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

class DatabaseExportImport {

    public String ExtractAllFile(String _zipFile, String _targetLocation,String zipPassword) {
        String done = "done";
        try {
            if (new File(_zipFile).exists()) {
                Log.e("_zipFile", "Path:: " + _zipFile);
                ZipFile zipFile = new ZipFile(_zipFile);
                if (zipFile.isEncrypted())
                    zipFile.setPassword(zipPassword);
                zipFile.extractAll(_targetLocation);

            } else {
                Log.e("zip file", "not found");
            }
        } catch (Exception e) {
            done = "";
            e.printStackTrace();
        }
        return done;
    }

    public byte[] getByteFromFile(String filePath) {
        InputStream is;
        ByteArrayOutputStream bos = null;
        try {
            File dbfile = new File(filePath);
            is = new BufferedInputStream(new FileInputStream(dbfile));
            bos = new ByteArrayOutputStream();
            while (is.available() > 0) {
                bos.write(is.read());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (bos != null) {
            return bos.toByteArray();
        } else {
            return null;
        }
    }
}
