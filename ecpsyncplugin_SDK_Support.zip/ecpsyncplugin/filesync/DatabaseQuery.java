package ecp.vcs.com.ecpsyncplugin.filesync;

class DatabaseQuery {

    // Table Names
    static final String TABLE_CPM_CUSTOMER_DISPATCH = "CPM_Customer_Dispatch";
    static final String TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS = "CPM_Customer_Dispatch_Product_Details";
    static final String TABLE_CPM_CUSTOMER_RECEIVE = "CPM_Customer_Receive";
    static final String TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS = "CPM_Customer_Receive_Product_Details";
    static final String TABLE_CPM_STRICKER_Details = "CPM_Sticker_Details";
    static final String TABLE_PRODUCT_SKU_MST = "Product_SKU_Mst";
    static final String TABLE_POLITICAL_GEOGRAPHY_LEVEL_COUNTRY_MST = "Political_Geography_Level_Country_Mst";
    static final String TABLE_POLITICAL_GEOGRAPHY_DETAILS = "Political_Geography_Details";
    static final String TABLE_CUSTOMER_TYPE_COUNTRY_MST = "Customer_Type_Country_Mst";
    static final String TABLE_PERSON_MST = "Person_Mst";
    static final String TABLE_CUSTOMER_PARTNER_MST = "Customer_Partner_Mst";
    static final String TABLE_CPM_CUSTOMER_STICKER_DAMAGE = "CPM_Customer_Sticker_Damage";
    static final String TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE = "CPM_Customer_Sticker_Damage_Remove";
    static final String TABLE_CPM_PALLET_MST = "CPM_Pallet_Mst";
    static final String TABLE_CPM_Customer_Sticker_Scrap = "CPM_Customer_Sticker_Scrap";
    static final String TABLE_CPM_Customer_Sticker_Consume = "CPM_Customer_Sticker_Consume";
    static final String TABLE_CPM_DAMAGE_TYPE = "CPM_Damage_Type";

    static final String TABLE_CPM_GENERAL_RECEIVE = "CPM_General_Receive";

    //Common Table in LAB & BASF-HK
    static final String TABLE_LOGIN_DETAILS = "LoginDetails";

    static final String TABLE_LOGIN_FORM_DETAILS = "LoginFormDetails";
    static final String TABLE_LOGIN_FAIL_ATTEMPT_DETAILS = "LoginFailAttempt_Details";

    //Table Name For LAB
    static final String TABLE_LAB_STORE = "LAB_Store";
    static final String TABLE_LAB_MATERIAL_ALLOCATION = "LAB_Material_Allocation";
    static final String TABLE_LAB_MATERIAL_RETURN = "LAB_Material_Return";
    static final String TABLE_LAB_CUSTOMER_DISPATCH = "LAB_Customer_Dispatch";
    static final String TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS = "LAB_Customer_Dispatch_Product_Details";
    static final String TABLE_LAB_DISPOSAL = "LAB_Disposal";
    static final String TABLE_LAB_STICKER_DETAILS = "LAB_Sticker_Details";




    //Common Table in LAB & BASF-HK
    static final String IFFCO_TABLE_CPM_CUSTOMER_DISPATCH = "CPM_CUSTOMER_DISPATCH";
    static final String IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK = "CPM_CUSTOMER_STICKER_BLOCK";
    static final String IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK_REMOVE = "CPM_CUSTOMER_STICKER_BLOCK_REMOVE";
    static final String IFFCO_TABLE_LOGIN_DETAILS = "LOGIN_DETAILS";
    static final String IFFCO_TABLE_LOGIN_FORM_DETAILS = "LOGIN_FORM_DETAILS";
    static final String IFFCO_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS = "LOGIN_FAIL_ATTEMPT_DETAILS";
    static final String IFFCO_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS = "CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS";
    static final String IFFCO_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS = "CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS";
    static final String IFFCO_TABLE_CPM_STRICKER_Details = "CPM_STICKER_DETAILS";
    static final String IFFCO_TABLE_CPM_SKU_STRICKER_Details = "CPM_SKU_STICKER_DETAILS";
    static final String IFFCO_TABLE_CPM_PALLET_MST = "CPM_PALLET_MST";
    static final String IFFCO_TABLE_PERSON_MST = "PERSON_MST";
    static final String IFFCO_TABLE_CUSTOMER_MST = "CUSTOMER_MST";
    static final String IFFCO_TABLE_CUSTOMER_TYPE_MST = "CUSTOMER_TYPE_MST";
    static final String IFFCO_TABLE_CPM_BLOCK_TYPE = "CPM_BLOCK_TYPE";
    static final String IFFCO_TABLE_PRODUCT_SKU_MST = "PRODUCT_SKU_MST";
    static final String IFFCO_TABLE_CROP_MST = "CROP_MST";
    static final String IFFCO_TABLE_SEASON_MST = "SEASON_MST";
    static final String IFFCO_TABLE_POLITICAL_GEOGRAPHY_DETAILS = "POLITICAL_GEOGRAPHY_DETAILS";
    static final String IFFCO_TABLE_POLITICAL_GEOGRAPHY_LEVEL_MST = "POLITICAL_GEOGRAPHY_LEVEL_MST";


}
