package ecp.vcs.com.ecpsyncplugin.filesync;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestTickle;
import com.android.volley.request.StringRequest;
import com.android.volley.toolbox.VolleyTickle;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import static ecp.vcs.com.ecpsyncplugin.filesync.FileSyncTask.EXTERNAL_STORAGE_APP_BACKUP_ROOT;
import static ecp.vcs.com.ecpsyncplugin.filesync.FileSyncTask.EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD;
import static ecp.vcs.com.ecpsyncplugin.filesync.FileSyncTask.EXTERNAL_STORAGE_APP_SYNC_ROOT;


public class LabFileSyncTask extends AsyncTask<Void, Void, Void> {

    private Context context;
    private FileSyncCallBack callBack;
    private String UserName, fk_EmpGlCode, ClientName, imei, version, packageName,
            uploadMethod, logUploadMethod, urlUpload;

    private int syncID;
    //private int lastUpdatedValue = 0;onFileSyncResponse
    //private boolean isAllProcessDone = false;
    //private int minimum = 0;
    //private int maximum = 0;

    private boolean syncStatus;
    private int syncCode;
    private String syncMessage;
    private String syncResMessage;
    private String dbPassword;
    private String isDbEncripted;

    private String dataDirPath;
    private String URLDownloadDB = "";
    private String msjSync = "Please wait while sync...";

    private Timer mTimer1;
    private Handler mTimerHandler = new Handler();
    private int mMin = 0;
    private int mMax = 0;

    public LabFileSyncTask(Context context, FileSyncCallBack callBack, String UserName, String fk_EmpGlCode, String ClientName, String imei, String version, String packageName, String uploadMethod, String logUploadMethod, String urlUpload, String databaseName, String dbPassword, String isDbEncripted) {
        this.context = context;
        this.callBack = callBack;
        this.UserName = UserName;
        this.fk_EmpGlCode = fk_EmpGlCode;
        this.ClientName = ClientName;
        this.imei = imei;
        this.version = version;
        this.packageName = packageName;
        this.uploadMethod = uploadMethod;
        this.logUploadMethod = logUploadMethod;
        this.urlUpload = urlUpload;
        this.isDbEncripted = isDbEncripted;
        this.dbPassword = dbPassword;
        //this.databaseName = databaseName;

        dataDirPath = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + databaseName;
    }

    private void stopTimer() {
        if (mTimer1 != null) {
            mMin = 0;
            mMax = 0;
            mTimer1.cancel();
            mTimer1.purge();
        }
    }

    private void startTimer() {
        mTimer1 = new Timer();
        //TODO
        //updateAutoProcessDetails(mMin);
        TimerTask mTt1 = new TimerTask() {
            public void run() {
                mTimerHandler.post(new Runnable() {
                    public void run() {
                        //TODO
                        if (mMin < mMax) {
                            mMin++;
                        }
                        //updateAutoProcessDetails(mMin);
                        callBack.onFileSyncResponse(1, "Update Count Auto", mMin);
                    }
                });
            }
        };

        mTimer1.schedule(mTt1, 1, 10000);
    }

    private void increaseTimmer(int min, int max) {
        stopTimer();
        mMin = min;
        mMax = max;
        startTimer();
    }

    @Override
    protected Void doInBackground(Void... voids) {
        FileSyncData(UserName, fk_EmpGlCode, ClientName, imei, version, packageName, uploadMethod, urlUpload, dbPassword);
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        Log.e("FILE SYNC", "@@@@@@@@ onPostExecute @@@@@@@@@@@@");
        //if (result != null && result.equalsIgnoreCase("done"))
        {
            if (!syncMessage.equalsIgnoreCase("done")) {
                syncResMessage = syncMessage;
            }
            if (syncCode == 200) {
                callBack.onFileSyncResponse(3, syncResMessage, 100);
                startIntentService("Y");
            } else {
                startIntentService("N");
            }

        }
        /*else {
            //callBack.onFileSyncResponse(2, "error", lastProgress);
        }*/
    }

    @Override
    protected void onCancelled(Void aVoid) {
        super.onCancelled(aVoid);
        Log.e("FILE SYNC", "@@@@@@@@ onCancelled @@@@@@@@@@@@");
        if (!syncMessage.equalsIgnoreCase("done")) {
            syncResMessage = syncMessage;
        }
        if (syncCode == 200) {
            callBack.onFileSyncResponse(3, syncResMessage, 100);
            startIntentService("Y");
        } else {
            startIntentService("N");
        }

    }

    @Override
    protected void onPreExecute() {
        // temp();

        callBack.onFileSyncResponse(1, msjSync, 1);
    }

    @Override
    protected void onProgressUpdate(Void... values) {
    }

    private void startIntentService(String status) {
        Log.e("DB", "=========startIntentService: =========" + status);
       /* appPrefs.setSyncId(syncID);
        appPrefs.setDeviceSyncStatus(status);
        appPrefs.setDeviceSyncJson(hashMap.toString());*/

        Intent vcsTimeIntent = new Intent(context, AppIdentifyService.class);
        vcsTimeIntent.putExtra("SyncId", syncID);
        vcsTimeIntent.putExtra("DeviceSyncStatus", status);
        vcsTimeIntent.putExtra("DeviceSyncJson", hashMap.toString());
        vcsTimeIntent.putExtra("PersonId", fk_EmpGlCode);
        vcsTimeIntent.putExtra("SubModuleName", ClientName);
        vcsTimeIntent.putExtra("DeviceId", imei);
        vcsTimeIntent.putExtra("Version", version);
        vcsTimeIntent.putExtra("APIToken", UserName);
        vcsTimeIntent.putExtra("BaseUrl", urlUpload);
        vcsTimeIntent.putExtra("logUploadMethod", logUploadMethod);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(vcsTimeIntent);
        } else {
            context.startService(vcsTimeIntent);
        }
    }

    private void FileSyncData(String UserName, String fk_EmpGlCode, String ClientName, String imei, String
            strVersion, String packageName, String uploadMethod, String urlUpload, String dbPassword) {
        Log.e("UserName", ":" + UserName);
        Log.e("fk_EmpGlCode", ":" + fk_EmpGlCode);
        Log.e("ClientName", ":" + ClientName);
        Log.e("imei", ":" + imei);
        Log.e("strVersion", ":" + strVersion);
        Log.e("packageName", ":" + packageName);
        Log.e("uploadMethod", ":" + uploadMethod);
        Log.e("urlUpload", ":" + urlUpload);

        SyncDB(version, context, dbPassword);
        Log.e("syncMessage", "" + syncMessage);
        //return syncMessage;
    }

    /*private void temp() {
        try {
            if (timer == null) {
                timer = new CountDownTimer(System.currentTimeMillis(), 2000) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                        if (isAllProcessDone) {
                            if (i >= 100) {
                                if (lastUpdatedValue >= 100) {
                                    Log.e("lastUpdatedValue", lastUpdatedValue + "");
                                    timer.onFinish();
                                    timer.cancel();

                                    //syncErrorBroadCast("Synchronization", syncMessage);
                                    callBack.onFileSyncResponse(2, syncMessage, syncCode);

                                } else {
                                    lastUpdatedValue = lastUpdatedValue + 3;
                                    changePercent(lastUpdatedValue);

                                }
                            }
                        } else {
                            if (i >= minimum && i <= maximum) {
                                i = i + 1;
                                if (i >= 100) {
                                    i = 100;
                                }
                            } else {
                                if (i <= maximum)
                                    i = minimum;
                            }
                            if (i < 100) {
                                changePercent(i);

                            }
                        }
                    }

                    @Override
                    public void onFinish() {
                        i = 0;
                        lastUpdatedValue = 0;
                    }
                };
                timer.start();
            }
        } catch (Exception e) {
            writeLog("SYNC_ERROR", e.getMessage());
            e.printStackTrace();
            if (timer != null) {
                i = 0;
                lastUpdatedValue = 0;
                timer.onFinish();
                timer.cancel();
            }
        }
    }*/

    /*private void startTimer(int min, int max) {
     *//*this.minimum = min;
        this.maximum = max;*//*

        //callBack.onFileSyncResponse(1, "Sync complete", randInt(min, max));
    }*/

    private void cancelTimer() {
        /*if (timer != null) {
            timer.cancel();
        }*/
    }

    /*private void changePercent(int percent) {
        percentProgress = percent;

        if (percent >= 100) {
            percent = 100;

            callBack.onFileSyncResponse(3, "Sync complete", percent);
        }
    }*/

    private void Progress(int min, int max) {
        callBack.onFileSyncResponse(1, msjSync, randInt(min, max));
    }

    private void ProgressDone() {
        if (!syncMessage.equalsIgnoreCase("done")) {
            syncResMessage = syncMessage;
        }
        callBack.onFileSyncResponse(3, syncResMessage, 100);
    }

    private void SyncDB(String version, Context context, String dbPassword) {
        writeLog("FB_SYNC_START", "");
        try {
            File DirDelete = new File("" + EXTERNAL_STORAGE_APP_SYNC_ROOT);
            if (DirDelete.exists() && !DirDelete.isDirectory()) {
                //noinspection ResultOfMethodCallIgnored
                DirDelete.delete();
            }
        } catch (Exception e) {
            writeLog("SYNC_ERROR", e.getMessage());
            e.printStackTrace();
        }

        String tempName = CommonFunctionLib.GetCurrentDate("ddMMyyyy_HHmmss") + "_" + version;
        Calendar calendar = Calendar.getInstance();
        int WDAY = calendar.get(Calendar.DAY_OF_WEEK);

        Progress(1, 6);

        String DB_PATH = EXTERNAL_STORAGE_APP_SYNC_ROOT + "/" + WDAY + "/" + tempName + "/";

        File fileMainDir = new File(DB_PATH);
        if (fileMainDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            fileMainDir.delete();
        }
        //noinspection ResultOfMethodCallIgnored
        fileMainDir.mkdirs();

        String fileLoginDetails$_1 = "LoginDetails$_1.txt";

        File dirLS = new File(fileMainDir, "LS");
        dirLS.mkdir();

        File dirLMA = new File(fileMainDir, "LMA");
        dirLMA.mkdir();

        File dirLMR = new File(fileMainDir, "LMR");
        dirLMR.mkdir();

        File dirLD = new File(fileMainDir, "LD");
        dirLD.mkdir();

        File dirLCD = new File(fileMainDir, "LCD");
        dirLCD.mkdir();

        File dirLCDPD = new File(fileMainDir, "LCDPD");
        dirLCDPD.mkdir();

        File dirLSD = new File(fileMainDir, "LSD");
        dirLSD.mkdir();

        DatabaseHelper db = new DatabaseHelper(dataDirPath);

        Progress(7, 10);

        generateTextFile(DB_PATH, fileLoginDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_DETAILS).toString());

        Progress(10, 12);

        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_STORE, 1000, 0, dirLS.getAbsolutePath());

        Progress(12, 15);

        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_MATERIAL_ALLOCATION, 1000, 0, dirLMA.getAbsolutePath());

        Progress(15, 18);

        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_MATERIAL_RETURN, 1000, 0, dirLMR.getAbsolutePath());
        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_DISPOSAL, 1000, 0, dirLD.getAbsolutePath());

        Progress(18, 20);

        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH, 1000, 0, dirLCD.getAbsolutePath());
        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS, 1000, 0, dirLCDPD.getAbsolutePath());

        Progress(20, 21);

        db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_STICKER_DETAILS, 1000, 0, dirLSD.getAbsolutePath());

        Progress(21, 22);

        writeLog("CREATE_ZIP_START", "");
        String zipFilePath = CreateZipFile(fileMainDir.getAbsolutePath(), fileMainDir.getName(), WDAY, dbPassword, isDbEncripted);
        writeLog("CREATE_ZIP_END", "");
        String size = checkFileZiseString(zipFilePath);
        writeLog("UPLOAD_ZIP_SIZE", size);
        Log.e("ZIP", zipFilePath);
        writeLog("UPLOAD_ZIP_START", "");

        increaseTimmer(23, 50);

        String strUploadMessage = UploadDatabaseFileZipOld(zipFilePath, fileMainDir.getName() + ".zip");


        stopTimer();

        if (strUploadMessage.equalsIgnoreCase("done")) {
            writeLog("UPLOAD_ZIP_END", "");
            //afterUpload(strUploadMessage, fileMainDir.getName() + ".zip", dbPassword);
            strUploadMessage = afterUploadDatabase(zipFilePath, fileMainDir.getName() + ".zip");

            /*Log.e("afterUploadDatabase", ":" + strUploadMessage);

            try {
                Thread.sleep(5000);
            } catch (Exception e) {
                e.printStackTrace();
            }

            Log.e("calling", "afterUpload");*/


        } else {
            syncStatus = false;
            if (strUploadMessage.equalsIgnoreCase("Session expired. Please try again")) {
                syncCode = 222;
            } else {
                syncCode = 103;
            }
            syncMessage = strUploadMessage;
            writeLog("UPLOAD_ZIP_END", strUploadMessage);
            whenAllProgressDone();
        }
    }

    static void generateTextFile(String root, String sFileName, String sBody) {
        try {
            writeLog("GENERATE_TXT_FILE_START", sFileName);
            File gpxfile = new File(root, sFileName);
            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.flush();
            writer.close();
            writeLog("GENERATE_TXT_FILE_END", sFileName);
        } catch (IOException e) {
            writeLog("GENERATE_TXT_FILE_EXCEPTION", sFileName);
            e.printStackTrace();
        }
    }

    private static String CreateZipFile(String FileName, String fZipName, int WDAY, String zipPassword, String isDbEncripted) {
        String DB_PATH = EXTERNAL_STORAGE_APP_SYNC_ROOT + "/" + WDAY + "/";
        File dbFile = new File(FileName);
        String zipFileName = DB_PATH + fZipName + ".zip";
        if (dbFile.exists()) {
            if (isDbEncripted.equalsIgnoreCase("true")) {
                zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName, fZipName, zipPassword);
            } else {
                zipFileName = AddFilesWithStandardZipEncryptionOld(dbFile, zipFileName);
            }
        } else {
            zipFileName = "";
        }
        return zipFileName;
    }

    private static String AddFilesWithStandardZipEncryptionOld(File dbFile, String zipFilePath) {
        String done;
        try {
            ZipFile zipFile = new ZipFile(zipFilePath);
            //ArrayList filesToAdd = new ArrayList();
            //filesToAdd.add(dbFile);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            zipFile.addFolder(dbFile, parameters);
            done = zipFilePath;
        } catch (Exception e) {
            writeLog("SYNC_ERROR", e.getMessage());
            e.printStackTrace();
            done = "";
        }
        return done;
    }

    private static String AddFilesWithStandardZipEncryption(File dbFile, String zipFilePath, String fZipName, String zipPassword) {
        String done;
        try {

            //listAllFiles(dbFile);
            // Initiate ZipFile object with the path/name of the zip file.
            // Zip file may not necessarily exist. If zip file exists, then
            // all these files are added to the zip file. If zip file does not
            // exist, then a new zip file is created with the files mentioned
            ZipFile zipFile = new ZipFile(zipFilePath);

            //zipFile.setPassword(DatabaseHelper.DBPs);
            // Build the list of files to be added in the array list
            // Objects of type File have to be added to the ArrayList
            //ArrayList filesToAdd = new ArrayList();
            //noinspection unchecked
            //filesToAdd.add(dbFile);
            //filesToAdd.add(new File("c:\\ZipTest\\myvideo.avi"));
            //filesToAdd.add(new File("c:\\ZipTest\\mysong.mp3"));
            // Initiate Zip Parameters which define various properties such
            // as compression method, etc. More parameters are explained in other
            // examples
            // set compression method to deflate
            // compression
            // Set the compression level. This value has to be in between 0 to 9
            // Several predefined compression levels are available
            // DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
            // DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
            // DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
            // DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
            // DEFLATE_LEVEL_ULTRA - Highest compression level but low speed

            // Now add files to the zip file
            // Note: To add a single file, the method addFile can be used
            // Note: If the zip file already exists and if this zip file is a split file
            // then this method throws an exception as Zip Format Specification does not
            // allow updating split zip files
            //parameters.setRootFolderInZip(fZipName);


            /*zipFile.addFolder(dbFile, parameters);*//*

            //File targetFile = new File(dbFile);

            /*for (File f : dbFile.listFiles()) {
                if (f.isFile()) {
                    parameters.setFileNameInZip(f.getName());
                    zipFile.addFile(dbFile, parameters);
                } else if (f.isDirectory()) {
                    parameters.setFileNameInZip(f.getName());
                    zipFile.addFolder(dbFile, parameters);
                }
            }*/

            listAllFiles(dbFile, zipFile, zipPassword);
            Log.e("all files added", "loop end");
            Thread.sleep(5000);
            Log.e("all files added", "thread end");
            done = zipFilePath;
        } catch (Exception e) {
            e.printStackTrace();
            writeLog("SYNC_ERROR", e.getMessage());
            done = "";
        }
        return done;
    }

    static void listAllFiles(File folder, ZipFile zipFile, String zipPassword) {
        try {
            System.out.println("In listAllfiles(File) method");
            File[] fileNames = folder.listFiles();
            for (File file : fileNames) {
                ZipParameters parameters = new ZipParameters();
                parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
                parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_FAST);
                parameters.setEncryptFiles(true);
                parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
                parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
                parameters.setPassword(zipPassword);
                parameters.setReadHiddenFiles(true);

                // if directory call the same method again
                if (file.isDirectory()) {
                    //parameters.setRootFolderInZip(file.getName());
                    //parameters.setSourceExternalStream(true);
                    //parameters.setIncludeRootFolder(true);
                    //zipFile.addFolder(file, parameters);
                    Log.e("folder Name", "" + file.getName());
                    listAllFiles(file, zipFile, zipPassword);
                } else {
                    parameters.setSourceExternalStream(true);
                    parameters.setFileNameInZip(file.getName());
                    zipFile.addFile(file, parameters);
                    Log.e("file Name", "" + file.getName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String UploadDatabaseFileZipOld(String filePath, String fileName) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String strSyncMessage;

        try {

            byte[] fByte = null;
            String encodeDb = "";
            DatabaseExportImport databaseExportImport = new DatabaseExportImport();
            try {
                fByte = databaseExportImport.getByteFromFile(filePath);
                if (fByte != null) {
                    encodeDb = Base64.encodeBytes(fByte);
                }
            } catch (Exception e) {
                writeLog("SYNC_ERROR", e.getMessage());
                e.printStackTrace();
                try {
                    fByte = databaseExportImport.getByteFromFile(filePath);
                    if (fByte != null) {
                        encodeDb = Base64.encodeBytes(fByte);
                    }
                } catch (Exception e1) {
                    writeLog("SYNC_ERROR", e1.getMessage());
                    e1.printStackTrace();
                }
                //writeLog("SYNC_ERROR", e.getMessage());
            }

            //Progress(26, 60);

            if (fByte != null && !encodeDb.equalsIgnoreCase("")) {
                /*randomNo = randInt(27, 30);
                startTimer(27, 30);*/

                // VolleyLog.DEBUG = true;

                final Map<String, String> parameterPost = new HashMap<>();
                parameterPost.clear();
                parameterPost.put("FileArray", encodeDb);
                parameterPost.put("FileName", fileName);
                parameterPost.put("DeviceId", imei);
                parameterPost.put("PersonId", fk_EmpGlCode);
                parameterPost.put("Version", version);
                parameterPost.put("SubModuleName", ClientName);
                parameterPost.put("APIToken", UserName);
                parameterPost.put("Action", "UPLOAD");
                parameterPost.put("SyncId", "0");

                /*parameterPost.put("DeviceId", "000000000000000");
                parameterPost.put("PersonId", "3");
                parameterPost.put("Version", version);
                parameterPost.put("SubModuleName", ClientName);
                parameterPost.put("APIToken", "D847EDB6-E1E5-4D0F-AA29-143CA21CA571");*/


                RequestTickle mRequestTickle = VolleyTickle.newRequestTickle(context);

                //private static final int id_new = 1013;
                //private static int percentProgress = 0;
                // Binder given to clients
                //private boolean isActivityRunning = true;
                //private String syncStageStatus = "P";
                //Timer t;
                StringRequest stringRequest = new StringRequest(Request.Method.POST, urlUpload + "/" + uploadMethod, null,
                        null) {
                    protected Map<String, String> getParams() {
                        if (parameterPost.size() > 0) {
                            return parameterPost;
                        } else {
                            return null;
                        }
                    }
                };

                int DEFAULT_TIMEOUT_MS = 2700000;
                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        DEFAULT_TIMEOUT_MS,
                        0,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                mRequestTickle.add(stringRequest);
                NetworkResponse response = mRequestTickle.start();

                Log.e("jsonUploadDownloadDB", "-->" + response.statusCode);
                String jsonUploadDownloadDB;
                if (response.statusCode == 200) {

                    jsonUploadDownloadDB = VolleyTickle.parseResponse(response);

                    Progress(61, 65);

                    Log.e("download ", "link : " + jsonUploadDownloadDB);
                    JSONObject json = new JSONObject(jsonUploadDownloadDB);
                    syncResMessage = json.getString("Message");
                    Log.e("FileSync", "===========UploadDatabaseFileZipOld: ============" + json.toString());
                    String strValidSync = json.optString("Status");
                    //startTimer(35, 40);
                    if (strValidSync.equalsIgnoreCase("1")) {
                        strSyncMessage = "done";
                        writeLog("UPLOAD_ZIP_API_SUCCESS", "");
                        syncMessage = json.optString("Message");
                        URLDownloadDB = json.optString("Response");
                    } else if (strValidSync.equalsIgnoreCase("2")) {
                        strSyncMessage = "Session expired. Please try again";
                        syncMessage = strSyncMessage;
                        writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                    } else {
                        strSyncMessage = json.optString("Message");
                        syncMessage = strSyncMessage;
                        writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                    }

                    try {
                        String syncId = json.optString("SyncId");
                        syncID = syncId != null ? Integer.parseInt(syncId) : 0;

                        Log.e("syncID", "syncID:" + syncID);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //appPrefs.setSyncCode(Integer);
                } else {
                    //strSyncMessage = "File is not encoded error please try again.";
                    strSyncMessage = "Responce code error please try again.";
                    writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                }
            } else {
                strSyncMessage = "File is not encoded error please try again.";
                writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
            }
            writeLog("UPLOAD_ZIP_API_END", "");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = CommonFunctionLib.checkErrorReset(error);
            strSyncMessage = "" + error;
            writeLog("UPLOAD_ZIP_API_EXCEPTION", strSyncMessage);
        }
        return strSyncMessage;
    }

    private String afterUploadDatabase(String filePath, String fileName) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String strSyncMessage;

        try {

            //byte[] fByte = null;
            //String encodeDb = "";
            //DatabaseExportImport databaseExportImport = new DatabaseExportImport();
            /*try {
                fByte = databaseExportImport.getByteFromFile(filePath);
                if (fByte != null) {
                    encodeDb = Base64.encodeBytes(fByte);
                }
            } catch (Exception e) {
                writeLog("SYNC_ERROR", e.getMessage());
                e.printStackTrace();
                try {
                    fByte = databaseExportImport.getByteFromFile(filePath);
                    if (fByte != null) {
                        encodeDb = Base64.encodeBytes(fByte);
                    }
                } catch (Exception e1) {
                    writeLog("SYNC_ERROR", e1.getMessage());
                    e1.printStackTrace();
                }
                //writeLog("SYNC_ERROR", e.getMessage());
            }*/

            //Progress(26, 60);

            //if (fByte != null && !encodeDb.equalsIgnoreCase("")) {
                /*randomNo = randInt(27, 30);
                startTimer(27, 30);*/

            // VolleyLog.DEBUG = true;

            final Map<String, String> parameterPost = new HashMap<>();
            parameterPost.clear();
            parameterPost.put("FileArray", "");
            parameterPost.put("FileName", fileName);
            parameterPost.put("DeviceId", imei);
            parameterPost.put("PersonId", fk_EmpGlCode);
            parameterPost.put("Version", version);
            parameterPost.put("SubModuleName", ClientName);
            parameterPost.put("APIToken", UserName);
            parameterPost.put("Action", "PROCESS");
            parameterPost.put("SyncId", "" + syncID);

                /*parameterPost.put("DeviceId", "000000000000000");
                parameterPost.put("PersonId", "3");
                parameterPost.put("Version", version);
                parameterPost.put("SubModuleName", ClientName);
                parameterPost.put("APIToken", "D847EDB6-E1E5-4D0F-AA29-143CA21CA571");*/


            RequestTickle mRequestTickle = VolleyTickle.newRequestTickle(context);

            //private static final int id_new = 1013;
            //private static int percentProgress = 0;
            // Binder given to clients
            //private boolean isActivityRunning = true;
            //private String syncStageStatus = "P";
            //Timer t;
            StringRequest stringRequest = new StringRequest(Request.Method.POST, urlUpload + "/" + uploadMethod, null,
                    null) {
                protected Map<String, String> getParams() {
                    if (parameterPost.size() > 0) {
                        return parameterPost;
                    } else {
                        return null;
                    }
                }
            };

            int DEFAULT_TIMEOUT_MS = 2700000;
            stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                    DEFAULT_TIMEOUT_MS,
                    0,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            mRequestTickle.add(stringRequest);
            NetworkResponse response = mRequestTickle.start();

            Log.e("jsonUploadDownloadDB", "-->" + response.statusCode);
            String jsonUploadDownloadDB;
            if (response.statusCode == 200) {

                jsonUploadDownloadDB = VolleyTickle.parseResponse(response);

                Progress(61, 65);

                Log.e("download ", "link : " + jsonUploadDownloadDB);
                JSONObject json = new JSONObject(jsonUploadDownloadDB);
                syncResMessage = json.getString("Message");
                Log.e("FileSync", "===========UploadDatabaseFileZipOld: ============" + json.toString());
                String strValidSync = json.optString("Status");
                //startTimer(35, 40);
                if (strValidSync.equalsIgnoreCase("1")) {
                    strSyncMessage = "done";
                    writeLog("UPLOAD_ZIP_API_SUCCESS", "");
                    syncMessage = json.optString("Message");
                    URLDownloadDB = json.optString("Response");
                } else if (strValidSync.equalsIgnoreCase("2")) {
                    strSyncMessage = "Session expired. Please try again";
                    syncMessage = strSyncMessage;
                    writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                } else {
                    strSyncMessage = json.optString("Message");
                    syncMessage = strSyncMessage;
                    writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                }

                try {
                    String syncId = json.optString("SyncId");
                    syncID = syncId != null ? Integer.parseInt(syncId) : 0;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                //appPrefs.setSyncCode(Integer);

                afterUpload(strSyncMessage, fileName, dbPassword);
            } else {
                //strSyncMessage = "File is not encoded error please try again.";
                strSyncMessage = "Responce code error please try again.";
                writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
            }
            /*} else {
                strSyncMessage = "File is not encoded error please try again.";
                writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
            }*/
            writeLog("UPLOAD_ZIP_API_END", "");
        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = CommonFunctionLib.checkErrorReset(error);
            strSyncMessage = "" + error;
            writeLog("UPLOAD_ZIP_API_EXCEPTION", strSyncMessage);
        }
        return strSyncMessage;
    }

    private void afterUpload(String strUploadMessage, String zipName, String zipPassword) {
        if (strUploadMessage.equalsIgnoreCase("done")) {
            //startTimer(40, 45);
            String DownloadURL = URLDownloadDB;
            if (DownloadURL.trim().length() > 0) {
                //startTimer(45, 50);
                writeLog("DOWNLOAD_DB_START", "");
                increaseTimmer(50, 70);
                String strDBMessage = DownloadDBFromUrlZip(DownloadURL, zipName, zipPassword);//, context, databaseName
                writeLog("DOWNLOAD_DB_END", "");
                stopTimer();

                if (strDBMessage.equals("Done")) {
                    Progress(70, 85);
                    //File directory = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, "10102018_162249_SSC");
                    writeLog("INSERT_DATA_TO_DB_START", "");
                    File directory = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, zipName.replaceAll(".zip", ""));

                    File[] files = directory.listFiles();

                    DatabaseHelper db = new DatabaseHelper(dataDirPath);
                    db.open().beginTransaction();
                    db.open().delete(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                    db.open().setTransactionSuccessful();
                    db.open().endTransaction();
                    for (File f : files) {
                        boolean status = true;
                        if (f.isFile() && f.getPath().endsWith(".txt") && f.getName().contains("$")) {
                            status = UpdateDBDataFromFile(db, f);
                        } else if (f.isDirectory()) {
                            File[] fFolders = f.listFiles();
                            for (File fSt : fFolders) {
                                if (fSt.isFile() && fSt.getPath().endsWith(".txt") && fSt.getName().contains("$")) {
                                    status = UpdateDBDataFromFile(db, fSt);
                                    //break;
                                }
                            }
                        }
                        if (!status) {
                            syncStatus = false;
                            syncCode = 105;
                            syncMessage = "Response data file not proper, Please re-sync.";
                            whenAllProgressDone();
                            break;
                        }
                    }

                    writeLog("INSERT_DATA_TO_DB_END", "");
                    writeLog("SYNC_END", "");
                    //private CountDownTimer timer;
                    //int i = 99;
                    Progress(86, 97);
                    //isAllProcessDone = true;
                    //lastUpdatedValue = i;
                    //i = 100;
                    syncCode = 200;
                    syncMessage = "done";

                    //changePercent(i);

                    try {
                        File fileMainDir = new File(EXTERNAL_STORAGE_APP_BACKUP_ROOT(context));
                        deleteRecursive(fileMainDir);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    ProgressDone();

                } else {
                    writeLog("SYNC_ERROR", "Database corrupted.");
                    cancelTimer();
                    //syncStageStatus = "F";
                    syncStatus = false;
                    syncCode = 105;
                    syncMessage = "Database corrupted please re-sync.";
                    whenAllProgressDone();
                }
            } else {
                writeLog("SYNC_ERROR", "Database download URL not found.");
                cancelTimer();
                //syncStageStatus = "F";
                syncStatus = false;
                syncCode = 104;
                syncMessage = "Database download URL not found.";
                whenAllProgressDone();
            }
        } else {
            writeLog("SYNC_ERROR", "Database download URL not found.");
            cancelTimer();
            //syncStageStatus = "F";
            syncStatus = false;
            syncCode = 104;
            syncMessage = "Database URL not found.";
            whenAllProgressDone();
        }

        //whenAllProgressDone();
    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);
        //noinspection ResultOfMethodCallIgnored
        fileOrDirectory.delete();
    }

    private boolean UpdateDBDataFromFile(DatabaseHelper db, File f) {
        try {
            String filename = f.getName();
            //Log.e("filename","======filename====="+filename);
            String tablename = filename.substring(0, filename.lastIndexOf("$"));
            if (filename.contains("\\")) {
                tablename = filename.substring(filename.lastIndexOf("\\") + 1, filename.lastIndexOf("$"));
            }

            StringBuilder text = new StringBuilder();

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
            }
            br.close();

            JSONArray jsonArray = new JSONArray(text.toString());

            //Log.e("jsonArray", "======jsonArray======" + jsonArray.toString());
            deleteRecordForViolation(db, jsonArray, tablename);

            return db.insertRecordDynamicForLAB(tablename, jsonArray,null);
//            return db.insertRecordDynamicUsingContentValues(tablename, jsonArray);
        } catch (Exception e) {
            e.printStackTrace();
            writeLog("SYNC_ERROR", e.getMessage());
        }
        return false;
    }

    private void deleteRecordForViolation(DatabaseHelper db1, JSONArray jsonArray, String tableName) {

        SQLiteDatabase db = db1.open();

        try {

            db.beginTransaction();
            StringBuilder initGlCodes = new StringBuilder();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                if (initGlCodes.length() == 0) {
                    initGlCodes = new StringBuilder(object.getString("intGlCode"));
                } else {
                    initGlCodes.append(",").append(object.getString("intGlCode"));
                }
            }
            Log.e("INITGLCODE", "====tableName====" + tableName);
            Log.e("INITGLCODE", "====initGlCodes====" + initGlCodes);
            if (initGlCodes.length() > 0) {
                String selectQuery = "SELECT intGlCode FROM " + tableName + "  WHERE intGlCode IN (" + initGlCodes + ")";
                Log.e("INITGLCODE", "====selectQuery====" + selectQuery);
                Cursor c = db.rawQuery(selectQuery, null);
                // looping through all rows and adding to list
                try {
                    if (c.getCount() > 0) {
                        Log.e("INITGLCODE", "====tableName====" + tableName);
                        String deleteQuery = "DELETE FROM  " + tableName + "  WHERE intGlCode IN (" + initGlCodes + ")";
                        Log.e("INITGLCODE", "====deleteQuery====" + deleteQuery);
                        db.execSQL(deleteQuery);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    c.close();
                }
            }

            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.endTransaction();
        }
    }

    private String DownloadDBFromUrlZip(String DownloadUrl, String ZipfileName, String zipPassword) {
        String strSyncMessage = "Done";
        try {
            File downloadDB = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD);
            if (!downloadDB.exists())
                //noinspection ResultOfMethodCallIgnored
                downloadDB.mkdirs();

            //startTimer(50, 60);

            File file = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, ZipfileName);

            final int BUFFER_SIZE = 3 * 1024;
            URL url = new URL(DownloadUrl);

            URLConnection uCon = url.openConnection();
            //uCon.setConnectTimeout(120000);
            uCon.setConnectTimeout(2700000);
            InputStream downloadInputStream = uCon.getInputStream();
            //int fileLength = ucon.getContentLength();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(downloadInputStream, BUFFER_SIZE);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] byteBuffer = new byte[BUFFER_SIZE];
            int current = 0;

            //startTimer(65, 70);

            while (current != -1) {
                fileOutputStream.write(byteBuffer, 0, current);
                current = bufferedInputStream.read(byteBuffer, 0, BUFFER_SIZE);
            }

            fileOutputStream.flush();
            fileOutputStream.close();
            downloadInputStream.close();

            //startTimer(71, 73);

        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = CommonFunctionLib.checkErrorReset(error);
            strSyncMessage = "104: " + error;
            writeLog("DOWNLOAD_DB_EXCEPTION", strSyncMessage);
        }

        //startTimer(74, 78);

        if (strSyncMessage.equals("Done")) {
            strSyncMessage = ExtractDownlodedFile(ZipfileName, strSyncMessage, zipPassword);
        }
        return strSyncMessage;
    }

    private String ExtractDownlodedFile(String ZipfileName, String strSyncMessage, String zipPassword) {
        String zipFile = EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD + "/" + ZipfileName;
        DatabaseExportImport databaseExportImport = new DatabaseExportImport();
        String zipFolder = ZipfileName.replaceAll(".zip", "");
        if (!databaseExportImport.ExtractAllFile(zipFile, "" + EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD + "/" + zipFolder, zipPassword)
                .equalsIgnoreCase("Done")) {
            strSyncMessage = "105:";
        }
        return strSyncMessage;
    }

    private void sendError() {
        callBack.onFileSyncResponse(2, String.valueOf(syncCode), 0);
    }

    private void whenAllProgressDone() {
        Log.e("FILE SYNC", "===========whenAllProgressDone: ========");
        if (syncStatus) {
            writeLog("SYNC_SUCCESS", "");
            /*String SyncComplateDate = Utils.getCurrentDateTimeFormated();
            ECPSharedPrefrances ecpSharedPrefrances = new ECPSharedPrefrances(this, this.getPackageName());
            ecpSharedPrefrances.setSharedPreferences(Constant.AUTO_SYNC_DATE, SyncComplateDate);*/
        } else {
            //syncErrorBroadCast("Sync Failed", "Sync not completed successfully please try again.");
            //callBack.onFileSyncResponse(2, "Sync not completed successfully please try again.", syncCode);
            sendError();
            cancelTimer();
            writeLog("SYNC_FAIL", "Sync not completed successfully.");
        }
    }

    private static final JSONObject hashMap = new JSONObject();

    private static void writeLog(String key, String value) {
        try {
            hashMap.put(key, value + " Date Time:-" + getCurrentDateTimeFormated());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static String getCurrentDateTimeFormated() {
        String date1 = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            date1 = format.format(Calendar.getInstance().getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date1;
    }

    private String checkFileZiseString(String path) {
        String isCompress;
        File f = new File(path);
        long totalLength = f.length();
        String sizeMB = CommonFunctionLib.size(totalLength);
        Log.e("sizeMB", "" + sizeMB);
        isCompress = sizeMB;
        return isCompress;
    }

    private int randInt(int min, int max) {

        // NOTE: This will (intentionally) not run as written so that folks
        // copy-pasting have to think about how to initialize their
        // Random instance.  Initialization of the Random instance is outside
        // the main scope of the question, but some decent options are to have
        // a field that is initialized once and then re-used as needed or to
        // use ThreadLocalRandom (if using at least Java 1.7).
        //
        // In particular, do NOT do 'Random rand = new Random()' here or you
        // will get not very good / not very random results.
        Random rand = new Random();
        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        return rand.nextInt((max - min) + 1) + min;
    }

}