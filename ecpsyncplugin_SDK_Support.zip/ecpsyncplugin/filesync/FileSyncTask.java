package ecp.vcs.com.ecpsyncplugin.filesync;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestTickle;
import com.android.volley.Response;
import com.android.volley.error.AuthFailureError;
import com.android.volley.error.NetworkError;
import com.android.volley.error.NoConnectionError;
import com.android.volley.error.ParseError;
import com.android.volley.error.ServerError;
import com.android.volley.error.TimeoutError;
import com.android.volley.error.VolleyError;
import com.android.volley.request.JsonObjectRequest;
import com.android.volley.request.JsonRequest;
import com.android.volley.request.StringRequest;
import com.android.volley.toolbox.VolleyTickle;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import ecp.vcs.com.ecpsyncplugin.Utils;
import ecp.vcs.com.ecpsyncplugin.dbSync.BaseTimmerClass;
import ecp.vcs.com.ecpsyncplugin.dbSync.SyncData;


public class FileSyncTask extends BaseTimmerClass {

    private Context context;
    private FileSyncCallBack callBack;
    private String UserName, fk_EmpGlCode, ClientName, imei, version, packageName,
            uploadMethod, logUploadMethod, urlUpload, customerID;

    //private static final String TAG = "FileSyncronizationService";
    //private static final int id = 1012;
    //public static final String EXTERNAL_STORAGE_APP_BACKUP_ROOT = "" + Environment.getExternalStorageDirectory() +
    //  "/basfsync";
    public static String EXTERNAL_STORAGE_APP_BACKUP_ROOT(Context context) {
        return
                context.getFilesDir().getAbsolutePath() +
                        "/basfsync";
    }

    public static String EXTERNAL_STORAGE_APP_SYNC_ROOT;
    public static String EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD;

    private int syncID;
    //private int lastUpdatedValue = 0;onFileSyncResponse
    //private boolean isAllProcessDone = false;
    //private int minimum = 0;
    //private int maximum = 0;

    private int syncStatus;
    private int syncCode;
    private String syncMessage;
    private String syncResMessage;
    private String dbPassword;
    private String isDbEncripted;
    private String fkCustomerGlCode;
    private String DeviceSyncStatus;
    private String CustomerCode;
    private String SystemName;
    private String LastSyncDate;
    private String ServerSyncId;
    private String serviceAPIKe;

    private String dataDirPath;
    private String URLDownloadDB = "";
    private String msjSync = "Please wait while sync...";

//    private Timer mTimer1;
//    private TimerTask mTt1;
//    private Handler mTimerHandler;
//    private int mMin = 0;
//    private int mMax = 0;

    JSONObject requestJSON;
    JSONObject syncJSON;

    String packageNameValue = "";

    public FileSyncTask(Context context, FileSyncCallBack callBack, String UserName,
                        String fk_EmpGlCode, String ClientName, String imei, String version,
                        String packageName, String uploadMethod, String logUploadMethod,
                        String urlUpload, String databaseName, String dbPassword, String isDbEncripted,
                        String fkCustomerGlCode, String DeviceSyncStatus, String CustomerCode,
                        String SystemName, String LastSyncDate, String ServerSyncId, String serviceAPIKe) {
        this.context = context;
        this.callBack = callBack;
        this.UserName = UserName;
        this.fk_EmpGlCode = fk_EmpGlCode;
        this.ClientName = ClientName;
        this.imei = imei;
        this.version = version;
        this.packageName = packageName;
        this.uploadMethod = uploadMethod;
        this.logUploadMethod = logUploadMethod;
        this.urlUpload = urlUpload;
        this.isDbEncripted = isDbEncripted;
        this.dbPassword = dbPassword;
        this.fkCustomerGlCode = fkCustomerGlCode;
        this.DeviceSyncStatus = DeviceSyncStatus;
        this.CustomerCode = CustomerCode;
        this.SystemName = SystemName;
        this.LastSyncDate = LastSyncDate;
        this.ServerSyncId = ServerSyncId;
        this.serviceAPIKe = serviceAPIKe;
        customerID = fkCustomerGlCode;
        //this.databaseName = databaseName;


        /*EXTERNAL_STORAGE_APP_SYNC_ROOT = "" + Environment.getExternalStorageDirectory() +
                "/basfsync/" + packageName + "/SyncBackup";
        EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD = "" + Environment.getExternalStorageDirectory() +
                "/basfsync/" + packageName + "/SyncDownload";*/

        EXTERNAL_STORAGE_APP_SYNC_ROOT = "" + context.getFilesDir().getAbsolutePath() +
                "/basfsync/" + packageName + "/SyncBackup";
        EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD = "" + context.getFilesDir().getAbsolutePath() +
                "/basfsync/" + packageName + "/SyncDownload";

        packageNameValue = packageName;

        dataDirPath = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + databaseName;

        requestJSON = new JSONObject();
        syncJSON = new JSONObject();

    }

    public void startSyncDataFile() {
        new LongOperation().execute();
    }

    @Override
    public void updateAutoProcessDetails(int progress) {
        callBack.onFileSyncResponse(1, "Update Count Auto", progress);
    }

    /*protected void stopTimer() {
        if (mTimer1 != null) {
            mMin = 0;
            mMax = 0;
            mTimer1.cancel();
            mTimer1.purge();
        }
    }

    protected void startTimer() {
        mTimer1 = new Timer();
        mTt1 = new TimerTask() {
            public void run() {
                mTimerHandler.post(new Runnable() {
                    public void run() {
                        if (mMin < mMax) {
                            mMin++;
                        }
                        //updateAutoProcessDetails(mMin);
                        callBack.onFileSyncResponse(1, "Update Count Auto", mMin);
                    }
                });
            }
        };

        mTimer1.schedule(mTt1, 1, 10000);
    }

    protected void increaseTimmer(int min, int max) {
        stopTimer();
        mMin = min;
        mMax = max;
        startTimer();
    }*/

    private class LongOperation extends AsyncTask<Void, Void, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            FileSyncData(UserName, fk_EmpGlCode, ClientName, imei, version, packageName, uploadMethod, urlUpload, dbPassword);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Log.e("FILE SYNC", "@@@@@@@@ onPostExecute @@@@@@@@@@@@");
            //if (result != null && result.equalsIgnoreCase("done"))
//        {
            if (!syncMessage.equalsIgnoreCase("done")) {
                syncResMessage = syncMessage;
            }
            if (syncCode == 200) {
                syncStatus = 1;
                //Progress(100,100);
                callBack.onFileSyncResponse(3, syncResMessage, 100);
                startIntentService("Y");
            } else {
                startIntentService("N");
            }

//        }
        /*else {
            //callBack.onFileSyncResponse(2, "error", lastProgress);
        }*/
        }

        @Override
        protected void onCancelled(Void aVoid) {
            super.onCancelled(aVoid);
            Log.e("FILE SYNC", "@@@@@@@@ onCancelled @@@@@@@@@@@@");
            if (!syncMessage.equalsIgnoreCase("done")) {
                syncResMessage = syncMessage;
            }
            if (syncCode == 200) {
                syncStatus = 1;
                callBack.onFileSyncResponse(3, syncResMessage, 100);
                startIntentService("Y");
            } else {
                startIntentService("N");
            }
        }

        @Override
        protected void onPreExecute() {
            // temp();
//        stopTimer();
//        mTimerHandler = new Handler();
//        mMin = 0;
//        mMax = 0;
//        Progress(1,1);
            callBack.onFileSyncResponse(1, msjSync, 1);
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private void startIntentService(String status) {
        Log.e("DB", "=========startIntentService: =========" + status);

        String jsonFull = "{\"Sync_Log\":[" + requestJSON.toString() + "]}";

        Intent vcsTimeIntent = new Intent(context, AppIdentifyService.class);
        vcsTimeIntent.putExtra("SyncId", syncID);
        vcsTimeIntent.putExtra("DeviceSyncStatus", status);
        vcsTimeIntent.putExtra("DeviceSyncJson", syncJSON.toString());
        vcsTimeIntent.putExtra("PersonId", fk_EmpGlCode);
        vcsTimeIntent.putExtra("SubModuleName", ClientName);
        vcsTimeIntent.putExtra("DeviceId", imei);
        vcsTimeIntent.putExtra("Version", version);
        vcsTimeIntent.putExtra("APIToken", UserName);
        vcsTimeIntent.putExtra("BaseUrl", urlUpload);
        vcsTimeIntent.putExtra("logUploadMethod", logUploadMethod);
        vcsTimeIntent.putExtra("SyncType", "F");
        vcsTimeIntent.putExtra("SyncLogJson", jsonFull);
        vcsTimeIntent.putExtra("ExtraFields", "");
        vcsTimeIntent.putExtra("CustomerID", customerID.isEmpty() ? '0' : customerID);
        vcsTimeIntent.putExtra("packageName", packageName);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(vcsTimeIntent);
        } else {
            context.startService(vcsTimeIntent);
        }
    }

    private void FileSyncData(String UserName, String fk_EmpGlCode, String ClientName, String imei, String
            strVersion, String packageName, String uploadMethod, String urlUpload, String dbPassword) {
        Log.e("UserName", ":" + UserName);
        Log.e("fk_EmpGlCode", ":" + fk_EmpGlCode);
        Log.e("ClientName", ":" + ClientName);
        Log.e("imei", ":" + imei);
        Log.e("strVersion", ":" + strVersion);
        Log.e("packageName", ":" + packageName);
        Log.e("uploadMethod", ":" + uploadMethod);
        Log.e("urlUpload", ":" + urlUpload);

        SyncDB(version, context, dbPassword);
        Log.e("syncMessage", "" + syncMessage);
        //return syncMessage;
    }

    private void cancelTimer() {

    }

    private void Progress(int min, int max) {
        int mMin = 0;
        int mMax = 0;
        Log.e("isProgress","==isProgress=="+isProgress);
        Log.e("mMin","==mMin=="+min);
        Log.e("mMax","==mMax=="+max);
        if(isProgress && max > 45){
            if(isProgress) {
                mMin = 35;
                mMax = 45;
            }
        } else if(isCheckDownload && max > 60){
            if(isCheckDownload) {
                mMin = 45;
                mMax = 60;
            }
        } else {
            mMin = min;
            mMax = max;
        }
        callBack.onFileSyncResponse(1, msjSync, randInt(mMin, mMax));
    }

    private void ProgressDone() {
        if (!syncMessage.equalsIgnoreCase("done")) {
            syncResMessage = syncMessage;
        }
        callBack.onFileSyncResponse(3, syncResMessage, 100);
    }

    @SuppressWarnings("ResultOfMethodCallIgnored")
    private void SyncDB(String version, Context context, String dbPassword) {
        writeLog("FB_SYNC_START", "");

        Utils.writeJSONFile(requestJSON, "SYNC_START", Utils.getCurrentDateTime());

        try {
            File DirDelete = new File("" + EXTERNAL_STORAGE_APP_SYNC_ROOT);
            if (DirDelete.exists() && DirDelete.isDirectory()) {
                //noinspection ResultOfMethodCallIgnored
                //DirDelete.delete();
                Utils.DeleteRecursive(DirDelete);
            }
        } catch (Exception e) {
            writeLog("SYNC_ERROR", e.getMessage());
            e.printStackTrace();
        }

        String tempName = CommonFunctionLib.GetCurrentDate("ddMMyyyy_HHmmss") + "_" + version;
        Calendar calendar = Calendar.getInstance();
        int WDAY = calendar.get(Calendar.DAY_OF_WEEK);

        Progress(1, 6);

        String DB_PATH = EXTERNAL_STORAGE_APP_SYNC_ROOT + "/" + WDAY + "/" + tempName + "/";

        File fileMainDir = new File(DB_PATH);
        if (fileMainDir.exists()) {
            //noinspection ResultOfMethodCallIgnored
            fileMainDir.delete();
        }
        //noinspection ResultOfMethodCallIgnored
        fileMainDir.mkdirs();

        ////Utils.writeTextFile("---Export Database Start---",context);
        Utils.writeJSONFile(syncJSON, "1", "---Export Database Start---");
        Utils.writeJSONFile(requestJSON, "EXPORT_FILE_START", Utils.getCurrentDateTime());

        if (packageNameValue.toLowerCase().equals("com.ecubix.basflab")) {
            String fileLoginDetails$_1 = "LoginDetails$_1.txt";

            File dirLS = new File(fileMainDir, "LS");
            dirLS.mkdir();

            File dirLMA = new File(fileMainDir, "LMA");
            dirLMA.mkdir();

            File dirLMR = new File(fileMainDir, "LMR");
            dirLMR.mkdir();

            File dirLD = new File(fileMainDir, "LD");
            dirLD.mkdir();

            File dirLCD = new File(fileMainDir, "LCD");
            dirLCD.mkdir();

            File dirLCDPD = new File(fileMainDir, "LCDPD");
            dirLCDPD.mkdir();

            File dirLSD = new File(fileMainDir, "LSD");
            dirLSD.mkdir();

            DatabaseHelper db = new DatabaseHelper(dataDirPath);

            Progress(7, 10);

            generateTextFile(DB_PATH, fileLoginDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_DETAILS).toString());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_STORE, 1000, 0, dirLS.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_MATERIAL_ALLOCATION, 1000, 0, dirLMA.getAbsolutePath());

            Progress(11, 12);

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_MATERIAL_RETURN, 1000, 0, dirLMR.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_DISPOSAL, 1000, 0, dirLD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH, 1000, 0, dirLCD.getAbsolutePath());

            Progress(13, 15);

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS, 1000, 0, dirLCDPD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_LAB_STICKER_DETAILS, 1000, 0, dirLSD.getAbsolutePath());

        } else if (packageNameValue.toLowerCase().equals("com.ecubix.basf.retailer") || packageNameValue.toLowerCase().equals("com.ecubix.basfhkre_ret")) {
            String fileCPM_Customer_Dispatch$_1 = "CPM_Customer_Dispatch$_1.txt";
            String fileLoginDetails$_1 = "LoginDetails$_1.txt";

            String fileCPM_Customer_Receive$_1 = "CPM_Customer_Receive$_1.txt";
            String fileCPM_Customer_Sticker_Scrap$_1 = "CPM_Customer_Sticker_Scrap$_1.txt";
            String fileCPM_Customer_Sticker_Consume$_1 = "CPM_Customer_Sticker_Consume$_1.txt";

            String fileLoginFailAttempt_Details$_1 = "LoginFailAttempt_Details$_1.txt";
            String fileLoginFormDetails$_1 = "LoginFormDetails$_1.txt";

            File dirCDPD = new File(fileMainDir, "CCDPD");
            //noinspection ResultOfMethodCallIgnored
            dirCDPD.mkdir();

            File dirCRPD = new File(fileMainDir, "CCRPD");
            //noinspection ResultOfMethodCallIgnored
            dirCRPD.mkdir();

            File dirCCSD = new File(fileMainDir, "CCSD");
            //noinspection ResultOfMethodCallIgnored
            dirCCSD.mkdir();

            File dirCCSDR = new File(fileMainDir, "CCSDR");
            //noinspection ResultOfMethodCallIgnored
            dirCCSDR.mkdir();

            File dirCPM = new File(fileMainDir, "CPM");
            //noinspection ResultOfMethodCallIgnored
            dirCPM.mkdir();

            File dirCGR = new File(fileMainDir, "CGR");
            //noinspection ResultOfMethodCallIgnored
            dirCGR.mkdir();

            File dirCSD = new File(fileMainDir, "CPM_Sticker_Details");
            //noinspection ResultOfMethodCallIgnored
            dirCSD.mkdir();

            DatabaseHelper db = new DatabaseHelper(dataDirPath);

            Progress(7, 10);

            generateTextFile(DB_PATH, fileLoginDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_DETAILS).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Dispatch$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH).toString());

            Progress(11, 12);
            generateTextFile(DB_PATH, fileCPM_Customer_Receive$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Scrap$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_Customer_Sticker_Scrap).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Consume$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_Customer_Sticker_Consume).toString());

            generateTextFile(DB_PATH, fileLoginFormDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_FORM_DETAILS).toString());
            generateTextFile(DB_PATH, fileLoginFailAttempt_Details$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_FAIL_ATTEMPT_DETAILS).toString());

            Progress(13, 15);
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, 1000, 0, dirCDPD.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, 1000, 0, dirCRPD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_PALLET_MST, 1000, 0, dirCPM.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE, 1000, 0, dirCCSD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE, 1000, 0, dirCCSDR.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_STRICKER_Details, 1000, 0, dirCSD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_GENERAL_RECEIVE, 1000, 0, dirCGR.getAbsolutePath());

        } else if (packageNameValue.toLowerCase().equals("com.ecubix.iffcocpm")) {

            String fileCPM_Customer_Dispatch$_1 = "CPM_CUSTOMER_DISPATCH$_1.txt";
            String fileLoginDetails$_1 = "LOGIN_DETAILS$_1.txt";

//            String fileCPM_Customer_Receive$_1 = "CPM_Customer_Receive$_1.txt";
            String fileCPM_Customer_Sticker_Scrap$_1 = "CPM_CUSTOMER_STICKER_BLOCK$_1.txt";
            String fileCPM_Customer_Sticker_Consume$_1 = "CPM_CUSTOMER_STICKER_BLOCK_REMOVE$_1.txt";

            String fileLoginFailAttempt_Details$_1 = "LOGIN_FAIL_ATTEMPT_DETAILS$_1.txt";
            String fileLoginFormDetails$_1 = "LOGIN_FORM_DETAILS$_1.txt";

            File dirCDPD = new File(fileMainDir, "CCDPD");
            //noinspection ResultOfMethodCallIgnored
            dirCDPD.mkdir();

            File dirCRPD = new File(fileMainDir, "CCRPD");
            //noinspection ResultOfMethodCallIgnored
            dirCRPD.mkdir();

            File dirCSSD = new File(fileMainDir, "CPM_SKU_STICKER_DETAILS");
            //noinspection ResultOfMethodCallIgnored
            dirCSSD.mkdir();

            //File dirCCSDR = new File(fileMainDir, "CCSDR");
            //noinspection ResultOfMethodCallIgnored
            //dirCCSDR.mkdir();

            File dirCPM = new File(fileMainDir, "CPM");
            //noinspection ResultOfMethodCallIgnored
            dirCPM.mkdir();

            File dirCSD = new File(fileMainDir, "CPM_STICKER_DETAILS");
            //noinspection ResultOfMethodCallIgnored
            dirCSD.mkdir();

            File dirCM = new File(fileMainDir, "CM");
            //noinspection ResultOfMethodCallIgnored
            dirCM.mkdir();

            DatabaseHelper db = new DatabaseHelper(dataDirPath);

            Progress(7, 10);

            generateTextFile(DB_PATH, fileLoginDetails$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_LOGIN_DETAILS).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Dispatch$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH).toString());

            Progress(11, 12);
//            generateTextFile(DB_PATH, fileCPM_Customer_Receive$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Scrap$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Consume$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK_REMOVE).toString());

            generateTextFile(DB_PATH, fileLoginFormDetails$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_LOGIN_FORM_DETAILS).toString());
            generateTextFile(DB_PATH, fileLoginFailAttempt_Details$_1, db.getJsonArrayFromTableNameForIFFCO(DatabaseQuery.IFFCO_TABLE_LOGIN_FAIL_ATTEMPT_DETAILS).toString());

            Progress(13, 15);
            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CUSTOMER_MST, 1000, 0, dirCM.getAbsolutePath());
            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, 1000, 0, dirCDPD.getAbsolutePath());

            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, 1000, 0, dirCRPD.getAbsolutePath());
            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_PALLET_MST, 1000, 0, dirCPM.getAbsolutePath());

            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_SKU_STRICKER_Details, 1000, 0, dirCSSD.getAbsolutePath());
            //db.writeTransactionTablesToFile(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE, 1000, 0, dirCCSDR.getAbsolutePath());

            db.writeTransactionTablesToFileForIFFCO(DatabaseQuery.IFFCO_TABLE_CPM_STRICKER_Details, 1000, 0, dirCSD.getAbsolutePath());

        } else {

            String fileCPM_Customer_Dispatch$_1 = "CPM_Customer_Dispatch$_1.txt";
            String fileLoginDetails$_1 = "LoginDetails$_1.txt";

            String fileCPM_Customer_Receive$_1 = "CPM_Customer_Receive$_1.txt";
            String fileCPM_Customer_Sticker_Scrap$_1 = "CPM_Customer_Sticker_Scrap$_1.txt";
            String fileCPM_Customer_Sticker_Consume$_1 = "CPM_Customer_Sticker_Consume$_1.txt";

            String fileLoginFailAttempt_Details$_1 = "LoginFailAttempt_Details$_1.txt";
            String fileLoginFormDetails$_1 = "LoginFormDetails$_1.txt";

            File dirCDPD = new File(fileMainDir, "CCDPD");
            //noinspection ResultOfMethodCallIgnored
            dirCDPD.mkdir();

            File dirCRPD = new File(fileMainDir, "CCRPD");
            //noinspection ResultOfMethodCallIgnored
            dirCRPD.mkdir();

            File dirCCSD = new File(fileMainDir, "CCSD");
            //noinspection ResultOfMethodCallIgnored
            dirCCSD.mkdir();

            File dirCCSDR = new File(fileMainDir, "CCSDR");
            //noinspection ResultOfMethodCallIgnored
            dirCCSDR.mkdir();

            File dirCPM = new File(fileMainDir, "CPM");
            //noinspection ResultOfMethodCallIgnored
            dirCPM.mkdir();

            File dirCSD = new File(fileMainDir, "CPM_Sticker_Details");
            //noinspection ResultOfMethodCallIgnored
            dirCSD.mkdir();

            DatabaseHelper db = new DatabaseHelper(dataDirPath);

            Progress(7, 10);

            generateTextFile(DB_PATH, fileLoginDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_DETAILS).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Dispatch$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH).toString());

            Progress(11, 12);
            generateTextFile(DB_PATH, fileCPM_Customer_Receive$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Scrap$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_Customer_Sticker_Scrap).toString());
            generateTextFile(DB_PATH, fileCPM_Customer_Sticker_Consume$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_CPM_Customer_Sticker_Consume).toString());

            generateTextFile(DB_PATH, fileLoginFormDetails$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_FORM_DETAILS).toString());
            generateTextFile(DB_PATH, fileLoginFailAttempt_Details$_1, db.getJsonArrayFromTableName(DatabaseQuery.TABLE_LOGIN_FAIL_ATTEMPT_DETAILS).toString());

            Progress(13, 15);
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, 1000, 0, dirCDPD.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, 1000, 0, dirCRPD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_PALLET_MST, 1000, 0, dirCPM.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE, 1000, 0, dirCCSD.getAbsolutePath());
            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE, 1000, 0, dirCCSDR.getAbsolutePath());

            db.writeTransactionTablesToFile(DatabaseQuery.TABLE_CPM_STRICKER_Details, 1000, 0, dirCSD.getAbsolutePath());

        }

        Utils.writeJSONFile(requestJSON, "EXPORT_FILE_END", Utils.getCurrentDateTime());
        Utils.writeJSONFile(syncJSON, "2", "---Export Database End---");
        ////Utils.writeTextFile("---Export Database End---",context);

        writeLog("CREATE_ZIP_START", "");

        Utils.writeJSONFile(requestJSON, "CREATE_ZIP_START", Utils.getCurrentDateTime());
        Utils.writeJSONFile(syncJSON, "3", "---Create Zip File Start---");
        ////Utils.writeTextFile("---Create Zip File Start---",context);

        String zipFilePath = CreateZipFile(fileMainDir.getAbsolutePath(), fileMainDir.getName(), WDAY, dbPassword, isDbEncripted);
        writeLog("CREATE_ZIP_END", "");

        Utils.writeJSONFile(requestJSON, "CREATE_ZIP_END", Utils.getCurrentDateTime());
        Utils.writeJSONFile(syncJSON, "3", "---Create Zip File End---");
        ////Utils.writeTextFile("---Create Zip File End---",context);

        Utils.writeJSONFile(requestJSON, "CREATE_ZIP_FILE_NAME", fileMainDir.getName());
        Utils.writeJSONFile(syncJSON, "4", "---Crate ZIP File Name---" + fileMainDir.getName());
        ////Utils.writeTextFile("---Crate ZIP File Name---" + fileMainDir.getName(),context);

        String size = checkFileZiseString(zipFilePath);

        Utils.writeJSONFile(requestJSON, "CREATE_ZIP_SIZE", size);
        Utils.writeJSONFile(syncJSON, "5", "---ZIP Size---" + size);
        ////Utils.writeTextFile("---ZIP Size---" + size,context);

        writeLog("UPLOAD_ZIP_SIZE", size);
        Log.e("ZIP", zipFilePath);
        writeLog("UPLOAD_ZIP_START", "");

        Progress(16, 19);

        Utils.writeJSONFile(requestJSON, "UPLOAD_API_CALL_START", Utils.getCurrentDateTime());
        Utils.writeJSONFile(syncJSON, "6", "---Upload API call start---");
        ////Utils.writeTextFile("---Upload API call start---",context);

//        String strUploadMessage = "";
        if (Utils.inNetwork(context)) {
            String items = UploadDatabaseFileZipOld(zipFilePath,
                    fileMainDir.getName() + ".zip", "FileUpload", requestJSON.toString(), "");
            Log.e("isTimeOut_INNNN", "isTimeOut_INNNN:::" + isTimeOut);
            if (isTimeOut) {
                multipleRequest(zipFilePath,
                        fileMainDir.getName() + ".zip", "CHECK_DOWNLOAD");
            } else {
                if(items.equalsIgnoreCase("TIMEOUT!!!!!") || items.isEmpty()){
                    multipleRequest(zipFilePath,
                            fileMainDir.getName() + ".zip", "CHECK_DOWNLOAD");
                }
            }
        } else {
            writeLog("UPLOAD_ZIP_API_FAIL", "No Internet Connection.");
            Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
//            sendBroadCastDetails(2, "No Internet Connection", lastProgress);
            sendError("No Internet Connection.",lastProgress);
        }
        /*Log.e("strUploadMessage", "----11111111111----" + strUploadMessage);
        if (strUploadMessage.equalsIgnoreCase("Process")) {
            if (Utils.inNetwork(context)) {
                multipleRequest(zipFilePath,
                        fileMainDir.getName() + ".zip", "Process");
            } else {
                strUploadMessage = "No Internet Connection.";
            }
        }
        Log.e("strUploadMessage", "----22222222222222----" + strUploadMessage);
        if (strUploadMessage.equalsIgnoreCase("CHECK_DOWNLOAD")) {
            if (Utils.inNetwork(context)) {
                multipleRequest(zipFilePath,
                        fileMainDir.getName() + ".zip", "CHECK_DOWNLOAD");
            } else {
                strUploadMessage = "No Internet Connection.";
            }
        } else {
            if (!strUploadMessage.equalsIgnoreCase("done") && syncStatus != 3) {
                Log.e("===AAA===", "===strUploadMessage===syncStatus" + strUploadMessage.toString() + "******" + syncStatus);
                syncStatus = 0;
                if (strUploadMessage.equalsIgnoreCase("Session expired. Please try again")) {
                    syncCode = 222;
                } else {
                    syncCode = 103;
                }
                syncMessage = strUploadMessage;
                writeLog("UPLOAD_ZIP_END", strUploadMessage);

                ////Utils.writeTextFile("---Exception Error---" + syncMessage,context);
                Utils.writeJSONFile(syncJSON, "31", "---Exception Error---" + syncMessage);
                Log.e("===GGG===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
                whenAllProgressDone();
            }
        }*/
//        Log.e("strUploadMessage", "----33333333333----" + strUploadMessage);
//        Log.e("strUploadMessage", "-----strUploadMessage----" + strUploadMessage);
//        if (strUploadMessage.equalsIgnoreCase("done")) {
//            writeLog("UPLOAD_ZIP_END", "");
//            afterUpload(strUploadMessage, fileMainDir.getName() + ".zip", dbPassword);
//        } else {
//            syncStatus = false;
//            if (strUploadMessage.equalsIgnoreCase("Session expired. Please try again")) {
//                syncCode = 222;
//            } else {
//                syncCode = 103;
//            }
//            syncMessage = strUploadMessage;
//            writeLog("UPLOAD_ZIP_END", strUploadMessage);
//
//            ////Utils.writeTextFile("---Exception Error---" + syncMessage,context);
//            Utils.writeJSONFile(syncJSON, "31", "---Exception Error---" + syncMessage);
//
//            whenAllProgressDone();
//        }
    }

    static void generateTextFile(String root, String sFileName, String sBody) {
        try {
            writeLog("GENERATE_TXT_FILE_START", sFileName);
            File gpxfile = new File(root, sFileName);
            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.flush();
            writer.close();
            writeLog("GENERATE_TXT_FILE_END", sFileName);
        } catch (IOException e) {
            writeLog("GENERATE_TXT_FILE_EXCEPTION", sFileName);
            e.printStackTrace();
        }
    }

    private static String CreateZipFile(String FileName, String fZipName, int WDAY, String zipPassword, String isDbEncripted) {
        String DB_PATH = EXTERNAL_STORAGE_APP_SYNC_ROOT + "/" + WDAY + "/";
        File dbFile = new File(FileName);
        String zipFileName = DB_PATH + fZipName + ".zip";
        if (dbFile.exists()) {
            if (isDbEncripted.equalsIgnoreCase("true")) {
                zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName, fZipName, zipPassword);
            } else {
                zipFileName = AddFilesWithStandardZipEncryptionOld(dbFile, zipFileName);
            }
        } else {
            zipFileName = "";
        }
        return zipFileName;
    }

    private static String AddFilesWithStandardZipEncryptionOld(File dbFile, String zipFilePath) {
        String done;
        try {
            ZipFile zipFile = new ZipFile(zipFilePath);
            //ArrayList filesToAdd = new ArrayList();
            //filesToAdd.add(dbFile);
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            zipFile.addFolder(dbFile, parameters);
            done = zipFilePath;
        } catch (Exception e) {
            writeLog("SYNC_ERROR", e.getMessage());
            e.printStackTrace();
            done = "";
        }
        return done;
    }

    private static String AddFilesWithStandardZipEncryption(File dbFile, String zipFilePath, String fZipName, String zipPassword) {
        String done;
        try {

            //listAllFiles(dbFile);
            // Initiate ZipFile object with the path/name of the zip file.
            // Zip file may not necessarily exist. If zip file exists, then
            // all these files are added to the zip file. If zip file does not
            // exist, then a new zip file is created with the files mentioned
            ZipFile zipFile = new ZipFile(zipFilePath);

            //zipFile.setPassword(DatabaseHelper.DBPs);
            // Build the list of files to be added in the array list
            // Objects of type File have to be added to the ArrayList
            //ArrayList filesToAdd = new ArrayList();

            //filesToAdd.add(dbFile);
            //filesToAdd.add(new File("c:\\ZipTest\\myvideo.avi"));
            //filesToAdd.add(new File("c:\\ZipTest\\mysong.mp3"));
            // Initiate Zip Parameters which define various properties such
            // as compression method, etc. More parameters are explained in other
            // examples
            // set compression method to deflate
            // compression
            // Set the compression level. This value has to be in between 0 to 9
            // Several predefined compression levels are available
            // DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
            // DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
            // DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
            // DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
            // DEFLATE_LEVEL_ULTRA - Highest compression level but low speed

            // Now add files to the zip file
            // Note: To add a single file, the method addFile can be used
            // Note: If the zip file already exists and if this zip file is a split file
            // then this method throws an exception as Zip Format Specification does not
            // allow updating split zip files
            //parameters.setRootFolderInZip(fZipName);


            /*zipFile.addFolder(dbFile, parameters);*//*

            //File targetFile = new File(dbFile);

            /*for (File f : dbFile.listFiles()) {
                if (f.isFile()) {
                    parameters.setFileNameInZip(f.getName());
                    zipFile.addFile(dbFile, parameters);
                } else if (f.isDirectory()) {
                    parameters.setFileNameInZip(f.getName());
                    zipFile.addFolder(dbFile, parameters);
                }
            }*/

            listAllFiles(dbFile, zipFile, zipPassword);
            Log.e("all files added", "loop end");
            Thread.sleep(5000);
            Log.e("all files added", "thread end");
            done = zipFilePath;
        } catch (Exception e) {
            e.printStackTrace();
            writeLog("SYNC_ERROR", e.getMessage());
            done = "";
        }
        return done;
    }

    static void listAllFiles(File folder, ZipFile zipFile, String zipPassword) {
        try {
            System.out.println("In listAllfiles(File) method");
            File[] fileNames = folder.listFiles();
            for (File file : fileNames) {
                ZipParameters parameters = new ZipParameters();
                parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
                parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_FAST);
                parameters.setEncryptFiles(true);
                parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
                parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
                parameters.setPassword(zipPassword);
                parameters.setReadHiddenFiles(true);

                // if directory call the same method again
                if (file.isDirectory()) {
                    //parameters.setRootFolderInZip(file.getName());
                    //parameters.setSourceExternalStream(true);
                    //parameters.setIncludeRootFolder(true);
                    //zipFile.addFolder(file, parameters);
                    Log.e("folder Name", "" + file.getName());
                    listAllFiles(file, zipFile, zipPassword);
                } else {
                    parameters.setSourceExternalStream(true);
                    parameters.setFileNameInZip(file.getName());
                    zipFile.addFile(file, parameters);
                    Log.e("file Name", "" + file.getName());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    boolean isFirstTimeDone = true;
    boolean isProgress = true;
    boolean isCheckDownload = true;
    boolean isTimeOut = false;
    private String UploadDatabaseFileZipOld(final String filePath, final String fileName, String action, String jsonData, String extraFields) {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String strSyncMessage = "";

        try {

            ////Utils.writeTextFile("---Convert DB File---",context);
            Utils.writeJSONFile(syncJSON, "7", "---Convert DB File---");

            byte[] fByte = null;
            String encodeDb = "";
            DatabaseExportImport databaseExportImport = new DatabaseExportImport();
            try {
                fByte = databaseExportImport.getByteFromFile(filePath);
                if (fByte != null) {
                    encodeDb = Base64.encodeBytes(fByte);
                }
            } catch (Exception e) {

                writeLog("SYNC_ERROR", e.getMessage());
                strSyncMessage = "101:" + e.getMessage();
                ////Utils.writeTextFile("---Exception Error---" + strSyncMessage,context);
                Utils.writeJSONFile(syncJSON, "8", "---Exception Error---" + strSyncMessage);

                e.printStackTrace();
                try {
                    fByte = databaseExportImport.getByteFromFile(filePath);
                    if (fByte != null) {
                        encodeDb = Base64.encodeBytes(fByte);
                    }
                } catch (Exception e1) {
                    writeLog("SYNC_ERROR", e1.getMessage());

                    strSyncMessage = "102:" + e.getMessage();
                    ////Utils.writeTextFile("---Exception Error---" + strSyncMessage,context);
                    Utils.writeJSONFile(syncJSON, "9", "---Exception Error---" + strSyncMessage);

                    e1.printStackTrace();
                }

            }

//            if (fByte != null && !encodeDb.equalsIgnoreCase("")) {

                if (action.equalsIgnoreCase("Process")) {
                    if(isProgress) {
                        isProgress=false;
                        Progress(35, 35);
                        increaseTimmer(35, 45);
                    }
                } else if (action.equalsIgnoreCase("CHECK_DOWNLOAD")){
                    if(isCheckDownload) {
                        isCheckDownload=false;
                        Progress(45, 45);
                        increaseTimmer(45, 60);
                    }
                } else {
                    Progress(20, 20);
                    increaseTimmer(20, 35);
                }


//                if (action.equalsIgnoreCase("Process")) {
//                    if (isProgress) {
//                        isProgress = false;
//                        Log.e("=====PPP=====","====action===="+action);
//                        Progress(35, 35);
//                        increaseTimmer(35, 45);
//                    }
//                } else if (action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//                    if (isCheckDownload) {
//                        isCheckDownload = false;
//                        Log.e("=====QQQ=====","====action===="+action);
//                        Progress(45, 45);
//                        increaseTimmer(45, 60);
//                    }
//                } else {
//                    Log.e("=====RRR=====","====action===="+action);
//                    Progress(20, 20);
//                    increaseTimmer(20, 34);
//                }

                StringRequest stringRequest = null;
                JsonObjectRequest stringRequest1 = null;

                mRequestTickle = VolleyTickle.newRequestTickle(context);


                if (packageName.equalsIgnoreCase("com.ecubix.iffcocpm")) {
                    final Map<String, String> parameterPost = new HashMap<>();
                    parameterPost.clear();

                    //IFFCO CPM
                    parameterPost.put("FileArray", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? "" : encodeDb);
                    parameterPost.put("FileName", fileName.isEmpty() ? "" : fileName);
                    parameterPost.put("DeviceId", imei.isEmpty() ? "" : imei);
                    parameterPost.put("PersonId", fk_EmpGlCode.isEmpty() ? "" : fk_EmpGlCode);
                    parameterPost.put("Version", version.isEmpty() ? "" : version);
                    parameterPost.put("SubModuleName", ClientName.isEmpty() ? "" : ClientName);
                    parameterPost.put("APIToken", UserName.isEmpty() ? "" : UserName);
                    parameterPost.put("Action", action.isEmpty() ? "" : action);
                    parameterPost.put("ZipPassword", dbPassword.isEmpty() ? "" : dbPassword);
                    parameterPost.put("CustomerId", fkCustomerGlCode.isEmpty() ? "" : fkCustomerGlCode);
                    parameterPost.put("DeviceSyncStatus", DeviceSyncStatus.isEmpty() ? "" : DeviceSyncStatus);
                    parameterPost.put("CustomerCode", CustomerCode.isEmpty() ? "" : CustomerCode);
                    parameterPost.put("SystemName", SystemName.isEmpty() ? "" : SystemName);
                    parameterPost.put("LastSyncDate", LastSyncDate.isEmpty() ? "" : LastSyncDate);
                    parameterPost.put("ServerSyncId", ServerSyncId.isEmpty() ? "" : ServerSyncId);

                    String jsonFull = "{\"Sync_Log\":[" + jsonData + "]}";

                    parameterPost.put("JsonData", jsonFull);
                    parameterPost.put("ExtraFields", extraFields.isEmpty() ? "" : extraFields);
                    parameterPost.put("SyncId", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? String.valueOf(syncID) : "");

                    Log.e("DB Sync", "====strFilename====" + fileName);
                    Log.e("DB Sync", "====Imei====" + imei);
                    Log.e("DB Sync", "====fk_EmpGlCode====" + fk_EmpGlCode);
                    Log.e("DB Sync", "====strVersion====" + version);
                    Log.e("DB Sync", "====ClientName====" + ClientName);
                    Log.e("DB Sync", "====UserName====" + UserName);
                    Log.e("DB Sync", "====action====" + action);
                    Log.e("DB Sync", "====jsonData====" + jsonData);
                    Log.e("DB Sync", "====syncID====" + parameterPost.toString());
                    Log.e("DB Sync", "====ZipPassword====" + dbPassword);

                    encodeDb = null;

                    stringRequest = new StringRequest(Request.Method.POST, urlUpload + "/" + uploadMethod, null,
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    if (error instanceof NetworkError) {
                                    } else if (error instanceof ServerError) {
                                    } else if (error instanceof AuthFailureError) {
                                    } else if (error instanceof ParseError) {
                                    } else if (error instanceof NoConnectionError) {
                                    } else if (error instanceof TimeoutError) {
                                        Log.e("DB Sync", "====TimeoutError====");
                                        Log.e("DB Sync", "====TimeoutError====");
                                        syncStatus = 3;
                                        isTimeOut = true;
                                    }
                                }
                            }) {

                        protected Map<String, String> getParams() {
                            if (parameterPost.size() > 0) {
                                return parameterPost;
                            } else {
                                //Utils.printLoge(5, "noperameters jsonTask....", "............" + Utils.parameterPost);
                                return null;
                            }
                        }

                        @Override
                        public String getBodyContentType() {
                            return "application/x-www-form-urlencoded";
                        }


                        @Override
                        public Map<String, String> getHeaders() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("X-ApiKey", "i3BalYxQL");
                            params.put("Content-Type", "application/x-www-form-urlencoded");
                            Log.e("getHeaders", params.toString());
                            return params;
                        }
                    };
                } else {
                    final Map<String, String> parameterPost = new HashMap<>();
                    parameterPost.clear();
                    parameterPost.put("FileArray", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? "" : encodeDb);
                    parameterPost.put("FileName", fileName);
                    parameterPost.put("DeviceId", imei);
                    parameterPost.put("PersonId", fk_EmpGlCode);
                    parameterPost.put("Version", version);
                    parameterPost.put("SubModuleName", ClientName);
                    parameterPost.put("APIToken", UserName);
                    parameterPost.put("Action", action);

                    String jsonFull = "{\"Sync_Log\":[" + jsonData + "]}";

                    parameterPost.put("JsonData", jsonFull);
                    parameterPost.put("ExtraFields", extraFields);
                    parameterPost.put("SyncId", action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD") ? String.valueOf(syncID) : "");

                    Log.e("DB Sync", "====strFilename====" + fileName);
                    Log.e("DB Sync", "====Imei====" + imei);
                    Log.e("DB Sync", "====fk_EmpGlCode====" + fk_EmpGlCode);
                    Log.e("DB Sync", "====strVersion====" + version);
                    Log.e("DB Sync", "====ClientName====" + ClientName);
                    Log.e("DB Sync", "====UserName====" + UserName);
                    Log.e("DB Sync", "====action====" + action);
                    Log.e("DB Sync", "====jsonData====" + jsonFull);
                    Log.e("DB Sync", "====syncID====" + syncID);

                    Log.e("parameterPost", "-->" + parameterPost.toString());

//                    stringRequest = new StringRequest(Request.Method.POST, urlUpload + "/" + uploadMethod, null,
//                            new Response.ErrorListener() {
//                                @Override
//                                public void onErrorResponse(VolleyError error) {
//                                    if (error instanceof NetworkError) {
//                                    } else if (error instanceof ServerError) {
//                                    } else if (error instanceof AuthFailureError) {
//                                    } else if (error instanceof ParseError) {
//                                    } else if (error instanceof NoConnectionError) {
//                                    } else if (error instanceof TimeoutError) {
//                                        Log.e("DB Sync", "====TimeoutError====");
//                                        Log.e("DB Sync", "====TimeoutError====");
//                                        syncStatus = 3;
//                                        isTimeOut = true;
//                                    }
//                                }
//                            }) {
//                        protected Map<String, String> getParams() {
//                            if (parameterPost.size() > 0) {
//                                return parameterPost;
//                            } else {
//                                return null;
//                            }
//                        }
//                    };

                    stringRequest1 = new JsonObjectRequest(Request.Method.POST, urlUpload + "/" + uploadMethod, new JSONObject(parameterPost),null,
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    if (error instanceof NetworkError) {
                                    } else if (error instanceof ServerError) {
                                    } else if (error instanceof AuthFailureError) {
                                    } else if (error instanceof ParseError) {
                                    } else if (error instanceof NoConnectionError) {
                                    } else if (error instanceof TimeoutError) {
                                        Log.e("DB Sync", "====TimeoutError====");
                                        Log.e("DB Sync", "====TimeoutError====");
                                        syncStatus = 3;
                                        isTimeOut = true;
                                    }
                                }
                            }) {


                        @Override
                        public String getBodyContentType() {
                            return "application/json";
                        }

                        @Override
                        public Map<String, String> getHeaders() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("X-ApiKey", "i3BalYxQL");
                            params.put("Content-Type", "application/json");
                            Log.e("getHeaders", params.toString());
                            return params;
                        }
                    };
                }

                int DEFAULT_TIMEOUT_MS = 2700000;
                int DEFAULT_PROCESS_TIMEOUT_MS = 60000;
                if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
                    isTimeOut = false;
                    if(stringRequest != null) {
                        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                                DEFAULT_PROCESS_TIMEOUT_MS,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    }

                    if(stringRequest1 != null) {
                        stringRequest1.setRetryPolicy(new DefaultRetryPolicy(
                                DEFAULT_PROCESS_TIMEOUT_MS,
                                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    }
                } else {
                    if(stringRequest != null) {
                        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                                DEFAULT_TIMEOUT_MS,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    }

                    if(stringRequest1 != null) {
                        stringRequest1.setRetryPolicy(new DefaultRetryPolicy(
                                DEFAULT_TIMEOUT_MS,
                                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                    }
                }

                mRequestTickle.getCache().clear();
                mRequestTickle.add(stringRequest);
                NetworkResponse response = mRequestTickle.start();

                Log.e("jsonUploadDownloadDB", "-->" + response.statusCode);
                String jsonUploadDownloadDB;
                if (response.statusCode == 200) {

                    jsonUploadDownloadDB = VolleyTickle.parseResponse(response);

//                    stopTimer();
//                    if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//                        Progress(60, 60);
//                    } else {
//                        Progress(35, 35);
//                    }

                    Log.e("download ", "link : " + jsonUploadDownloadDB);
                    JSONObject json = new JSONObject(jsonUploadDownloadDB);
                    syncResMessage = json.getString("Message");
                    Log.e("FileSync", "===========UploadDatabaseFileZipOld: ============" + json.toString());
                    String strValidSync = json.optString("Status");

                    try {
                        String syncId = json.optString("SyncId");
                        syncID = syncId != null ? Integer.parseInt(syncId) : 0;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if (strValidSync.equalsIgnoreCase("1")) {

                        writeLog("UPLOAD_ZIP_API_SUCCESS", "");
                        syncMessage = json.optString("Message");

                        if (action.equalsIgnoreCase("Process") || action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
                            Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_END", Utils.getCurrentDateTime());
                            //Utils.writeTextFile("---Process API Call End---",context);
                            Utils.writeJSONFile(syncJSON, "10", "---Process API Call End---");

                            URLDownloadDB = json.optString("Response");
                            syncMessage = json.optString("Message");
                            strSyncMessage = "done";

                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            Log.e("strSyncMessage", "=====strSyncMessage====" + strSyncMessage);
                            if (isFirstTimeDone) {
                                isFirstTimeDone = false;
                                stopTimer();
                                if (strSyncMessage.equalsIgnoreCase("done")) {
                                    writeLog("UPLOAD_ZIP_END", "");
                                    afterUpload(strSyncMessage, fileName, dbPassword);
                                } else {
                                    syncStatus = 0;
                                    completeMethodCall(strSyncMessage);
                                }
                            }
                        } else {

                            Utils.writeJSONFile(requestJSON, "UPLOAD_API_CALL_END", Utils.getCurrentDateTime());
                            //Utils.writeTextFile("---Upload API Call End---",context);
                            Utils.writeJSONFile(syncJSON, "11", "---Upload API Call End---");

                            Utils.writeJSONFile(requestJSON, "PROCESS_API_CALL_START", Utils.getCurrentDateTime());
                            //Utils.writeTextFile("---Process API Call Start---",context);
                            Utils.writeJSONFile(syncJSON, "12", "---Process API Call Start---");


                            strSyncMessage = "Process";

//                            multipleRequest(zipFilePath,
//                                    fileMainDir.getName() + ".zip", "Process");
//                            stopTimer();


                            if (Utils.inNetwork(context)) {
                                multipleRequest(filePath,
                                        fileName, "Process");
                            } else {
                                stopTimer();
                                strSyncMessage = "No Internet Connection.";
                                writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                                Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
//                                sendBroadCastDetails(2, "No Internet Connection", lastProgress);
                                sendError("No Internet Connection.",lastProgress);

                            }

//                            UploadDatabaseFileZipOld(filePath,
//                                    fileName + ".zip","Process",requestJSON.toString(),"");
                        }

                    } else if (strValidSync.equalsIgnoreCase("3")) {

//                        if (action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//                            try {
//                                ///Thread.sleep(120000);
//                                Thread.sleep(60000);
//                            } catch (Exception e) {
//                                e.printStackTrace();
//                            }
//                        }
//                        stopTimer();


                        if (Utils.inNetwork(context)) {
                            multipleRequest(filePath,
                                    fileName, "CHECK_DOWNLOAD");
                        } else {
                            stopTimer();
                            strSyncMessage = "No Internet Connection.";
                            writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                            Utils.writeJSONFile(syncJSON, "42", "---No Internet Connection.---");
//                            sendBroadCastDetails(2, "No Internet Connection", lastProgress);
                            sendError("No Internet Connection.",lastProgress);

                        }
//                        UploadDatabaseFileZipOld(filePath,
//                                fileName, "CHECK_DOWNLOAD", requestJSON.toString(), "");
                    } else if (strValidSync.equalsIgnoreCase("2")) {
                        stopTimer();
                        syncStatus = 0;
                        strSyncMessage = "Session expired. Please try again";
                        syncMessage = strSyncMessage;
                        writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);

                        //Utils.writeTextFile("---Response Error---" + jsonUploadDownloadDB,context);
                        Utils.writeJSONFile(syncJSON, "13", "---Response Error---" + jsonUploadDownloadDB);
                        completeMethodCall(strSyncMessage);
                    } else {
                        stopTimer();
                        syncStatus = 0;
                        strSyncMessage = json.optString("Message");
                        syncMessage = strSyncMessage;
                        writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);

                        //Utils.writeTextFile("---Response Error---" + jsonUploadDownloadDB,context);
                        Utils.writeJSONFile(syncJSON, "14", "---Response Error---" + jsonUploadDownloadDB);
                        completeMethodCall(strSyncMessage);
                    }

                } else {
                    Log.e("99999", "---Response Status Not Getting 200---" + response.statusCode);
                    Log.e("88888", "---syncStatus---" + syncStatus);
                    if (response.statusCode != -1) {
                        if (!isTimeOut) {
                            syncStatus = 0;
                            stopTimer();
                            strSyncMessage = "Response Status Error";
                            ////Utils.writeTextFile("---Response Status Not Getting 200---" + response.statusCode, context);
                            Utils.writeJSONFile(syncJSON, "20", "---Response Status Not Getting 200---" + response.statusCode);
//                            strSyncMessage[0] = "10002";
                            completeMethodCall(strSyncMessage);
                            //sendBroadCastDetails(2, "Response Status Error", lastProgress);

                            Log.e("102", "not in isTimeOut case");
                        }
                    } else {
                        stopTimer();
                        isTimeOut = true;
                        strSyncMessage = "TIMEOUT!!!!!";
                        syncStatus = 3;
                        //Log.e("102", "found -1 not do any thing::::"+strSyncMessage[0]);
                        Log.e("20", "---Response Status Not Getting 200---" + response.statusCode);
                    }
                    //strSyncMessage = "File is not encoded error please try again.";
//                    strSyncMessage = "Responce code error please try again.";
//                    writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
                    //Utils.writeTextFile("---Response Status Not Getting 200---" + response.statusCode,context);
//                    Utils.writeJSONFile(syncJSON, "15", "---Response Status Not Getting 200---" + response.statusCode);
//                    completeMethodCall(strSyncMessage);
                }
//            } else {
//
//                stopTimer();
//                syncStatus = 0;
//                strSyncMessage = "File is not encoded error please try again.";
//                writeLog("UPLOAD_ZIP_API_FAIL", strSyncMessage);
//                //Utils.writeTextFile("---File Array Null---",context);
//                Utils.writeJSONFile(syncJSON, "16", "---File Array Null---");
//                completeMethodCall(strSyncMessage);
//            }
            writeLog("UPLOAD_ZIP_API_END", "");
        } catch (Exception e) {

            stopTimer();
            syncStatus = 0;
            e.printStackTrace();
            String error = e.getMessage();
            error = CommonFunctionLib.checkErrorReset(error);
            strSyncMessage = "" + error;
            writeLog("UPLOAD_ZIP_API_EXCEPTION", strSyncMessage);

            //Utils.writeTextFile("---Exception Error---" + strSyncMessage,context);
            Utils.writeJSONFile(syncJSON, "17", "---Exception Error---" + strSyncMessage);
            completeMethodCall(strSyncMessage);
        }
        return strSyncMessage;
    }

    RequestTickle mRequestTickle;
    private int lastProgress = 0;
    private void multipleRequest(String filePath, final String fileName, final String action) {
        Log.e("==========Process", ":2========");
        Log.e("==========action", ":" + action);

        if (mRequestTickle != null) {
            mRequestTickle.getCache().clear();
        }

        if (action.equalsIgnoreCase("CHECK_DOWNLOAD")) {
//            if(isCheckDownloadAPICall){
//                isCheckDownloadAPICall = false;
//                try {
//                    ///Thread.sleep(120000);
//                    Thread.sleep(15000);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            } else {
                try {
                    ///Thread.sleep(120000);
                    Thread.sleep(60000);
                } catch (Exception e) {
                    e.printStackTrace();
                }
//            }
        }

        if (Utils.inNetwork(context)) {

            Log.e("multipleRequest", ":after delay");

            UploadDatabaseFileZipOld(filePath,
                    fileName, action, requestJSON.toString(), "");
        } else {
            ////Utils.writeTextFile("---No Internet Connection.---", context);
            stopTimer();
            syncStatus = 0;

            syncMessage = "No Internet Connection";
            writeLog("UPLOAD_ZIP_API_EXCEPTION", syncMessage);

            //Utils.writeTextFile("---Exception Error---" + strSyncMessage,context);
            Utils.writeJSONFile(syncJSON, "87", "---Exception Error---" + syncMessage);
            completeMethodCall(syncMessage);

        }

    }

    void completeMethodCall(String strSyncMessage) {
//        syncStatus = 0;
        if (strSyncMessage.equalsIgnoreCase("Session expired. Please try again")) {
            syncCode = 222;
        } else {
            syncCode = 103;
        }
        syncMessage = strSyncMessage;
        writeLog("UPLOAD_ZIP_END", strSyncMessage);

        ////Utils.writeTextFile("---Exception Error---" + syncMessage,context);
        Utils.writeJSONFile(syncJSON, "31", "---Exception Error---" + syncMessage);
        Log.e("===BBB===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
        whenAllProgressDone();
    }

    private void afterUpload(String strUploadMessage, String zipName, String zipPassword) {
        if (strUploadMessage.equalsIgnoreCase("done") && !isProgress) {

            String DownloadURL = URLDownloadDB;
            if (DownloadURL.trim().length() > 0) {

                writeLog("DOWNLOAD_DB_START", "");

                Progress(61,61);
//                increaseTimmer(61, 75);

                Utils.writeJSONFile(requestJSON, "DOWNLOAD_START", Utils.getCurrentDateTime());
                //Utils.writeTextFile("---Download DB Start---",context);
                Utils.writeJSONFile(syncJSON, "18", "---Download DB Start--DownloadURL-" + DownloadURL);
                Utils.writeJSONFile(syncJSON, "18", "---Download DB Start--zipName-" + zipName);

                String strDBMessage = DownloadDBFromUrlZip(DownloadURL, zipName, zipPassword);//, context, databaseName
                writeLog("DOWNLOAD_DB_END", "");

                Utils.writeJSONFile(requestJSON, "DOWNLOAD_END", Utils.getCurrentDateTime());
                //Utils.writeTextFile("---Download DB End---",context);
                Utils.writeJSONFile(syncJSON, "19", "---Download DB End---");

                stopTimer();

                if (strDBMessage.equalsIgnoreCase("done")) {

                    Progress(76,76);
//                    increaseTimmer(76, 95);

                    Utils.writeJSONFile(requestJSON, "IMPORT_FILE_START", Utils.getCurrentDateTime());
                    //Utils.writeTextFile("---Import File Start---",context);
                    Utils.writeJSONFile(syncJSON, "20", "---Import File Start---");

                    //File directory = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, "10102018_162249_SSC");
                    writeLog("INSERT_DATA_TO_DB_START", "");
                    File directory = new File(EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, zipName.replaceAll(".zip", ""));

                    File[] files = directory.listFiles();

                    DatabaseHelper db = new DatabaseHelper(dataDirPath);
                    db.open().beginTransaction();

                    if (packageNameValue.toLowerCase().equals("com.ecubix.basflab")) {
                        db.open().delete(DatabaseQuery.TABLE_LAB_CUSTOMER_DISPATCH_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                    } else if (packageNameValue.toLowerCase().equals("com.ecubix.basf.retailer") || packageNameValue.toLowerCase().equals("com.ecubix.basfhkre_ret")) {
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_GENERAL_RECEIVE, "chrSync=+?", new String[]{"N"});
                    } else if (packageNameValue.toLowerCase().equals("com.ecubix.iffcocpm")) {
                        db.open().delete(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, "CHR_SYNC=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, "CHR_SYNC=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK, "CHR_SYNC=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.IFFCO_TABLE_CPM_CUSTOMER_STICKER_BLOCK_REMOVE, "CHR_SYNC=+?", new String[]{"N"});
                    } else {
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_DISPATCH_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_RECEIVE_PRODUCT_DETAILS, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE, "chrSync=+?", new String[]{"N"});
                        db.open().delete(DatabaseQuery.TABLE_CPM_CUSTOMER_STICKER_DAMAGE_REMOVE, "chrSync=+?", new String[]{"N"});
                    }
                    db.open().setTransactionSuccessful();
                    db.open().endTransaction();
                    for (File f : files) {
                        boolean status = true;
                        if (f.isFile() && f.getPath().endsWith(".txt") && f.getName().contains("$")) {
                            status = UpdateDBDataFromFile(db, f);
                        } else if (f.isDirectory()) {
                            File[] fFolders = f.listFiles();
                            for (File fSt : fFolders) {
                                if (fSt.isFile() && fSt.getPath().endsWith(".txt") && fSt.getName().contains("$")) {
                                    status = UpdateDBDataFromFile(db, fSt);
                                    //break;
                                }
                            }
                        }
                        if (!status) {
                            syncStatus = 0;
                            syncCode = 105;
                            syncMessage = "Response data file not proper, Please re-sync.";

                            //Utils.writeTextFile("---Response Error---" + syncMessage,context);
                            Utils.writeJSONFile(syncJSON, "21", "---Response Error---" + syncMessage);
                            Log.e("===CCC===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
                            whenAllProgressDone();
                            break;
                        }
                    }

                    Utils.writeJSONFile(requestJSON, "IMPORT_FILE_END", Utils.getCurrentDateTime());
                    //Utils.writeTextFile("---Import File End---",context);
                    Utils.writeJSONFile(syncJSON, "22", "---Import File End---");

                    writeLog("INSERT_DATA_TO_DB_END", "");
                    writeLog("SYNC_END", "");
                    //private CountDownTimer timer;
                    //int i = 99;

                    //stopTimer();
                    Progress(96, 97);

                    //isAllProcessDone = true;
                    //lastUpdatedValue = i;
                    //i = 100;
                    syncCode = 200;
                    syncMessage = "done";
                    syncStatus = 1;
                    //changePercent(i);

                    try {
                        File fileMainDir = new File(EXTERNAL_STORAGE_APP_BACKUP_ROOT(context));
                        deleteRecursive(fileMainDir);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    Progress(98, 99);

                    Utils.writeJSONFile(requestJSON, "SYNC_END", Utils.getCurrentDateTime());
                    //Utils.writeTextFile("---Sync End---",context);
                    Utils.writeJSONFile(syncJSON, "23", "---Sync End---");
//                    Progress(100, 100);
                    ProgressDone();
                } else {
                    writeLog("SYNC_ERROR", "Database corrupted.");
                    cancelTimer();
                    //syncStageStatus = "F";
                    syncStatus = 0;
                    syncCode = 105;
                    syncMessage = "Database corrupted please re-sync.";

                    //Utils.writeTextFile("---Database corrupted please re-sync.---" + syncMessage,context);
                    Utils.writeJSONFile(syncJSON, "24", "---Database corrupted please re-sync.---" + syncMessage);
                    Log.e("===DDD===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
                    whenAllProgressDone();
                }
            } else {
                writeLog("SYNC_ERROR", "Database download URL not found.");
                cancelTimer();
                //syncStageStatus = "F";
                syncStatus = 0;
                syncCode = 104;
                syncMessage = "Database download URL not found.";

                //Utils.writeTextFile("---Database download URL not found.---" + syncMessage,context);
                Utils.writeJSONFile(syncJSON, "25", "---Database download URL not found.---" + syncMessage);
                Log.e("===EEE===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
                whenAllProgressDone();
            }
        } else {
            writeLog("SYNC_ERROR", "Database download URL not found.");
            cancelTimer();
            //syncStageStatus = "F";
            syncStatus = 0;
            syncCode = 104;
            syncMessage = "Database URL not found.";

            //Utils.writeTextFile("---Database URL not found.---" + syncMessage,context);
            Utils.writeJSONFile(syncJSON, "26", "---Database URL not found.---" + syncMessage);
            Log.e("===FFF===", "===strUploadMessage===syncStatus" + syncMessage.toString() + "******" + syncStatus);
            whenAllProgressDone();
        }

    }

    private void deleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                deleteRecursive(child);
        //noinspection ResultOfMethodCallIgnored
        fileOrDirectory.delete();
    }

    private boolean UpdateDBDataFromFile(DatabaseHelper db, File f) {
        try {
            String filename = f.getName();
            //Log.e("filename","======filename====="+filename);
            String tablename = filename.substring(0, filename.lastIndexOf("$"));
            if (filename.contains("\\")) {
                tablename = filename.substring(filename.lastIndexOf("\\") + 1, filename.lastIndexOf("$"));
            }

            StringBuilder text = new StringBuilder();

            BufferedReader br = new BufferedReader(new FileReader(f));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
            }
            br.close();

            JSONArray jsonArray = new JSONArray(text.toString());

            //deleteRecordForViolation(db, jsonArray, tablename);

            boolean isInsert;
            if (packageNameValue.toLowerCase().equals("com.ecubix.basflab")) {
                deleteRecordForViolation(db, jsonArray, tablename);
                isInsert = db.insertRecordDynamicForLAB(tablename, jsonArray, syncJSON);
            } else if (packageNameValue.toLowerCase().equals("com.ecubix.iffcocpm")) {
                deleteRecordForViolationIFFCO(db, jsonArray, tablename);
                isInsert = db.insertRecordDynamicForIFFCO(tablename, jsonArray, syncJSON);
            } else {
                deleteRecordForViolation(db, jsonArray, tablename);
                isInsert = db.insertRecordDynamic3(tablename, jsonArray, syncJSON);
            }

            return isInsert;

        } catch (Exception e) {
            e.printStackTrace();
            writeLog("SYNC_ERROR", e.getMessage());
            //Utils.writeTextFile("---Exception Error--UpdateDBDataFromFile--" + e.getMessage(),context);
            Utils.writeJSONFile(syncJSON, "27", "---Exception Error--UpdateDBDataFromFile--" + e.getMessage());
        }
        return false;
    }

    private void deleteRecordForViolation(DatabaseHelper db1, JSONArray jsonArray, String tableName) {

        SQLiteDatabase db = db1.open();

        try {

            db.beginTransaction();
            StringBuilder initGlCodes = new StringBuilder();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                if (initGlCodes.length() == 0) {
                    initGlCodes = new StringBuilder(object.getString("intGlCode"));
                } else {
                    initGlCodes.append(",").append(object.getString("intGlCode"));
                }
            }
            Log.e("INITGLCODE", "====tableName====" + tableName);
            Log.e("INITGLCODE", "====initGlCodes====" + initGlCodes);
            if (initGlCodes.length() > 0) {
                String selectQuery = "SELECT intGlCode FROM " + tableName + "  WHERE intGlCode IN (" + initGlCodes + ")";
                Log.e("INITGLCODE", "====selectQuery====" + selectQuery);
                Cursor c = db.rawQuery(selectQuery, null);
                // looping through all rows and adding to list
                try {
                    if (c.getCount() > 0) {
                        Log.e("INITGLCODE", "====tableName====" + tableName);
                        String deleteQuery = "DELETE FROM  " + tableName + "  WHERE intGlCode IN (" + initGlCodes + ")";
                        Log.e("INITGLCODE", "====deleteQuery====" + deleteQuery);
                        db.execSQL(deleteQuery);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    //Utils.writeTextFile("---Exception Error--deleteRecordForViolation--" + e.getMessage(),context);
                    Utils.writeJSONFile(syncJSON, "28", "---Exception Error--deleteRecordForViolation--" + e.getMessage());
                } finally {
                    c.close();
                }
            }

            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();

            //Utils.writeTextFile("---Exception Error--deleteRecordForViolation--" + e.getMessage(),context);
            Utils.writeJSONFile(syncJSON, "29", "---Exception Error--deleteRecordForViolation--" + e.getMessage());
        } finally {
            db.endTransaction();
        }
    }

    private void deleteRecordForViolationIFFCO(DatabaseHelper db1, JSONArray jsonArray, String tableName) {

        SQLiteDatabase db = db1.open();

        try {

            db.beginTransaction();
            StringBuilder initGlCodes = new StringBuilder();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject object = jsonArray.getJSONObject(i);
                if (initGlCodes.length() == 0) {
                    initGlCodes = new StringBuilder(object.getString("INT_GLCODE"));
                } else {
                    initGlCodes.append(",").append(object.getString("INT_GLCODE"));
                }
            }
            Log.e("INITGLCODE", "====tableName====" + tableName);
            Log.e("INITGLCODE", "====initGlCodes====" + initGlCodes);
            if (initGlCodes.length() > 0) {
                String selectQuery = "SELECT INT_GLCODE FROM " + tableName + "  WHERE INT_GLCODE IN (" + initGlCodes + ")";
                Log.e("INITGLCODE", "====selectQuery====" + selectQuery);
                Cursor c = db.rawQuery(selectQuery, null);
                // looping through all rows and adding to list
                try {
                    if (c.getCount() > 0) {
                        Log.e("INITGLCODE", "====tableName====" + tableName);
                        String deleteQuery = "DELETE FROM  " + tableName + "  WHERE INT_GLCODE IN (" + initGlCodes + ")";
                        Log.e("INITGLCODE", "====deleteQuery====" + deleteQuery);
                        db.execSQL(deleteQuery);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    //Utils.writeTextFile("---Exception Error--deleteRecordForViolation--" + e.getMessage(),context);
                    Utils.writeJSONFile(syncJSON, "28", "---Exception Error--deleteRecordForViolation--" + e.getMessage());
                } finally {
                    c.close();
                }
            }

            db.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();

            //Utils.writeTextFile("---Exception Error--deleteRecordForViolation--" + e.getMessage(),context);
            Utils.writeJSONFile(syncJSON, "29", "---Exception Error--deleteRecordForViolation--" + e.getMessage());
        } finally {
            db.endTransaction();
        }
    }

    private String DownloadDBFromUrlZip(String DownloadUrl, String ZipfileName, String zipPassword) {
        String strSyncMessage = "done";
        try {
            File downloadDB = new File(FileSyncTask.EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD);
            if (!downloadDB.exists())
                //noinspection ResultOfMethodCallIgnored
                downloadDB.mkdirs();

            //startTimer(50, 60);

            File file = new File(FileSyncTask.EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD, ZipfileName);

            final int BUFFER_SIZE = 3 * 1024;
            URL url = new URL(DownloadUrl);

            URLConnection uCon = url.openConnection();
            //uCon.setConnectTimeout(120000);
            uCon.setConnectTimeout(2700000);
            InputStream downloadInputStream = uCon.getInputStream();
            //int fileLength = ucon.getContentLength();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(downloadInputStream, BUFFER_SIZE);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] byteBuffer = new byte[BUFFER_SIZE];
            int current = 0;

            //startTimer(65, 70);

            while (current != -1) {
                fileOutputStream.write(byteBuffer, 0, current);
                current = bufferedInputStream.read(byteBuffer, 0, BUFFER_SIZE);
            }

            fileOutputStream.flush();
            fileOutputStream.close();
            downloadInputStream.close();

            //startTimer(71, 73);

        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = CommonFunctionLib.checkErrorReset(error);
            strSyncMessage = "104: " + error;
            writeLog("DOWNLOAD_DB_EXCEPTION", strSyncMessage);

            //Utils.writeTextFile("---Download Fail---" + strSyncMessage,context);
            Utils.writeJSONFile(syncJSON, "30", "---Download Fail---" + strSyncMessage);
        }

        //startTimer(74, 78);

        if (strSyncMessage.equalsIgnoreCase("done")) {
            strSyncMessage = ExtractDownlodedFile(ZipfileName, strSyncMessage, zipPassword);
        }
        return strSyncMessage;
    }

    private String ExtractDownlodedFile(String ZipfileName, String strSyncMessage, String zipPassword) {
        String zipFile = EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD + "/" + ZipfileName;
        DatabaseExportImport databaseExportImport = new DatabaseExportImport();
        String zipFolder = ZipfileName.replaceAll(".zip", "");
        if (!databaseExportImport.ExtractAllFile(zipFile, "" + EXTERNAL_STORAGE_APP_SYNC_DOWNLOAD + "/" + zipFolder, zipPassword)
                .equalsIgnoreCase("Done")) {
            strSyncMessage = "105:";
        }
        return strSyncMessage;
    }

    private void sendError(String errorMessage,int progress) {
        callBack.onFileSyncResponse(2, errorMessage, progress);
    }

    private void whenAllProgressDone() {
        Log.e("FILE SYNC", "===========whenAllProgressDone: ========" + syncStatus);
        if (syncStatus == 1) {
            writeLog("SYNC_SUCCESS", "");
        } else {
            sendError("Sync not completed successfully.",lastProgress);
            cancelTimer();
            writeLog("SYNC_FAIL", "Sync not completed successfully.");
        }
    }

    private static final JSONObject hashMap = new JSONObject();

    private static void writeLog(String key, String value) {
        try {
            hashMap.put(key, value + " Date Time:-" + getCurrentDateTimeFormated());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private static String getCurrentDateTimeFormated() {
        String date1 = "";
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            date1 = format.format(Calendar.getInstance().getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date1;
    }

    private String checkFileZiseString(String path) {
        String isCompress;
        File f = new File(path);
        long totalLength = f.length();
        String sizeMB = CommonFunctionLib.size(totalLength);
        Log.e("sizeMB", "" + sizeMB);
        isCompress = sizeMB;
        return isCompress;
    }

    private int randInt(int min, int max) {

        // NOTE: This will (intentionally) not run as written so that folks
        // copy-pasting have to think about how to initialize their
        // Random instance.  Initialization of the Random instance is outside
        // the main scope of the question, but some decent options are to have
        // a field that is initialized once and then re-used as needed or to
        // use ThreadLocalRandom (if using at least Java 1.7).
        //
        // In particular, do NOT do 'Random rand = new Random()' here or you
        // will get not very good / not very random results.
        Random rand = new Random();
        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        lastProgress = rand.nextInt((max - min) + 1) + min;
        return lastProgress;
    }

}