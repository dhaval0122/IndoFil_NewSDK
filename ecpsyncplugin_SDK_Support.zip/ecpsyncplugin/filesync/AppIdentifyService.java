package ecp.vcs.com.ecpsyncplugin.filesync;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestTickle;
import com.android.volley.Response;
import com.android.volley.error.VolleyError;
import com.android.volley.request.StringRequest;
import com.android.volley.toolbox.VolleyTickle;

import java.util.HashMap;
import java.util.Map;


public class AppIdentifyService extends Service {
    private final String CHANNEL_ID = "channel_BASF_01";
    private static final int NOTIFICATION_ID = 12345678;


    int SyncId = 0;
    String DeviceSyncStatus, DeviceSyncJson,
            PersonId, SubModuleName, DeviceId, Version,
            APIToken, logUploadMethod, BaseUrl, SyncType, SyncLogJson, ExtraFields, customerID = "", packageName;

    @Override
    public void onCreate() {
        super.onCreate();

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        // Android O requires a Notification Channel.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Create the channel for the notification
            NotificationChannel mChannel =
                    new NotificationChannel(CHANNEL_ID, "BASF-HK", NotificationManager.IMPORTANCE_DEFAULT);
            mChannel.setSound(null, null);
            mChannel.enableLights(true);
            mChannel.enableVibration(false);
            mChannel.setLightColor(Color.GRAY);
            mChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);

            // Set the Notification Channel for the Notification Manager.
            //mNotificationManager.createNotificationChannel(mChannel);
            mNotificationManager.createNotificationChannel(mChannel);
            //startForeground(1, mChannel);

            startForeground(NOTIFICATION_ID, getNotification());
        }
    }

    private Notification getNotification() {

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentText("Optimize Process")
                .setContentTitle("BASF-HK")
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_HIGH)
                //.setTicker(text)
                .setWhen(System.currentTimeMillis());

        // Set the Channel ID for Android O.
        // if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        //    builder.setChannelId(CHANNEL_ID); // Channel ID
        // }

        return builder.build();
    }

    @SuppressLint("StaticFieldLeak")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.e("AppIdentify", "==============onStartCommand: ===============");
        //appPrefs = new AppPrefs(this);

        if (intent != null && intent.hasExtra("SyncId")) {
            SyncId = intent.getIntExtra("SyncId", 0);
            DeviceSyncStatus = intent.getStringExtra("DeviceSyncStatus");
            DeviceSyncJson = intent.getStringExtra("DeviceSyncJson");
            PersonId = intent.getStringExtra("PersonId");
            SubModuleName = intent.getStringExtra("SubModuleName");
            DeviceId = intent.getStringExtra("DeviceId");
            Version = intent.getStringExtra("Version");
            APIToken = intent.getStringExtra("APIToken");
            BaseUrl = intent.getStringExtra("BaseUrl");
            logUploadMethod = intent.getStringExtra("logUploadMethod");

            SyncType = intent.getStringExtra("SyncType");
            SyncLogJson = intent.getStringExtra("SyncLogJson");
            ExtraFields = intent.getStringExtra("ExtraFields");

            customerID = String.valueOf(intent.getExtras().get("CustomerID"));
            Log.e("customerID---jay-",customerID);
            packageName = intent.getStringExtra("packageName");

        }

        final RequestTickle mRequestTickle = VolleyTickle.newRequestTickle(this);
        try {
            new AsyncTask<Void, Void, Void>() {
                @Override
                protected void onPreExecute() {
                    super.onPreExecute();
                    try {
                        Log.e("AppIdentifyService", "========onStartCommand: =====syncID=====" + SyncId);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


                @Override
                protected Void doInBackground(Void... voids) {
                    try {

                        StringRequest stringRequest;

                        //RequestTickle mRequestTickle = VolleyTickle.newRequestTickle(context);
                        final Map<String, String> queryMap = new HashMap<>();

                        if (packageName.equalsIgnoreCase("com.ecubix.iffcocpm")) {

                            //IFFCO CPM
                            queryMap.put("PersonId", PersonId);
                            queryMap.put("SyncId", String.valueOf(SyncId > 0 ? SyncId : 0));
                            queryMap.put("DeviceSyncStatus", DeviceSyncStatus != null ? DeviceSyncStatus : "");
                            queryMap.put("DeviceSyncJson", DeviceSyncJson != null ? DeviceSyncJson : "");
                            queryMap.put("SubModuleName", SubModuleName);
                            queryMap.put("DeviceId", DeviceId != null ? DeviceId : "");
                            queryMap.put("Version", Version);
                            queryMap.put("APIToken", APIToken != null ? APIToken : "");
                            queryMap.put("SyncType", SyncType != null ? SyncType : "");
                            queryMap.put("SyncLogJson", SyncLogJson != null ? SyncLogJson : "");
                            queryMap.put("ExtraFields", ExtraFields != null ? ExtraFields : "");
                            queryMap.put("CustomerID", customerID != null ? customerID : "");
                            queryMap.put("Action", "");

                            Log.e("DB Sync", "====queryMap====" + queryMap.toString());

                            String urls = BaseUrl + logUploadMethod;
                            Log.e("urls:", "" + urls);
                            Log.e("urls:", "" + queryMap);

                            stringRequest = new StringRequest(Request.Method.POST, urls, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Log.e("AppIdentify", "DeviceSyncLog Response # " + response);
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.e("AppIdentify", "DeviceSyncLog Error # " + error.getMessage());
                                }
                            }) {

                                protected Map<String, String> getParams() {
                                    if (queryMap.size() > 0) {
                                        return queryMap;
                                    } else {
                                        //Utils.printLoge(5, "noperameters jsonTask....", "............" + Utils.parameterPost);
                                        return null;
                                    }
                                }

                                @Override
                                public String getBodyContentType() {
                                    return "application/x-www-form-urlencoded";
                                }


                                @Override
                                public Map<String, String> getHeaders() {
                                    Map<String, String> params = new HashMap<String, String>();
                                    params.put("X-ApiKey", "i3BalYxQL");
                                    params.put("Content-Type", "application/x-www-form-urlencoded");
                                    Log.e("getHeaders", params.toString());
                                    return params;
                                }


                            };
                        } else {

                            //final Map<String, String> queryMap = new HashMap<>();
                            queryMap.put("PersonId", PersonId);
                            queryMap.put("SyncId", String.valueOf(SyncId > 0 ? SyncId : 0));
                            queryMap.put("DeviceSyncStatus", DeviceSyncStatus != null ? DeviceSyncStatus : "");
                            queryMap.put("DeviceSyncJson", DeviceSyncJson != null ? DeviceSyncJson : "");
                            queryMap.put("SubModuleName", SubModuleName);
                            queryMap.put("DeviceId", DeviceId != null ? DeviceId : "");
                            queryMap.put("Version", Version);
                            queryMap.put("APIToken", APIToken != null ? APIToken : "");
                            queryMap.put("SyncType", SyncType != null ? SyncType : "");
                            queryMap.put("SyncLogJson", SyncLogJson != null ? SyncLogJson : "");
                            queryMap.put("ExtraFields", ExtraFields != null ? ExtraFields : "");

                            String urls = BaseUrl + logUploadMethod;
                            Log.e("urls:", "" + urls);
                            Log.e("urls:", "" + queryMap);


                            stringRequest = new StringRequest(Request.Method.POST, urls, new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Log.e("AppIdentify", "DeviceSyncLog Response # " + response);
                                }
                            }, new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Log.e("AppIdentify", "DeviceSyncLog Error # " + error.getMessage());
                                }
                            }) {
                                protected Map<String, String> getParams() {
                                    if (queryMap.size() > 0) {
                                        return queryMap;
                                    } else {
                                        return null;
                                    }
                                }

                            };

                        }
                        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                                0,
                                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                        mRequestTickle.add(stringRequest);
                        mRequestTickle.start();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }


                @Override
                protected void onPostExecute(Void aVoid) {
                    super.onPostExecute(aVoid);
                    clearNotification();
                    stopSelf();
                }

            }.execute();


        } catch (Exception e) {
            e.printStackTrace();
        }
        return START_STICKY;
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        clearNotification();
        stopSelf();
    }

    private void clearNotification() {
        /*NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        assert notificationManager != null;
        notificationManager.cancelAll();*/
        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        assert notificationManager != null;
        //notificationManager.cancelAll();
        notificationManager.cancel(NOTIFICATION_ID);
    }
}
