package ecp.vcs.com.ecpsyncplugin.filesync;

public interface FileSyncCallBack {
    void onFileSyncResponse(int type, String details, int progress);
}
