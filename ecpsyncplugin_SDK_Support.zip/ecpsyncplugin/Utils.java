package ecp.vcs.com.ecpsyncplugin;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.util.Log;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;


public class Utils {

    public static String DATE_WITH_TIME_SERVER_FORMAT = "yyyy-MM-dd HH:mm:ss";
    //String DATE_WITH_TIME_DISPLAY_FORMAT = "MM/dd/yyyy HH:mm:ss";

    public static void copyFile(File src, File dst) throws IOException {
        FileChannel inChannel = new FileInputStream(src).getChannel();
        FileChannel outChannel = new FileOutputStream(dst).getChannel();
        try {
            inChannel.transferTo(0, inChannel.size(), outChannel);
        } finally {
            if (inChannel != null)
                inChannel.close();
            //if (outChannel != null)
            outChannel.close();
        }
    }

    /**
     * @return boolean indicating whether network is connected or not <br /><br />
     * <p/>
     * <strong>Note:</strong><br/>
     * <p>This method requires android.permission.ACCESS_NETWORK_STATE permission </p>
     */
    public static boolean inNetwork(Context context) {
        boolean isConnected = false;
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        @SuppressLint("MissingPermission")
        NetworkInfo nInfo = manager.getActiveNetworkInfo();
        if (nInfo != null && nInfo.isConnectedOrConnecting()) {
            isConnected = true;
        }
        return isConnected;
    }

    public static String checkErrorReset(String errorString) {
        String messges = "";
        try {
            if (!errorString.equalsIgnoreCase("")) {
                if (errorString.contains("ECONNREFUSED") || errorString.contains("ENETUNREACH")) {
                    messges = "Internet connection reset, Please try again";
                } else if (errorString.contains("ETIMEDOUT")) {
                    messges = "Internet connection timeout, Please try again";
                } else {
                    messges = errorString;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            messges = errorString;
        }
        return messges;
    }

    /*public static String ConvertExceptionToString(Throwable e) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        return sw.toString();
    }*/

    public static String GetCurrentDate(String Format) {

        String Date = null;
        try {
            Calendar cal = new GregorianCalendar();
            DateFormat dateFormat = new SimpleDateFormat(Format, Locale.US);
            Date = dateFormat.format(cal.getTime());
//			Log.e(" Date ", " : " + Date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return Date;
    }

    /*public static String CreateZipFile(String uploadPath, String FileName, String fZipName, int WDAY, String zipPassword) {
        //uploadPath till /Upload
        //Utils.writeToFileMainSync("inside CreateZipFile");
        //String DB_PATH = Constant.ECTERNAL_STORAGE_APP_UPLOAD;
        uploadPath = uploadPath + "/" + WDAY + "/";
        String mPath = uploadPath + FileName;
        File dbFile = new File(mPath);
        String zipFileName = uploadPath + fZipName;
        if (dbFile.exists()) {
            //Utils.writeToFileMainSync("inside CreateZipFile exists");
            zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName, zipPassword);
        } else {
            //Utils.writeToFileMainSync("inside CreateZipFile not exists");
            zipFileName = "";
        }
        return zipFileName;
    }*/

    /*private static final String ECTERNAL_STORAGE_ROOT = "" + Environment
            .getExternalStorageDirectory();

    private static final String ECTERNAL_STORAGE_APP_ROOT = "" + ECTERNAL_STORAGE_ROOT + "/" +
            "Flut12er02app19/com.vcs.ecp";*/

    private static String ECTERNAL_STORAGE_ROOT(Context context) {
        return context.getFilesDir().getAbsolutePath();
    }

    private static final String ECTERNAL_STORAGE_APP_ROOT(Context context) {
        return ECTERNAL_STORAGE_ROOT(context) + "/" +
                "Flut12er02app19/com.vcs.ecp";
    }

    public static void writeTextFile(String sBody, Context context) {
        try {
            File root = new File(ECTERNAL_STORAGE_APP_ROOT(context));
            if (!root.exists()) {
                root.mkdirs();
            }
            File gpxfile = new File(root, "SyncLogFile.txt");
            FileWriter writer = new FileWriter(gpxfile);
            writer.append(sBody);
            writer.append("\n");
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeJSONFile(JSONObject reqJson, String key, String value) {
        try {
            reqJson.put(key, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String CreateZipFile(String uploadPath, String FileName, String fZipName, int WDAY, String zipPassword, String isEncripted, Context context) {
        //uploadPath till /Upload
        //Utils.writeToFileMainSync("inside CreateZipFile");
        //String DB_PATH = Constant.ECTERNAL_STORAGE_APP_UPLOAD;
        uploadPath = uploadPath + "/" + WDAY + "/";
        String mPath = uploadPath + FileName;
        File dbFile = new File(mPath);
        String zipFileName = uploadPath + fZipName;
        if (dbFile.exists()) {
            //Utils.writeToFileMainSync("inside CreateZipFile exists");
            if (isEncripted.equalsIgnoreCase("true"))
                zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName, fZipName, zipPassword);
            else
                zipFileName = AddFilesWithStandardZipEncryption(dbFile, zipFileName);
        } else {
            //Utils.writeToFileMainSync("inside CreateZipFile not exists");
            ////Utils.writeTextFile("---Inside CreateZipFile not exists---", context);
            zipFileName = "";
        }
        return zipFileName;
    }

    private static String AddFilesWithStandardZipEncryption(File dbFile, String zipFilePath, String fZipName, String zipPassword) {
        String done;
        try {

            if (fZipName.contains(".zip")) {
                fZipName = fZipName.replace(".zip", ".db");
            }

            // Initiate ZipFile object with the path/name of the zip file.
            // Zip file may not necessarily exist. If zip file exists, then
            // all these files are added to the zip file. If zip file does not
            // exist, then a new zip file is created with the files mentioned
            ZipFile zipFile = new ZipFile(zipFilePath);
            //zipFile.setPassword(DatabaseHelper.DBPs);
            // Build the list of files to be added in the array list
            // Objects of type File have to be added to the ArrayList
            ArrayList filesToAdd = new ArrayList();
            //noinspection unchecked
            filesToAdd.add(dbFile);

            // Initiate Zip Parameters which define various properties such
            // as compression method, etc. More parameters are explained in other
            // examples
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate
            // compression
            // Set the compression level. This value has to be in between 0 to 9
            // Several predefined compression levels are available
            // DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
            // DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
            // DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
            // DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
            // DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_FAST);
            // Now add files to the zip file
            // Note: To add a single file, the method addFile can be used
            // Note: If the zip file already exists and if this zip file is a split file
            // then this method throws an exception as Zip Format Specification does not
            // allow updating split zip files
            parameters.setFileNameInZip(fZipName);
            parameters.setEncryptFiles(true);
            parameters.setSourceExternalStream(true);
            parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
            parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
            parameters.setPassword(zipPassword);
            zipFile.addFiles(filesToAdd, parameters);

            done = zipFilePath;
        } catch (Exception e) {
            e.printStackTrace();
            done = "";
        }
        return done;
    }

    private static String AddFilesWithStandardZipEncryption(File dbFile, String zipFilePath) {
        String done;
        try {
            // Initiate ZipFile object with the path/name of the zip file.
            // Zip file may not necessarily exist. If zip file exists, then
            // all these files are added to the zip file. If zip file does not
            // exist, then a new zip file is created with the files mentioned
            ZipFile zipFile = new ZipFile(zipFilePath);
            // Build the list of files to be added in the array list
            // Objects of type File have to be added to the ArrayList
            ArrayList filesToAdd = new ArrayList();
            //noinspection unchecked
            filesToAdd.add(dbFile);
            //filesToAdd.add(new File("c:\\ZipTest\\myvideo.avi"));
            //filesToAdd.add(new File("c:\\ZipTest\\mysong.mp3"));
            // Initiate Zip Parameters which define various properties such
            // as compression method, etc. More parameters are explained in other
            // examples
            ZipParameters parameters = new ZipParameters();
            parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE); // set compression method to deflate
            // compression
            // Set the compression level. This value has to be in between 0 to 9
            // Several predefined compression levels are available
            // DEFLATE_LEVEL_FASTEST - Lowest compression level but higher speed of compression
            // DEFLATE_LEVEL_FAST - Low compression level but higher speed of compression
            // DEFLATE_LEVEL_NORMAL - Optimal balance between compression level/speed
            // DEFLATE_LEVEL_MAXIMUM - High compression level with a compromise of speed
            // DEFLATE_LEVEL_ULTRA - Highest compression level but low speed
            parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
            // Now add files to the zip file
            // Note: To add a single file, the method addFile can be used
            // Note: If the zip file already exists and if this zip file is a split file
            // then this method throws an exception as Zip Format Specification does not
            // allow updating split zip files
            zipFile.addFiles(filesToAdd, parameters);
            done = zipFilePath;
        } catch (Exception e) {
            e.printStackTrace();
            done = "";
        }
        return done;
    }

    public static byte[] ConvertDBFile(String uploadFilePath, String FileName, Context context, int WDAY) {
        InputStream is;
        ByteArrayOutputStream bos = null;
        try {
            //Calendar calendar = Calendar.getInstance();
            //int Wday = calendar.get(Calendar.DAY_OF_WEEK);
            //String PACKAGE_NAME = this.ctx.getPackageName();
            /*String DB_PATH = Environment.getExternalStorageDirectory() + "/" + PACKAGE_NAME +
            "/SyncBackup/Upload/";*/
            // String DB_PATH = Constant.ECTERNAL_STORAGE_APP_UPLOAD;
            uploadFilePath = uploadFilePath + "/" + WDAY + "/";
            String mPath = uploadFilePath + FileName;
            File dbfile = new File(mPath);
            is = new BufferedInputStream(new FileInputStream(dbfile));
            bos = new ByteArrayOutputStream();
            while (is.available() > 0) {
                bos.write(is.read());
            }
        } catch (Exception e) {
            ////Utils.writeTextFile("---Convert DB File---" + e.toString(), context);
            e.printStackTrace();
        }
        if (bos != null) {
            return bos.toByteArray();
        } else {
            return null;
        }
    }

    public static String ExtractSingleFile(String _zipFile, String _targetLocation, String dbFileName, String zipPassword) {
        String done = "done";
        try {
            if (new File(_zipFile).exists()) {
                Log.e("_zipFile", "Path:: " + _zipFile);
                // Initiate ZipFile object with the path/name of the zip file.
                ZipFile zipFile = new ZipFile(_zipFile);
                // Check to see if the zip file is password protected
                if (zipFile.isEncrypted()) {
                    // if yes, then set the password for the zip file
                    zipFile.setPassword(zipPassword);
                }
                // Specify the file name which has to be extracted and the path to which
                // this file has to be extracted
                zipFile.extractFile(dbFileName, _targetLocation);
                // Note that the file name is the relative file name in the zip file.
                // For example if the zip file contains a file "mysong.mp3" in a folder
                // "FolderToAdd", then extraction of this file can be done as below:
                //zipFile.extractFile("FolderToAdd\\myvideo.avi", "c:\\ZipTest\\");
                //if (zipFile != null) {
                //zipFile = null;
                //}
            } else {
                Log.e("zip file", "not fpund");
            }
        } catch (Exception e) {
            done = "";
            e.printStackTrace();
        }
        return done;
    }

    public static void deleteFiles(File exportFile) {
        if (exportFile.exists() && exportFile.isFile()) {
            //noinspection ResultOfMethodCallIgnored
            exportFile.delete();
        }

        if (exportFile.exists() && exportFile.isDirectory()) {
            DeleteRecursive(exportFile);
        }
    }

    public static void DeleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                DeleteRecursive(child);
        if (fileOrDirectory.exists()) {
            //noinspection ResultOfMethodCallIgnored
            fileOrDirectory.delete();
            /*if (b) {
                Utils.printLoge(5, "delete dir", "delete dir");
            } else {
                Utils.printLoge(5, "not delete dir", "not delete dir");
            }*/
        }
    }

    /*public static boolean isDatabaseCorrupted(String mPath) {
        boolean isCorrupted = false;
        //String mPath = "/data/data/" + context.getPackageName()
        // + "/databases/" + "ecp_mobile";
        File pathFile = new File(mPath);
        if (pathFile.exists()) {
            SQLiteDatabase sqliteDatabase = SQLiteDatabase.openDatabase(mPath, null, SQLiteDatabase.OPEN_READWRITE | SQLiteDatabase.NO_LOCALIZED_COLLATORS);
            Cursor cursor1 = sqliteDatabase.rawQuery("SELECT MAX(intGlCode) AS intGlCode FROM " +
                    "Login", null);
            if (cursor1 != null && cursor1.getCount() > 0) {
                cursor1.moveToFirst();
                final int count = cursor1.getInt(cursor1.getColumnIndex("intGlCode"));
                isCorrupted = count <= 0;
            }

            if (cursor1 != null)
                cursor1.close();

            //Dhaval Change 04/06/18
            Cursor cursor = sqliteDatabase.rawQuery("SELECT count(*) AS count FROM Employee_Mst", null);
            if (cursor != null && cursor.getCount() > 0) {
                cursor.moveToFirst();
                final int count = cursor.getInt(cursor.getColumnIndex("count"));
                isCorrupted = count <= 0;
            }

            if (cursor != null)
                cursor.close();
            sqliteDatabase.close();
        }
        return isCorrupted;
    }*/

    public static boolean copyDataBase(File src, File dst, String version) {
        Log.e("copyDataBase", "copyDataBase");
        Log.e("src", ":" + src);
        Log.e("dst", ":" + dst);
        //Dhaval Cahnge 04/06/18
        try {
            if (Build.VERSION.SDK_INT > 19) {
                try (InputStream inm = new FileInputStream(src)) {
                    try (OutputStream out = new FileOutputStream(dst)) {
                        // Transfer bytes from in to out
                        byte[] buf = new byte[1024];
                        int len;
                        while ((len = inm.read(buf)) > 0) {
                            out.write(buf, 0, len);
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return true;
            } else {
                //Open your local db as the input stream
                InputStream myInput = new FileInputStream(src);
                //Open the empty db as the output stream
                OutputStream myOutput = new FileOutputStream(dst);
                //transfer bytes from the inputfile to the outputfile
                byte[] buffer = new byte[1024];
                int length;
                while ((length = myInput.read(buffer)) > 0) {
                    myOutput.write(buffer, 0, length);
                }
                //Close the streams
                myOutput.flush();
                myOutput.close();
                myInput.close();

                return true;
            }
        } catch (Exception e) {
            Log.e("error", "error copy file:" + e.getMessage());
            //Utils.writeToFileSyncVersion("error copy file:" + e.getMessage(), version);
            e.printStackTrace();
            return false;
        }
    }

    public static String getTimeFromUTC(String utcTime, String format) throws Exception {
        SimpleDateFormat sourceFormat = new SimpleDateFormat(DATE_WITH_TIME_SERVER_FORMAT, Locale.ENGLISH);
        sourceFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = sourceFormat.parse(utcTime);

        SimpleDateFormat targetFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        targetFormat.setTimeZone(TimeZone.getDefault());
        return targetFormat.format(date);
    }

    public static String getCurrentDateTime() {
        SimpleDateFormat targetFormat = new SimpleDateFormat(DATE_WITH_TIME_SERVER_FORMAT, Locale.ENGLISH);
        targetFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return targetFormat.format(new java.util.Date());
    }

    /*public String getDateTime(String dateTime, String format) throws Exception {
        SimpleDateFormat sourceFormat = new SimpleDateFormat(DATE_WITH_TIME_SERVER_FORMAT, Locale.ENGLISH);
        sourceFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = sourceFormat.parse(dateTime);
        sourceFormat.setTimeZone(TimeZone.getDefault());

        SimpleDateFormat targetFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        return targetFormat.format(date);
    }*/

    /*public String getDateTime(Date dateTime, String format) throws Exception {
        SimpleDateFormat targetFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        return targetFormat.format(dateTime);
    }

    public String getDateTime(String dateTime, String sourceFormate, String format) throws Exception {
        SimpleDateFormat sourceFormat = new SimpleDateFormat(sourceFormate, Locale.ENGLISH);
        sourceFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        Date date = sourceFormat.parse(dateTime);
        sourceFormat.setTimeZone(TimeZone.getDefault());

        SimpleDateFormat targetFormat = new SimpleDateFormat(format, Locale.ENGLISH);
        return targetFormat.format(date);
    }*/

    /**
     * Get Serial Number From Scanned Barcode
     */
    public static String getSerialNoFromBarcode(String barcode, boolean isFromScanScreen) {
        if (barcode.length() <= 14) {
            return barcode;
        }
        String serialNo = "";
        String varString = barcode;
        varString = varString.replace("\"", "");
        varString = varString.trim();
        String finalStr = "";
        String groupSeparator = "";
        for (int i = 0; i < varString.length(); i++) {
            char k = varString.charAt(i);
            int ascii = (int) k;
            if (ascii != 29) {
                finalStr = finalStr + k;
            } else {
                finalStr = finalStr + k;
                groupSeparator = k + "";
            }
        }
        Log.e("FIANAL STRING ", "===finalSt===rgetSerialNoFromBarcode: " + finalStr);
        if (!finalStr.isEmpty()) {
            if (groupSeparator.length() > 0) {
                String[] separated = finalStr.split(groupSeparator);
                Log.e("SPLIT", "========getSerialNoFromBarcode: ======" + separated.length);
                Log.e("SPLIT", "========separated: ===0===" + separated[0]);
                Log.e("SPLIT", "========separated: ===1===" + separated[1]);

                String separated1 = separated[separated.length - 1];
                //String separated1 = separated[1];
                if (!separated1.trim().isEmpty()) {
                    String code = separated1.substring(0, 2);
                    Log.e("CODE", "======Code======:" + code);
                    serialNo = separated1.substring(2);
                    serialNo = serialNo + "/" + code;
                    Log.e("TAG_SERIAL_NO", serialNo);
                }
            } else {
                if (!isFromScanScreen) {
                    return barcode;
                }
            }
        }
        return serialNo;
    }

    /**
     * Get Serial Number From Scanned Barcode
     */
    public static String getSerialNoFromBarcode16(String barcode, boolean isFromScanScreen) {
        if (barcode.length() <= 16) {
            return barcode;
        }
        String serialNo = "";
        String varString = barcode;
        varString = varString.replace("\"", "");
        varString = varString.trim();
        String finalStr = "";
        String groupSeparator = "";
        for (int i = 0; i < varString.length(); i++) {
            char k = varString.charAt(i);
            int ascii = (int) k;
            if (ascii != 29) {
                finalStr = finalStr + k;
            } else {
                finalStr = finalStr + k;
                groupSeparator = k + "";
            }
        }
        Log.e("FIANAL STRING ", "===finalSt===rgetSerialNoFromBarcode: " + finalStr);
        if (!finalStr.isEmpty()) {
            if (groupSeparator.length() > 0) {
                String[] separated = finalStr.split(groupSeparator);
                Log.e("SPLIT", "========getSerialNoFromBarcode: ======" + separated.length);
                Log.e("SPLIT", "========separated: ===0===" + separated[0]);
                Log.e("SPLIT", "========separated: ===1===" + separated[1]);

                String separated1 = separated[separated.length - 1];
                //String separated1 = separated[1];
                if (!separated1.trim().isEmpty()) {
                    String code = separated1.substring(0, 2);
                    Log.e("CODE", "======Code======:" + code);
                    serialNo = separated1.substring(2);
                    serialNo = serialNo + "/" + code;
                    Log.e("TAG_SERIAL_NO", serialNo);
                }
            } else {
                if (!isFromScanScreen) {
                    return barcode;
                }
            }
        }
        return serialNo;
    }


}
