package ecp.vcs.com.ecpsyncplugin;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.os.StrictMode;
import android.util.Base64;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestTickle;
import com.android.volley.request.StringRequest;
import com.android.volley.toolbox.VolleyTickle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import ecp.vcs.com.ecpsyncplugin.filesync.AppIdentifyService;
import ecp.vcs.com.ecpsyncplugin.filesync.FileSyncCallBack;

class SyncData {
    private Context context;
    private FileSyncCallBack callBack;
    private static final String update_progress = "update_progress";
    private static final String ECTERNAL_STORAGE_ROOT = "" + Environment
            .getExternalStorageDirectory();
    private static final String ECTERNAL_STORAGE_APP_ROOT = "" + ECTERNAL_STORAGE_ROOT + "/" +
            "Flut12er02app19/com.vcs.ecp";
    private static final String ECTERNAL_STORAGE_APP_SYNC_ROOT = "" + ECTERNAL_STORAGE_APP_ROOT +
            "/SyncBackup";
    private static final String ECTERNAL_STORAGE_APP_DOWNLOAD = "" +
            ECTERNAL_STORAGE_APP_SYNC_ROOT + "/Download";
    private static final String ECTERNAL_STORAGE_APP_UPLOAD = "" + ECTERNAL_STORAGE_APP_SYNC_ROOT
            + "/Upload";
    private static String URLDownloadDB = "";
    private String fk_EmpGlCode = "";
    private String ClientName = "";
    private String imei = "";
    private String version = "";
    private String UserName = "";
    private String urlUpload = "";
    private String logUploadMethod = "";
    private int syncID = 0;

    SyncData(Context _context, FileSyncCallBack _callBack){
        this.context = _context;
        this.callBack = _callBack;
    }

    public void startSyncData(String _UserName,String _fk_EmpGlCode,String _ClientName,String _imei,String _version,String packageName,String _logUploadMethod,String _urlUpload,String databaseName,String dbPassword,String isDbEncripted,String methodSyncID){
        UserName = _UserName;
        fk_EmpGlCode = _fk_EmpGlCode;
        ClientName = _ClientName;
        imei = _imei;
        version = _version;
        urlUpload = _urlUpload;
        logUploadMethod = methodSyncID;

        new LongOperation().execute(_UserName, _fk_EmpGlCode, _ClientName, _imei, _version, packageName, _logUploadMethod, _urlUpload, databaseName, dbPassword, isDbEncripted);
    }

    private class LongOperation extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            String doneItem = SyncDB(params[0], params[1], params[2], params[3], params[4], params[5], params[6], params[7], params[8], context, params[9], params[10]);
            //return "";

            if (doneItem.equalsIgnoreCase("done")) {
                startIntentService("Y");
            } else {
                startIntentService("N");
            }

            return doneItem;
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null && result.equalsIgnoreCase("done")) {
                sendBroadCastDetails(3, "Sync Complate 100%", 100);
            } else {
                sendBroadCastDetails(2, result, lastProgress);
            }
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

    private String SyncDB(String UserName, String fk_EmpGlCode, String ClientName, String imei, String
            strVersion, String packageName, String uploadMethod, String urlUpload, String DATABASE_NAME, Context context, String dbPassword, String isDbEncripted) {
        /*Log.e("UserName", ":" + UserName);
        Log.e("fk_EmpGlCode", ":" + fk_EmpGlCode);
        Log.e("ClientName", ":" + ClientName);
        Log.e("imei", ":" + imei);
        Log.e("strVersion", ":" + strVersion);
        Log.e("packageName", ":" + packageName);
        Log.e("uploadMethod", ":" + uploadMethod);
        Log.e("urlUpload", ":" + urlUpload);*/

        String tempName = Utils.GetCurrentDate("ddMMyyyy_HHmmss") + "_" + UserName;
        String fName = tempName + "_ecp_mobile.db";
        String fZipName = tempName + "_ecp_mobile.zip";
        String exportPath = ECTERNAL_STORAGE_APP_UPLOAD;
        Calendar calendar = Calendar.getInstance();
        int WDAY = calendar.get(Calendar.DAY_OF_WEEK);

        String dataDirPath = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + DATABASE_NAME;

        sendBroadCastDetails(1, "export DB", randInt(1, 5));

        if (exportSyncDbNew(dataDirPath, exportPath, fName, WDAY)) {
            sendBroadCastDetails(1, "zip DB", randInt(5, 7));
            if (!Utils.CreateZipFile(exportPath, fName, fZipName, WDAY, dbPassword, isDbEncripted,context).equalsIgnoreCase("")) {
                sendBroadCastDetails(1, "upload DB", randInt(7, 15));
                //String downloadPath = ECTERNAL_STORAGE_APP_DOWNLOAD;
                //Log.e("strUploadMessage", ":" + strUploadMessage);
                return UploadDatabaseFileZipOld(urlUpload, fZipName, UserName,
                        fk_EmpGlCode, ClientName, imei, strVersion, context, WDAY, exportPath, uploadMethod, fName, DATABASE_NAME, dataDirPath, packageName, dbPassword, isDbEncripted);
            } else {
                sendBroadCastDetails(2, "Filed to create zip file", lastProgress);
                return "notdone";
            }
        } else {
            sendBroadCastDetails(2, "Export database filed", lastProgress);
            return "notdone";
        }
    }

    private static boolean SdIsPresent() {
        return Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED);
    }

    private boolean exportSyncDbNew(String dataDirPath, String exportPath, String Filename, int Wday) {

        Log.e("dataDirPath", ":" + dataDirPath);
        Log.e("exportPath", ":" + exportPath);

        if (!SdIsPresent())
            return false;

        if (new File(dataDirPath).exists()) {
            File exportDir = new File(exportPath + "/" + Wday);
            if (!exportDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                exportDir.mkdirs();
            }
            File file = new File(exportDir, Filename);
            try {
                if (!file.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    file.createNewFile();
                    Utils.copyFile(new File(dataDirPath), file);
                    return true;
                } else {
                    return false;
                }
            } catch (IOException e) {
                //isFielCopeError = true;
                //fileCopeException = "101: " + Utils.checkErrorReset(Utils.ConvertExceptionToString(e));
                return false;
            }
        } else {
            //isFielCopeError = true;
            //fileCopeException = "101";
            return false;
        }
    }

    private String UploadDatabaseFileZipOld(String url, String strFilename, String UserName, String fk_EmpGlCode, String
            ClientName, String Imei, String strVersion, Context context, int WDAY, String uploadPath, String MNDatabaseUpload,
                                            String fName, String DATABASE_NAME, String dataDirPath, String packageName, String dbPassword, String isDbEncripted) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String strSyncMessage = "Done";

        try {
            byte[] fByte = Utils.ConvertDBFile(uploadPath, strFilename, context, WDAY);
            String encodeDb = "";
            if (fByte != null) {
                //encodeDb = Base64.encodeBytes(fByte);
                encodeDb = Base64.encodeToString(fByte, Base64.DEFAULT);
            }
            sendBroadCastDetails(1, "upload DB", randInt(15, 20));
            //changePercent(randInt(25, 27));

            if (fByte != null && !encodeDb.equalsIgnoreCase("")) {
                fByte = null;
                // changePercent(randInt(27, 30));

                sendBroadCastDetails(1, "upload DB", randInt(20, 25));

                //VolleyLog.DEBUG = true;

                final Map<String, String> parameterPost = new HashMap<>();
                parameterPost.clear();

                //ECP
                /*parameterPost.put("FileArray", encodeDb);
                parameterPost.put("Filename", strFilename);
                parameterPost.put("UserName", UserName);
                parameterPost.put("fk_EmpGLCode", String.valueOf(fk_EmpGlCode));
                parameterPost.put("varClientName", ClientName);
                parameterPost.put("varIMEINumber", Imei);
                parameterPost.put("strVersion", strVersion);
                parameterPost.put("varAppType", "Android");*/

                //BASF_HK
                parameterPost.put("FileArray", encodeDb);
                parameterPost.put("FileName", strFilename);
                parameterPost.put("DeviceId", Imei);
                parameterPost.put("PersonId", fk_EmpGlCode);
                parameterPost.put("Version", strVersion);
                parameterPost.put("SubModuleName", ClientName);
                parameterPost.put("APIToken", UserName);

                encodeDb = null;

                RequestTickle mRequestTickle = VolleyTickle.newRequestTickle(context);

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url + "/" + MNDatabaseUpload, null,
                        null) {

                    protected Map<String, String> getParams() {
                        if (parameterPost.size() > 0) {
                            return parameterPost;
                        } else {
                            //Utils.printLoge(5, "noperameters jsonTask....", "............" + Utils.parameterPost);
                            return null;
                        }
                    }

                };
                //int DEFAULT_TIMEOUT_MS = 720000;
                int DEFAULT_TIMEOUT_MS = 2700000;
                //int DEFAULT_TIMEOUT_MS = 120000;
                stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                        DEFAULT_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                mRequestTickle.add(stringRequest);
                NetworkResponse response = mRequestTickle.start();

                Log.e("jsonUploadDownloadDB", "-->" + response.statusCode);
                String jsonUploadDownloadDB;
                if (response.statusCode == 200) {
                    jsonUploadDownloadDB = VolleyTickle.parseResponse(response);


                    sendBroadCastDetails(1, "upload DB", randInt(26, 35));

                    Log.e("download ", "link : " + jsonUploadDownloadDB);
                    JSONObject json = new JSONObject(jsonUploadDownloadDB);
                    JSONArray jsonArray = json.optJSONArray("Status");
                    if (jsonArray != null) {
                        int jsonSize = jsonArray.length();
                        for (int jsonIndex = 0; jsonIndex < jsonSize; jsonIndex++) {
                            JSONObject innerObject = jsonArray.getJSONObject(jsonIndex);
                            if (innerObject != null) {
                                String strValidSync = innerObject.optString("isValid");

                                sendBroadCastDetails(1, "upload DB", randInt(36, 40));

                                if (strValidSync.equalsIgnoreCase("True")) {
                                    URLDownloadDB = innerObject.optString("Message");
                                } else {
                                    strSyncMessage = innerObject.optString("Message");
                                }

                                strSyncMessage = afterUpload(strSyncMessage, strFilename, fName, DATABASE_NAME,
                                        dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                            }
                        }
                    } else {
                        //strSyncMessage = "102";
                        String Status = json.getString("Status");
                        String Response = json.getString("Response");

                        if (Status.equalsIgnoreCase("1")) {
                            URLDownloadDB = Response;

                            strSyncMessage = afterUpload(strSyncMessage, strFilename, fName, DATABASE_NAME,
                                    dataDirPath, strVersion, packageName, dbPassword, isDbEncripted);
                        } else {
                            strSyncMessage = "102";
                        }
                    }

                    try {
                        String syncId = json.optString("SyncId");
                        syncID = syncId != null ? Integer.parseInt(syncId) : 0;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    strSyncMessage = "102";
                }
            } else {
                strSyncMessage = "103";
            }
        } catch (Exception e) {

            e.printStackTrace();
            String error = e.getMessage();
            strSyncMessage = "104: " + error;
        }
        return strSyncMessage;
    }

    private String afterUpload(String strUploadMessage, String fZipName, String fName, String databaseName, String dataDirPath, String version, String packageName, String dbPassword, String isDbEncripted) {
        //changePercent(randInt(20, 25));

        //DatabaseExportImport databaseExportImport = new DatabaseExportImport();


        if (strUploadMessage.equalsIgnoreCase("Done")) {

            // data_createJson.put("6_UPLOAD_END", "" + getTimeinSec(new DateTime()));
            sendBroadCastDetails(1, "upload DB", randInt(41, 45));
            // changePercent(randInt(40, 45));

            String DownloadURL = URLDownloadDB;
            //Utils.printLoge1(5, "CALL", "DownloadURL : " + SyncURLDownloadDB);
            if (DownloadURL.trim().length() > 0) {

                // data_createJson.put("7_DOWNLOAD_URL", DownloadURL);

                // changePercent(randInt(45, 50));

                sendBroadCastDetails(1, "upload DB", randInt(46, 50));

                // data_createJson.put("8_DOWNLOAD_START", "" + getTimeinSec(new DateTime()));

                String strDBMessage = DownloadDBFromUrlZip(DownloadURL, fZipName, fName, databaseName, dbPassword);//, context, databaseName

                if (strDBMessage.equals("Done")) {
                    //data_createJson.put("9_DOWNLOAD_END", "" + getTimeinSec(new DateTime()));

                    //changePercent(randInt(82, 90));

                    sendBroadCastDetails(1, "upload DB", randInt(83, 90));

                    try {
                        Thread.sleep(1000);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    //data_createJson.put("10_RESTORE_DB_START", "" + getTimeinSec(new DateTime()));

                    //int restore = databaseExportImport.restoreDownloadedDb(NEW_APP_VERSION_SYNC, dataDirPath, downloadPath, databaseName);
                    int restore = 0;
                    if (!SdIsPresent())
                        restore = 1;

                    File exportFile = new File(dataDirPath);
                    File importFile = new File(ECTERNAL_STORAGE_APP_DOWNLOAD, databaseName);


                    if (!importFile.exists()) {
                        restore = 1;
                    }

                    Log.e("at::", "isDatabaseCorrupted");

                    /*if (checkCurrupDownload) {
                        Log.e("inside::", "isDatabaseCorrupted");
                        if (Utils.isDatabaseCorrupted(importFile.getAbsolutePath()))
                            restore = 5;
                    }*/

                    if (restore == 0) {

                        Log.e("delete::", "delete db from package");
                        //Dhaval Change: 05/06/18
                        try {
                            Thread.sleep(1000);
                            Utils.deleteFiles(exportFile);
                            Thread.sleep(3000);
                        } catch (Exception e) {
                            Log.e("error::", "delete file 1:" + e.getMessage());
                            e.printStackTrace();
                            try {
                                Thread.sleep(1000);
                                Utils.deleteFiles(exportFile);
                                Thread.sleep(3000);
                            } catch (Exception eq) {
                                Log.e("error::", "delete file 2:" + e.getMessage());
                                eq.printStackTrace();
                            }
                        }
                        Log.e("Copy::", "copy db start");
                        try {
                            Thread.sleep(1000);
                            try {
                                //noinspection ResultOfMethodCallIgnored
                                exportFile.createNewFile();
                            } catch (IOException eio) {
                                eio.printStackTrace();
                                //restore = 4;
                            }
                            Thread.sleep(2000);
                            boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                            Thread.sleep(3000);
                            restore = isCopy ? 3 : 2;
                        } catch (Exception e) {
                            Log.e("error::", "copy file 1:" + e.getMessage());
                            e.printStackTrace();
                            //Dhaval change : 05/06/18
                            try {
                                Thread.sleep(2000);
                                boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                                Thread.sleep(3000);
                                restore = isCopy ? 3 : 2;
                            } catch (Exception e1) {
                                Log.e("error::", "copy file 2:" + e.getMessage());
                                e1.printStackTrace();
                                //restore = 1;
                                try {
                                    Thread.sleep(2000);
                                    boolean isCopy = Utils.copyDataBase(importFile, exportFile, version);
                                    Thread.sleep(3000);
                                    restore = isCopy ? 3 : 2;
                                } catch (Exception e2) {
                                    Log.e("error::", "copy file 2:" + e.getMessage());
                                    e2.printStackTrace();
                                    restore = 1;
                                }
                            }
                        }


                        try {
                            Thread.sleep(3000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        Log.e("restore", "restore DB Return:" + restore);
                    }

                    if (restore == 3) {

                        //data_createJson.put("11_RESTORE_DB_END1", "" + getTimeinSec(new DateTime()));

                        //changePercent(randInt(90, 96));
                        //ECP_Scan_SyncSyncCompleteStatus = true;
                        sendBroadCastDetails(1, "upload DB", randInt(91, 96));

                        try {
                            Thread.sleep(1000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //data_createJson.put("12_CHECK_DB_CURRUPT_START", "" + getTimeinSec(new DateTime()));
                        //boolean isCurrupt = Utils.isDatabaseCorruptedNew(ECPSyncronizationService.this, packageName);
                        //File importFile = new File(ECTERNAL_STORAGE_APP_DOWNLOAD, DbExportImport.DATABASE_NAME);

                        try {
                            Thread.sleep(2000);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        /*if (isDbEncripted.equalsIgnoreCase("true")) {
                            try {
                                ExportSqlChiper exportSqlChiper = new ExportSqlChiper();
                                String dataDirPath1 = Environment.getDataDirectory() + "/data/" + packageName + "/app_flutter/" + databaseName;
                                Log.e("dataDirPath ", "plain text:" + dataDirPath1);
                                if (exportSqlChiper.checkDatabaseEnciptedorPlain(registrar.context(), dataDirPath1, "")) {
                                    Thread.sleep(500);
                                    exportSqlChiper.migrateEncriptedDB(registrar.context(), dataDirPath1, dbPassword);
                                }
                                Thread.sleep(2000);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }*/


                        //sendBroadCastDetails(3, "Sync Complate 100%");
                        return "done";

                    } else {
                        if (restore == 2) {
                            //syncStageStatus = "F";
                            //data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 107" + getTimeinSec(new DateTime()));
                            // database currupted
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "107";
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //Utils.printLoge1(5, "CALL", "ERROR : 107");
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 107", lastProgress);
                            return "notdone";
                        } else if (restore == 5) {
                            // syncStageStatus = "F";
                            // data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 223" + getTimeinSec(new DateTime()));

                            // database currupted
                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "225";
                            //ECP_Scan_SyncSyncCompleteStatus = false;
                            //Utils.printLoge1(5, "CALL", "ERROR : 223");
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 223", lastProgress);
                            return "notdone";
                        } else {
                            // syncStageStatus = "F";
                            // data_createJson.put("10_RESTORE_DB_END_FAIL", "ERROR : 106" + getTimeinSec(new DateTime()));

                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            //isFielCopeError = true;
                            //fileCopeException = "106";
                            // ECP_Scan_SyncSyncCompleteStatus = false;
                            sendBroadCastDetails(2, "10_RESTORE_DB_END_FAIL 106", lastProgress);
                            return "notdone";
                        }
                    }
                } else {

                    // syncStageStatus = "F";
                    // data_createJson.put("9_DOWNLOAD_END_FAIL", "ERROR : 106:2 :" + CommonFunctionLib.GetCurrentDate(ENTRY_DATE));

                    //isFielCopeError = true;
                    //fileCopeException = "106: " + Utils.checkErrorReset(strDBMessage);
                    //ECP_Scan_SyncSyncCompleteStatus = false;
                    sendBroadCastDetails(2, "9_DOWNLOAD_END_FAIL", lastProgress);
                    return "notdone";
                }
            } else {

                // syncStageStatus = "F";
                //   data_createJson.put("6_DOWNLOAD_END_FAIL", "ERROR : 106:3 :" + getTimeinSec(new DateTime()));

                //   ECP_Scan_SyncSyncCompleteStatus = false;
                sendBroadCastDetails(2, "6_DOWNLOAD_END_FAIL", lastProgress);
                return "notdone";
            }
        } else {

            // syncStageStatus = "F";
            // data_createJson.put("5_UPLOAD_END_FAIL", "ERROR : 101 : " + getTimeinSec(new DateTime()));

            //isFielCopeError = true;
            //fileCopeException = "101: " + Utils.checkErrorReset(strUploadMessage);
            // ECP_Scan_SyncSyncCompleteStatus = false;
            sendBroadCastDetails(2, "5_UPLOAD_END_FAIL", lastProgress);
            return "notdone";
        }

        //whenAllProgressDone();
    }

    private String DownloadDBFromUrlZip(String DownloadUrl, String ZipfileName, String dbFilename, String databaseName, String zipPassword) {
        String strSyncMessage = "Done";
        try {
            File downloadDB = new File(ECTERNAL_STORAGE_APP_DOWNLOAD);
            if (!downloadDB.exists())
                //noinspection ResultOfMethodCallIgnored
                downloadDB.mkdirs();

            // changePercent(randInt(50, 60));
            sendBroadCastDetails(1, "upload DB", randInt(51, 60));
            File file = new File(ECTERNAL_STORAGE_APP_DOWNLOAD, ZipfileName);

            //final int BUFFER_SIZE = 32 * 1024;
            final int BUFFER_SIZE = 3 * 1024;
            URL url = new URL(DownloadUrl);

            URLConnection uCon = url.openConnection();
            //uCon.setConnectTimeout(120000);
            uCon.setConnectTimeout(2700000);
            InputStream downloadInputStream = uCon.getInputStream();
            //int fileLength = ucon.getContentLength();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(downloadInputStream, BUFFER_SIZE);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] byteBuffer = new byte[BUFFER_SIZE];
            int current = 0;

            //changePercent(randInt(65, 70));
            sendBroadCastDetails(1, "upload DB", randInt(61, 70));

            while (current != -1) {
                fileOutputStream.write(byteBuffer, 0, current);
                current = bufferedInputStream.read(byteBuffer, 0, BUFFER_SIZE);
            }


            fileOutputStream.flush();
            fileOutputStream.close();
            downloadInputStream.close();


            //changePercent(randInt(71, 73));

            sendBroadCastDetails(1, "upload DB", randInt(71, 75));

        } catch (Exception e) {
            e.printStackTrace();
            String error = e.getMessage();
            error = Utils.checkErrorReset(error);
            strSyncMessage = "104: " + error;
        }

        //changePercent(randInt(74, 77));

        if (strSyncMessage.equals("Done")) {
            strSyncMessage = ExtractDownlodedFile(ZipfileName, dbFilename, strSyncMessage, databaseName, zipPassword);
        }
        return strSyncMessage;
    }

    private String ExtractDownlodedFile(String ZipfileName, String dbFilename, String strSyncMessage, String databaseName, String zipPassword) {

        String zipFile = ECTERNAL_STORAGE_APP_DOWNLOAD + "/" + ZipfileName;

        //String size = checkFileZiseString(zipFile);
        //data_createJson.put("9_DOWNLOAD_FILE_SIZE", "" + size);

        //DatabaseExportImport databaseExportImport = new DatabaseExportImport();

        if (!Utils.ExtractSingleFile(zipFile, "" + ECTERNAL_STORAGE_APP_DOWNLOAD + "/", dbFilename, zipPassword)
                .equalsIgnoreCase("Done")) {
            strSyncMessage = "105:";
        } else {
            try {

                sendBroadCastDetails(1, "upload DB", randInt(76, 82));
                //changePercent(randInt(78, 82));

                File f = new File("" + ECTERNAL_STORAGE_APP_DOWNLOAD + "/" + dbFilename);
                File f1 = new File("" + ECTERNAL_STORAGE_APP_DOWNLOAD + "/" + databaseName);
                if (f.exists()) {
                    if (f1.exists()) {
                        //noinspection ResultOfMethodCallIgnored
                        f1.delete();
                    }
                    //noinspection ResultOfMethodCallIgnored
                    f.renameTo(f1);
                }
            } catch (Exception e) {
                String error = e.getMessage();
                error = Utils.checkErrorReset(error);
                strSyncMessage = "104: " + error;
            }
        }

        return strSyncMessage;
    }

    private int lastProgress = 0;

    private int randInt(int min, int max) {

        // NOTE: This will (intentionally) not run as written so that folks
        // copy-pasting have to think about how to initialize their
        // Random instance.  Initialization of the Random instance is outside
        // the main scope of the question, but some decent options are to have
        // a field that is initialized once and then re-used as needed or to
        // use ThreadLocalRandom (if using at least Java 1.7).
        //
        // In particular, do NOT do 'Random rand = new Random()' here or you
        // will get not very good / not very random results.
        Random rand = new Random();
        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        lastProgress = rand.nextInt((max - min) + 1) + min;
        return lastProgress;
    }

    private void sendBroadCastDetails(int type, String details, int progress) {
        callBack.onFileSyncResponse(type,details,progress);
    }

    private void startIntentService(String status) {
        Intent vcsTimeIntent = new Intent(context, AppIdentifyService.class);
        vcsTimeIntent.putExtra("SyncId", syncID);
        vcsTimeIntent.putExtra("DeviceSyncStatus", status);
        vcsTimeIntent.putExtra("DeviceSyncJson", "");
        vcsTimeIntent.putExtra("PersonId", fk_EmpGlCode);
        vcsTimeIntent.putExtra("SubModuleName", ClientName);
        vcsTimeIntent.putExtra("DeviceId", imei);
        vcsTimeIntent.putExtra("Version", version);
        vcsTimeIntent.putExtra("APIToken", UserName);
        vcsTimeIntent.putExtra("BaseUrl", urlUpload);
        vcsTimeIntent.putExtra("logUploadMethod", logUploadMethod);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(vcsTimeIntent);
        } else {
            context.startService(vcsTimeIntent);
        }
    }
}
