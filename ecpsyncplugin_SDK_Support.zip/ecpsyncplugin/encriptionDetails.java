package ecp.vcs.com.ecpsyncplugin;

import android.content.Context;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


class encriptionDetails {

    public static String Decrypt(String text, String key) throws Exception {
        Cipher cipher = Cipher.getInstance
                ("AES/CBC/PKCS5Padding"); //this parameters should not be changed
        byte[] keyBytes = new byte[16];
        byte[] b = key.getBytes("UTF-8");
        int len = b.length;
        if (len > keyBytes.length)
            len = keyBytes.length;
        System.arraycopy(b, 0, keyBytes, 0, len);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
        byte[] results = new byte[text.length()];
        //BASE64Decoder decoder = new BASE64Decoder();
        try {
            results = cipher.doFinal(decodeString(text));
        } catch (Exception e) {
            System.out.println("Error in Decryption : " + e.toString());
        }
        System.out.println("Data : " + new String(results, "UTF-8"));
        return new String(results, "UTF-8"); // it returns the result as a String
    }

    // Encription Methods
    public static String Encrypt(String text, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        byte[] keyBytes = new byte[16];
        byte[] b = key.getBytes("UTF-8");
        int len = b.length;
        if (len > keyBytes.length)
            len = keyBytes.length;
        System.arraycopy(b, 0, keyBytes, 0, len);
        SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(keyBytes);
        cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);

        byte[] results = cipher.doFinal(text.getBytes("UTF-8"));
        //BASE64Encoder encoder = new BASE64Encoder();
        return encodeString(results); // it returns the result as a String
    }

    private static String encodeString(byte[] results) {
        return Base64.encodeToString(results, Base64.DEFAULT).trim();
    }

    private static byte[] decodeString(String results) {
        byte[] data = null;
        try {
            data = Base64.decode(results.getBytes("UTF-8"), Base64.DEFAULT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    //private static String Key = "your key";

    /*public static String encryptString(String stringToEncode, String Key, String iv1) throws NullPointerException {

        try {
            SecretKeySpec skeySpec = getKey(Key);
            byte[] clearText = stringToEncode.getBytes("UTF8");
            //final byte[] iv = new byte[16];
            final byte[] iv = iv1.getBytes();
            Arrays.fill(iv, (byte) 0x00);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivParameterSpec);
            return Base64.encodeToString(cipher.doFinal(clearText), Base64.DEFAULT);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }

    public static String decryptString(String stringToEncode, String Key, String iv1) throws NullPointerException {

        try {
            SecretKeySpec skeySpec = getKey(Key);
            byte[] clearText = stringToEncode.getBytes("UTF8");
            final byte[] iv = iv1.getBytes();
            Arrays.fill(iv, (byte) 0x00);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivParameterSpec);
            byte[] cipherData = cipher.doFinal(Base64.decode(clearText, Base64.DEFAULT));
            return new String(cipherData, "UTF-8");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }


    private static SecretKeySpec getKey(String password) throws UnsupportedEncodingException {
        int keyLength = 256;
        byte[] keyBytes = new byte[keyLength / 8];
        Arrays.fill(keyBytes, (byte) 0x0);
        byte[] passwordBytes = password.getBytes("UTF-8");
        int length = passwordBytes.length < keyBytes.length ? passwordBytes.length : keyBytes.length;
        System.arraycopy(passwordBytes, 0, keyBytes, 0, length);
        SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
        return key;
    }*/

    public static String getUniqueNumber(Context context) {
        String android_id = getUniqueID(context);
        String randomNumber = getRandomNumber();
        Log.e("LENGTH", android_id.length() + " : " + String.valueOf(System.currentTimeMillis()).length() + " : " + randomNumber.length());
        return android_id + System.currentTimeMillis() + getRandomNumber();
    }

    private static String getUniqueID(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    private static String getRandomNumber() {
        long number = (long) Math.floor(Math.random() * 6_000_000L) + 1_000_000L;
        return String.valueOf(number);
    }
}
