package ecp.vcs.com.ecpsyncplugin;


public class ExportSqlChiper {

    /*public boolean checkDatabaseEnciptedorPlain(Context context, String datbasePath, String Password) {
        File legacyFile = new File(datbasePath);
        if (legacyFile.exists()) {
            try {
                SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(legacyFile, Password, null);
                db.close();
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        } else {
            return false;
        }
    }*/

    /*public void migratePlainTextDB(Context context, String datbasePath, String Password) {
        //File dbFile = ctxt.getDatabasePath(".encryptedDb");
        //FeedReaderDbHelper.getInstance(this);

        try {
            File newFile = File.createTempFile("sqlcipherutils", "tmp", context.getCacheDir());
            File legacyFile = new File(datbasePath);
            if (legacyFile.exists()) {
                SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(legacyFile, Password, null);

                db.rawExecSQL(String.format("ATTACH DATABASE '%s' AS plaintext KEY '%s';", newFile.getAbsolutePath(), ""));
                db.rawExecSQL("SELECT sqlcipher_export('plaintext')");
                db.rawExecSQL("DETACH DATABASE plaintext;");
                int version = db.getVersion();
                db.close();
                db = SQLiteDatabase.openDatabase(newFile.getAbsolutePath(), "", null, SQLiteDatabase.OPEN_READWRITE);
                db.setVersion(version);
                db.close();
                legacyFile.delete();
                newFile.renameTo(legacyFile);

                Thread.sleep(1000);

                *//*if (!newFile.exists() && legacyFile.exists()) {
                    //db = SQLiteDatabase.openDatabase(legacyFile.getAbsolutePath(), "", null, SQLiteDatabase.OPEN_READWRITE);
                   Cursor cursor = db.rawQuery("SELECT * FROM '" + FeedReaderContract.FeedEntry.TABLE_NAME + "';", null);
                    Log.e(MainActivity.class.getSimpleName(), "Rows count: " + cursor.getCount());
                    cursor.close();
                    db.close();
                }*//*

                Log.e("DONE", "migration complate");
            } else {
                Log.e("DONE", "migration file not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/

    /*public void migrateEncriptedDB(Context context, String datbasePath, String Password) {
        //File dbFile = ctxt.getDatabasePath(".encryptedDb");
        //FeedReaderDbHelper.getInstance(this);

        try {
            File newFile = File.createTempFile("sqlcipherutils.db", "", context.getCacheDir());
            File legacyFile = new File(datbasePath);
            if (legacyFile.exists()) {
                SQLiteDatabase db = SQLiteDatabase.openOrCreateDatabase(legacyFile, "", null);

                db.rawExecSQL(String.format("ATTACH DATABASE '%s' AS encrypted KEY '%s';", newFile.getAbsolutePath(), Password));
                db.rawExecSQL("SELECT sqlcipher_export('encrypted')");
                db.rawExecSQL("DETACH DATABASE encrypted;");
                int version = db.getVersion();
                db.close();
                db = SQLiteDatabase.openDatabase(newFile.getAbsolutePath(), Password, null, SQLiteDatabase.OPEN_READWRITE);
                db.setVersion(version);
                db.close();

                legacyFile.delete();
                newFile.renameTo(legacyFile);

                Thread.sleep(1000);

                *//*if (!newFile.exists() && legacyFile.exists()) {
                    db = SQLiteDatabase.openDatabase(legacyFile.getAbsolutePath(), details, null, SQLiteDatabase.OPEN_READWRITE);
                    Cursor cursor = db.rawQuery("SELECT * FROM '" + FeedReaderContract.FeedEntry.TABLE_NAME + "';", null);
                    Log.e(MainActivity.class.getSimpleName(), "Rows count: " + cursor.getCount());
                    cursor.close();
                    db.close();
                }*//*

                Log.e("DONE", "migration complate");
            } else {
                Log.e("DONE", "migration file not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }*/
}
